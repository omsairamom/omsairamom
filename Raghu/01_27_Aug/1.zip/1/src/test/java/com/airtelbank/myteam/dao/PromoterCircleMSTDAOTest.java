package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterCircleMSTEntity;
import com.airtelbank.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.myteam.repository.PromoterCircleMSTRepository;
import com.airtelbank.myteam.repository.PromoterUserProfileMSTRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterCircleMSTDAOTest
{
    @InjectMocks
    PromoterCircleMSTDAO promoterCircleMSTDAO;

    @Mock
    PromoterCircleMSTRepository promoterCircleMSTRepository;

    @Test
    void fetchCircleByCircleId()
    {
        Optional<PromoterCircleMSTEntity> item = Optional.of(new PromoterCircleMSTEntity());
        Mockito.when(promoterCircleMSTRepository.findOneByCircleId(Mockito.anyString())).thenReturn(item);
        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity =
                promoterCircleMSTDAO.fetchCircleByCircleId("9839057135");
        assertNotNull(promoterCircleMSTEntity);
    }
}