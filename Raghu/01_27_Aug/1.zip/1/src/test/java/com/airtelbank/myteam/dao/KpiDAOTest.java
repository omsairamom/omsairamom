package com.airtelbank.myteam.dao;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterUserMSTRepository;
import com.airtelbank.util.PropertyManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class KpiDAOTest
{
    @Autowired
    KpiDAO kpiDAO;

    @MockBean
    JdbcTemplate jdbcTemplate;

    @BeforeEach
    private void setUp()
    {
        MockitoAnnotations.initMocks(this);
    }

    @Autowired
    PropertyManager prop;

    @Autowired
    private PromoterUserMSTRepository promoterUserMSTRepository;

//    @Test
//    public void fetchKPIDetails_Success() throws Exception
//    {
//        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
//        snapWorkRequest.setMobileNo("9876543220");
////        snapWorkRequest.setCatId("2");
////        snapWorkRequest.setCategoryName("Promoter");
//
////        Map<String, Object> row = new HashMap<>();
////        row.put("PROMOTER_KPI_ID", "Test");
////        row.put("LAPU_NO", "Test");
////        row.put("CAT_NAME", "Promoter");
////        row.put("CAT_ID", "2");
////        row.put("PROMOTER_TYPE", "Combined");
////        row.put("KPI_ID", "2");
////        row.put("KPI_TYPE", "PROMO");
////        row.put("LMTD", "Test");
////        row.put("MTD", "Test");
////        row.put("ACHIEVED_PERCENTAGE", "Test");
////        row.put("TARGET", "Target");
////
////        List<Map<String, Object>> rows  = new ArrayList<>();
////        rows.add(row);
////
////        String query = prop.getProperty("PROMOTER_KPI_MST_V2_FETCH_CATID_PROMOTERTYPE");
////
////        String query_1 = prop.getProperty("PROMOTER_KPI_MST_V2_FETCH_CATNAME_PAPPCATEGORYMST");
////
////        String query_2 = prop.getProperty("PROMOTER_KPI_MST_V2_FETCH_ALLKPIS_PAPPCATEGORYMST_2");
////
////        String query_3 = prop.getProperty("PROMOTER_KPI_MST_V2_FETCH_TARGETS_PAPPCATEGORYMST");
////
////        String query_4 = prop.getProperty("PROMOTER_KPI_MST_V2_FETCH_LAPUNO_PROMOTERKPIMST");
////
////        Mockito.when(jdbcTemplate.queryForList(query, new Object[] { snapWorkRequest.getMobileNo() })).thenReturn(rows);
////
////        Mockito.when(jdbcTemplate.queryForList(query_1, new Object[] { snapWorkRequest.getCatId() })).thenReturn(rows);
////
////        Mockito.when(jdbcTemplate.queryForList(query_2, new Object[] { snapWorkRequest.getCatId(), "Combined" })).thenReturn(rows);
////
////        Mockito.when(jdbcTemplate.queryForList(query_3, new Object[] { "2"})).thenReturn(rows);
////
////        Mockito.when(jdbcTemplate.queryForList(query_4, new Object[] { snapWorkRequest.getMobileNo(), snapWorkRequest.getCategoryName(), "PROMO" })).thenReturn(rows);
//
//        PromoterUserMSTEntity promoterUserMSTEntity = new PromoterUserMSTEntity();
//        promoterUserMSTEntity.setCategory("MER");
//        List<PromoterUserMSTEntity> promoterUserMSTEntities = new ArrayList<>();
//        promoterUserMSTEntities.add(promoterUserMSTEntity);
//        Mockito.when(promoterUserMSTRepository.findAllByUserNo(Mockito.anyString())).thenReturn(promoterUserMSTEntities);
//        SnapWorkResponse snapWorkResponse = kpiDAO.fetchKPIDetailsV2(snapWorkRequest.getMobileNo());
//        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("ADMIN_FETCH_KPI_DETAIL_SUCCESS"));
//
//    }

    @Test
    public void fetchKPIDetails_Fail() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("121212");

//        Map<String, Object> row = new HashMap<>();
//        row.put("PROMOTER_KPI_ID", "Test");
//        row.put("LAPU_NO", "Test");
//        row.put("CAT_NAME", "Test");
//        row.put("CAT_ID", "2");
//        row.put("PROMOTER_TYPE", "Combined");
//
//        List<Map<String, Object>> rows  = new ArrayList<>();
//        rows.add(row);
//
//        String query = prop.getProperty("PROMOTER_KPI_MST_V2_FETCH_CATID_PROMOTERTYPE");
//
//        Mockito.when(jdbcTemplate.queryForList(query, new Object[] { snapWorkRequest.getMobileNo() })).thenReturn(null);

        SnapWorkResponse snapWorkResponse = kpiDAO.fetchKPIDetailsV2(snapWorkRequest.getMobileNo());
        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("ADMIN_FETCH_KPI_DETAIL_FAIL"));

    }
}
