package com.airtelbank.myteam.service.impl;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.dao.UploadDocumentsDAO;
import com.airtelbank.myteam.service.CaptureComplianceService;
import com.airtelbank.util.PropertyManager;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileInputStream;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class CaptureComplianceServiceImplTest
{
	@Autowired
	PropertyManager prop;

	@Autowired
	CaptureComplianceService captureComplianceService;

	@Autowired
	SnapWorkRequest request;

	@Autowired
	private UploadDocumentsDAO uploadDocumentsDAO;

	@BeforeEach
	private void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void captureComplianceDetails_success() throws Exception
	{
		File file = new File("src/test/resources/vpnimage.jpg");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));
		String mobileNo = "9876543220";
		String action = "add";
		String encStatus = "N";

		SnapWorkResponse response = captureComplianceService.captureComplianceDetails(multipartFile, mobileNo, action);

		assertNotNull(response);
	}

	@Test
	public void captureComplianceDetails_1_success() throws Exception
	{
		File file = new File("src/test/resources/vpnimage.jpg");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));
		String mobileNo = "9876543220";
		String action = "add";
		String encStatus = "N";

		SnapWorkResponse response = captureComplianceService.captureComplianceDetails(multipartFile, mobileNo, action);

		assertNotNull(response);
	}


	@Test
	void captureComplianceDetails_isdelete_success() throws Exception
	{
		File file = new File("src/test/resources/vpnimage.jpg");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));
		String mobileNo = "7607842101";
		String action = "delete";
		String encStatus = "Y";

		SnapWorkResponse response = captureComplianceService.captureComplianceDetails(multipartFile, mobileNo, action);

		assertNotNull(response);
	}

	@Test
	void captureComplianceDetails_isdelete_fail() throws Exception
	{
		File file = new File("src/test/resources/Promoter_KPI_MST.csv");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));
		String mobileNo = "7607842101";
		String action = "delete";
		String encStatus = "N";

		SnapWorkResponse response = captureComplianceService.captureComplianceDetails(multipartFile, mobileNo, action
				);

		assertEquals(prop.getProperty("COMPLIANCE_CAPTURE_DEL_FILE_NOT_EXIST_MSG"), response.getMessage());
	}

	@Test
	void captureComplianceDetails_mobileNoBlank_fail() throws Exception
	{
		File file = new File("src/test/resources/Promoter_KPI_MST.csv");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));
		String mobileNo = "abcddd";
		String action = "delete";
		String encStatus = "N";

		SnapWorkResponse response = captureComplianceService.captureComplianceDetails(multipartFile, mobileNo, action
		);

		assertNotNull(response);
	}

	@Test
	void captureComplianceDetails_throwException() throws Exception
	{
		SnapWorkResponse response = captureComplianceService.captureComplianceDetails(null, null, null);
		assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
	}
}