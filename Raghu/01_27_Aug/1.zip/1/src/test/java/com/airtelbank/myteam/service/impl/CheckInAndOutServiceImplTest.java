package com.airtelbank.myteam.service.impl;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterCircleMSTEntity;
import com.airtelbank.entity.PromoterOutletMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.jwt.AeroCache;
import com.airtelbank.myteam.dao.*;
import com.airtelbank.myteam.repository.PromoterCheckInDetailsAuditRepository;
import com.airtelbank.myteam.repository.PromoterOutletMSTRepository;
import com.airtelbank.myteam.service.CheckInAndOutService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import java.time.LocalDateTime;
import java.util.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@SpringBootTest
class CheckInAndOutServiceImplTest
{
    @Autowired
    CheckInAndOutService checkInAndOutService;

    @MockBean
    PromoterUserMSTDAO promoterUserMSTDAO;

    @MockBean
    PromoterOutletMSTDAO promoterOutletMSTDAO;

    @MockBean
    PromoterCircleMSTDAO promoterCircleMSTDAO;

    @MockBean
    AeroCache aeroCache;

    @Mock
    CheckInAndOutDAO dashboardDao;

    @MockBean
    PromoterCheckInDetailsAuditRepository promoterCheckInDetailsAuditRepository;

    @MockBean
    PromoterOutletMSTRepository promoterOutletMSTRepository;

    @MockBean
    PromoterCheckInDetailsAuditDAO promoterCheckInDetailsAuditDAO;

    @Autowired
    PropertyManager prop;

    @Autowired
    SnapWorkRequest request;

    @MockBean
    CommonUtils commonUtils;

    private String promoterNo = "9839057135";

    private String outletNo = "9839057135";

    private String latitude = "26.777781";

    private String longitude = "80.924892";

    @Test
    public void checkInDetailsV2_Success() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("9839057135");
        request.setLatitude("26.7777819");
        request.setLongitude("80.9248925");

        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity = Optional.of(new PromoterCircleMSTEntity());
        promoterCircleMSTEntity.get().setCircleId("1");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());

        Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity =
                Optional.of(new PromoterOutletMSTEntity());
        promoterOutletMSTEntity.get().setOutletNo("9161493626");
        promoterOutletMSTEntity.get().setOutletName("Om");
        promoterOutletMSTEntity.get().setPromoterNo("9839057135");
        promoterOutletMSTEntity.get().setPromoterUserMSTEntity(promoterUserMSTEntity.get());

        Mockito.when(promoterOutletMSTRepository.findByPromoterNoANDOutletNo(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Optional.of(promoterOutletMSTEntity.get()));

        Mockito.when(promoterUserMSTDAO.fetchUserByIDWithStatus(1L))
                .thenReturn(Optional.of(promoterUserMSTEntity.get()));

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("shopLatitude", "26.7777819");
        map.put("shopLongitude", "80.9248925");

        Mockito.when(aeroCache.getOutletDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(map);

//        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity = Optional.of(new PromoterCircleMSTEntity());
//        promoterCircleMSTEntity.get().setCircleId("1");

//        Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity = Optional.of(new PromoterOutletMSTEntity());
        //promoterOutletMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());

        Mockito.when(promoterOutletMSTDAO.fetchOutletByOutletNo(Mockito.anyString())).thenReturn(promoterOutletMSTEntity);

        Mockito.when(promoterCircleMSTDAO.fetchCircleByCircleId(Mockito.anyString())).thenReturn(promoterCircleMSTEntity);

        PromoterCheckInDetailsAuditEntity promoterCheckInDetailsAuditEntity = new PromoterCheckInDetailsAuditEntity();
        promoterCheckInDetailsAuditEntity.setId(1L);
        promoterCheckInDetailsAuditEntity.setCheckInType("1");
        promoterCheckInDetailsAuditEntity.setStatus("Pending");
        promoterCheckInDetailsAuditEntity.setPromoterUserMSTEntity(promoterUserMSTEntity.get());
        promoterCheckInDetailsAuditEntity.setPromoterOutletMSTEntity(promoterOutletMSTEntity.get());
        promoterCheckInDetailsAuditEntity.setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());
        promoterCheckInDetailsAuditEntity.setOutletLatitude(promoterOutletMSTEntity.get().getLatitude());
        promoterCheckInDetailsAuditEntity.setOutletLongitude(promoterOutletMSTEntity.get().getLongitude());
        promoterCheckInDetailsAuditEntity.setPromoterLatitude(request.getLatitude());
        promoterCheckInDetailsAuditEntity.setPromoterLongitude(request.getLongitude());
       // promoterCheckInDetailsAuditEntity.setMarryDistance(marryDist);

        PromoterCheckInDetailsAuditEntity prom = new PromoterCheckInDetailsAuditEntity();
        prom.setStatus("Success");
        prom.setId(1L);
        prom.setCheckInType("1");
        prom.setStatus("Success");
        prom.setPromoterUserMSTEntity(promoterUserMSTEntity.get());
        prom.setPromoterOutletMSTEntity(promoterOutletMSTEntity.get());
        prom.setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());
        prom.setOutletLatitude(promoterOutletMSTEntity.get().getLatitude());
        prom.setOutletLongitude(promoterOutletMSTEntity.get().getLongitude());
        prom.setPromoterLatitude(request.getLatitude());
        prom.setPromoterLongitude(request.getLongitude());
        // promoterCheckInDetailsAuditEntity.setMarryDistance(marryDist);

     //   Mockito.when(promoterCheckInDetailsAuditRepository.saveAndFlush(Mockito.any())).thenReturn(prom);
        Mockito.when(promoterCheckInDetailsAuditDAO.saveAndFlushCheckInDetails(Mockito.any())).thenReturn(prom);

        Mockito.when(commonUtils.calculateMarryDistance(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("200");

        Mockito.when(promoterCheckInDetailsAuditRepository.save(Mockito.any())).thenReturn(prom);

        Mockito.when(promoterOutletMSTRepository.save(Mockito.any())).thenReturn(null);

        SnapWorkResponse response = checkInAndOutService.checkInDetailsV2(promoterNo, outletNo , latitude, longitude);

       // assertEquals(response.getStatusCode(), "200");
        assertNotNull(response);
    }

    @Test
    public void checkInDetails_Request_Empty_V2_Fail() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("");
        request.setLatitude("");
        request.setLongitude("");

        SnapWorkResponse response = checkInAndOutService.checkInDetailsV2(promoterNo, outletNo , latitude, longitude);

        assertEquals(response.getStatusCode(), prop.getProperty(Constants.FAILURE_STATUS_CODE));
    }

    @Test
    public void checkInDetails_Fetch_User_MST_V2_Fail() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("9839057135");
        request.setLatitude("26.7777819");
        request.setLongitude("80.9248925");

        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity = Optional.of(new PromoterCircleMSTEntity());
        promoterCircleMSTEntity.get().setCircleId("1");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());

        Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity =
                Optional.of(new PromoterOutletMSTEntity());
        promoterOutletMSTEntity.get().setOutletNo("9161493626");
        promoterOutletMSTEntity.get().setOutletName("Om");
        promoterOutletMSTEntity.get().setPromoterNo("9839057135");
        promoterOutletMSTEntity.get().setPromoterUserMSTEntity(promoterUserMSTEntity.get());

        Mockito.when(promoterOutletMSTRepository.findByPromoterNoANDOutletNo(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Optional.of(promoterOutletMSTEntity.get()));

        Mockito.when(promoterUserMSTDAO.fetchUserByIDWithStatus(1L))
                .thenReturn(Optional.empty());

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135"))
                .thenReturn(Optional.empty());

        SnapWorkResponse response = checkInAndOutService.checkInDetailsV2(promoterNo, outletNo, latitude, longitude);

        assertEquals(response.getStatusCode(), prop.getProperty(Constants.FAILURE_STATUS_CODE));
    }

    @Test
    public void checkInDetails_Fetch_User_MST_V2_Error() throws Exception
    {
        SnapWorkResponse response = checkInAndOutService.checkInDetailsV2(null, null, null, null);

        assertEquals(response.getStatusCode(), prop.getProperty(Constants.FAILURE_STATUS_CODE));
    }

    @Test
    public void checkOutDetailsV2_Success() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("9839057135");
        request.setLatitude("26.7777819");
        request.setLongitude("80.9248925");

        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity = Optional.of(new PromoterCircleMSTEntity());
        promoterCircleMSTEntity.get().setCircleId("1");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());

        Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity =
                Optional.of(new PromoterOutletMSTEntity());
        promoterOutletMSTEntity.get().setOutletNo("9161493626");
        promoterOutletMSTEntity.get().setOutletName("Om");
        promoterOutletMSTEntity.get().setPromoterNo("9839057135");
        promoterOutletMSTEntity.get().setPromoterUserMSTEntity(promoterUserMSTEntity.get());

        Mockito.when(promoterOutletMSTRepository.findByPromoterNoANDOutletNo(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Optional.of(promoterOutletMSTEntity.get()));

        Mockito.when(promoterUserMSTDAO.fetchUserByIDWithStatus(1L))
                .thenReturn(Optional.of(promoterUserMSTEntity.get()));

        Mockito.when(promoterOutletMSTDAO.fetchOutletByOutletNo(Mockito.anyString())).thenReturn(promoterOutletMSTEntity);

        Mockito.when(promoterCircleMSTDAO.fetchCircleByCircleId(Mockito.anyString())).thenReturn(promoterCircleMSTEntity);

        PromoterCheckInDetailsAuditEntity promoterCheckInDetailsAuditEntity = new PromoterCheckInDetailsAuditEntity();
        promoterCheckInDetailsAuditEntity.setId(1L);
        promoterCheckInDetailsAuditEntity.setCheckInType("0");
        promoterCheckInDetailsAuditEntity.setStatus("Pending");
        promoterCheckInDetailsAuditEntity.setPromoterUserMSTEntity(promoterUserMSTEntity.get());
        promoterCheckInDetailsAuditEntity.setPromoterOutletMSTEntity(promoterOutletMSTEntity.get());
        promoterCheckInDetailsAuditEntity.setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());
        promoterCheckInDetailsAuditEntity.setOutletLatitude(promoterOutletMSTEntity.get().getLatitude());
        promoterCheckInDetailsAuditEntity.setOutletLongitude(promoterOutletMSTEntity.get().getLongitude());
        promoterCheckInDetailsAuditEntity.setPromoterLatitude(request.getLatitude());
        promoterCheckInDetailsAuditEntity.setPromoterLongitude(request.getLongitude());
        promoterCheckInDetailsAuditEntity.setCreatedDate(LocalDateTime.now());
        promoterCheckInDetailsAuditEntity.setUpdatedDate(LocalDateTime.now());

        PromoterCheckInDetailsAuditEntity prom = new PromoterCheckInDetailsAuditEntity();
        prom.setStatus("Success");
        prom.setId(1L);
        prom.setUpdatedDate(LocalDateTime.now());
        prom.setCheckInType("1");
        prom.setStatus("Success");
        prom.setPromoterUserMSTEntity(promoterUserMSTEntity.get());
        prom.setPromoterOutletMSTEntity(promoterOutletMSTEntity.get());
        prom.setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());
        prom.setOutletLatitude(promoterOutletMSTEntity.get().getLatitude());
        prom.setOutletLongitude(promoterOutletMSTEntity.get().getLongitude());
        prom.setPromoterLatitude(request.getLatitude());
        prom.setPromoterLongitude(request.getLongitude());
        prom.setCreatedDate(LocalDateTime.now());
        prom.setUpdatedDate(LocalDateTime.now());

        Mockito.when(promoterCheckInDetailsAuditDAO.saveAndFlushCheckInDetails(Mockito.any())).thenReturn(prom);

        Mockito.when(commonUtils.calculateMarryDistance(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("200");

        Mockito.when(promoterCheckInDetailsAuditRepository.save(Mockito.any())).thenReturn(prom);

        SnapWorkResponse response = checkInAndOutService.checkOutDetailsV2(promoterNo , outletNo, latitude, longitude, "Hi");

        assertNotNull(response);
    }

    @Test
    public void checkOutDetails_FETCH_USER_MST_V2_Fail_1() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setLatitude("26.7777819");
        request.setLongitude("80.9248925");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus("9839057135"))
                .thenReturn(Optional.empty());

        SnapWorkResponse response = checkInAndOutService.checkOutDetailsV2("", "", "", "", "Hi");

        assertEquals(response.getStatusCode(), prop.getProperty(Constants.FAILURE_STATUS_CODE));
    }

    @Test
    public void checkOutDetails_FETCH_USER_MST_V2_Fail() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("9839057135");
        request.setLatitude("26.7777819");
        request.setLongitude("80.9248925");

        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity = Optional.of(new PromoterCircleMSTEntity());
        promoterCircleMSTEntity.get().setCircleId("1");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());

        Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity =
                Optional.of(new PromoterOutletMSTEntity());
        promoterOutletMSTEntity.get().setOutletNo("9161493626");
        promoterOutletMSTEntity.get().setOutletName("Om");
        promoterOutletMSTEntity.get().setPromoterNo("9839057135");
        promoterOutletMSTEntity.get().setPromoterUserMSTEntity(promoterUserMSTEntity.get());

        Mockito.when(promoterOutletMSTRepository.findByPromoterNoANDOutletNo(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Optional.of(promoterOutletMSTEntity.get()));

        Mockito.when(promoterUserMSTDAO.fetchUserByIDWithStatus(1L))
                .thenReturn(Optional.empty());

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus("9839057135"))
                .thenReturn(Optional.empty());

        SnapWorkResponse response = checkInAndOutService.checkOutDetailsV2(promoterNo, outletNo, latitude, longitude, "Hi");

        assertEquals(response.getStatusCode(), prop.getProperty(Constants.FAILURE_STATUS_CODE));
    }

    @Test
    public void checkOutDetails_Request_Empty_V2_Fail() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setLatitude("");
        request.setLongitude("");

        SnapWorkResponse response = checkInAndOutService.checkOutDetailsV2(promoterNo, outletNo, latitude, longitude, "Hi");

        assertEquals(response.getStatusCode(), prop.getProperty(Constants.FAILURE_STATUS_CODE));
    }

    @Test
    public void checkInOutStatusSuccessTest() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("9839057135");
        request.setLatitude("26.7777819");
        request.setLongitude("80.9248925");

        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity = Optional.of(new PromoterCircleMSTEntity());
        promoterCircleMSTEntity.get().setCircleId("1");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());

        Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity =
                Optional.of(new PromoterOutletMSTEntity());
        promoterOutletMSTEntity.get().setOutletNo("9161493626");
        promoterOutletMSTEntity.get().setOutletName("Om");
        promoterOutletMSTEntity.get().setPromoterNo("9839057135");
        promoterOutletMSTEntity.get().setPromoterUserMSTEntity(promoterUserMSTEntity.get());

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus("9839057135"))
                .thenReturn(Optional.of(promoterUserMSTEntity.get()));

        Mockito.when(promoterOutletMSTRepository.findByPromoterNoANDOutletNo(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Optional.of(promoterOutletMSTEntity.get()));

        Mockito.when(promoterUserMSTDAO.fetchUserByIDWithStatus(1L))
                .thenReturn(Optional.of(promoterUserMSTEntity.get()));




        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("res", "9839057135");
        map.put("dateOfVisit", "DATE_OF_VISIT");
        map.put("inOrOut", "in_or_out");
        map.put("PROMTR_MOBNO", "PROMTR_MOBNO");
        map.put("Mobile_No", "lapu_no");
        map.put("retailerName", "STORE_NAME");
        map.put("Type", "type");
        map.put("longitude", "LONGITUDE");
        map.put("latitude", "LATITUDE");
        list.add(map);

        when(dashboardDao.getCheckInCheckOutDetails(Mockito.anyString())).thenReturn(list);

       // when(dashboardDao.getRetailerAddress(Mockito.any())).thenReturn(retailerAddress);

        SnapWorkResponse response = checkInAndOutService.checkInOutStatus(promoterNo);

        assertNotNull(response);
    }

    @Test
    public void checkInOutStatusFailTest() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("9999755652");

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

        when(dashboardDao.getCheckInCheckOutDetails(Mockito.anyString())).thenReturn(list);

        SnapWorkResponse response = checkInAndOutService.checkInOutStatus(promoterNo);

        assertNotNull(response);
    }

    @Test
    public void checkInOutStatusFailTest_1() throws Exception
    {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setProMobileNo("9999755652");

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

        when(dashboardDao.getCheckInCheckOutDetails(Mockito.anyString())).thenReturn(list);

        SnapWorkResponse response = checkInAndOutService.checkInOutStatus("");

        assertNotNull(response);
    }

    @Test
    public void when_CheckInCheckOut_Then_ThrowExceptionTest() throws Exception
    {
        SnapWorkResponse response = checkInAndOutService.checkInOutStatus(null);
        assertNotNull(response);
    }
}