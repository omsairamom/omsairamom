package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterUserMSTRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterUserMSTDAOTest
{
    @InjectMocks
    PromoterUserMSTDAO promoterUserMSTDAO;

    @Mock
    PromoterUserMSTRepository promoterUserMSTRepository;

    @BeforeEach
    void setUp() {
    }

    @Test
    void fetchUserByPhoneNumber() {
        Optional<PromoterUserMSTEntity> item = Optional.of(new PromoterUserMSTEntity());
        Mockito.when(promoterUserMSTRepository.findOneByUserNo(Mockito.anyString())).thenReturn(item);
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135");
        assertNotNull(promoterUserMSTEntity);
    }

    @Test
    void fetchUserByPhoneNumberWithStatus() {
        Optional<PromoterUserMSTEntity> item = Optional.of(new PromoterUserMSTEntity());
        Mockito.when(promoterUserMSTRepository.findOneByUserNoWithStatus(Mockito.anyString(), Mockito.anyString())).thenReturn(item);
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus("9839057135");
        assertNotNull(promoterUserMSTEntity);
    }

    @Test
    void fetchUserByIDWithStatus() {
        Optional<PromoterUserMSTEntity> item = Optional.of(new PromoterUserMSTEntity());
        Mockito.when(promoterUserMSTRepository.findOneByIdWithStatus(Mockito.anyLong(), Mockito.anyString())).thenReturn(item);
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                promoterUserMSTDAO.fetchUserByIDWithStatus(1L);
        assertNotNull(promoterUserMSTEntity);
    }
}