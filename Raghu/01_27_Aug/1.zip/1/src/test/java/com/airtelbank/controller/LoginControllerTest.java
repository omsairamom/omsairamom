package com.airtelbank.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.dao.LoginDAO;
import com.airtelbank.service.LoginService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class LoginControllerTest {

    @InjectMocks
    LoginController loginController;

    @Mock
    LoginDAO loginDao;

    @Mock
    LoginService loginService;

    @Autowired
    PropertyManager prop;

    @Mock
    PropertyManager propMock;

    @Mock
    CommonUtils commonUtil;

    @Mock
    HttpServletRequest httpServletRequest;

    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    ObjectMapper objectmapper = new ObjectMapper();

    @BeforeEach
    private void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    public void loginWithPassword_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("102 N");
        snapWorkRequest.setLongitude("108 W");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("LOGIN_WITH_PASWD_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(loginService.loginWithPasswordCheck(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.loginWithPassword(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

    @Test
    public void loginWithPassword_Fail() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setDeviceId("");
        snapWorkRequest.setPassword("");
        snapWorkRequest.setIsGpsEnabled("");
        snapWorkRequest.setFcmToken("");
        snapWorkRequest.setLatitude("");
        snapWorkRequest.setLongitude("");

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.loginWithPassword(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

//      assertEquals("500", snapWorkResponse.getStatusCode());
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void loginWithPassword_Fail_1() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(null);
        snapWorkRequest.setDeviceId(null);
        snapWorkRequest.setPassword(null);
        snapWorkRequest.setIsGpsEnabled(null);
        snapWorkRequest.setFcmToken(null);
        snapWorkRequest.setLatitude(null);
        snapWorkRequest.setLongitude(null);


//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.loginWithPassword(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

//        assertEquals("500", snapWorkResponse.getStatusCode());
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void loginWithPassword_throwException() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.loginWithPassword(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

//        assertEquals("500", snapWorkResponse.getStatusCode());
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void getUserProfile_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setJwtToken("abcdef#123");


        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FETCH_PROFILE_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        String payload = "{\"mobileno\":\"7006980036\"}";

        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        Mockito.when(loginService.fetchUserProfile_V2(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.getUserProfile(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void getUserProfile_Fail() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setJwtToken("abcdef#123");

        String payload = "{\"mobileno\":\"\"}";

        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.getUserProfile(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

//        assertEquals("500", snapWorkResponse.getStatusCode());
        assertNotNull(snapWorkResponse);
    }

    // @Test
    public void getUserProfile_throwException() {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(null);
        snapWorkRequest.setDeviceId(null);
        snapWorkRequest.setJwtToken("abcdef#123");

        //    Mockito.when(loginDao.getJWT(Mockito.anyString())).thenReturn("abcde#123");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.getUserProfile(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void setPassword_Success() throws Exception {
        String JWTTokenDB = "abcde#123";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@1234");
        snapWorkRequest.setJwtToken("abcde#123");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("SET_PASSWORD_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(loginDao.getJWT(Mockito.any())).thenReturn(JWTTokenDB);

        Mockito.when(loginService.setPasswordDetailsV2(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.resetPassword(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
//        assertNull(snapWorkResponse);
    }

    @Test
    public void setPassword_Fail() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        String JWTTokenDB = "abcde#123";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setDeviceId("");
        snapWorkRequest.setPassword("");
        snapWorkRequest.setJwtToken("");

        Mockito.when(loginDao.getJWT(Mockito.any())).thenReturn(JWTTokenDB);
//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.resetPassword(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

//      assertEquals("500", snapWorkResponse.getStatusCode());
        assertNull(snapWorkResponse);
    }

    @Test
    public void setPassword_Fail1() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        String JWTTokenDB = "abcdef#123";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(null);
        snapWorkRequest.setDeviceId(null);
        snapWorkRequest.setPassword(null);
        snapWorkRequest.setJwtToken(null);

        Mockito.when(loginDao.getJWT(Mockito.any())).thenReturn(JWTTokenDB);
//        Mockito.when(response.getMessage()).thenReturn("Invalid JWT Token");
//        Mockito.when(response.getStatusCode()).thenReturn("401");
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.resetPassword(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        // assertEquals("401", snapWorkResponse.getStatusCode());
        assertNull(snapWorkResponse);
    }

    //@Test
    public void setPassword_throwException() {
        SnapWorkResponse response = new SnapWorkResponse();

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.resetPassword(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void sendOTPDetails_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("LOGIN_SEND_OTP_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(loginService.sendOTP(Mockito.anyString(), Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.sendOTPDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    // @Test
    public void sendOTPDetails_Fail() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.sendOTPDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    //@Test
    public void sendOTPDetails_Fail_1() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(null);

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.sendOTPDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());

    }

    // @Test
    public void sendOTPDetails_throwException() {
        SnapWorkResponse response = new SnapWorkResponse();

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.sendOTPDetails(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());

    }

    @Test
    public void verifyOTPDetails_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setOtp("1112233");
        snapWorkRequest.setOtpVerficatonCode("12345");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("Y");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("LOGIN_VERIFY_OTP_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(loginService.verifyOTP(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.verifyOTPDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void verifyOTPDetails_Fail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setOtp("");
        snapWorkRequest.setOtpVerficatonCode("");
        snapWorkRequest.setIsUserExist("");
        snapWorkRequest.setIsUserDeviceExist("");

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.verifyOTPDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
        //assertEquals("500", snapWorkResponse.getStatusCode());
    }

//   // @Test
//    public void verifyOTPDetails_Fail_1() throws Exception
//    {
//        SnapWorkResponse response = new SnapWorkResponse();
//
//        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
//        snapWorkRequest.setMobileNo(null);
//        snapWorkRequest.setOtp(null);
//        snapWorkRequest.setOtpVerficatonCode(null);
//        snapWorkRequest.setIsUserExist(null);
//        snapWorkRequest.setIsUserDeviceExist(null);
//
//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");
//
//        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
//
//        ResponseEntity<Object> responseEntity = loginController.verifyOTPDetails(snapWorkRequest);
//        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
//
//        assertEquals("500", snapWorkResponse.getStatusCode());
//
//    }

    @Test
    public void verifyOTPDetails_throwException() {
        SnapWorkResponse response = new SnapWorkResponse();

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.verifyOTPDetails(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void logOutAttendanceUpload_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("9839057136");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setUserName("Sabreena");
        snapWorkRequest.setLatitude("102 N");
        snapWorkRequest.setLongitude("108 W");

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("LOGOUT_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(loginService.logOutAttendance(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.logOutAttendanceUpload(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void logOutAttendanceUpload_Fail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setDeviceId("");
        snapWorkRequest.setUserName("");
        snapWorkRequest.setLatitude("");
        snapWorkRequest.setLongitude("");

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.logOutAttendanceUpload(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals("500", snapWorkResponse.getStatusCode());
    }

//    // @Test
//    public void logOutAttendanceUpload_Fail_1() throws Exception {
//        SnapWorkResponse response = new SnapWorkResponse();
//
//        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
//        snapWorkRequest.setMobileNo(null);
//        snapWorkRequest.setDeviceId(null);
//        snapWorkRequest.setUserName(null);
//        snapWorkRequest.setLatitude(null);
//        snapWorkRequest.setLongitude(null);
//
//
//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");
//
//        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
//
//        ResponseEntity<Object> responseEntity = loginController.logOutAttendanceUpload(snapWorkRequest);
//        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
//
//        assertEquals("500", snapWorkResponse.getStatusCode());
//
//    }

    @Test
    public void logOutAttendanceUpload_throwException() {
        SnapWorkResponse response = new SnapWorkResponse();

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.logOutAttendanceUpload(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void attendanceView_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7607842101");
        snapWorkRequest.setDeviceId("and009");
        snapWorkRequest.setStartDate("18-11-2020");
        snapWorkRequest.setEndDate("24-11-2020");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("VIEW_ATTENDANCE_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");

        Mockito.when(loginService.attendanceViewDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyString(), Mockito.anyString())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.attendanceView(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
        assertNotNull(snapWorkResponse);
//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    public void attendanceView_Fail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setDeviceId("");
        snapWorkRequest.setStartDate("");
        snapWorkRequest.setEndDate("");

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.attendanceView(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals("500", snapWorkResponse.getStatusCode());
    }

//    // @Test
//    public void attendanceView_Fail_1() throws Exception
//    {
//        SnapWorkResponse response = new SnapWorkResponse();
//
//        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
//        snapWorkRequest.setMobileNo(null);
//        snapWorkRequest.setDeviceId(null);
//        snapWorkRequest.setStartDate(null);
//        snapWorkRequest.setEndDate(null);
//
//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");
//
//        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
//
//        ResponseEntity<Object> responseEntity = loginController.attendanceView(snapWorkRequest);
//        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
//
//        assertEquals("500", snapWorkResponse.getStatusCode());
//
//    }

    @Test
    public void attendanceView_throwException() {
        SnapWorkResponse response = new SnapWorkResponse();

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.attendanceView(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void getToken_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("JWT_GENERATED_SUCCESSFULLY"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(loginService.isRefreshToKen(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.getToken(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void getToken_Fail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.getToken(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals("500", snapWorkResponse.getStatusCode());
    }

//    //  @Test
//    public void getToken_Fail_1() throws Exception
//    {
//        SnapWorkResponse response = new SnapWorkResponse();
//
//        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
//        snapWorkRequest.setMobileNo(null);
//
//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");
//
//        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
//
//        ResponseEntity<Object> responseEntity = loginController.getToken(snapWorkRequest);
//        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
//
//        assertEquals("500", snapWorkResponse.getStatusCode());
//
//    }

    @Test
    public void getToken_throwException() {
        SnapWorkResponse response = new SnapWorkResponse();

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = loginController.getToken(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }


    @Test
    public void profileUpload_success() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("UPLOAD_PROFILE_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);

        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "multipart/form-data", IOUtils.toByteArray(input));

        String payload = "{\"mobileno\":\"7006980036\"}";

        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        Mockito.when(loginService.profileUploadDetails("7006980036", multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");


        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addParameter("parameterName", "someValue");

        ResponseEntity<Object> responseEntity = loginController.profileUpload(multipartFile, request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    public void profileUpload_fail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

//        Mockito.when(response.getMessage()).thenReturn("Sorry! Invalid MIME type");
//        Mockito.when(response.getStatusCode()).thenReturn("500");


        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "text/plain-data", IOUtils.toByteArray(input));

        String payload = "{\"mobileno\":\"\"}";

        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");


        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addParameter("parameterName", "someValue");

        ResponseEntity<Object> responseEntity = loginController.profileUpload(multipartFile, request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
        assertNotNull(snapWorkResponse);
//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void profileUpload_mobileNo_Emptyfail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty(Constants.LOGIN_UPLOAD_INVALID_CONTENT_TYPE_MSG));
        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
        response.setResponse(jsonObject);

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "text/plain-data", IOUtils.toByteArray(input));
        String payload = "{\"mobileno\":\"7006980036\"}";

        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);


        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addParameter("parameterName", "someValue");

        ResponseEntity<Object> responseEntity = loginController.profileUpload(multipartFile, request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void profileUpload_invalidfileExtention_fail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty(Constants.LOGIN_UPLOAD_INVALID_FILE_EXTN_MSG));
        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
        response.setResponse(jsonObject);

//        Mockito.when(response.getMessage()).thenReturn("Sorry! Invalid MIME type");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        File file = new File("src/test/resources/Promoter_KPI_MST.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "multipart/form-data", IOUtils.toByteArray(input));
        String payload = "{\"mobileno\":\"7006980036\"}";

        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addParameter("parameterName", "someValue");

        ResponseEntity<Object> responseEntity = loginController.profileUpload(multipartFile, request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void profileUpload_mobileNo_throwException() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();
//        response.setStatusCode("200");
//
//        Mockito.when(response.getMessage()).thenReturn("Server Error, please try after sometime.");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addParameter("parameterName", "someValue");

        ResponseEntity<Object> responseEntity = loginController.profileUpload(null, request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void attendanceUpload_Success() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("UPLOAD_ATTENDANCE_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);


        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);

        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "multipart/form-data", IOUtils.toByteArray(input));


        Mockito.when(loginService.attendanceUploadDetails(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.attendanceUpload(multipartFile,
                "y1+Lk+jGATrRtpJR+F2R8nyPpI3nbtWXjB1qsg+SEesuWYtQ00+KU8F6n8ATphQpbNnhVWnUFwC+nu4HWNKfUwwhFdTKpVdXCbqWSgUzWDOM3jl5a8zHdjbDA4sSKOz4obobZvOtontCUwAo0m3Ft5zntmE22OUebeL5mk5lgzsK6PE44UcRayPjd8njhk6mIHiciPKG+G662WH2lrJ948+WLIfF3ozp53Uhh8YA9YU=");

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getMessage(), response.getMessage());
    }

    @Test
    public void attendanceUpload_mobileNo_Emptyfail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("LOGIN_UPLOAD_INVALID_CONTENT_TYPE_MSG"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "text/plain-data", IOUtils.toByteArray(input));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.attendanceUpload(multipartFile,
                "y1+Lk+jGATrRtpJR+F2R8nyPpI3nbtWXjB1qsg+SEesuWYtQ00+KU8F6n8ATphQpbNnhVWnUFwC+nu4HWNKfUwwhFdTKpVdXCbqWSgUzWDOM3jl5a8zHdjbDA4sSKOz4obobZvOtontCUwAo0m3Ft5zntmE22OUebeL5mk5lgzsK6PE44UcRayPjd8njhk6mIHiciPKG+G662WH2lrJ948+WLIfF3ozp53Uhh8YA9YU=");

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void attendanceUpload_mobileNo_throwException() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

//        Mockito.when(response.getMessage()).thenReturn("Server Error, please try after sometime.");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.attendanceUpload(null,
                "");

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void attendanceUpload_invalidfileExtention_fail() throws Exception {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("LOGIN_UPLOAD_INVALID_FILE_EXTN_MSG"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

//        Mockito.when(response.getMessage()).thenReturn("Sorry! Invalid MIME type");
//        Mockito.when(response.getStatusCode()).thenReturn("500");

        File file = new File("src/test/resources/Promoter_KPI_MST.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "multipart/form-data", IOUtils.toByteArray(input));


        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = loginController.attendanceUpload(multipartFile,
                "y1+Lk+jGATrRtpJR+F2R8nyPpI3nbtWXjB1qsg+SEesuWYtQ00+KU8F6n8ATphQpbNnhVWnUFwC+nu4HWNKfUwwhFdTKpVdXCbqWSgUzWDOM3jl5a8zHdjbDA4sSKOz4obobZvOtontCUwAo0m3Ft5zntmE22OUebeL5mk5lgzsK6PE44UcRayPjd8njhk6mIHiciPKG+G662WH2lrJ948+WLIfF3ozp53Uhh8YA9YU=");

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }
}