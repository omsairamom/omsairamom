package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.service.CaptureComplianceService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.PropertyManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class CaptureComplianceControllerTest {
    @InjectMocks
    CaptureComplianceController captureComplianceController;

    @Mock
    CaptureComplianceService capComplianceService;

    @Autowired
    PropertyManager prop;

    @Mock
    PropertyManager propMock;

    @Mock
    CommonUtils commonUtil;

//    @Mock
//    SnapWorkResponse response;

    @Mock
    HttpServletRequest httpServletRequest;

    @Test
    void captureComplianceDetails_Success() throws Exception {
        String payload = "{\"mobileno\":\"9897108505\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("COMPLIANCE_CAPTURE_ADD_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        SnapWorkRequest request = new SnapWorkRequest();
        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "multipart/form-data", IOUtils.toByteArray(input));

        ObjectMapper objectMapper = new ObjectMapper();

        MockMultipartFile metadata =
                new MockMultipartFile(
                        "request",
                        "request",
                        MediaType.APPLICATION_JSON_VALUE,
                        objectMapper.writeValueAsString(request).getBytes(StandardCharsets.UTF_8));


        Mockito.when(capComplianceService.captureComplianceDetails(multipartFile, "9897108505", "add")).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = captureComplianceController.captureComplianceDetails(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

    @Test
    void captureComplianceDetails_Fail() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        String payload = "{\"mobileno\":\"\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");


        SnapWorkRequest request = new SnapWorkRequest();
        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "multipart/form-data", IOUtils.toByteArray(input));

        ObjectMapper objectMapper = new ObjectMapper();

        MockMultipartFile metadata =
                new MockMultipartFile(
                        "request",
                        "request",
                        MediaType.APPLICATION_JSON_VALUE,
                        objectMapper.writeValueAsString(request).getBytes(StandardCharsets.UTF_8));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                captureComplianceController.captureComplianceDetails(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
        assertNotNull(snapWorkResponse);
        //  assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

    @Test
    void captureComplianceDetails_ContentTypeFail() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("COMPLIANCE_UPLOAD_INVALID_CONTENT_TYPE_MSG"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        String payload = "{\"mobileno\":\"9897108505\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");


        SnapWorkRequest request = new SnapWorkRequest();
        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "text/plain-data", IOUtils.toByteArray(input));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                captureComplianceController.captureComplianceDetails(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
       // assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

    @Test
    void captureComplianceDetails_fileTypeFail() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("COMPLIANCE_UPLOAD_INVALID_FILE_EXTN_MSG"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        String payload = "{\"mobileno\":\"9897108505\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");


        File file = new File("src/test/resources/Promoter_KPI_MST.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "multipart/form-data", IOUtils.toByteArray(input));


        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                captureComplianceController.captureComplianceDetails(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
        //assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

     @Test
    void captureComplianceDetails_throwExcepion() throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        String payload = "{\"mobileno\":\"9897108505\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

//        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
//        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));


        Mockito.when(capComplianceService.captureComplianceDetails(null, "7607842101", "add")).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                captureComplianceController.captureComplianceDetails(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);

//        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }
}