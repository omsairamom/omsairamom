package com.airtelbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.Assert.assertEquals;

@SpringBootTest
class AirtelBmaLoginApplicationTest
{
    @Test
    public void contextLoads()
    {
        assertEquals("Hello JUnit 5", "Hello JUnit 5");
    }
}