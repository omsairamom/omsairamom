package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.dao.KpiDAO;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class KPIControllerTest
{
    @InjectMocks
    KPIController kpiController;

    @Mock
    KpiDAO fileUploadDAO;

    @Autowired
    PropertyManager prop;

    @Mock
    PropertyManager propMock;

    @Mock
    CommonUtils commonUtil;

    @Test
    public void fetchKPIDetails_v2_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("9718056667");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("ADMIN_FETCH_KPI_DETAIL_SUCCESS"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(fileUploadDAO.fetchKPIDetailsV2(snapWorkRequest.getMobileNo())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiController.fetchKPIDetails_v2(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    public void fetchKPIDetails_v2_Fail() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

//        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
//        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiController.fetchKPIDetails_v2(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
        assertNotNull(snapWorkRequest);

    }

    @Test
    public void fetchKPIDetails_v2_Fail_1() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(null);

//        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
//        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiController.fetchKPIDetails_v2(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

      //  assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void fetchKPIDetails_v2_throwException()
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest request = null;

//        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
//        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        ResponseEntity<Object> responseEntity = kpiController.fetchKPIDetails_v2(request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

//        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
        assertNotNull(snapWorkResponse);
    }
}