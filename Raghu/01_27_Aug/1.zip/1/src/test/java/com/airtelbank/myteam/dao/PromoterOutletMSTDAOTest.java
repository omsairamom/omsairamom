package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterOutletMSTEntity;
import com.airtelbank.myteam.repository.PromoterOutletMSTRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.Optional;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterOutletMSTDAOTest
{
    @InjectMocks
    PromoterOutletMSTDAO promoterOutletMSTDAO;

    @Mock
    PromoterOutletMSTRepository promoterOutletMSTRepository;

    @BeforeEach
    void setUp()
    {

    }

    @Test
    void fetchPromoterUserKYCMST()
    {
        Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity =
                Optional.of(new PromoterOutletMSTEntity());

        Mockito.when(promoterOutletMSTRepository
                .findOneByPromoterNo(Mockito.anyString())).thenReturn(promoterOutletMSTEntity);
        Optional<PromoterOutletMSTEntity> response =
                promoterOutletMSTDAO.fetchOutletByOutletNo("9839057135");

        assertNotNull(response);
    }
}