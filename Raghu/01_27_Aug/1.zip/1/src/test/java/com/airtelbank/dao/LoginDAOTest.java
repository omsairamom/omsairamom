package com.airtelbank.dao;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.bean.LoginInfoTrackerBean;
import com.airtelbank.bean.UserDevicesBean;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.entity.*;
import com.airtelbank.myteam.repository.*;
import com.airtelbank.util.CustomException;
import com.airtelbank.util.PropertyManager;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDateTime;
import java.util.*;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class LoginDAOTest
{
    @Autowired
    LoginDAO loginDao;

    @MockBean
    JdbcTemplate jdbcTemplate;

    @MockBean
    PromoterUserProfileMSTRepository promoterUserProfileMSTRepository;

    @MockBean
    PromoterUserMSTRepository promoterUserMSTRepository;

    @MockBean
    PromoterCircleMSTRepository promoterCircleMSTRepository;

    @MockBean
    PromoterLoginTrackerAuditRepository promoterLoginTrackerAuditRepository;

    @MockBean
    PromoterAttendanceAuditRepository promoterAttendanceAuditRepository;

    @BeforeEach
    private void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @MockBean
    PropertyManager prop;

    @Test
    public void getDeviceCount() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("DEVICE_ID", "97");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        int deviceIdCount = loginDao.getDeviceCount("7607842101");
        assertTrue(deviceIdCount > 0);
    }

    @Test
    public void validatePassword() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("USER_PWD", "Airtel@123");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean isValidPassword = loginDao.validatePassword("device123", "7607842101", "Airtel@123", "Airtel@123");
        assertTrue(isValidPassword == true);
    }

    @Test
    public void updateFCMTokenDetails() throws Exception {

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int updateFcmTokenCount = loginDao.updateFCMTokenDetails("device123", "fcmToken123");
        assertTrue(updateFcmTokenCount > 0);
    }

    @Test
    public void updateJWT() throws Exception {

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int updateFcmTokenCount = loginDao.updateJWT("jwt123", "7607842101");
        assertTrue(updateFcmTokenCount > 0);
    }

    @Test
    public void getRollDetails() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("USER_TYPE", "Promoter");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        String rollName = loginDao.getRollDetails("7607842101");
        assertTrue(!rollName.equals(""));
    }

    @Test
    public void getRollDetails_Exception() throws Exception
    {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("USER_TYPE", "Promoter");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(null);

        String rollName = loginDao.getRollDetails("7607842101");
        assertNotNull(rollName);
    }

    @Test
    public void checkFirtstTimeLoginDtls() throws Exception
    {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("USER_TYPE", "Promoter");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag = loginDao.checkFirtstTimeLoginDtls("7607842101");
        assertTrue(flag == true);
    }

    @Test
    public void fetchEODSubmitAttendanceDtls() throws Exception {
        boolean flag = true;

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        Map<String, Object> row = new HashMap<>();
        row.put("MOBILENO", "7006980036");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(row);


        String query = "";
        when(prop.getProperty("LOGIN_CHECK_EOD_ATTEN_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag1 = loginDao.fetchEODSubmitAttendanceDtls(snapWorkRequest.getMobileNo());

        assertEquals(flag1, flag);
    }

    @Test
    public void getTrainingDueDate() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();
        List<Map<String, Object>> rows1 = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("USER_TYPE", "Promoter");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        rows1 = loginDao.getTrainingDueDate("7607842101");
        assertTrue(rows1.size() > 0);
    }

    @Test
    public void getPromoterType() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("PROMOTER_TYPE", "Combined");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        String promoterName = loginDao.getPromoterType("7607842101");
        assertTrue(promoterName.equalsIgnoreCase("Combined"));
    }

    @Test
    public void getUserNameDetails() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("USER_NAME", "Deeksha");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        String userName = loginDao.getUserNameDetails("7607842101");
        assertTrue(userName.equalsIgnoreCase("Deeksha"));
    }

    @Test
    public void getCircleZoneDtls() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();
        List<Map<String, Object>> rows1 = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("CIRCLE_ID", "1");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        rows1 = loginDao.getCircleZoneDtls("7607842101");
        assertTrue(rows1.size() > 0);
    }

    @Test
    public void testSaveAttendanceDetails() throws Exception {
        int count = 1;

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        AttendanceBean obj = new AttendanceBean();
        obj.setMobileNo("7006980036");
        obj.setLatitude("26.7777819");
        obj.setType(1);
        obj.setLongitude("80.9248925");
        obj.setAddress("Uttar Pradesh ");
        obj.setSelfiePath("/vpn.jpg");
        obj.setField1("test");
        obj.setField2("test");
        obj.setField3("test");
        obj.setField4("test");
        obj.setField5("test");

        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("mobileNo", "7006980036");
        rows.add(map);

        String query = "";
        when(prop.getProperty("LOGIN_ATTENDANCE_UPLOAD_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(count);

        int row = loginDao.saveAttendanceDetails(obj);

        assertEquals(row, count);

        System.out.println("Deepak " + row + " == " + count);
    }

    @Test
    public void getAttendanceDetails() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        Map<String, Object> row = new HashMap<>();
        row.put("MOBILENO", "7006980036");
        row.put("StartDate", "12/08/2020");
        row.put("EndDate", "20/09/2020");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(row);

        String query = "";
        when(prop.getProperty("LOGIN_ATTENDANCE_VIEW_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> list = loginDao.getAttendanceDetails(snapWorkRequest.getMobileNo(), "12/08/2020", "20/09/2020");

        assertEquals(rows, list);

        System.out.println("Deepak " + list + " == " + rows);
    }

    @Test
    public void isUserDeviceExist() throws Exception {
        Map<String, Object> row = new HashMap<>();
        row.put("mobileNo", "7006980036");
        row.put("StartDate", "12/08/2020");
        row.put("EndDate", "20/09/2020");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(row);

        String query = "";
        when(prop.getProperty("LOGIN_CHECK_USERDEVICE_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag = loginDao.isUserDeviceExist("abc123", "7607842101");

        assertEquals(true, flag);
    }

    @Test
    public void updateUserDeviceDetails() throws Exception {
        UserDevicesBean obj = new UserDevicesBean();
        obj.setMobileNo("7607842101");
        obj.setDeviceId("12");
        obj.setFcmToken("fcmtoken123");
        obj.setAppVersion("0.1");
        obj.setDeviceModel("ime123");
        obj.setImei("ime123");
        obj.setOs("kernel");
        obj.setPassword("airtel@12345");
        obj.setLanguage("En");
        obj.setDelBlockFlag(0);
        obj.setDelBlockBy("NA");
        obj.setDelBlockReason("NA");

        String query = "";
        when(prop.getProperty("LOGIN_UPDATE_USERDEVICE_DTLS")).thenReturn(query);
        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int count = loginDao.updateUserDeviceDetails(obj);
        assertEquals(1, count);

    }

    @Test
    public void saveUserDeviceDetailsWithPassword() throws Exception {
        UserDevicesBean obj = new UserDevicesBean();
        obj.setMobileNo("7607842101");
        obj.setDeviceId("12");
        obj.setFcmToken("fcmtoken123");
        obj.setAppVersion("0.1");
        obj.setDeviceModel("ime123");
        obj.setImei("ime123");
        obj.setOs("kernel");
        obj.setPassword("airtel@12345");
        obj.setLanguage("En");
        obj.setDelBlockFlag(0);
        obj.setDelBlockBy("NA");
        obj.setDelBlockReason("NA");

        String query = "";
        when(prop.getProperty("LOGIN_SAVE_USERDEVICES_DTLS")).thenReturn(query);
        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int count = loginDao.saveUserDeviceDetailsWithPassword(obj);
        assertEquals(1, count);
    }

    @Test
    public void getRollName() throws Exception {
        Map<String, Object> row = new HashMap<>();
        row.put("RollName", "0");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(row);

        String query = "";
        when(prop.getProperty("LOGIN_FETCH_ROLE_NAME")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        String roll = loginDao.getRollName("7607842101");
        assertEquals("RollName", roll);
    }

    @Test
    public void isAppUserExist() throws Exception {
        Map<String, Object> row = new HashMap<>();
        row.put("MobileNo", "7607842101");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(row);

        String query = "";
        when(prop.getProperty("LOGIN_CHECK_APP_USER_EXIST_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag = loginDao.isAppUserExist("7607842101");
        assertEquals(true, flag);
    }

    @Test
    public void isMobileNoExist() throws Exception {
        Map<String, Object> row = new HashMap<>();
        row.put("MobileNo", "7607842101");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(row);

        String query = "";
        when(prop.getProperty("LOGIN_CHECK_MOBILE_EXIST_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag = loginDao.isMobileNoExist("7607842101");
        assertEquals(true, flag);
    }

    @Test
    public void isDeviceExist() throws Exception {
        Map<String, Object> row = new HashMap<>();
        row.put("MobileNo", "7607842101");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(row);

        String query = "";
        when(prop.getProperty("LOGIN_CHECK_APP_DEVICE_EXIST_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag = loginDao.isDeviceExist("7607842101", "deviceID123");
        assertEquals(true, flag);
    }

    @Test
    void checkPromoterType() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("promoter_type", "Merchant");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        String promoterType = loginDao.checkPromoterType("7607842101");
        assertTrue(promoterType.equalsIgnoreCase("Merchant"));
    }

    @Test
    public void updateDeleteBlockFlag() throws Exception {
        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);

        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int count = loginDao.updateDeleteBlockFlag("97", "7006980034");
        assertTrue(count > 0);
    }

    @Test
    public void updateDeviceId() throws Exception {
        String query = "";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setImei("test");
        snapWorkRequest.setFcmToken("test");
        snapWorkRequest.setAppVersion("test");
        snapWorkRequest.setDeviceType("test");
        snapWorkRequest.setDeviceModel("test");

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int count = loginDao.updateDeviceId("7006980034", "device123", snapWorkRequest);
        assertTrue(count > 0);
    }

    @Test
    public void saveMultipleDeviceLoginDetails() throws Exception {
        String query = "";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setDeviceType("test");

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int count = loginDao.saveMultipleDeviceLoginDetails("7006980034", "device123", snapWorkRequest);
        assertTrue(count > 0);

    }

    @Test
    public void fetchMobileRegisterCount() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("COUNT", "1");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        int count = loginDao.fetchMobileRegisterCount("7006980034");
        assertTrue(count > 0);
    }

    @Test
    public void isUserExist() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("mobileNo", "7006980034");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag = loginDao.isUserExist("7006980034");
        assertTrue(rows.size() > 0);
    }

    @Test
    public void getJWT() throws Exception {
        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("JWT_TOKEN", "jwt123");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        String flag = loginDao.getJWT("7006980034");
        assertTrue(rows.size() > 0);
    }

    @Test
    public void saveLoginAndLogOutDetails() throws Exception {
        String query = "";

        final LoginInfoTrackerBean obj = new LoginInfoTrackerBean();
        obj.setMobileNo("7006980034");
        obj.setUserName("Sabreena");
        obj.setLongitude("80.9248925");
        obj.setLatitude("26.7777819");
        obj.setIsGpsEnabled("Y");
        obj.setLoginType(1);
        obj.setUdid("abc12");
        obj.setField1("");
        obj.setField2("");
        obj.setField3("");
        obj.setField4("");
        obj.setField5("");

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int count = loginDao.saveLoginAndLogOutDetails(obj);

        assertTrue(count > 0);
    }

    @Test
    void fetchUserProfileForChannel() throws CustomException
    {
        Optional<PromoterUserProfileMSTEntity> item = Optional.of(new PromoterUserProfileMSTEntity());
        Mockito.when(promoterUserProfileMSTRepository.findOneByUserNoAndChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(item);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                loginDao.fetchUserProfileForChannel("9839057135", "abc");
        assertNotNull(promoterUserProfileMSTEntity);
    }

    @Test
    void fetchUserByPhoneNumber() {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());

        Mockito.when(promoterUserMSTRepository
                .findOneByUserNo(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserMSTEntity> response =
                loginDao.fetchUserByPhoneNumber("9839057135");

        Assert.assertNotNull(response);
    }

    @Test
    void fetchCircleByCircleId() {
        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity =
                Optional.of(new PromoterCircleMSTEntity());

        Mockito.when(promoterCircleMSTRepository
                .findOneByCircleId(Mockito.anyString())).thenReturn(promoterCircleMSTEntity);
        Optional<PromoterCircleMSTEntity> response =
                loginDao.fetchCircleByCircleId("1");

        Assert.assertNotNull(response);
    }

    @Test
    void saveLoginAndLogOutDetails_V2() throws Exception {
        PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity =
                new PromoterLoginTrackerAuditEntity();
        promoterLoginTrackerAuditEntity.setId(1L);
        promoterLoginTrackerAuditEntity.setDeviceId("123445");
        promoterLoginTrackerAuditEntity.setChannel("abc");
        promoterLoginTrackerAuditEntity.setUserNo("7008991222");

        PromoterUserMSTEntity promoterUserMSTEntity = new PromoterUserMSTEntity();
        promoterUserMSTEntity.setId(1L);
        promoterUserMSTEntity.setUsername("HCL");
        promoterLoginTrackerAuditEntity.setPromoterUserMSTEntity(promoterUserMSTEntity);

        doReturn(promoterLoginTrackerAuditEntity).when(promoterLoginTrackerAuditRepository).saveAndFlush(Mockito.any());

        PromoterLoginTrackerAuditEntity response =
                loginDao.saveLoginAndLogOutDetails_V2(promoterLoginTrackerAuditEntity);
        Assert.assertNotNull(response);
    }

    @Test
    void getAttendanceDetails_V2() throws Exception {

        List<PromoterAttendanceAuditEntity> findAttendanceByDateRange = new ArrayList<>();

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());

        Mockito.when(promoterUserMSTRepository
                .findOneByUserNo(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Mockito.when(promoterAttendanceAuditRepository
                .findAttendanceByDateRange(Mockito.any(),Mockito.anyString(),Mockito.anyString())).thenReturn(findAttendanceByDateRange);
        List<PromoterAttendanceAuditEntity> response =
                loginDao.getAttendanceDetails_V2("9839057135","02-03-2021","03-05-2021");


        Assert.assertNotNull(response);
    }

    @Test
    void validatePassword_V2() throws Exception
    {
        String dbPassword = "Test@123";

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity = Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("Test@123");
        promoterUserProfileMSTEntity.get().setChannel("ddIndia");

        Mockito.when(promoterUserProfileMSTRepository
                .findOneByUserNoWithStatus(Mockito.anyString(),Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);

        boolean response =
                loginDao.validatePassword_V2("9839057135","Test@123");

        assertNotNull(response);
    }

//    @Test
//    void setBlockCounterToXAndBlockExpiryY() throws Exception
//    {
//        PromoterUserProfileMSTEntity promoterUserProfileMSTEntity = new PromoterUserProfileMSTEntity();
//        promoterUserProfileMSTEntity.setAttempts(1);
//        promoterUserProfileMSTEntity.setBlockExpiryDate(LocalDateTime.now());
//
//        loginDao.setBlockCounterToXAndBlockExpiryY(promoterUserProfileMSTEntity,1, LocalDateTime.now());
//
//        Mockito.verify(loginDao, Mockito.times(1)).setBlockCounterToXAndBlockExpiryY(promoterUserProfileMSTEntity,1, LocalDateTime.now());
//    }
}
