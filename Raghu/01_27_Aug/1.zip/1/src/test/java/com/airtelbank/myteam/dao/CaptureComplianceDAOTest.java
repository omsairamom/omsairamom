package com.airtelbank.myteam.dao;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.util.PropertyManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class CaptureComplianceDAOTest {
	
	@Autowired
	CaptureComplianceDAO captureComplianceDAO;
	
	@MockBean
    JdbcTemplate jdbcTemplate;

    @BeforeEach
    private void setUp()
    {
        MockitoAnnotations.initMocks(this);
    }

    @MockBean
    PropertyManager prop;
    
    @Test
    public void fetchComplRetailerDetails_SuccessTest() throws Exception
    {
    	SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        Map<String, Object> row = new HashMap<>();
        row.put("MOBILENO", "7006980036");
    
        List<Map<String, Object>> rows  = new ArrayList<>();
        rows.add(row);   

        String query = "";
		when( prop.getProperty("COMPLIANCE_FETCH_RETAILER_DTLS")).thenReturn(query);
		when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> list = captureComplianceDAO.fetchComplRetailerDetails(snapWorkRequest.getMobileNo());

        assertEquals(list , rows);

    }
    
    @Test
    public void getKpiDetails_SuccessTest() throws Exception
    {
    	SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        Map<String, Object> row = new HashMap<>();
        row.put("MOBILENO", "7006980036");
    
        List<Map<String, Object>> rows  = new ArrayList<>();
        rows.add(row);   

        String query = "";
		when( prop.getProperty("COMPLIANCE_FETCH_KPI_DTLS")).thenReturn(query);
		when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> list = captureComplianceDAO.getKpiDetails(snapWorkRequest.getMobileNo());

        assertEquals(list , rows);
    }
}
