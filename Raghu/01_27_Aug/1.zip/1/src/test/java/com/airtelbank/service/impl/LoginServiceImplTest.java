package com.airtelbank.service.impl;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.dao.LoginDAO;
import com.airtelbank.dao.UploadDocumentsDAO;
import com.airtelbank.entity.PromoterAttendanceAuditEntity;
import com.airtelbank.entity.PromoterCircleMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.jwt.AeroCache;
import com.airtelbank.jwt.CommonJWTUtil;
import com.airtelbank.jwt.JTIToken;
import com.airtelbank.jwt.JWTSigner;
import com.airtelbank.myteam.dao.PromoterUserMSTDAO;
import com.airtelbank.myteam.dao.PromoterUserProfileMSTDAO;
import com.airtelbank.service.LoginService;
import com.airtelbank.util.KibanaLoggerUtils;
import com.airtelbank.util.PropertyManager;
import com.airtelbank.util.RestClientUtil;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.net.URI;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class LoginServiceImplTest {
    @Autowired
    LoginService loginService;

    @Autowired
    LoginServiceImpl loginServiceImpl;

    @MockBean
    LoginDAO loginDAO;

    @MockBean
    PromoterUserMSTDAO promoterUserMSTDAO;

    @MockBean
    PromoterUserProfileMSTDAO promoterUserProfileMSTDAO;

    @MockBean
    private UploadDocumentsDAO uploadDocumentsDAO;

    @MockBean
    CommonJWTUtil commonUtil;

    @MockBean
    RestClientUtil restClient;

    @Autowired
    PropertyManager prop;

    @Autowired
    SnapWorkRequest request;

//	@Autowired
//	SnapWorkResponse response;

    @MockBean
    JTIToken jtiToken;

    @MockBean
    JWTSigner signer;

    @Autowired
    KibanaLoggerUtils kibanaLoggerObj;

    @MockBean
    RestTemplate restTemplate;

    @MockBean
    AeroCache aeroCache;

    @BeforeEach
    private void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void fetchUserProfile_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7607842101");
        snapWorkRequest.setDeviceId("and090");
        snapWorkRequest.setJwtToken(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");
        PromoterCircleMSTEntity promoterCircleMSTEntity1 = new PromoterCircleMSTEntity();
        promoterCircleMSTEntity1.setCircleId("1");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity1);


        doReturn(promoterUserMSTEntity).when(loginDAO).fetchUserByPhoneNumber(Mockito.anyString());
        Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity =
                Optional.of(new PromoterCircleMSTEntity());
        promoterCircleMSTEntity.get().setCircleId("1");
        promoterCircleMSTEntity.get().setCircleName("A");

        doReturn(promoterCircleMSTEntity).when(loginDAO).fetchCircleByCircleId(Mockito.anyString());

        SnapWorkResponse snapWorkResponse = loginService.fetchUserProfile_V2(snapWorkRequest);
        assertEquals("Profile fetched successfully .", snapWorkResponse.getMessage());
    }

    @Test
    public void fetchUserProfileFailTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7507842101");
        snapWorkRequest.setDeviceId(" ");
        snapWorkRequest.setJwtToken(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");

        SnapWorkResponse response = loginService.fetchUserProfile_V2(snapWorkRequest);

        assertEquals(prop.getProperty("NO_USER_MESSAGE"), response.getMessage());

    }

    @Test
    public void fetchUserProfile_userType_Fail() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7607842101");
        snapWorkRequest.setDeviceId("and090");
        snapWorkRequest.setJwtToken(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("");
        PromoterCircleMSTEntity promoterCircleMSTEntity1 = new PromoterCircleMSTEntity();
        promoterCircleMSTEntity1.setCircleId("1");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity1);

        doReturn(promoterUserMSTEntity).when(loginDAO).fetchUserByPhoneNumber(Mockito.anyString());

        SnapWorkResponse snapWorkResponse = loginService.fetchUserProfile_V2(snapWorkRequest);
        assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"), snapWorkResponse.getMessage());
    }

    @Test
    public void attendanceUploadDetailsSuccess() throws Exception {
        int insertCount = 1;

        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        String selfieName = prop.getProperty("UPLOAD_ATTENDANCE_DIR_NAME");
        String uploadPath = loginServiceImpl.imageUpload("9876543220", multipartFile, selfieName);

        AttendanceBean obj = new AttendanceBean();
        obj.setSelfiePath(uploadPath);

//		Mockito.when(loginDAO.saveAttendanceDetails(Mockito.any())).thenReturn(insertCount);
//		Mockito.when(loginDAO.fetchEODSubmitAttendanceDtls(Mockito.any())).thenReturn(true);

        Mockito.when(uploadDocumentsDAO.saveAttendanceDetails(Mockito.any())).thenReturn(insertCount);

        SnapWorkResponse snapWorkResponse = loginService.attendanceUploadDetails("9876543220", multipartFile, obj, "Y");

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void attendanceUploadDetailsFail() throws Exception {
        int insertCount = 0;

        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "text/plain",
                IOUtils.toByteArray(input));

        String selfieName = prop.getProperty("UPLOAD_ATTENDANCE_DIR_NAME");
        String uploadPath = loginServiceImpl.imageUpload("7006980036", multipartFile, selfieName);

        AttendanceBean obj = new AttendanceBean();
        obj.setSelfiePath(uploadPath);

        Mockito.when(loginDAO.saveAttendanceDetails(Mockito.any())).thenReturn(insertCount);

        SnapWorkResponse snapWorkResponse = loginService.attendanceUploadDetails("7006980036", multipartFile, obj, "Y");

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("FAILURE_ERROR_MESSAGE"));

    }

    @Test
    public void when_attendanceUploadDetails_Then_ThrowExceptionTest() throws Exception {

        AttendanceBean obj = new AttendanceBean();
        obj.setSelfiePath("");

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("exception");
        SnapWorkResponse response = loginService.attendanceUploadDetails(null, null, obj, "Y");

        assertEquals(response.getStatusCode(), prop.getProperty("FAILURE_STATUS_CODE"));

    }

    @Test
    public void attendanceViewDetails() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7607842101");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.9248925");
        snapWorkRequest.setDeviceId("and009");
        snapWorkRequest.setStartDate("18-11-2020");
        snapWorkRequest.setEndDate("24-11-2020");
        Map<String, Object> attendanceRow = new HashMap<>();
        attendanceRow.put("ATT_DATETIME", "Test");
        attendanceRow.put("DISPLAY_DATE", "Test");
        attendanceRow.put("LATITUDE", "26.7777819");
        attendanceRow.put("LONGITUDE", "80.9248925");
        attendanceRow.put("ADDRESS", "Noida");
        attendanceRow.put("SELFIE_PATH", "Test");
        attendanceRow.put("TYPE", "Test");
        JSONObject jsonAttendanceObj = new JSONObject();
        jsonAttendanceObj.put("address", "Noida");
        List<Map<String, Object>> attendanceRows = new ArrayList<>();
        attendanceRows.add(attendanceRow);
        List<PromoterAttendanceAuditEntity> promoterAttendanceAuditEntity = new ArrayList<>();
        PromoterAttendanceAuditEntity promoterAttendanceAuditEntity1 = new PromoterAttendanceAuditEntity();
        promoterAttendanceAuditEntity1.setPromoterNo("7006980033");
        promoterAttendanceAuditEntity1.setSelfieId("abc12");
        promoterAttendanceAuditEntity1.setLatitude(snapWorkRequest.getLatitude());
        promoterAttendanceAuditEntity1.setLongitude(snapWorkRequest.getLongitude());
        promoterAttendanceAuditEntity1.setAddress("noida");
        promoterAttendanceAuditEntity1.setCreatedDate(LocalDateTime.now());
        promoterAttendanceAuditEntity.add(promoterAttendanceAuditEntity1);

        doReturn(promoterAttendanceAuditEntity).when(loginDAO).getAttendanceDetails_V2(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        SnapWorkResponse snapWorkResponse = loginService.attendanceViewDetails("and009",
                "7607842101", snapWorkRequest, "26.7777819", "80.9248925");
        assertEquals("Fetched attendance details successfully", snapWorkResponse.getMessage());
    }

    @Test
    public void attendanceViewDetails_Fail() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7607842101");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.9248925");
        snapWorkRequest.setDeviceId("and009");
        snapWorkRequest.setStartDate("18-11-2020");
        snapWorkRequest.setEndDate("24-11-2020");
        Map<String, Object> attendanceRow = new HashMap<>();
        attendanceRow.put("ATT_DATETIME", "Test");
        attendanceRow.put("DISPLAY_DATE", "Test");
        attendanceRow.put("LATITUDE", "26.7777819");
        attendanceRow.put("LONGITUDE", "80.9248925");
        attendanceRow.put("ADDRESS", "Noida");
        attendanceRow.put("SELFIE_PATH", "Test");
        attendanceRow.put("TYPE", "Test");
        JSONObject jsonAttendanceObj = new JSONObject();
        jsonAttendanceObj.put("address", "Noida");
        List<Map<String, Object>> attendanceRows = new ArrayList<>();
        attendanceRows.add(attendanceRow);

        doReturn(null).when(loginDAO).getAttendanceDetails_V2(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        SnapWorkResponse snapWorkResponse = loginService.attendanceViewDetails("and009",
                "7607842101", snapWorkRequest, "26.7777819", "80.9248925");
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void attendanceViewDetails_Exception() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7607842101");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.9248925");
        snapWorkRequest.setDeviceId("and009");
        snapWorkRequest.setStartDate("18-11-2020");
        snapWorkRequest.setEndDate("24-11-2020");
        Map<String, Object> attendanceRow = new HashMap<>();
        attendanceRow.put("ATT_DATETIME", "Test");
        attendanceRow.put("DISPLAY_DATE", "Test");
        attendanceRow.put("LATITUDE", "26.7777819");
        attendanceRow.put("LONGITUDE", "80.9248925");
        attendanceRow.put("ADDRESS", "Noida");
        attendanceRow.put("SELFIE_PATH", "Test");
        attendanceRow.put("TYPE", "Test");
        JSONObject jsonAttendanceObj = new JSONObject();
        jsonAttendanceObj.put("address", "Noida");
        List<Map<String, Object>> attendanceRows = new ArrayList<>();
        attendanceRows.add(attendanceRow);

        doReturn(null).when(loginDAO).getAttendanceDetails_V2(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        SnapWorkResponse snapWorkResponse = loginService.attendanceViewDetails(null, null,
                null, null, null);
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void logOutAttendanceSuccessTest() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setLatitude("102 N");
        snapWorkRequest.setLongitude("108 W");
        snapWorkRequest.setUserName("Sabreena");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsGpsEnabled("Y");


        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString()))
                .thenReturn(Optional.of(promoterUserMSTEntity.get()));

        SnapWorkResponse response = loginService.logOutAttendance(snapWorkRequest);

        assertEquals(prop.getProperty("LOGOUT_SUCC_MSG"), response.getMessage());

    }

    @Test
    public void logOutAttendance_mobileNo_Blank_Fail() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setLatitude("102 N");
        snapWorkRequest.setLongitude("108 W");
        snapWorkRequest.setUserName("Sabreena");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsGpsEnabled("Y");

        SnapWorkResponse response = loginService.logOutAttendance(snapWorkRequest);

        assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"), response.getMessage());

    }

    @Test
    public void logOutAttendanceFailTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980033");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setUserName("Sabreena");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setLatitude("102 N");
        snapWorkRequest.setLongitude("108 W");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
//        promoterUserMSTEntity.get().setCategory("MER");
//        promoterUserMSTEntity.get().setStatus("A");
//        promoterUserMSTEntity.get().setId(1L);
//        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
//        promoterUserMSTEntity.get().setUserNo("9161493626");
//        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString()))
                .thenReturn(Optional.empty());

        SnapWorkResponse response = loginService.logOutAttendance(snapWorkRequest);

        assertEquals(prop.getProperty("LOGOUT_FAIL_MSG"), response.getMessage());

    }


    @Test
    public void when_logOutAttendance_Then_ThrowExceptionTest() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setLatitude("exception");

        SnapWorkResponse response = loginService.logOutAttendance(snapWorkRequest);
        assertEquals(response.getStatusCode(), prop.getProperty("FAILURE_STATUS_CODE"));

    }

    @Test
    public void isUserExistSuccessTest() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");

        when(loginDAO.isAppUserExist(Mockito.any())).thenReturn(true);
        when(loginDAO.isMobileNoExist(Mockito.any())).thenReturn(true);
        when(loginDAO.isDeviceExist(Mockito.any(), Mockito.any())).thenReturn(true);

        SnapWorkResponse response = loginService.isUserExist("7006980036", snapWorkRequest);

        assertEquals(prop.getProperty("USER_EXIST"), response.getMessage());

    }

    @Test
    public void when_isUserExist_Then_ThrowExceptionTest() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setDeviceId("exception");

        SnapWorkResponse response = loginService.isUserExist("7006980036", snapWorkRequest);
        assertEquals(response.getStatusCode(), prop.getProperty("FAILURE_STATUS_CODE"));

    }


    @Test
    public void loginWithPasswordCheckSuccessTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("A");
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("c988eae2fb53b6bd3ce509a2556e083f8be3ac545f32cf9f561db5c2e9219725");
        promoterUserProfileMSTEntity.get().setUserNo("9161493626");
        promoterUserProfileMSTEntity.get().setUserType("RM");
        Mockito.when(loginDAO.fetchUserProfileForChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        Mockito.when(commonUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("LOGIN_WITH_PASWD_SUCC_MSG"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckFailTest_PasswordBlank() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("LOGIN_WITH_PASWD_FAIL_MSG"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckFailTest_MobileNoBlank() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);

        assertEquals(prop.getProperty("LOGIN_WITH_PASWD_FAIL_MSG"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckJWTTOKENFAIL() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("A");
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("c988eae2fb53b6bd3ce509a2556e083f8be3ac545f32cf9f561db5c2e9219725");
        promoterUserProfileMSTEntity.get().setUserNo("9161493626");
        promoterUserProfileMSTEntity.get().setUserType("RM");
        Mockito.when(loginDAO.fetchUserProfileForChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        Mockito.when(commonUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
                "");
        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("LOGIN_JWT_TOKEN_GEN_FAILED"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckBlockTimePass() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("A");
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("AW@123");
        promoterUserProfileMSTEntity.get().setUserNo("9161493626");
        promoterUserProfileMSTEntity.get().setUserType("RM");
        promoterUserProfileMSTEntity.get().setAttempts(1);
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(LocalDateTime.now());

        Mockito.when(loginDAO.fetchUserProfileForChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        Mockito.when(commonUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("LOGIN_WITH_PASWD_FAIL_MSG"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckBlockTimeNotPassed() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493625");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("A");
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("AW@123");
        promoterUserProfileMSTEntity.get().setUserNo("9161493625");
        promoterUserProfileMSTEntity.get().setUserType("RM");
        promoterUserProfileMSTEntity.get().setAttempts(1);
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(LocalDateTime.now().plusMinutes(30));

        Mockito.when(loginDAO.fetchUserProfileForChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        Mockito.when(commonUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("USER_BLOCKED_FOR_WRONG_ATTEMPT"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckAttemptsLesser() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493625");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("A");
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("AW@123");
        promoterUserProfileMSTEntity.get().setUserNo("9161493625");
        promoterUserProfileMSTEntity.get().setUserType("RM");
        promoterUserProfileMSTEntity.get().setAttempts(1);
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(null);

        Mockito.when(loginDAO.fetchUserProfileForChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        Mockito.when(commonUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("LOGIN_WITH_PASWD_FAIL_MSG"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckBlockedUser() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493625");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("A");
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("AW@123");
        promoterUserProfileMSTEntity.get().setUserNo("9161493625");
        promoterUserProfileMSTEntity.get().setUserType("RM");
        promoterUserProfileMSTEntity.get().setAttempts(4);
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(null);

        Mockito.when(loginDAO.fetchUserProfileForChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        Mockito.when(commonUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("USER_BLOCKED_FOR_WRONG_ATTEMPT"), response.getMessage());
    }

    @Test
    public void loginWithPasswordCheckBlockUser1() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setPassword("A@123");
        snapWorkRequest.setIsGpsEnabled("Y");
        snapWorkRequest.setFcmToken("Qwer");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setLongitude("80.92489258");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("A");
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setPassword("c988eae2fb53b6bd3ce509a2556e083f8be3ac545f32cf9f561db5c2e9219725");
        promoterUserProfileMSTEntity.get().setUserNo("9161493626");
        promoterUserProfileMSTEntity.get().setUserType("RM");
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(LocalDateTime.now().plusMinutes(30));
        Mockito.when(loginDAO.fetchUserProfileForChannel(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        Mockito.when(commonUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        SnapWorkResponse response = loginService.loginWithPasswordCheck(snapWorkRequest);
        assertEquals(prop.getProperty("USER_BLOCKED_FOR_WRONG_ATTEMPT"), response.getMessage());
    }

    @Test
    public void when_loginWithPasswordCheck_Then_ThrowExceptionTest() {
        try {

            SnapWorkResponse response = loginService.loginWithPasswordCheck(null);

            assertEquals(response.getMessage(), prop.getProperty("FAILURE_ERROR_MESSAGE"));

        } catch (Exception e) {

        }
    }

    @Test
    public void sendOTPSuccessTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");

        JSONObject jsonMetaObj = new JSONObject();
        jsonMetaObj.put("status", "0");
        jsonMetaObj.put("description", "sms sent");
        jsonMetaObj.put("code", "000");
        jsonMetaObj.put("fesessionid", "PAPPsHzOdpTcYgCp");
        jsonMetaObj.put("verificationToken", "d8f5313e-06cf-4e0f-b2da-707b44aff9d4");

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPhe2AQNnWUx3M\",\"verificationToken\":\"7437b695-15e7-4eac-88fc-98d4b7e05219\"},\"meta\":{\"code\":\"000\",\"description\":\"sms sent\",\"status\":0}}";

        when(loginDAO.getRollName(Mockito.any())).thenReturn("Promoter");
        when(loginDAO.isAppUserExist(Mockito.any())).thenReturn(true);
        when(loginDAO.isMobileNoExist(Mockito.any())).thenReturn(true);
        when(loginDAO.isDeviceExist(Mockito.any(), Mockito.any())).thenReturn(true);

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.sendOTP("7006980036", snapWorkRequest);

        assertEquals(prop.getProperty("LOGIN_SEND_OTP_SUCC_MSG"), response.getMessage());

    }

    @Test
    public void sendOTPFailStatusTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");

        JSONObject jsonMetaObj = new JSONObject();
        jsonMetaObj.put("status", "0");
        jsonMetaObj.put("description", "sms sent");
        jsonMetaObj.put("code", "000");
        jsonMetaObj.put("fesessionid", "PAPPsHzOdpTcYgCp");
        jsonMetaObj.put("verificationToken", "d8f5313e-06cf-4e0f-b2da-707b44aff9d4");

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPhe2AQNnWUx3M\",\"verificationToken\":\"7437b695-15e7-4eac-88fc-98d4b7e05219\"},\"meta\":{\"description\":\"sms sent\",\"status\":0}}";

        when(loginDAO.getRollName(Mockito.any())).thenReturn("Promoter");
        when(loginDAO.isAppUserExist(Mockito.any())).thenReturn(true);
        when(loginDAO.isMobileNoExist(Mockito.any())).thenReturn(true);
        when(loginDAO.isDeviceExist(Mockito.any(), Mockito.any())).thenReturn(true);

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.sendOTP("7006980036", snapWorkRequest);

        assertEquals(prop.getProperty("LOGIN_SEND_OTP_FAIL_MSG"), response.getMessage());

    }


    @Test
    public void setPasswordDetailsSuccessTest() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");
        snapWorkRequest.setPassword("Airtel@1234");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setDeviceModel("Redmi");
        snapWorkRequest.setDeviceType("xvyz");
        snapWorkRequest.setAppVersion("V 1.2");
        snapWorkRequest.setFcmToken("qwerty");
        snapWorkRequest.setImei("234567006980036");
        snapWorkRequest.setLanguage("English");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setOtp("980036");
        snapWorkRequest.setOtpVerficatonCode("000");
        snapWorkRequest.setAddress("Uttar Pradesh");
        snapWorkRequest.setAppFlowName("signup");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493625");
        promoterUserMSTEntity.get().setUserType("PR");


        final String baseUrl = prop.getProperty("MERCHANT_SIGNUP");
        URI uri = new URI(baseUrl);
        SnapWorkRequest request1 = new SnapWorkRequest();
        request1.setMobileNo("7006980036");
        request1.setPassword("Airtel@1234");
        ResponseEntity<String> result = new ResponseEntity<>(HttpStatus.CREATED);
        when(restTemplate.postForEntity(uri, request1, String.class)).thenReturn(result);
        String jwtToken = "abc123";
        when(commonUtil.generateJwtToken("7006980033", 0, "mobile")).thenReturn("eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");
        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        SnapWorkResponse response = loginService.setPasswordDetailsV2(snapWorkRequest);
        assertEquals(prop.getProperty("SET_PASSWORD_SUCC_MSG"), response.getMessage());
    }

    @Test
    public void setPasswordDetailsSuccessTest1() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setPassword("Airtel@1234");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setDeviceModel("Redmi");
        snapWorkRequest.setDeviceType("xvyz");
        snapWorkRequest.setAppVersion("V 1.2");
        snapWorkRequest.setFcmToken("qwerty");
        snapWorkRequest.setImei("234567006980036");
        snapWorkRequest.setLanguage("English");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setOtp("980036");
        snapWorkRequest.setOtpVerficatonCode("000");
        snapWorkRequest.setAddress("Uttar Pradesh");
        snapWorkRequest.setAppFlowName("forgotpassword");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("7006980036");
        promoterUserMSTEntity.get().setUserType("PR");
        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("7006980036");
        promoterUserProfileMSTEntity.get().setPassword("c988eae2fb53b6bd3ce509a2556e083f8be3ac545f32cf9f561db5c2e9219725");
        promoterUserProfileMSTEntity.get().setUserType("PR");
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setDeviceId("abc123");
        Mockito.when(promoterUserProfileMSTDAO.fetchUserByUserNo(Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);

        final String baseUrl = prop.getProperty("MERCHANT_SIGNUP");
        URI uri = new URI(baseUrl);
        SnapWorkRequest request1 = new SnapWorkRequest();
        request1.setMobileNo("7006980036");
        request1.setPassword("Airtel@1234");
        ResponseEntity<String> result = new ResponseEntity<>(HttpStatus.CREATED);
        when(restTemplate.postForEntity(uri, request1, String.class)).thenReturn(result);
        String jwtToken = "abc123";
        when(commonUtil.generateJwtToken("7006980036", 0, "mobile")).thenReturn("eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxMDgwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYwNjMwMTE2MywiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijc2MDc4NDIxMDEiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYwNjMxMTk2OCwiaWF0IjoxNjA2MzAxMTY4LCJqdGkiOiIwY2RmMjZjZC04NDNkLTQzMzUtYTVjOS0yNjVmMDQ0M2FjYTUifQ.Av1wh-eTS8uZifvEd54Ve_IKwb-1eUkVDKzPM1335Xo");


        SnapWorkResponse response = loginService.setPasswordDetailsV2(snapWorkRequest);
        assertEquals(prop.getProperty("SET_PASSWORD_SUCC_MSG"), response.getMessage());
    }

    @Test
    public void setPasswordDetails_AlreadySignUpTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");
        snapWorkRequest.setPassword("Airtel@1234");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setDeviceModel("Redmi");
        snapWorkRequest.setDeviceType("xvyz");
        snapWorkRequest.setAppVersion("V 1.2");
        snapWorkRequest.setFcmToken("qwerty");
        snapWorkRequest.setImei("234567006980036");
        snapWorkRequest.setLanguage("English");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setOtp("980036");
        snapWorkRequest.setOtpVerficatonCode("000");
        snapWorkRequest.setAddress("Uttar Pradesh");
        snapWorkRequest.setAppFlowName("signup");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493625");
        promoterUserMSTEntity.get().setUserType("PR");
        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("7006980036");
        promoterUserProfileMSTEntity.get().setPassword("c988eae2fb53b6bd3ce509a2556e083f8be3ac545f32cf9f561db5c2e9219725");
        promoterUserProfileMSTEntity.get().setUserType("PR");
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setDeviceId("abc123");
        Mockito.when(promoterUserProfileMSTDAO.fetchUserByUserNo(Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);


        final String baseUrl = prop.getProperty("MERCHANT_SIGNUP");
        URI uri = new URI(baseUrl);
        SnapWorkRequest request1 = new SnapWorkRequest();
        request1.setMobileNo("7006980035");
        request1.setPassword("Airtel@1234");
        ResponseEntity<String> result = new ResponseEntity<>(HttpStatus.CREATED);
        when(restTemplate.postForEntity(uri, request1, String.class)).thenReturn(result);
        String jwtToken = "abc123";
        when(commonUtil.generateJwtToken("7006980035", 0, "mobile")).thenReturn(jwtToken);

        SnapWorkResponse response = loginService.setPasswordDetailsV2(snapWorkRequest);
        assertEquals(prop.getProperty("ALREADY_SIGNUP_USER"), response.getMessage());
    }

    @Test
    public void setPasswordDetails_BlockedUserTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");
        snapWorkRequest.setPassword("Airtel@1234");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setDeviceModel("Redmi");
        snapWorkRequest.setDeviceType("xvyz");
        snapWorkRequest.setAppVersion("V 1.2");
        snapWorkRequest.setFcmToken("qwerty");
        snapWorkRequest.setImei("234567006980036");
        snapWorkRequest.setLanguage("English");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setOtp("980036");
        snapWorkRequest.setOtpVerficatonCode("000");
        snapWorkRequest.setAddress("Uttar Pradesh");
        snapWorkRequest.setAppFlowName("forgotpassword");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493625");
        promoterUserMSTEntity.get().setUserType("PR");
        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("7006980036");
        promoterUserProfileMSTEntity.get().setPassword("c988eae2fb53b6bd3ce509a2556e083f8be3ac545f32cf9f561db5c2e9219725");
        promoterUserProfileMSTEntity.get().setUserType("PR");
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setDeviceId("abc123");
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(LocalDateTime.now().plusMinutes(30));
        Mockito.when(promoterUserProfileMSTDAO.fetchUserByUserNo(Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);


        final String baseUrl = prop.getProperty("MERCHANT_SIGNUP");
        URI uri = new URI(baseUrl);
        SnapWorkRequest request1 = new SnapWorkRequest();
        request1.setMobileNo("7006980035");
        request1.setPassword("Airtel@1234");
        ResponseEntity<String> result = new ResponseEntity<>(HttpStatus.CREATED);
        when(restTemplate.postForEntity(uri, request1, String.class)).thenReturn(result);
        String jwtToken = "abc123";
        when(commonUtil.generateJwtToken("7006980035", 0, "mobile")).thenReturn(jwtToken);

        SnapWorkResponse response = loginService.setPasswordDetailsV2(snapWorkRequest);
        assertEquals(prop.getProperty("USER_BLOCKED_FOR_WRONG_ATTEMPT"), response.getMessage());
    }

    @Test
    public void setPasswordDetailsFailTest_NotSignUp() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("9161493676");
        snapWorkRequest.setPassword("Airtel@1234");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setDeviceModel("Redmi");
        snapWorkRequest.setDeviceType("xvyz");
        snapWorkRequest.setAppVersion("V 1.2");
        snapWorkRequest.setFcmToken("qwerty");
        snapWorkRequest.setImei("234567006980036");
        snapWorkRequest.setLanguage("English");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setOtp("980036");
        snapWorkRequest.setOtpVerficatonCode("000");
        snapWorkRequest.setAddress("Uttar Pradesh");
        snapWorkRequest.setAppFlowName("forgotpassword");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493676");
        promoterUserMSTEntity.get().setUserType("PR");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        SnapWorkResponse response = loginService.setPasswordDetailsV2(snapWorkRequest);
        assertEquals(prop.getProperty("USER_IS_NOT_REGISTERED"), response.getMessage());
    }

    @Test
    public void setPasswordDetailsFailTest_StatusD() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");
        snapWorkRequest.setPassword("Airtel@1234");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setDeviceModel("Redmi");
        snapWorkRequest.setDeviceType("xvyz");
        snapWorkRequest.setAppVersion("V 1.2");
        snapWorkRequest.setFcmToken("qwerty");
        snapWorkRequest.setImei("234567006980036");
        snapWorkRequest.setLanguage("English");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setOtp("980036");
        snapWorkRequest.setOtpVerficatonCode("000");
        snapWorkRequest.setAddress("Uttar Pradesh");
        snapWorkRequest.setAppFlowName("signup");

        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("D");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493625");
        promoterUserMSTEntity.get().setUserType("PR");


        final String baseUrl = prop.getProperty("MERCHANT_SIGNUP");
        URI uri = new URI(baseUrl);
        SnapWorkRequest request1 = new SnapWorkRequest();
        request1.setMobileNo("7006980123");
        request1.setPassword("Airtel@1234");
        ResponseEntity<String> result = new ResponseEntity<>(HttpStatus.CREATED);
        when(restTemplate.postForEntity(uri, request1, String.class)).thenReturn(result);
        String jwtToken = "abc123";
        when(commonUtil.generateJwtToken("7006980033", 0, "mobile")).thenReturn(jwtToken);
        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        SnapWorkResponse response = loginService.setPasswordDetailsV2(snapWorkRequest);
        assertEquals(prop.getProperty("MOBILE_NUMBER_NOT_WHITELISTED"), response.getMessage());
    }

    @Test
    public void setPasswordDetailsFailTest_MobileNoBlank() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setPassword("Airtel@1234");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setDeviceModel("Redmi");
        snapWorkRequest.setDeviceType("xvyz");
        snapWorkRequest.setAppVersion("V 1.2");
        snapWorkRequest.setFcmToken("qwerty");
        snapWorkRequest.setImei("234567006980036");
        snapWorkRequest.setLanguage("English");
        snapWorkRequest.setLatitude("26.7777819");
        snapWorkRequest.setOtp("980036");
        snapWorkRequest.setOtpVerficatonCode("000");
        snapWorkRequest.setAddress("Uttar Pradesh");
        snapWorkRequest.setAppFlowName("forgotpassword");


        SnapWorkResponse response = loginService.setPasswordDetailsV2(snapWorkRequest);

        assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"), response.getMessage());

    }

    @Test
    public void when_setPasswordDetails_Then_ThrowExceptionTest() throws Exception {

        SnapWorkResponse response = loginService.setPasswordDetailsV2(null);
        assertEquals(response.getStatusCode(), prop.getProperty("FAILURE_STATUS_CODE"));

    }

    @Test
    public void verifyOTPSuccessTest() throws Exception {
        int count = 0;
        int isMobileRegisterCount = 1;
        String jwtToken = "";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("Y");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"000\",\"description\":\"OTP verified\",\"status\":0}}";

        when(loginDAO.updateDeleteBlockFlag(Mockito.anyString(), Mockito.anyString())).thenReturn(count);
        when(loginDAO.fetchMobileRegisterCount(Mockito.anyString())).thenReturn(isMobileRegisterCount);

        when(loginDAO.isUserDeviceExist(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        when(loginDAO.updateJWT(Mockito.anyString(), Mockito.anyString())).thenReturn(1);
        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertNotNull(response.getMessage());

    }

    @Test
    public void verifyOTPSuccessTest1() throws Exception {
        int count = 1;
        int isMobileRegisterCount = 1;
        String jwtToken = "";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("N");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"000\",\"description\":\"OTP verified\",\"status\":0}}";

        when(loginDAO.updateDeleteBlockFlag(Mockito.anyString(), Mockito.anyString())).thenReturn(count);
        when(loginDAO.fetchMobileRegisterCount(Mockito.anyString())).thenReturn(isMobileRegisterCount);

        when(loginDAO.isUserDeviceExist(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        when(loginDAO.updateJWT(Mockito.anyString(), Mockito.anyString())).thenReturn(1);
        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertNotNull(response.getMessage());

    }

    @Test
    public void verifyOTP_mobileNoBlank_Fail() throws Exception {
        int count = 1;
        int isMobileRegisterCount = 1;
        String jwtToken = "";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(" ");
        snapWorkRequest.setDeviceId(" ");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("N");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"000\",\"description\":\"OTP verified\",\"status\":0}}";

        when(loginDAO.updateDeleteBlockFlag(Mockito.anyString(), Mockito.anyString())).thenReturn(count);
        when(loginDAO.fetchMobileRegisterCount(Mockito.anyString())).thenReturn(isMobileRegisterCount);

        when(loginDAO.isUserDeviceExist(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        when(loginDAO.updateJWT(Mockito.anyString(), Mockito.anyString())).thenReturn(1);
        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"), response.getMessage());

    }

    @Test
    public void verifyOTPFailAPIResponseEmpty() throws Exception {
        int count = 0;
        int isMobileRegisterCount = 1;
        String jwtToken = "";

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("Y");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "";

        when(loginDAO.updateDeleteBlockFlag(Mockito.anyString(), Mockito.anyString())).thenReturn(count);
        when(loginDAO.fetchMobileRegisterCount(Mockito.anyString())).thenReturn(isMobileRegisterCount);

        when(loginDAO.isUserDeviceExist(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        when(loginDAO.updateJWT(Mockito.anyString(), Mockito.anyString())).thenReturn(1);
        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals(prop.getProperty("LOGIN_VERIFY_OTP_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void verifyOTPFailAPIStatusNotContain() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("Y");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"000\",\"description\":\"OTP verified\"}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals(prop.getProperty("LOGIN_VERIFY_OTP_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void verifyOTPFailAPIdescriptionNotContain() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("Y");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"001\",\"description\":\"OTP Not verified\",\"status\":0}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals("OTP Not verified", response.getMessage());

    }

    @Test
    public void verifyOTPFail_throwException() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");
        snapWorkRequest.setDeviceId("abc123");
        snapWorkRequest.setIsUserExist("Y");
        snapWorkRequest.setIsUserDeviceExist("Y");

        String otpVerficatonCode = "000";
        String otp = "980036";


        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, null);

        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());

    }

    @Test
    public void isRefreshToKenSuccessTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        when(loginDAO.updateJWT(Mockito.anyString(), Mockito.any())).thenReturn(1);

        SnapWorkResponse response = loginService.isRefreshToKen(snapWorkRequest);

        assertEquals(prop.getProperty("JWT_GENERATED_SUCCESSFULLY"), response.getMessage());

    }

    @Test
    public void profileUploadDetails_success() throws Exception {
        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));
        String mobileNo = "9876543220";
        when(uploadDocumentsDAO.saveUserSelfieId(Mockito.anyString(), Mockito.anyString())).thenReturn(true);

        SnapWorkResponse response = loginService.profileUploadDetails(mobileNo, multipartFile);

        assertNotNull(response);
    }

    @Test
    public void profileUploadDetails_fail() throws Exception {
        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));
        String mobileNo = "9876543220";
        when(uploadDocumentsDAO.saveUserSelfieId(Mockito.anyString(), Mockito.anyString())).thenReturn(false);

        SnapWorkResponse response = loginService.profileUploadDetails(mobileNo, multipartFile);

        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());

    }

    @Test
    public void profileUploadDetails_throwException() throws Exception {
        File file = new File("src/test/resources/vpnimage.jpg");
        FileInputStream input = new FileInputStream(file);

        String mobileNo = "";

        SnapWorkResponse response = loginService.profileUploadDetails(mobileNo, null);

        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());

    }
}