package com.airtelbank.myteam.dao;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import com.airtelbank.bean.ActivityTrackerBean;
import com.airtelbank.util.PropertyManager;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class ActivityTrackerDAOTest {
	
	@Autowired
	ActivityTrackerDAO activityTrackerDAO;

	@MockBean
	JdbcTemplate jdbcTemplate;

	@BeforeEach
	private void setUp()
	{
	    MockitoAnnotations.initMocks(this);
	}

	@MockBean
	PropertyManager prop;

	@Test
	public void saveActivityTrackerDtlsSuccessTest() throws Exception 
	{
	    List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("mobileNo", "7006980036");
		map.put("latitude", "26.7777819");
		map.put("longitude", "80.9248925");
		rows.add(map);
	     
	    final  ActivityTrackerBean obj = new ActivityTrackerBean();
	    obj.setMobileNo("7006980036");
	    obj.setLatitude("26.7777819");
	    obj.setLongitude("80.9248925");
	     
	    String query = "";
	    
	    when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int rowcount = activityTrackerDAO.saveActivityTrackerDtls(obj);

		assertTrue(rowcount == 1);
		 
	}
}