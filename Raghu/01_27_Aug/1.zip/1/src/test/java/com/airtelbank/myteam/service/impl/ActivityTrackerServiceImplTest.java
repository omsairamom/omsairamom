package com.airtelbank.myteam.service.impl;

import com.airtelbank.bean.ActivityTrackerBean;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.dao.ActivityTrackerDAO;
import com.airtelbank.myteam.service.ActivityTrackerService;
import com.airtelbank.util.PropertyManager;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class ActivityTrackerServiceImplTest
{
    @Autowired
    PropertyManager prop;

    @Autowired
    ActivityTrackerService activityTrackerService;

    @Autowired
    SnapWorkRequest request;

    @MockBean
    ActivityTrackerDAO activityTrackerDAO;

    @Test
    void activityTrackerDetails_Success() throws Exception
    {
        ActivityTrackerBean obj = new ActivityTrackerBean();
        obj.setMobileNo("9934049049");
        obj.setLatitude("28.09090");
        obj.setLongitude("20.90900");

        when(activityTrackerDAO.saveActivityTrackerDtls(obj)).thenReturn(1);

        SnapWorkResponse response = activityTrackerService.activityTrackerDetails(snapWorkRequestModelObj());

        assertEquals(prop.getProperty("ACTIVITY_TRACKER_DTLS_SUCC_MSG"), response.getMessage());

    }

    @Test
    void activityTrackerDetails_Fail() throws Exception
    {
        JSONArray trackerInfo = new JSONArray();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setTrackerInfo(trackerInfo);

        ActivityTrackerBean obj = new ActivityTrackerBean();
        obj.setMobileNo("9934049049");
        obj.setLatitude("28.09090");
        obj.setLongitude("20.90900");

        when(activityTrackerDAO.saveActivityTrackerDtls(obj)).thenReturn(1);

        SnapWorkResponse response = activityTrackerService.activityTrackerDetails(snapWorkRequest);

        assertEquals(prop.getProperty("ACTIVITY_TRACKER_INVALID_REQUEST"), response.getMessage());

    }

    @Test
    void activityTrackerDetails_Exception() throws Exception
    {
        ActivityTrackerBean obj = new ActivityTrackerBean();
        obj.setMobileNo("9934049049");
        obj.setLatitude("28.09090");
        obj.setLongitude("20.90900");

        when(activityTrackerDAO.saveActivityTrackerDtls(obj)).thenReturn(1);

        SnapWorkResponse response = activityTrackerService.activityTrackerDetails(null);

        assertEquals(response.getMessage(), prop.getProperty("FAILURE_ERROR_MESSAGE"));
    }

    public SnapWorkRequest snapWorkRequestModelObj()
    {
        JSONArray trackerInfo = new JSONArray();

        JSONObject trackerJson = new JSONObject();
        trackerJson.put("seqId", "108");
        trackerJson.put("mobileNo", "9839057135");
        trackerJson.put("latitude", "21.90909");
        trackerJson.put("longitude", "22.9090");
        trackerInfo.add(trackerJson);

        JSONObject json = new JSONObject();
        json.put("trackerInfo", trackerJson);

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setTrackerInfo(trackerInfo);
        return snapWorkRequest;
    }
}