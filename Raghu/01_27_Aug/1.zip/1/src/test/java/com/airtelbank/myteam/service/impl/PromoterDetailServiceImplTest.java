package com.airtelbank.myteam.service.impl;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.entity.PromoterUserKYCMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.dao.PromoterUserKYCMSTDAO;
import com.airtelbank.myteam.dao.PromoterUserMSTDAO;
import com.airtelbank.myteam.service.PromoterDetailService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.time.LocalDateTime;
import java.util.Optional;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterDetailServiceImplTest
{
    @Autowired
    PromoterDetailService promoterDetailService;

    @Autowired
    PropertyManager prop;

    @Autowired
    SnapWorkRequest request;

    @MockBean
    CommonUtils commonUtils;

    @MockBean
    PromoterUserMSTDAO promoterUserMSTDAO;

    @MockBean
    PromoterUserKYCMSTDAO promoterUserKYCMSTDAO;

    @BeforeEach
    void setUp()
    {

    }

    @Test
    void getPromoterDetail_With_MSISDN_STATUS_A_Success()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135"))
                .thenReturn(promoterUserMSTEntity);

        Optional<PromoterUserKYCMSTEntity> promoterUserKYCMSTEntity = Optional.of(new PromoterUserKYCMSTEntity());
        promoterUserKYCMSTEntity.get().setAadhaarRefNumber("88888888888");

        Mockito.when(promoterUserKYCMSTDAO.fetchPromoterUserKYCMST(promoterUserMSTEntity.get())).thenReturn(promoterUserKYCMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("9839057135", Optional.of("A"));

        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_MSISDN_STATUS_D_Success()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("D");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135"))
                .thenReturn(Optional.of(promoterUserMSTEntity.get()));

        Optional<PromoterUserKYCMSTEntity> promoterUserKYCMSTEntity = Optional.of(new PromoterUserKYCMSTEntity());
        promoterUserKYCMSTEntity.get().setAadhaarRefNumber("88888888888");

        Mockito.when(promoterUserKYCMSTDAO.fetchPromoterUserKYCMST(promoterUserMSTEntity.get())).thenReturn(promoterUserKYCMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("9839057135", Optional.of("D"));

        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_MSISDN_STATUS_A_Fail()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("D");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135"))
                .thenReturn(promoterUserMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("9839057135", Optional.of("A"));

        //Deepak
        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_MSISDN_STATUS_D_Fail()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");


        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135"))
                .thenReturn(promoterUserMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("9839057135", Optional.of("D"));

        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_MSISDN_STATUS_C_Fail()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("D");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135"))
                .thenReturn(promoterUserMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("9839057135", Optional.of("C"));

        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_MSISDN_STATUS_NULL()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("D");
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUserType("RM");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9839057135"))
                .thenReturn(promoterUserMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("9839057135", Optional.empty());

        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_MSISDN_STATUS_A_FAIL()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9161493626"))
                .thenReturn(promoterUserMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("9161493626", Optional.of("A"));

        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_FAIL()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setStatus("A");

        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9161493626"))
                .thenReturn(promoterUserMSTEntity);

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("", Optional.of("A"));

        assertNotNull(snapWorkResponse);
    }

    @Test
    void getPromoterDetail_With_ERROR()
    {
        Mockito.when(promoterUserMSTDAO.fetchUserByPhoneNumber("9161493626"))
                .thenThrow(new RuntimeException());

        JSONObject snapWorkResponse =
                promoterDetailService.getPromoterDetail("EXCEPTION", Optional.of("EXCEPTION"));

        assertNotNull(snapWorkResponse);
    }
}