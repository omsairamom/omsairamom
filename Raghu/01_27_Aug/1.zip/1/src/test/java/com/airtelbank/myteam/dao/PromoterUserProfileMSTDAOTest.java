package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.myteam.repository.PromoterUserProfileMSTRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterUserProfileMSTDAOTest {

    @InjectMocks
    PromoterUserProfileMSTDAO promoterUserProfileMSTDAO;

    @Mock
    PromoterUserProfileMSTRepository promoterUserProfileMSTRepository;

    @BeforeEach
    void setUp() {
    }

    @Test
    void fetchUserByUserNo() {

        Optional<PromoterUserProfileMSTEntity> item =
                Optional.of(new PromoterUserProfileMSTEntity());
        Mockito.when(promoterUserProfileMSTRepository.findOneByUserNo(Mockito.anyString())).thenReturn(item);
        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
        promoterUserProfileMSTDAO.fetchUserByUserNo("9839057135");
        assertNotNull(promoterUserProfileMSTEntity);
    }

    @Test
    void saveUserProfile() {
        PromoterUserProfileMSTEntity promoterUserProfileMSTEntity = new PromoterUserProfileMSTEntity();
        Mockito.when(promoterUserProfileMSTRepository.save(Mockito.any())).thenReturn(promoterUserProfileMSTEntity);
        int i = promoterUserProfileMSTDAO.saveUserProfile(new PromoterUserProfileMSTEntity());
        assertNotNull(i);
    }

    @Test
    void updateProfile() {
        Optional<PromoterUserProfileMSTEntity> item =
                Optional.of(new PromoterUserProfileMSTEntity());
        Mockito.when(promoterUserProfileMSTRepository
                .updatePassword(Mockito.anyString(), Mockito.anyString())).thenReturn(1);
        int i = promoterUserProfileMSTDAO.updateProfile("12121","9839057135");
        assertNotNull(i);
    }
}