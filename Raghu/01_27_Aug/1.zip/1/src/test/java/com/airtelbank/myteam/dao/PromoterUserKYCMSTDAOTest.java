package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterUserKYCMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterUserKYCMSTRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.Optional;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterUserKYCMSTDAOTest
{
    @InjectMocks
    PromoterUserKYCMSTDAO promoterUserKYCMSTDAO;

    @Mock
    PromoterUserKYCMSTRepository promoterUserKYCMSTRepository;

    @BeforeEach
    void setUp()
    {

    }

    @Test
    void fetchPromoterUserKYCMST()
    {
        Optional<PromoterUserKYCMSTEntity> promoterUserKYCMSTEntity =
                Optional.of(new PromoterUserKYCMSTEntity());
        promoterUserKYCMSTEntity.get().setKuaCountry("INR");

        Mockito.when(promoterUserKYCMSTRepository.findById(1L)).thenReturn(promoterUserKYCMSTEntity);

        Optional<PromoterUserKYCMSTEntity> response =
                promoterUserKYCMSTDAO.fetchPromoterUserKYCMST(new PromoterUserMSTEntity());

        assertNotNull(response);
    }
}