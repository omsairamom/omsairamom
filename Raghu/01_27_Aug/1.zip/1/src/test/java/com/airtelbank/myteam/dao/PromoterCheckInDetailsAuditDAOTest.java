package com.airtelbank.myteam.dao;
import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterCircleMSTEntity;
import com.airtelbank.entity.PromoterOutletMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterCheckInDetailsAuditRepository;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.Optional;
import static org.mockito.Mockito.doReturn;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterCheckInDetailsAuditDAOTest
{
    @InjectMocks
    PromoterCheckInDetailsAuditDAO promoterCheckInDetailsAuditDAO;
    @Mock
    PromoterCheckInDetailsAuditRepository promoterCheckInDetailsAuditRepository;
    @BeforeEach
    void setUp() {
    }
    @Test
    void saveAndFlushCheckInDetails() {
        PromoterCheckInDetailsAuditEntity promoterCheckIn =
                new PromoterCheckInDetailsAuditEntity();
        promoterCheckIn.setId(1L);
        promoterCheckIn.setPromoterNo("123445");
        PromoterUserMSTEntity promoterUserMSTEntity = new PromoterUserMSTEntity();
        promoterUserMSTEntity.setId(1L);
        promoterUserMSTEntity.setUsername("HCL");
        promoterCheckIn.setPromoterUserMSTEntity(promoterUserMSTEntity);

        PromoterOutletMSTEntity promoterOutletMSTEntity = new PromoterOutletMSTEntity();
        promoterOutletMSTEntity.setId(1L);
        promoterOutletMSTEntity.setPromoterNo("!");
        promoterCheckIn.setPromoterOutletMSTEntity(promoterOutletMSTEntity);

        PromoterCircleMSTEntity promoterCircleMSTEntity = new PromoterCircleMSTEntity();
        promoterCircleMSTEntity.setId(1L);
        promoterCircleMSTEntity.setCircleId("1");
        promoterCheckIn.setPromoterCircleMSTEntity(promoterCircleMSTEntity);

        doReturn(promoterCheckIn).when(promoterCheckInDetailsAuditRepository).saveAndFlush(Mockito.any());
        PromoterCheckInDetailsAuditEntity response =
                promoterCheckInDetailsAuditDAO.saveAndFlushCheckInDetails(promoterCheckIn);
        Assert.assertNotNull(response);
    }
}