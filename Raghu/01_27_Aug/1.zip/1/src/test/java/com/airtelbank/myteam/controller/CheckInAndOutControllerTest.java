package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.service.CheckInAndOutService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import javax.servlet.http.HttpServletRequest;
import static org.junit.Assert.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class CheckInAndOutControllerTest
{
    @InjectMocks
    CheckInAndOutController checkInAndOutController;

    @Mock
    CheckInAndOutService chkInOutService;

    @Mock
    CommonUtils commonUtil;

    @Mock
    PropertyManager prop;

    @Mock
    HttpServletRequest httpServletRequest;

    @Before
    public void setUp()
    {
        ReflectionTestUtils.setField(checkInAndOutController,prop.getProperty(Constants.FAILURE_STATUS_CODE),"500");
    }

    @Test
    public void checkInDetailsV2_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setOutletNo("9839057138");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("DASHBOARD_CHECKIN_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");

        Mockito.when(chkInOutService.checkInDetailsV2(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(response);
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkInDetailsV2(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getMessage(), snapWorkResponse.getMessage());
    }

    @Test
    public void checkInDetailsV2_Fail() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setOutletNo(null);

        JSONObject jsonObject = new JSONObject();
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage("failed");
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkInDetailsV2(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void checkInDetailsV2_throwException() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
        SnapWorkRequest request = null;
        ResponseEntity<Object> responseEntity = checkInAndOutController.checkInDetailsV2(request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
        assertNotNull(snapWorkResponse);
    }

    @Test
    public void checkOutDetailsV2_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setOutletNo("9839057135");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("DASHBOARD_CHECKOUT_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");

        Mockito.when(chkInOutService.checkOutDetailsV2(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                checkInAndOutController.checkOutDetailsV2(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getMessage(), response.getMessage());
    }

    @Test
    public void checkOutDetailsV2_Fail() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setOutletNo("");

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkOutDetailsV2(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void checkOutDetailsV2_throwException()
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest request = null;

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkOutDetailsV2(request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void checkInOutStatus_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setOutletNo("9999755652");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("DASHBOARD_CHECKINANDOUT_DETAILS_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");
        Mockito.when(chkInOutService.checkInOutStatus(Mockito.any())).thenReturn(response);
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkInOutStatus();
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getMessage(), response.getMessage());
    }

    @Test
    public void checkInOutStatus_Fail_1() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setProMobileNo("");

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"9839057135\"\n" +
                "}");
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkInOutStatus();
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNull(snapWorkResponse);
    }

    @Test
    public void checkInOutStatus_Fail_2() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setProMobileNo(null);

        Mockito.when(httpServletRequest.getHeader(Mockito.any())).thenReturn("{\n" +
                "  \"mobileno\": \"" +
                "}");
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkInOutStatus();
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void checkInOutStatus_throwException()
    {
        SnapWorkResponse response = new SnapWorkResponse();
        SnapWorkRequest request = null;

        ResponseEntity<Object> responseEntity = checkInAndOutController.checkInOutStatus();
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }
}