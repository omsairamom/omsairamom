package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.service.impl.ActivityTrackerServiceImpl;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.PropertyManager;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class ActivityTrackerControllerTest
{
    @Mock
    ActivityTrackerServiceImpl activityTrackerService;

    @Mock
    CommonUtils commonUtil;

    @Autowired
    PropertyManager prop;

    @Mock
    PropertyManager propMock;

    @InjectMocks
    ActivityTrackerController activityTrackerController;

//    @Mock
//    SnapWorkResponse response;

    @Test
    void activityTrackerDetails_Success() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("ACTIVITY_TRACKER_DTLS_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));

        Mockito.when(activityTrackerService.activityTrackerDetails(Mockito.any())).thenReturn(response);
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                activityTrackerController.activityTrackerDetails(snapWorkRequestModelObj());
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    void activityTrackerDetails_Fail() throws Exception
    {
        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("ACTIVITY_TRACKER_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        response.setResponse(jsonObject);

        JSONArray trackerInfo = new JSONArray();

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setTrackerInfo(trackerInfo);


//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");
        Mockito.when(activityTrackerService.activityTrackerDetails(Mockito.any())).thenReturn(response);
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = activityTrackerController.activityTrackerDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
     //   assertEquals(snapWorkResponse.getStatusCode() , response.getStatusCode());

    }

//    //@Test
//    void activityTrackerDetails_Fail_1() throws Exception
//    {
//        SnapWorkResponse response = new SnapWorkResponse();
//
//        JSONArray trackerInfo = new JSONArray();
//
//        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
//        snapWorkRequest.setTrackerInfo(null);
//
//
//        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
//        Mockito.when(response.getStatusCode()).thenReturn("500");
//
//        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
//
//        ResponseEntity<Object> responseEntity = activityTrackerController.activityTrackerDetails(snapWorkRequest);
//        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
//
//        assertEquals( "500", snapWorkResponse.getStatusCode());
//
//    }

    @Test
    public void activityTrackerDetails_throwException() throws Exception
    {
        SnapWorkResponse response = new SnapWorkResponse();

        SnapWorkRequest request = null;

//        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
//        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        ResponseEntity<Object> responseEntity = activityTrackerController.activityTrackerDetails(request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);

    }

    public SnapWorkRequest snapWorkRequestModelObj()
    {
        JSONArray trackerInfo = new JSONArray();

        JSONObject trackerJson = new JSONObject();
        trackerJson.put("seqId", "108");
        trackerJson.put("mobileNo", "9839057135");
        trackerJson.put("latitude", "21.90909");
        trackerJson.put("longitude", "22.9090");
        trackerInfo.add(trackerJson);

        JSONObject json = new JSONObject();
        json.put("trackerInfo", trackerJson);

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setTrackerInfo(trackerInfo);
        return snapWorkRequest;
    }
}