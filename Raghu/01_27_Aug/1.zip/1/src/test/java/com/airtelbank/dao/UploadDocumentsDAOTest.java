package com.airtelbank.dao;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.entity.PromoterAttendanceAuditEntity;
import com.airtelbank.entity.PromoterCaptureComplianceEntity;
import com.airtelbank.entity.PromoterCircleMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterAttendanceAuditRepository;
import com.airtelbank.myteam.repository.PromoterCaptureComplianceRepository;
import com.airtelbank.myteam.repository.PromoterUserMSTRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.time.LocalDateTime;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doReturn;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class UploadDocumentsDAOTest
{
    @InjectMocks
    UploadDocumentsDAO uploadDocumentsDAO;

    @Mock
    PromoterUserMSTRepository promoterUserMSTRepository;

    @Mock
    PromoterAttendanceAuditRepository promoterAttendanceAuditRepository;

    @Mock
    PromoterCaptureComplianceRepository promoterCaptureComplianceRepository;

    @Test
    void fetchEODSubmitAttendanceDetails() {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUsername("HCL");
        promoterUserMSTEntity.get().setUserType("");
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setAgency("A");
        PromoterCircleMSTEntity promoterCircleMSTEntity = new PromoterCircleMSTEntity();
        promoterCircleMSTEntity.setId(1L);
        promoterCircleMSTEntity.setCircleName("A");
        promoterCircleMSTEntity.setDescription("Test");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity);
        promoterUserMSTEntity.get().setEmployeeId("1");
        promoterUserMSTEntity.get().setParentNo("1");
        promoterUserMSTEntity.get().setParentType("1");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        Mockito.when(promoterUserMSTRepository.findOneByUserNo(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        boolean uploadDoc =  uploadDocumentsDAO.fetchEODSubmitAttendanceDetails("9161493626");
        assertFalse( uploadDoc );
    }

    @Test
    void saveAttendanceDetails() {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUsername("HCL");
        promoterUserMSTEntity.get().setUserType("");
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setAgency("A");
        PromoterCircleMSTEntity promoterCircleMSTEntity = new PromoterCircleMSTEntity();
        promoterCircleMSTEntity.setId(1L);
        promoterCircleMSTEntity.setCircleName("A");
        promoterCircleMSTEntity.setDescription("Test");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity);
        promoterUserMSTEntity.get().setEmployeeId("1");
        promoterUserMSTEntity.get().setParentNo("1");
        promoterUserMSTEntity.get().setParentType("1");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());

        AttendanceBean attendanceBean = new AttendanceBean();
        attendanceBean.setAddress("HCL");
        attendanceBean.setLongitude("10.10");
        attendanceBean.setLatitude("11.10");
        attendanceBean.setMobileNo("9161493626");
        PromoterAttendanceAuditEntity  promoterAttendanceAuditEntity = new PromoterAttendanceAuditEntity();
        promoterAttendanceAuditEntity.setId(1l);
        promoterAttendanceAuditEntity.setPromoterNo("9161493626");
        doReturn(promoterUserMSTEntity).when(promoterUserMSTRepository).findOneByUserNo(Mockito.anyString());
        Mockito.when(promoterAttendanceAuditRepository.save(Mockito.any())).thenReturn(promoterAttendanceAuditEntity);
        int value = uploadDocumentsDAO.saveAttendanceDetails(attendanceBean);
        assertEquals(1,value);

    }

    @Test
    void saveUserSelfieId()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setSelfieId("8274982");

        Mockito.when(promoterUserMSTRepository
                .findOneByUserNo(Mockito.anyString())).thenReturn(promoterUserMSTEntity);

        boolean response =
                uploadDocumentsDAO.saveUserSelfieId("79879","9839057135");

        assertNotNull(response);
    }

    @Test
    void captureCompliance() {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                Optional.of(new PromoterUserMSTEntity());
        promoterUserMSTEntity.get().setId(1L);
        promoterUserMSTEntity.get().setUserNo("9161493626");
        promoterUserMSTEntity.get().setUsername("HCL");
        promoterUserMSTEntity.get().setUserType("");
        promoterUserMSTEntity.get().setCategory("MER");
        promoterUserMSTEntity.get().setAgency("A");
        PromoterCircleMSTEntity promoterCircleMSTEntity = new PromoterCircleMSTEntity();
        promoterCircleMSTEntity.setId(1L);
        promoterCircleMSTEntity.setCircleName("A");
        promoterCircleMSTEntity.setDescription("Test");
        promoterUserMSTEntity.get().setPromoterCircleMSTEntity(promoterCircleMSTEntity);
        promoterUserMSTEntity.get().setEmployeeId("1");
        promoterUserMSTEntity.get().setParentNo("1");
        promoterUserMSTEntity.get().setParentType("1");
        promoterUserMSTEntity.get().setStatus("A");
        promoterUserMSTEntity.get().setDob(LocalDateTime.now());
        Mockito.when(promoterUserMSTRepository.findOneByUserNo(Mockito.anyString())).thenReturn(promoterUserMSTEntity);
        PromoterCaptureComplianceEntity promoterCaptureComplianceEntity = new PromoterCaptureComplianceEntity();
        promoterCaptureComplianceEntity.setId(1L);
        promoterCaptureComplianceEntity.setDocumentId("1");
        Mockito.when(promoterCaptureComplianceRepository.save(Mockito.any())).thenReturn(promoterCaptureComplianceEntity);
        boolean value = uploadDocumentsDAO.captureCompliance("1","9161493626");
        assertTrue(value);
    }
}