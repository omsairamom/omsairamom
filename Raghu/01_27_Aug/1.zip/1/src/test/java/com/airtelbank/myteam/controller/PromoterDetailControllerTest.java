package com.airtelbank.myteam.controller;

import com.airtelbank.model.PromoterDetail.Data;
import com.airtelbank.model.PromoterDetail.Meta;
import com.airtelbank.model.PromoterDetail.PromoterDetail;
import com.airtelbank.myteam.service.PromoterDetailService;
import com.airtelbank.util.PropertyManager;
import com.google.gson.Gson;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.Optional;
import static org.junit.Assert.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterDetailControllerTest
{

    @InjectMocks
    PromoterDetailController promoterDetailController;

    @Mock
    PromoterDetailService promoterDetailService;


    @Autowired
    PropertyManager prop;

    @BeforeEach
    void setUp()
    {

    }

    @Test
    void getPromoterDetails() throws ParseException
    {
        PromoterDetail promoterDetail = new PromoterDetail();

        Meta meta = new Meta();
        Data data = new Data();

        meta.setCode("000");
        meta.setStatus(500);
        meta.setDescription("Invalid User");

        data.setMsisdn("9839057138");

        promoterDetail.setMeta(meta);
        promoterDetail.setData(data);

        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(new Gson().toJson(promoterDetail));

        Mockito.when(promoterDetailService.getPromoterDetail( "9839057135", Optional.of("A"))).thenReturn(json);

        ResponseEntity<Object> responseEntity = promoterDetailController.getPromoterDetails("9839057135", Optional.of("A"));
        JSONObject snapWorkResponse = (JSONObject) responseEntity.getBody();

        assertEquals(snapWorkResponse.toString(), json.toString());
    }
}