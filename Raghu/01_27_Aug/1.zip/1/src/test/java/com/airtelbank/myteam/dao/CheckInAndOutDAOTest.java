package com.airtelbank.myteam.dao;

import com.airtelbank.bean.CheckInOutBean;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterCheckInDetailsAuditRepository;
import com.airtelbank.util.PropertyManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class CheckInAndOutDAOTest
{
    @Autowired
    CheckInAndOutDAO checkInAndOutDAO;

    @MockBean
    PromoterCheckInDetailsAuditRepository promoterCheckInDetailsAuditRepository;

    @MockBean
    JdbcTemplate jdbcTemplate;

    @MockBean
    PropertyManager prop;

    @BeforeEach
    private void setUp()
    {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void saveCheckInOutDeatils() throws Exception
    {
        CheckInOutBean obj = new CheckInOutBean();
        obj.setRetMobileNo("7006980036");
        obj.setProMobileNo("7006980036");
        obj.setType("M");
        obj.setInOrOut("0");
        obj.setLatitude("26.7777819");
        obj.setLongitude("26.7777819");
        obj.setStoreName("Deepak");
        obj.setMarryDist("0.0");
        obj.setDateOfVisit("09-12-2020");
        obj.setField1("NA");
        obj.setField2("NA");
        obj.setField3("NA");
        obj.setField4("NA");
        obj.setField5("NA");

        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("mobileNo", "7006980036");
        map.put("latitude", "26.7777819");
        map.put("longitude", "80.9248925");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        when(jdbcTemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

        int rowcount =
                checkInAndOutDAO.saveCheckInOutDeatils(obj);

        assertEquals(0, rowcount);
    }

    @Test
    public void getRetailerDetails_SuccessTest() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");


        Map<String, Object> row = new HashMap<>();
        row.put("MOBILENO", "7006980035");

        List<Map<String, Object>> rows  = new ArrayList<>();
        rows.add(row);

        String query = "";
        when( prop.getProperty("CHECK_INOUT_FETCH_RETAILER_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> list = checkInAndOutDAO.getRetailerDetails(snapWorkRequest.getMobileNo());

        assertEquals(list , rows);

    }

    @Test
    public void getRetailerAddress_SuccessTest() throws Exception
    {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980035");


        Map<String, Object> row = new HashMap<>();
        row.put("MOBILENO", "7006980035");
        row.put("VILLAGE_NAME", "noida");
        row.put("BLOCK_TEHSIL", "Noida");
        row.put("DISTRICT", "Noida");
        row.put("CITY", "Noida");

        List<Map<String, Object>> rows  = new ArrayList<>();
        rows.add(row);

        String addr = rows.get(0).get("VILLAGE_NAME").toString();
        addr = addr + ", " + rows.get(0).get("BLOCK_TEHSIL").toString();
        addr = addr + ", " + rows.get(0).get("DISTRICT").toString();
        addr = addr + ", " + rows.get(0).get("CITY").toString();


        String query = "";
        when( prop.getProperty("CHECK_INOUT_FETCH_RETAILER_ADDRESS_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        String address = checkInAndOutDAO.getRetailerAddress(snapWorkRequest.getMobileNo());

        assertTrue(address.equals(addr));

    }

    @Test
    void isAppUserExist() throws Exception
    {
        Map<String, Object> row = new HashMap<>();
        row.put("LAPU_NO", "7006980036");

        List<Map<String, Object>> rows  = new ArrayList<>();
        rows.add(row);

        String query = "";
        when( prop.getProperty("CHECK_INOUT_APP_USER_EXIST_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag =
                checkInAndOutDAO.isAppUserExist("7006980036");

        assertEquals(true, flag);

    }

    @Test
    void isMappedUserExist() throws Exception
    {
        Map<String, Object> row = new HashMap<>();
        row.put("LAPU_NO", "7006980036");

        List<Map<String, Object>> rows  = new ArrayList<>();
        rows.add(row);

        String query = "";
        when( prop.getProperty("CHECK_INOUT_MAPPED_USER_EXIST_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        boolean flag =
                checkInAndOutDAO.isMappedUserExist("7006980036", "7006980036","Merchant");

        assertEquals(true , flag);

    }

    @Test
    void getCheckInCheckOutDetails()
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        Map<String, Object> row = new HashMap<>();
        row.put("MOBILENO", "7006980036");

        List<Map<String, Object>> rows  = new ArrayList<>();
        rows.add(row);

        String query = "";
        when( prop.getProperty("CHECK_IN_CHECKOUT_DTLS")).thenReturn(query);
        when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> list =
                checkInAndOutDAO.getCheckInCheckOutDetails(snapWorkRequest.getMobileNo());

        assertEquals(list , rows);
    }

    @Test
    void getCheckInCheckOutDetails_V2()
    {
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity = Optional.of(new PromoterUserMSTEntity());

        List<PromoterCheckInDetailsAuditEntity> items = new ArrayList<>();

        Mockito.when(promoterCheckInDetailsAuditRepository.getPromoterDetailsByID(Mockito.anyLong())).thenReturn(items);

        List<PromoterCheckInDetailsAuditEntity> promoterCheckInDetailsAuditEntities =
                checkInAndOutDAO.getCheckInCheckOutDetails_V2(Optional.of(promoterUserMSTEntity.get()));

        assertNotNull(promoterCheckInDetailsAuditEntities);
    }
}