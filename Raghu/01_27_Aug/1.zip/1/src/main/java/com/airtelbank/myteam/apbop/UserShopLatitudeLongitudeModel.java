package com.airtelbank.myteam.apbop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserShopLatitudeLongitudeModel
{
    private String shopLatitude;
    private String shopLongitude;
}
