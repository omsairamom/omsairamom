package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterOutletMSTEntity;
import com.airtelbank.myteam.repository.PromoterOutletMSTRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class PromoterOutletMSTDAO {

    @Autowired
    PromoterOutletMSTRepository promoterOutletMSTRepository;

    public Optional<PromoterOutletMSTEntity> fetchOutletByOutletNo(String promoterNo)
    {
        return promoterOutletMSTRepository.findOneByPromoterNo(promoterNo);
    }
}
