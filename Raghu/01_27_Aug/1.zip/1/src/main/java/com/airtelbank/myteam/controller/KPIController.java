package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.dao.KpiDAO;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class KPIController
{
	private static Logger logger = LoggerFactory.getLogger(KPIController.class);
	
	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();
	
	@Autowired
    KpiDAO kpiDAO;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	PropertyManager prop;
	
	@PostMapping(path="/v1/dashboard/fetch-kpi")
	public ResponseEntity<Object> fetchKPIDetails_v2(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try 
		{
			startTime = System.currentTimeMillis();
			logger.info("Fetch KPI details, Request start timeInMillis {}:" , startTime);
			
			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim(); 
			
			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo)) 
			{
				response = kpiDAO.fetchKPIDetailsV2(mobileNo);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}
			
			logger.info("Fetch KPI details, Response {}: " , gson.toJson(response));
			endTime = System.currentTimeMillis();
			logger.info("Fetch KPI details, Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("************************************************************************************************************************************* {}:" , "");
		}
		
		catch(Exception exe)
		{    
            commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
