package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterKPICategoryMSTEntity;
import com.airtelbank.entity.PromoterKPIDetailsMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromoterKPIDetailsMSTRepository extends JpaRepository<PromoterKPIDetailsMSTEntity, Long> {

    List<PromoterKPIDetailsMSTEntity> findAllByCatIdAndStatusEnableAndPromoterTypeIn(Long catId, String statusEnable, List<String> promoterType);

    List<PromoterKPIDetailsMSTEntity> findAllByCatIdAndStatusEnable(Long catId, String statusEnable);

}
