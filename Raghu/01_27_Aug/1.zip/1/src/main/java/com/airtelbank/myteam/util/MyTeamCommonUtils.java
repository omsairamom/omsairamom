package com.airtelbank.myteam.util;

import java.text.DecimalFormat;

import com.airtelbank.myteam.common.CommonException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 18, 2019 11:34:45 AM
 */
@Service
public class MyTeamCommonUtils {

	private static Logger logger = LoggerFactory.getLogger(MyTeamCommonUtils.class);
	
	public String calculateMarryDistance(String lat1, String lat2, String lon1, String lon2) {
		
		double distance = 0;
		DecimalFormat decimalFormat = new DecimalFormat("#.0000");
		
		try {
			double latitude1 = Double.parseDouble(lat1);
			double latitude2 = Double.parseDouble(lat2);
			double longitude1 = Double.parseDouble(lon1);
			double longitude2 = Double.parseDouble(lon2);
			
			final int R = 6371;

			double latDistance = Math.toRadians(latitude2 - latitude1);
			double lonDistance = Math.toRadians(longitude2 - longitude1);

			double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(latitude1))
					* Math.cos(Math.toRadians(latitude2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);

			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
			
			distance = R * c * 1000;

		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		}
		return decimalFormat.format(distance);

	}

	public String convertMillis(long totalMilliseconds){
		String time = "";
		try {
			int seconds = (int) (totalMilliseconds / 1000) % 60 ;
			int minutes = (int) ((totalMilliseconds / (1000*60)) % 60);
			int hours   = (int) ((totalMilliseconds / (1000*60*60)) % 24);
			int milliSeconds = (int) (totalMilliseconds / 1000);
			time = "Total Time in HH:mm:ss:SSS ===> " + hours + ":" + minutes + ":" + seconds + ":" + milliSeconds;
			logger.info(time);
			
		}catch(Exception exe){
			CommonException.getPrintStackTrace(exe);
		}
		return time;
	}

}
