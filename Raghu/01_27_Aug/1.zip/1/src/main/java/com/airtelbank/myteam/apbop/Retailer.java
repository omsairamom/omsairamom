package com.airtelbank.myteam.apbop;

import com.airtelbank.model.Retailer.RetailerAPIResponse;
import com.airtelbank.model.Retailer.RetailerMSDIN;
import com.airtelbank.myteam.util.HttpUtil;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class Retailer implements UserType
{
    @Autowired
    HttpUtil httpUtil;

    @Autowired
    PropertyManager prop;

    @Override
    public UserShopLatitudeLongitudeModel userTypeDetails(String flg_cust_typ, String msisdn)
    {
        String shopLatitude = null;
        String shopLongitude = null;

        UserShopLatitudeLongitudeModel userShopLatitudeLongitudeModel =
                new UserShopLatitudeLongitudeModel();

        RetailerMSDIN retailerMSDIN = new RetailerMSDIN();
        retailerMSDIN.setMsisdn(Long.parseLong(msisdn));

        // Hit API from RestTemplate
        String url = prop.getProperty(Constants.RETAILER_SHOP_API_URL_KEY);

        try {


            RetailerAPIResponse retailerAPIResponse =
                    httpUtil.hitRequest(url, retailerMSDIN, RetailerAPIResponse.class, null, HttpMethod.POST);

            if (retailerAPIResponse != null)
            {
                if (retailerAPIResponse.getMeta().getDescription().equalsIgnoreCase("SUCCESS"))
                {
                    if (retailerAPIResponse.getData().getRetailers().get(0).getLocation().getLat() != null
                            && retailerAPIResponse.getData().getRetailers().get(0).getLocation().getLon() != null) {
                        shopLatitude = retailerAPIResponse.getData().getRetailers().get(0).getLocation().getLat();
                        shopLongitude = retailerAPIResponse.getData().getRetailers().get(0).getLocation().getLon();
                    }
                    else
                    {
                        // When API response is null for Lat Lng values then By Default Lat Lng value are below
                        shopLatitude = null;
                        shopLongitude = null;
                    }
                }
                else
                {
                    // When API response is null for Lat Lng values then By Default Lat Lng value are below
                    shopLatitude = null;
                    shopLongitude = null;
                }
            }
            else
            {
                shopLatitude = null;
                shopLongitude = null;
            }

        }
        catch (Exception e)
        {
            shopLatitude = null;
            shopLongitude = null;
        }

        userShopLatitudeLongitudeModel.setShopLatitude(shopLatitude);
        userShopLatitudeLongitudeModel.setShopLongitude(shopLongitude);

        return userShopLatitudeLongitudeModel;
    }
}