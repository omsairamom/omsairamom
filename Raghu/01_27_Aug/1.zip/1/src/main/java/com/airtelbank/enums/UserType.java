package com.airtelbank.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum UserType {

	Cdh(30),
	MM(25),
	SH(20),
	ZM(15),
	CM(10),
	TL(5),
	PR(1);
	

	 private static final Map<Integer,UserType> lookup = new HashMap<Integer,UserType>();

	 static
	 {
	      for(UserType s : EnumSet.allOf(UserType.class))
	           lookup.put(s.getCode(), s);
	 }

	 private int code;

	 private UserType(int code) {
	      this.code = code;
	 }

	 public int getCode() { return code; }

	 public static UserType get(int code)
	 {
	      return lookup.get(code); 
	 }
}
