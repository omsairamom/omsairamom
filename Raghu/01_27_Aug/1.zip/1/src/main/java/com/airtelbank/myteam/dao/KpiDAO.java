package com.airtelbank.myteam.dao;

import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.dao.helper.PromoterKPIDAOHelper;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.CustomException;
import com.airtelbank.util.PropertyManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class KpiDAO
{
	@Autowired  
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;
	
	@Autowired
	CommonUtils commonUtil;

	@Autowired
	private PromoterKPIDAOHelper promoterKPIDAOHelper;
	
	public SnapWorkResponse fetchKPIDetailsV2(String mobileNo) throws CustomException
	{

		return promoterKPIDAOHelper.fetchKPIDetailsRevamp(mobileNo);
	}
}
