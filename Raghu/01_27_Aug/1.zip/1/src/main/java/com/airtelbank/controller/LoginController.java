package com.airtelbank.controller;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.service.LoginService;
import com.airtelbank.util.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.*;

@RestController
public class LoginController
{
	private static Logger logger = LoggerFactory.getLogger(LoginController.class);
	private static final String LATITUDE = "latitude";
	private static final String LONGITUDE = "longitude";

	@Autowired
	LoginService loginService;

	@Autowired
	PropertyManager prop;

	@Autowired
	CommonUtils commonUtil;

	@Autowired
	HttpServletRequest httpServletRequest;

	@Autowired
	SecureBuilderVer secureBuilderVer;

	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();

	@SuppressWarnings("unchecked")
	@PostMapping(path = "/v1/users/user-login")
	public ResponseEntity<Object> loginWithPassword(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		String passWord = "";

		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Login Request start timeInMillis {}:" ,startTime);

			JSONParser parser = new JSONParser();
			JSONObject jsonResObj = (JSONObject) parser.parse(gson.toJson(request));
			passWord = (String) jsonResObj.get("password");
			passWord = passWord.replace(passWord, "******");
			jsonResObj.put("password", passWord);
			logger.info("Login Request params {}:" ,jsonResObj);

			String deviceID = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
			String password = request.getPassword() == null ? "" : request.getPassword().trim();

			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo) && StringUtils.isNotBlank(password)
					&& StringUtils.isNotBlank(deviceID))
			{
				response = loginService.loginWithPasswordCheck(request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			logger.info("Login Request end timeInMillis {}:" ,endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(
					"************************************************************************************************************************************* {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/user-profile")
	public ResponseEntity<Object> getUserProfile(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		String payload = httpServletRequest.getHeader(Constants.JWT_PAYLOAD);
		logger.info("jwt_payload {}:" , payload);

		String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();

		if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo))
		{
			try
			{
				response = loginService.fetchUserProfile_V2(request);
			}
			catch (Exception exe)
			{
				commonUtil.exceptionHandler(prop, exe, response, json);
			}
		}
		else
		{
			response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
		}

		endTime = System.currentTimeMillis();
		logger.info("Get User Profile Request end timeInMillis {}:" , endTime);
		elapsedTimeMillis = (endTime - startTime);
		commonUtil.convertMillis(elapsedTimeMillis);
		logger.info("************************************************************************* {}:" , "");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/password-set")
	public ResponseEntity<Object> resetPassword(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		startTime = System.currentTimeMillis();
		logger.info("ReSet Password Request start timeInMillis {} :" ,startTime);
		response = loginService.setPasswordDetailsV2(request);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/send-otp")
	public ResponseEntity<Object> sendOTPDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Send OTP Details Request start timeInMillis {}:" , startTime);

			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();

			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo))
			{
				response = loginService.sendOTP(mobileNo, request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			logger.info("Send OTP Request end timeInMillis {}:" ,endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(
					"************************************************************************************************************************************* {}: " , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@SuppressWarnings("unchecked")
	@PostMapping(path = "/v1/users/verify-otp")
	public ResponseEntity<Object> verifyOTPDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			startTime = System.currentTimeMillis();
			String maskOtp = "";
			logger.info("Verify OTP Details Request start timeInMillis {}:" ,startTime);

			JSONParser parser = new JSONParser();
			JSONObject jsonResObj = (JSONObject) parser.parse(gson.toJson(request));
			maskOtp = (String) jsonResObj.get("otp");
			maskOtp = maskOtp.replace(maskOtp, "******");
			jsonResObj.put("otp", maskOtp);
			logger.info("Verify OTP Details Request {}:" ,jsonResObj);

			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
			String otp = request.getOtp() == null ? "" : request.getOtp().trim();
			String otpVerifCode = request.getOtpVerficatonCode() == null ? "" : request.getOtpVerficatonCode().trim();
			String isMobileNoExist = request.getIsUserExist() == null ? "" : request.getIsUserExist().trim();
			String isUserDeviceExist = request.getIsUserDeviceExist() == null ? ""
					: request.getIsUserDeviceExist().trim();

			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo) && StringUtils.isNotBlank(otp)
					&& StringUtils.isNotBlank(otpVerifCode) && StringUtils.isNotBlank(isMobileNoExist)
					&& StringUtils.isNotBlank(isUserDeviceExist))
			{
				response = loginService.verifyOTP(mobileNo, otpVerifCode, otp, request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Verify OTP Details, Response {}: " ,gson.toJson(response));

			endTime = System.currentTimeMillis();
			logger.info("Verify OTP Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(
					"************************************************************************************************************************************* {}:" ,"");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/logout")
	public ResponseEntity<Object> logOutAttendanceUpload(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Logout Request start timeInMillis {}:" ,startTime);

			String udid = request.getDeviceId() == null ? "" : request.getDeviceId().trim();

			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
			String latitude = httpServletRequest.getHeader(LATITUDE);
			String longitude = httpServletRequest.getHeader(LONGITUDE);

			request.setLatitude(latitude);
			request.setLongitude(longitude);


			String userName = request.getUserName() == null ? "" : request.getUserName().trim();


			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNotBlank(latitude)
					&& StringUtils.isNotBlank(longitude) && StringUtils.isNotBlank(userName)
					&& StringUtils.isNotBlank(udid))
			{
				response = loginService.logOutAttendance(request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			logger.info("Logout Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(
					"************************************************************************************************************************************* {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@ResponseBody
	@Validated
	@PostMapping(path = "/v2/users/selfie-upload")
	public ResponseEntity<Object> profileUpload(@RequestParam("file") MultipartFile file,
												HttpServletRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			String payload = httpServletRequest.getHeader("jwt_payload");
			org.json.JSONObject json1 = new org.json.JSONObject(payload);
			String mobileNo = json1.getString("mobileno");

			startTime = System.currentTimeMillis();
			logger.info("ProfileUpload Request start timeInMillis {}:" , startTime);

			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo) && !file.isEmpty())
			{
				logger.info("file.getContentType() {}:" , file.getContentType());
				logger.info("file.getOriginalFilename()  {}:" , file.getOriginalFilename());

				if (file.getContentType().trim().equalsIgnoreCase("image/jpeg") || file.getContentType().trim().equalsIgnoreCase("multipart/form-data")) {
					boolean isValidFileExtnFlag = FileExtenValidation.validateFileExtn(file.getOriginalFilename());

					if (isValidFileExtnFlag)
					{
						response = loginService.profileUploadDetails(mobileNo, file);
					}
					else
					{
						response.setMessage(prop.getProperty(Constants.LOGIN_UPLOAD_INVALID_FILE_EXTN_MSG));
						response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
						response.setResponse(json);
					}
				}
				else
				{
					response.setMessage(prop.getProperty(Constants.LOGIN_UPLOAD_INVALID_CONTENT_TYPE_MSG));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
				}
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			logger.info("ProfileUpload Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(
					"************************************************************************************************************************************* {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v2/users/attendance-upload")
	@ResponseBody
	public ResponseEntity<Object> attendanceUpload(@RequestParam("file") MultipartFile file, String data) throws Exception
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Attendance Upload Request start timeInMillis {}:", startTime);

			String decryptedString = EncryptionUtil.desEncrypt(data);
			logger.info(decryptedString);

			if (StringUtils.isNotBlank(decryptedString) || decryptedString.equals(""))
			{
				String[] keyValuePairs = decryptedString.split("&");
				Map<String, String> map = new HashMap<>();

				for (String pair : keyValuePairs)
				{
					String[] entry = pair.split("=");
					map.put(entry[0].trim(), entry[1].trim());
				}

				String deviceId = map.get("deviceId");
				String mobileNo = map.get("mobileNo");
				String latitude = map.get(LATITUDE);
				String longitude = map.get(LONGITUDE);
				String address = map.get("address");
				String encStatus = map.get("encStatus");
				String inOut = map.get("inOut");

				logger.info("deviceId {}:", deviceId);
				logger.info("mobileNo {}:", mobileNo);
				logger.info("latitude {}:", latitude);
				logger.info("longitude {}:", longitude);
				logger.info("address {}:", address);
				logger.info("encStatus {}:", encStatus);
				logger.info("inOut {}:", inOut);


				if (StringUtils.isNotBlank(mobileNo) && !file.isEmpty() && StringUtils.isNotBlank(encStatus)) {

					if (file.getContentType().trim().equalsIgnoreCase("image/jpeg") || file.getContentType().trim().equalsIgnoreCase("multipart/form-data")) {
						boolean isValidFileExtnFlag = FileExtenValidation.validateFileExtn(file.getOriginalFilename());

						if (isValidFileExtnFlag) {
							AttendanceBean obj = new AttendanceBean();
							obj.setMobileNo(mobileNo);
							obj.setLatitude(latitude);

							if (inOut.equals("in")) {
								obj.setType(0);
							} else if (inOut.equals("out")) {
								obj.setType(1);
							}

							obj.setLongitude(longitude);
							obj.setAddress(address);
							obj.setField1("NA");
							obj.setField2("NA");
							obj.setField3("NA");
							obj.setField4("NA");
							obj.setField5("NA");
							response = loginService.attendanceUploadDetails(mobileNo, file, obj, encStatus);
						} else {
							response.setMessage(prop.getProperty(Constants.LOGIN_UPLOAD_INVALID_FILE_EXTN_MSG));
							response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
							response.setResponse(json);
						}
					} else {
						response.setMessage(prop.getProperty(Constants.LOGIN_UPLOAD_INVALID_CONTENT_TYPE_MSG));
						response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
						response.setResponse(json);
					}

				} else {
					response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
				}

				endTime = System.currentTimeMillis();
				logger.info("Attendance Upload Request end timeInMillis {}:", endTime);
				elapsedTimeMillis = (endTime - startTime);
				commonUtil.convertMillis(elapsedTimeMillis);
				logger.info(
						"************************************************************************************************************************************* {}:", "");
			}
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/attendanceview")
	public ResponseEntity<Object> attendanceView(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			String latitude = httpServletRequest.getHeader(LATITUDE);
			String longitude = httpServletRequest.getHeader(LONGITUDE);

			startTime = System.currentTimeMillis();
			logger.info("View Attendance Request start timeInMillis {}:" , startTime);
			logger.info("View Attendance Request params {}:" , gson.toJson(request));
			String deviceID = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
			String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
			String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

			String lat = latitude;
			String lng = longitude;

			logger.info("startDate {}:", startDate);
			logger.info("endDate {}:", endDate);

			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNotBlank(startDate)
					&& StringUtils.isNotBlank(endDate) && StringUtils.isNotBlank(lat) && StringUtils.isNotBlank(lng))
			{
				response = loginService.attendanceViewDetails(deviceID, mobileNo, request, lat, lng);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			}

			logger.info("View Attendance Response {}: " , gson.toJson(response));

			endTime = System.currentTimeMillis();
			logger.info("View Attendance Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("********************************************************************************* {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/refreshtoken")
	public ResponseEntity<Object> getToken(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Check-out Details, Request start timeInMillis {}:" , startTime);

			if (StringUtils.isNotBlank(request.getMobileNo()))
			{
				response = loginService.isRefreshToKen(request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			logger.info("refreshtoken, Request end timeInMillis {}:" ,endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(
					"************************************************************************************************************************************* {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}



}