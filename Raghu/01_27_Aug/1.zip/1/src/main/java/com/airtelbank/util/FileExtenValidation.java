package com.airtelbank.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Aug 02, 2019 11:39:45 PM
 */
public class FileExtenValidation {

	private static Pattern FileExtnPtrn = Pattern.compile("([^\\s]+(\\.(?i)(JPG|jpg))$)"); 

	public static boolean validateFileExtn(String fileName) {      
		fileName = fileName.replaceAll("\\s+","");
		Matcher mtch = FileExtnPtrn.matcher(fileName);
		if(mtch.matches()){
			return true;
		}
		return false;
	}

}
