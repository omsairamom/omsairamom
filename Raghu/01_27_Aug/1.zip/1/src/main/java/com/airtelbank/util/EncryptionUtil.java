package com.airtelbank.util;

import com.airtelbank.common.CommonException;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.util.SimpleByteSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date June 07, 2019 04:02:45 PM
 */
public class EncryptionUtil {
	
	private static Logger logger = LoggerFactory.getLogger(EncryptionUtil.class);
	
	public static boolean generateDecryptPassword(String encryptedPassword,String password, String mobileNo, String SALTKEY)
	{
		boolean result = false;
		
		try {
			logger.info("Inside compareEncryptPassword() method in EncryptionUtil class...");
			String genencrypted = generateEncryptPassword(password,mobileNo);
			if(genencrypted.equals(encryptedPassword)){
				result = true;
			}
			logger.info("result :"+result);
		} catch (Exception e) {
			CommonException.getPrintStackTrace(e);
		}
		return result;
	}

	public static String generateEncryptPassword(String password, String mobileNo)
	{
		String encryptedpin = "";
		
		try
		{
			logger.info("Inside generateEncryptPassword() method in EncryptionUtil class...");
			Sha256Hash sha256Hash = new Sha256Hash((String)password, (new SimpleByteSource(mobileNo)).getBytes());
			encryptedpin = sha256Hash.toHex();
			logger.info("MPIN Encryption :"+encryptedpin);
			
		}
		catch (Exception e) 
		{
			CommonException.getPrintStackTrace(e);
			encryptedpin = password;
		}
		
		return encryptedpin;
	}

	public static String encrypt() throws Exception
	{
		try {
			String data = "123456";
			String key = "1234567812345678";
			String iv = "1234567812345678";
			Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
			int blockSize = cipher.getBlockSize();
			byte[] dataBytes = data.getBytes();
			int plaintextLength = dataBytes.length;
			if (plaintextLength % blockSize != 0) {
				plaintextLength = plaintextLength + (blockSize - (plaintextLength % blockSize));
			}
			byte[] plaintext = new byte[plaintextLength];
			System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.length);
			SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), "AES");
			IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());
			cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
			byte[] encrypted = cipher.doFinal(plaintext);
			return new sun.misc.BASE64Encoder().encode(encrypted);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String desEncrypt(String encrypted) throws Exception
	{
		try
		{
			String data = encrypted ;
			String key = "1234567812345678";
			String iv = "1234567812345678";
			byte[] encrypted1 = new BASE64Decoder().decodeBuffer(data);
			Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
			SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), "AES");
			IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());
			cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
			byte[] original = cipher.doFinal(encrypted1);
			String originalString = new String(original);
			return originalString;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
}
