package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.myteam.repository.PromoterUserProfileMSTRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class PromoterUserProfileMSTDAO
{
    @Autowired
    PromoterUserProfileMSTRepository promoterUserProfileMSTRepository;

    public Optional<PromoterUserProfileMSTEntity> fetchUserByUserNo(String userNo) {
        return promoterUserProfileMSTRepository.findOneByUserNo(userNo);
    }

    public int saveUserProfile(PromoterUserProfileMSTEntity promoterUserProfileMSTEntity){
        promoterUserProfileMSTRepository.save(promoterUserProfileMSTEntity);
        return 1;
    }

    public int updateProfile(String password, String userNo){
        return promoterUserProfileMSTRepository.updatePassword(password, userNo);
    }
}