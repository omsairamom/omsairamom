package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.service.CaptureComplianceService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.FileExtenValidation;
import com.airtelbank.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
public class CaptureComplianceController {

	private static Logger logger = LoggerFactory.getLogger(CaptureComplianceController.class);

	@Autowired
	CaptureComplianceService capComplianceService;

	@Autowired
	PropertyManager prop;

	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	HttpServletRequest httpServletRequest;

	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();

	@PostMapping(path = "/v2/compliance/capture")
	public ResponseEntity<Object> captureComplianceDetails(@Valid @RequestParam("file") MultipartFile file)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try
		{
			String payload = httpServletRequest.getHeader("jwt_payload");
			org.json.JSONObject json1 = new org.json.JSONObject(payload);
			String mobileNo = json1.getString("mobileno");
			
			startTime = System.currentTimeMillis();
			logger.info("Save Capture Compliance Details, Request start timeInMillis {} :" , startTime);

			if (StringUtils.isNotBlank(mobileNo) && !file.isEmpty())
			{

				if (file.getContentType().trim().equalsIgnoreCase("image/jpeg") || file.getContentType().trim().equalsIgnoreCase("multipart/form-data")) {
					boolean isValidFileExtnFlag = FileExtenValidation.validateFileExtn(file.getOriginalFilename());
					if (isValidFileExtnFlag)
					{
						response = capComplianceService.captureComplianceDetails(file, mobileNo, "add");
					}
					else
					{
						response.setMessage(prop.getProperty(Constants.COMPLIANCE_UPLOAD_INVALID_FILE_EXTN_MSG));
						response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
						response.setResponse(json);
					}
				}
				else
				{
					response.setMessage(prop.getProperty(Constants.COMPLIANCE_UPLOAD_INVALID_CONTENT_TYPE_MSG));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
				}
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Save Capture Compliance Details, response  {} :" ,gson.toJson(response));
			endTime = System.currentTimeMillis();
			logger.info("Save Capture Compliance Details, Request end timeInMillis {} :" ,endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(
					"*************************************************************************************************************************************{} :" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
