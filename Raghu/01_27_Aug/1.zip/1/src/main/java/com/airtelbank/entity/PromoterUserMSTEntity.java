package com.airtelbank.entity;

import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.lang.Nullable;

@Entity
@ToString
@Getter
@Setter
@Table(name = "PROMOTER_USER_MST",indexes = 
{
		@Index(name = "userNoIndex",  columnList="userNo", unique = true),
        @Index(name = "IndexCircleId", columnList = "circle_id"),
		@Index(name = "IndexParentID", columnList = "parent_id"),
		@Index(name = "IndexParentNo", columnList = "parentNo"),
        @Index(name = "IndexUserType", columnList = "userType"),
})
@EntityListeners(AuditingEntityListener.class)
public class PromoterUserMSTEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

 
    @Column(unique = true)
    @NotNull
    private String userNo;
    
    @Column
    @NotNull
    private String username;

    @Column
    @NotNull
    private String userType;

    @Column
    @NotNull
    private String category;
    
    @Column
    private String agency;

    @ManyToOne
    @NotNull
    @JoinColumn(name = "circle_id", referencedColumnName = "id")
    private PromoterCircleMSTEntity promoterCircleMSTEntity; 

    @Column
    private String employeeId;

    @Column
    private LocalDateTime dob;

    @Column
    private LocalDateTime doj;

    @ManyToOne
    @JoinColumn(name = "parent_id", referencedColumnName = "id")
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    private String parentNo;

    @Column
    private String parentType;

    @Column
    @NotNull
    private String status;

    @ManyToOne
    @NotNull
    @JoinColumn(name = "file_id", referencedColumnName = "id")
    private PromoterUploadFileAuditEntity promoterUploadFileAuditEntity;
  
    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdDate;

    @LastModifiedDate
    @Column
    private LocalDateTime updatedDate;

    @Column
    @Nullable
    private String selfieId;

    @Column
    private String interviewerNo;

    @Column
    private LocalDateTime interviewDate;


    @Column
    private String custom_field1;
    
    @Column
    private String custom_field2;
    
    @Column
    private String custom_field3;
    
    @Column
    private String custom_field4;
    
    @Column
    private String custom_field5;
    
    @Transient
    private Integer lineNo;
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass()!= this.getClass()) {
            return false;
        }
        if (obj instanceof PromoterUserMSTEntity) {
            if (((PromoterUserMSTEntity) obj).getUserNo().equals(this.getUserNo())) {
                return true;
            }
        }

        return false;
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(this.getUserNo());
    }

    

}
