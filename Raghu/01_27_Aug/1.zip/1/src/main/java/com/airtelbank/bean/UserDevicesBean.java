package com.airtelbank.bean;

/**
 * @author Mayuri Patil
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 06, 2019 08:14:45 PM
 */
public class UserDevicesBean {
	
	private String mobileNo;
	private String deviceId;
	private String fcmToken;
	private String appVersion;
	private String deviceModel;
	private String imei;
	private String os;
	private String password;
	private String language;
	private String registrationDt;
	private int delBlockFlag;
	private String delBlockBy;
	private String delBlockReason;
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getFcmToken() {
		return fcmToken;
	}
	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}
	public String getAppVersion() {
		return appVersion;
	}
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getRegistrationDt() {
		return registrationDt;
	}
	public void setRegistrationDt(String registrationDt) {
		this.registrationDt = registrationDt;
	}
	public int getDelBlockFlag() {
		return delBlockFlag;
	}
	public void setDelBlockFlag(int delBlockFlag) {
		this.delBlockFlag = delBlockFlag;
	}
	public String getDelBlockBy() {
		return delBlockBy;
	}
	public void setDelBlockBy(String delBlockBy) {
		this.delBlockBy = delBlockBy;
	}
	public String getDelBlockReason() {
		return delBlockReason;
	}
	public void setDelBlockReason(String delBlockReason) {
		this.delBlockReason = delBlockReason;
	}
	
	
}
