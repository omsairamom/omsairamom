
package com.airtelbank.model.Profile;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Data {

    @SerializedName("fileRequestId")
    @Expose
    private String fileRequestId;
    @SerializedName("fileURL")
    @Expose
    private String fileURL;

    public String getFileRequestId() {
        return fileRequestId;
    }

    public void setFileRequestId(String fileRequestId) {
        this.fileRequestId = fileRequestId;
    }

    public String getFileURL() {
        return fileURL;
    }

    public void setFileURL(String fileURL) {
        this.fileURL = fileURL;
    }

}
