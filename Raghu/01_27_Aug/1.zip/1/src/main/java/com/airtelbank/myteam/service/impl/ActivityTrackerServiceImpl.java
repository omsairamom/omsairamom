package com.airtelbank.myteam.service.impl;

import com.airtelbank.bean.ActivityTrackerBean;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.common.CommonException;
import com.airtelbank.myteam.dao.ActivityTrackerDAO;
import com.airtelbank.myteam.service.ActivityTrackerService;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map.Entry;

@Service
public class ActivityTrackerServiceImpl implements ActivityTrackerService {

	private static final Logger logger = LoggerFactory.getLogger(ActivityTrackerServiceImpl.class);

	@Autowired
	PropertyManager prop;

	@Autowired
	ActivityTrackerDAO activityTrackerDAO;

	@Autowired
	SnapWorkRequest request;

	@SuppressWarnings("unchecked")
	@Override
	public SnapWorkResponse activityTrackerDetails(SnapWorkRequest request) throws Exception
	{
		SnapWorkResponse response = new SnapWorkResponse();

		JSONObject json = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		HashMap<String, Object> map = new HashMap<>();
		ActivityTrackerBean obj = new ActivityTrackerBean();

		try 
		{
			logger.info("Inside activityTrackerDetails() method in ActivityTrackerServiceImpl class.. {}:" , "");

			JSONArray trackerJsonArr = request.getTrackerInfo();			
			logger.info("trackerJsonArr {}:" , trackerJsonArr);
			
			if (!trackerJsonArr.isEmpty()) 
			{

				for (int i = 0; i < trackerJsonArr.size(); i++)
				{

					HashMap<String, String> passedValues = (HashMap<String, String>) trackerJsonArr.get(i);

					for (Entry<String, String> mapTemp : passedValues.entrySet()) 
					{

						String key = mapTemp.getKey();
						String value = mapTemp.getValue();
						map.put(key, value);
					}
					
					String seqId = map.get("seqId") == null ? "" : map.get("seqId").toString();
					String mobileNo = map.get("mobileNo") == null ? "" :map.get("mobileNo").toString();
					String latitude = map.get("latitude") == null ? "" :map.get("latitude").toString();
					String longitude = map.get("longitude") == null ? "" : map.get("longitude").toString();

					obj.setMobileNo(mobileNo);
					obj.setLatitude(latitude);
					obj.setLongitude(longitude);

					int count = activityTrackerDAO.saveActivityTrackerDtls(obj);
					logger.info("ACTIVITY_TRACKER_SAVE_DTLS count: {} :"  ,count);

					if (count > 0) {

						JSONObject trackerJson = new JSONObject();
						trackerJson.put("seqId", seqId);
						trackerJson.put("mobileNo", mobileNo);
						trackerJson.put("latitude", latitude);
						trackerJson.put("longitude", longitude);
						jsonArray.add(trackerJson);
					}

				}
				
				json.put("trackerInfo", jsonArray);
				response.setMessage(prop.getProperty(Constants.ACTIVITY_TRACKER_DTLS_SUCC_MSG));
				response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
				response.setResponse(json);
				logger.info("Success Response generated:{} :", "");

			}
			else
			{
				logger.error("activityTrackerDetails() trackerJsonArr is empty: {} :" , "");
				response.setMessage(prop.getProperty(Constants.ACTIVITY_TRACKER_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}
			logger.info("activityTrackerDetails() Response generated: {} :" , "");
			return response;
			
		}
		catch (Exception exe) 
		{
			logger.error("activityTrackerDetails() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
			return response;
		}
	}
}