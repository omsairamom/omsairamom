package com.airtelbank.myteam.dao;

import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CaptureComplianceDAO {

	private final Logger logger = LoggerFactory.getLogger(CaptureComplianceDAO.class.getClass());

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	public List<Map<String, Object>> fetchComplRetailerDetails(String mobileNo) throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows = null;

		logger.info("Inside fetchComplRetailerDetails() method in CaptureComplianceDAO class... {}:" , "");

		query = prop.getProperty(Constants.COMPLIANCE_FETCH_RETAILER_DTLS);

		rows = jdbctemplate.queryForList(query, mobileNo);
		logger.info("fetchComplRetailerDetails(), rows {}:" , rows);

		return rows;
	}

	public List<Map<String, Object>> getKpiDetails(String mobileNo) throws Exception
	{
		List<Map<String, Object>> rows = null;

		String query = prop.getProperty("COMPLIANCE_FETCH_KPI_DTLS");
		rows = jdbctemplate.queryForList(query, mobileNo);
		logger.info("getKpiDetails(), rows {}:"  ,rows);

		return rows;
	}
}
