package com.airtelbank.util;

import com.airtelbank.bean.UploadDocumentsResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

@Service
public class UploadDocuments {

    private static final Logger logger = LoggerFactory.getLogger(UploadDocuments.class);

    @Value("${dms.file.upload.url}")
    private String serverUrl;

    public UploadDocumentsResponse uploadDocument(MultipartFile file) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost uploadFile = new HttpPost(serverUrl);
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        File convFile = new File(file.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        builder.addBinaryBody(
                "file",
                new FileInputStream(convFile),
                ContentType.APPLICATION_OCTET_STREAM,
                convFile.getName()
        );

        HttpEntity multipart = builder.build();
        uploadFile.setEntity(multipart);
        CloseableHttpResponse response = httpClient.execute(uploadFile);
        ObjectMapper objectMapper = new ObjectMapper();
        UploadDocumentsResponse uploadDocumentsResponse = objectMapper.readValue(response.getEntity().getContent(), UploadDocumentsResponse.class);
        logger.info("Upload documents response:{}", uploadDocumentsResponse.toString());
        return uploadDocumentsResponse;
    }

    public UploadDocumentsResponse uploadDocument(File convFile, String filename) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost uploadFile = new HttpPost(serverUrl);
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.addBinaryBody(
                "file",
                new FileInputStream(convFile),
                ContentType.APPLICATION_OCTET_STREAM,
                convFile.getName()
        );

        HttpEntity multipart = builder.build();
        uploadFile.setEntity(multipart);
        CloseableHttpResponse response = httpClient.execute(uploadFile);
        ObjectMapper objectMapper = new ObjectMapper();
        UploadDocumentsResponse uploadDocumentsResponse = objectMapper.readValue(response.getEntity().getContent(), UploadDocumentsResponse.class);
        logger.info("Upload documents response:{}", uploadDocumentsResponse.toString());
        return uploadDocumentsResponse;
    }
}
