package com.airtelbank.myteam.apbop;

public interface UserType
{
    UserShopLatitudeLongitudeModel userTypeDetails(String flg_cust_typ, String msisdn);
}
