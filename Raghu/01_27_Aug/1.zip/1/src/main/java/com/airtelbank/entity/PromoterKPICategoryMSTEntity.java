package com.airtelbank.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "PAPP_KPI_CATEGORY_MST")
@EntityListeners(AuditingEntityListener.class)
public class PromoterKPICategoryMSTEntity {

    @Id
    @Column
    private Long catId;

    @Column
    private String catName;

    @Column
    private String catDesc;

    @Column
    private String updatedBy;

    @Column
    @CreatedDate
    private LocalDateTime createDt;

    @Column
    @LastModifiedDate
    private LocalDateTime updateDt;

    @Column
    private String custom_field1;

    @Column
    private String custom_field2;

    @Column
    private String custom_field3;

    @Column
    private String custom_field4;

    @Column
    private String custom_field5;

}

