package com.airtelbank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Entity
@ToString
@Getter
@Setter
@Table(name = "PROMOTER_CIRCLE_MST",
indexes = { 
		@Index(name = "IndexCircleId_CIRCLE",  columnList="circleId", unique = true)})
@EntityListeners(AuditingEntityListener.class)
public class PromoterCircleMSTEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(unique = true)
    @NotNull
    private String circleId;

    @Column
    @NotNull
    private String circleName;

    @Column
    private String description;

    @Column
    @CreatedDate
    private LocalDateTime createdDate;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDate;
    
    @Column
    private String custom_field1;
    
    @Column
    private String custom_field2;
    
    @Column
    private String custom_field3;
    
    @Column
    private String custom_field4;
    
    @Column
    private String custom_field5;

}
