package com.airtelbank.service.impl;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.bean.UserDevicesBean;
import com.airtelbank.common.CommonException;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.dao.LoginDAO;
import com.airtelbank.dao.UploadDocumentsDAO;
import com.airtelbank.encryption.EncryptionRSA;
import com.airtelbank.entity.*;
import com.airtelbank.enums.UserProfileStatus;
import com.airtelbank.enums.UserStatus;
import com.airtelbank.jwt.AeroCache;
import com.airtelbank.jwt.CommonJWTUtil;
import com.airtelbank.jwt.JTIToken;
import com.airtelbank.model.Profile.Profile;
import com.airtelbank.myteam.dao.PromoterUserKYCMSTDAO;
import com.airtelbank.myteam.dao.PromoterUserMSTDAO;
import com.airtelbank.myteam.dao.PromoterUserProfileMSTDAO;
import com.airtelbank.myteam.repository.PromoterLoginTrackerAuditRepository;
import com.airtelbank.myteam.util.HttpUtil;
import com.airtelbank.service.LoginService;
import com.airtelbank.util.*;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@Primary
public class LoginServiceImpl implements LoginService {
    private static Logger logger = LoggerFactory.getLogger(LoginServiceImpl.class);
    private static final String PUB_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnsUrIe1pCJLoggVpXwd3GWeoX+Fc6uAYUkPrgrewiXh8995uTPVKzfJAy5ioqFmOfpXKIuaFGd4wS/BraLlHxtM+/qvAkreDKmLaBYqn0p3EaEwKUIPXx4LATA9Uip3WZMmZ08ToHwJY8pCkDqWLyHJt45f6j2WLPwom45e+bO7UvUv1lhSxWCNuD8KbwPrhwKUOiY5PL+PSMgSyMnTVOMQICF5X8JSRFzTdwbNls/LFrDqBOxjj26QvL2oo9IYWsClrfupILFl5M6exxY2QATqF8En/LnD4eiow1I4Wt8scYmvplS22Upbwartf/9MB0gufXriA2vEl+QaB+j46OQIDAQAB";
    private static final String BLOCK_LOGGER = "Account is temporarily blocked. Please try after some time: {} :";
    private static final String SUCCESS_LOGGER = "Success Response generated:  {} for mobileNo: {}:";

    private String setName = "COMB_PROM_SESSION_MGMT";

    private String slash = "/";

    private static final String DEVICEIDLOGGER = "deviceID {}:";
    private static final String JWTTOKENLOGGER = "jwtToken {}:";
    private static final String MOBILENOLOGGER = "mobileNo {}:";

    @Autowired
    AeroCache aeroCache;

    @Autowired
    PropertyManager prop;

    @Autowired
    LoginDAO loginDao;

    @Autowired
    RestClientUtil restClient;

    @Autowired
    SnapWorkRequest request;

    @Autowired
    CommonJWTUtil commonUtil;

    @Autowired
    JTIToken jtiToken;


    @Autowired
    PromoterUserMSTDAO promoterUserMSTDAO;

    @Autowired
    PromoterUserProfileMSTDAO promoterUserProfileMSTDAO;

    @Autowired
    PromoterUserKYCMSTDAO promoterUserKYCMSTDAO;

    @Autowired
    PromoterLoginTrackerAuditRepository promoterLoginTrackerAuditRepository;

    @Autowired
    private UploadDocumentsDAO uploadDocumentsDAO;

    @Autowired
    private UploadDocuments uploadDocuments;

    private static Map<Integer, Integer> attemptToBlockTimeMap = new HashMap<>();
    private static Integer minWrongAttemptToBlock = 15;
    private static Integer maxWrongAttemptToBlock = 15;
    private static Integer blockTimeOnMaxWrongLogin = 15;

    @Autowired
    HttpUtil httpUtil;

    @PostConstruct
    public void populateBlockTimerWithAttemptCountMap() {
        String attemptsToBlockTimeMap = prop.getProperty("ATTEMPTS_TO_BLOCK_TIME_IN_MINUTE_MAP");
        if (attemptsToBlockTimeMap == null)
            attemptsToBlockTimeMap = "3:15,4:15,5:15";
        minWrongAttemptToBlock = Integer.parseInt(attemptsToBlockTimeMap.split(",")[0].split(":")[0]);
        for (String token : attemptsToBlockTimeMap.split(",")) {
            attemptToBlockTimeMap.put(Integer.parseInt(token.split(":")[0]), Integer.parseInt(token.split(":")[1]));
            maxWrongAttemptToBlock = Integer.parseInt(token.split(":")[0]);
            blockTimeOnMaxWrongLogin = Integer.parseInt(token.split(":")[1]);
        }

    }

    @SuppressWarnings("unchecked")
    @Override
    public SnapWorkResponse loginWithPasswordCheck(SnapWorkRequest request) {
        SnapWorkResponse response = new SnapWorkResponse();

        JSONObject json = new JSONObject();

        try {
            logger.info("Inside loginWithPasswordCheck() method in LoginServiceImpl class.. {}:", "");
            String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
            String deviceID = request.getDeviceId() == null ? "" : request.getDeviceId().trim();

            logger.info(MOBILENOLOGGER, mobileNo);
            logger.info(DEVICEIDLOGGER, deviceID);

            if (mobileNo.isEmpty() || deviceID.isEmpty()) {
                logger.info("loginWithPasswordCheck() mobileNo/device id is blank for mobileNo {}, {} :", "", mobileNo);
                // return Invalid Creds
                String statusCode = prop.getProperty(Constants.FAILURE_STATUS_CODE);
                String message = prop.getProperty(Constants.LOGIN_WITH_PASWD_FAIL_MSG);
                return loginResponse(response, json, statusCode, message, message);
            }


            // Fetch Promoter details from PROMOTER_USER_MST
            Optional<PromoterUserMSTEntity> promoterUserMSTEntity = promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(mobileNo);

            if (!promoterUserMSTEntity.isPresent()) {
                logger.info("loginWithPasswordCheck() User is not present or not in Active State in promoterUserMSTEntity for mobileNo {}, {}:", "", mobileNo);
                // return Invalid Credential Error
                String statusCode = prop.getProperty(Constants.FAILURE_STATUS_CODE);
                String message = prop.getProperty(Constants.LOGIN_WITH_PASWD_FAIL_MSG);
                return loginResponse(response, json, statusCode, message, message);
            }

            logger.info("loginWithPasswordCheck() is not blank: {} for mobileNo {} :", "", mobileNo);
            String origPassword = request.getPassword() == null ? "" : request.getPassword();
            String encPassword = EncryptionUtil.generateEncryptPassword(origPassword, mobileNo);

            if (encPassword.isEmpty() || origPassword.isEmpty()) {
                logger.info("loginWithPasswordCheck() encPassword/origPassword is blank: {} for mobileNo {} :", "", mobileNo);
                // return Invalid Credential Error
                String statusCode = prop.getProperty(Constants.FAILURE_STATUS_CODE);
                String message = prop.getProperty(Constants.LOGIN_WITH_PASWD_FAIL_MSG);
                return loginResponse(response, json, statusCode, message, message);
            }

            logger.info("loginWithPasswordCheck() encPassword is not blank: {} for mobileNo {} :", encPassword, mobileNo);

            Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                    loginDao.fetchUserProfileForChannel(mobileNo, "PAPP");

            if (!promoterUserProfileMSTEntity.isPresent() || (promoterUserMSTEntity.isPresent() && !promoterUserMSTEntity.get().getStatus().equalsIgnoreCase("A"))) {
                logger.info("loginWithPasswordCheck() User is not present / or not in active state in promoterUserProfileMSTEntity: {} for mobileNo {} :", "", mobileNo);
                // return Error
                String statusCode = prop.getProperty(Constants.FAILURE_STATUS_CODE);
                String message = prop.getProperty(Constants.LOGIN_WITH_PASWD_FAIL_MSG);
                return loginResponse(response, json, statusCode, message, message);
            }

            PromoterUserProfileMSTEntity promoterProfile = promoterUserProfileMSTEntity.get();

            boolean isPasswordCheck = promoterUserProfileMSTEntity.get().getPassword().equalsIgnoreCase(encPassword);

            if (isPasswordCheck) {
                logger.info("loginWithPasswordCheck() password is correct for mobileNo {} :", mobileNo);
                // If Unblocked or BlockTime is passed
                if (promoterProfile.getBlockExpiryDate() == null || promoterProfile.getBlockExpiryDate().isBefore(LocalDateTime.now())) {
                    logger.info("loginWithPasswordCheck() user Unblocked or BlockTime is passed for mobileNo {} :", mobileNo);
                    // Reset attempt to 0 and Expiry Null.
                    loginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, 0, null);
                    return proceedLogin(request, promoterUserMSTEntity.get(), response);

                }

                // If already blocked
                if (promoterProfile.getBlockExpiryDate() != null &&
                        promoterProfile.getBlockExpiryDate().isAfter(LocalDateTime.now())) {
                    logger.info("loginWithPasswordCheck()  already blocked for mobileNo {} :", mobileNo);
                    // return Temporary Block Error
                    logger.error(BLOCK_LOGGER, "");
                    String statusCode = prop.getProperty(Constants.WRONG_ATTEMPT_STATUS_CODE);
                    String message = prop.getProperty(Constants.USER_BLOCKED_FOR_WRONG_ATTEMPT);
                    return loginResponse(response, json, statusCode, message, message);
                }


            } else {

                logger.error("loginWithPasswordCheck() Password is Incorrect for mobileNo {} :", mobileNo);

                int existingAttempt = promoterProfile.getAttempts();
                int totalWrongAttempts = promoterProfile.getAttempts() + 1;

                if (promoterProfile.getBlockExpiryDate() == null) {
                    logger.info("loginWithPasswordCheck() BlockExpirytime is null for mobileNo {} :", mobileNo);

                    // First time crossing Min Wrong Attempt
                    if (totalWrongAttempts >= minWrongAttemptToBlock) {
                        logger.info("loginWithPasswordCheck() First time crossing Min Wrong Attempt(3): {} for mobileNo {} :", totalWrongAttempts, mobileNo);
                        //increaseAttemptAndSetBlockExpiryTime
                        loginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, totalWrongAttempts, LocalDateTime.now().plusMinutes(attemptToBlockTimeMap.getOrDefault(minWrongAttemptToBlock, 15)));
                        promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                        // return block message
                        logger.error(BLOCK_LOGGER, "");
                        String statusCode = prop.getProperty(Constants.WRONG_ATTEMPT_STATUS_CODE);
                        String message = prop.getProperty(Constants.USER_BLOCKED_FOR_WRONG_ATTEMPT);
                        return loginResponse(response, json, statusCode, message, message);

                    } else {
                        logger.info("loginWithPasswordCheck() Wrong Attempts less than min wrong attempts to block: {} for mobileNo {} :", totalWrongAttempts, mobileNo);
                        //increment Attempt Only.
                        loginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, totalWrongAttempts, null);
                        promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                        // Return server error
                        logger.error("loginWithPasswordCheck() Password is incorrect : {} for mobileNo {}:", "", mobileNo);
                        String statusCode = prop.getProperty(Constants.FAILURE_STATUS_CODE);
                        String message = prop.getProperty(Constants.LOGIN_WITH_PASWD_FAIL_MSG);
                        return loginResponse(response, json, statusCode, message, message);
                    }

                }

                // If Unblocked or BlockTime is passed
                if (promoterProfile.getBlockExpiryDate() != null && promoterProfile.getBlockExpiryDate().isBefore(LocalDateTime.now())) {
                    logger.info("loginWithPasswordCheck() Unblocked or BlockTime is passed for mobileNo {} :", mobileNo);
                    //resetBlockCounterTo1AndBlockExpiryNull()
                    loginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, 1, null);
                    promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                    // Return Temp Block Error
                    logger.error("loginWithPasswordCheck() Password is incorrect : {} for mobileNo {}:", "", mobileNo);
                    String statusCode = prop.getProperty(Constants.FAILURE_STATUS_CODE);
                    String message = prop.getProperty(Constants.LOGIN_WITH_PASWD_FAIL_MSG);
                    return loginResponse(response, json, statusCode, message, message);
                }

                // If already blocked
                if (promoterProfile.getBlockExpiryDate() != null && promoterProfile.getBlockExpiryDate().isAfter(LocalDateTime.now())) {
                    logger.info("loginWithPasswordCheck() Already blocked and Wrong Attempts more than min wrong attempts to block: {} for mobileNo {} :", totalWrongAttempts, mobileNo);
                    // incrementAttemptAndUpdateBlockExpiry
                    LocalDateTime newBlockExpiry = LocalDateTime.now().plusMinutes(attemptToBlockTimeMap.getOrDefault(totalWrongAttempts, blockTimeOnMaxWrongLogin));

                    loginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, totalWrongAttempts, newBlockExpiry);
                    promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                    // Return server error
                    logger.error(BLOCK_LOGGER, "");
                    String statusCode = prop.getProperty(Constants.WRONG_ATTEMPT_STATUS_CODE);
                    String message = prop.getProperty(Constants.USER_BLOCKED_FOR_WRONG_ATTEMPT);
                    return loginResponse(response, json, statusCode, message, message);

                }
            }

            logger.info("loginWithPasswordCheck() Response generated: {} for mobileNo: {}:", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("loginWithPasswordCheck() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    public SnapWorkResponse proceedLogin(SnapWorkRequest request, PromoterUserMSTEntity userMSTEntity, SnapWorkResponse response) {

        String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
        String deviceID = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
        String latitude = request.getLatitude() == null ? "" : request.getLatitude().trim();
        String longitude = request.getLongitude() == null ? "" : request.getLongitude().trim();


        JSONObject json = new JSONObject();
        String jwtToken = commonUtil.generateJwtToken(mobileNo, 0, "mobile");
        if (jwtToken.isEmpty()) {
            logger.error("loginWithPasswordCheck() jwtToken is blank: {} :", "");
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.LOGIN_JWT_TOKEN_GEN_FAILED));
            response.setResponse(json);
            return response;
        }


        json.put("jwtToken", jwtToken);
        logger.info("Login Successful: {} for mobileNo: {}:", "", mobileNo);


        // Saving Records in Login Tracker Table
        PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity =
                ProObjectHelper.getObjForLogInOutTracker(userMSTEntity, mobileNo, latitude, longitude, "1", deviceID, "PAPP");

        try {
            PromoterLoginTrackerAuditEntity saveResp =
                    loginDao.saveLoginAndLogOutDetails_V2(promoterLoginTrackerAuditEntity);
        } catch (Exception e) {
            logger.error("proceedLogin() Saving Records in Login Tracker Table Exception {}, {}:", e.getMessage(), e.getCause());
        }


        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setMessage(prop.getProperty(Constants.LOGIN_WITH_PASWD_SUCC_MSG));
        response.setResponse(json);
        logger.info("Success Response generated for mobileNo: {}:", mobileNo);
        return response;

    }

    private SnapWorkResponse loginResponse(SnapWorkResponse response, JSONObject json, String statusCode, String message, String desc) {
        logger.error("Return final response {} :", "");
        response.setStatusCode(statusCode);
        response.setMessage(message);
        response.setDesc(desc);
        response.setResponse(json);
        return response;
    }

    public SnapWorkResponse proceedSuccess(SnapWorkResponse response, JSONObject json, String mobileNo) {
        String jwtFlag = prop.getProperty("JWT_FLAG");
        try {
            if (StringUtils.isNotBlank(jwtFlag) && jwtFlag.equalsIgnoreCase("Y")) {
                String jwtToken = commonUtil.generateJwtToken(mobileNo, 0, "mobile");
                json.put("jwtToken", jwtToken);
            } else
                json.put("jwtToken", "NA");

        } catch (Exception exe) {
            logger.info("Exception while generating JWT Token in Password set {} for mobileNo {}:", exe, mobileNo);
        }
        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setMessage(prop.getProperty(Constants.SET_PASSWORD_SUCC_MSG));
        response.setResponse(json);
        logger.info("setPasswordDetails() Response generated:  {} for mobileNo: {}", "", mobileNo);
        return response;
    }

    @Override
    public SnapWorkResponse setPasswordDetailsV2(SnapWorkRequest request) {
        SnapWorkResponse response = new SnapWorkResponse();

        JSONObject json = new JSONObject();
        try {
            logger.info("Inside setPasswordDetails() method in LoginServiceImpl class.. {}:", "");
            String deviceID = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
            String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
            String appFlowName = request.getAppFlowName() == null ? "" : request.getAppFlowName().trim();
            String password = request.getPassword() == null ? "" : request.getPassword();

            if (StringUtils.isBlank(deviceID) || StringUtils.isBlank(mobileNo) || !StringUtils.isNumeric(mobileNo) || StringUtils.isBlank(appFlowName) || StringUtils.isBlank(password)) {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
                return response;
            }
            UserDevicesBean obj = new UserDevicesBean();
            obj.setMobileNo(request.getMobileNo() == null ? "" : request.getMobileNo().trim());
            obj.setDeviceId(request.getDeviceId() == null ? "" : request.getDeviceId().trim());

            String encPassword = EncryptionUtil.generateEncryptPassword(password, mobileNo);
            obj.setPassword(encPassword);

            Optional<PromoterUserMSTEntity> promoterUserMSTEntity = promoterUserMSTDAO.fetchUserByPhoneNumber(mobileNo);

            List<String> allowed_usertypes_list = Arrays.asList(prop.getProperty(Constants.ALLOWED_USERTYPES_FOR_WHITELISTING).split(","));
            logger.info("ALLOWED_USERTYPES_FOR_WHITELISTING {}:", prop.getProperty(Constants.ALLOWED_USERTYPES_FOR_WHITELISTING));

            boolean isWhiteListed = promoterUserMSTEntity.isPresent() && promoterUserMSTEntity.get().getStatus().equalsIgnoreCase(UserStatus.A.name()) && allowed_usertypes_list.contains(promoterUserMSTEntity.get().getUserType());

            logger.info("Set Pwd Flow: isWhiteListed as Active Promoter: {} for mobileNo: {}:", isWhiteListed, mobileNo);

            if (!isWhiteListed) {
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setMessage(prop.getProperty(Constants.MOBILE_NUMBER_NOT_WHITELISTED));
                response.setResponse(json);
                return response;
            }

            Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity = promoterUserProfileMSTDAO.fetchUserByUserNo(mobileNo);

            boolean isForbidden = promoterUserProfileMSTEntity.isPresent() && !promoterUserProfileMSTEntity.get().getStatus().equalsIgnoreCase(UserProfileStatus.A.getCode()); // If anything apart from Active, it is Forbidden Profile.
            logger.info("User has Profile Forbidden Status: {} for mobileNo: {}:", isForbidden, mobileNo);

            if (isForbidden) {
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
                response.setResponse(json);
                return response;
            }

            boolean isSignedUp = promoterUserProfileMSTEntity.isPresent() && promoterUserProfileMSTEntity.get().getStatus().equalsIgnoreCase(UserProfileStatus.A.getCode());
            int alreadySignedUp = isSignedUp ? 1 : 0;

            logger.info("Reset Pwd isSignedUp:  {} for mobileNo: {}:", isSignedUp, mobileNo);

            switch (alreadySignedUp) {

                // Signup User
                case 1:
                    if (StringUtils.equalsIgnoreCase(appFlowName, "signup")) {
                        String statusCode = prop.getProperty(Constants.ALREADY_SIGNUP_USER_CODE);
                        String message = prop.getProperty(Constants.ALREADY_SIGNUP_USER);
                        return loginResponse(response, json, statusCode, message, message); // Msg is passed as desc too.
                    } else if (StringUtils.equalsIgnoreCase(appFlowName, "forgotpassword") && promoterUserProfileMSTEntity.get().getBlockExpiryDate() != null && promoterUserProfileMSTEntity.get().getBlockExpiryDate().isAfter(LocalDateTime.now())) {
                        logger.info("Forgot Password Flow, User is SignedUp. Account is temporarily blocked. Please try after some time: {} :", mobileNo);
                        String statusCode = prop.getProperty(Constants.WRONG_ATTEMPT_STATUS_CODE);
                        String message = prop.getProperty(Constants.USER_BLOCKED_FOR_WRONG_ATTEMPT);

                        return loginResponse(response, json, statusCode, message, message);
                    } else if (StringUtils.equalsIgnoreCase(appFlowName, "forgotpassword") && ((promoterUserProfileMSTEntity.get().getBlockExpiryDate() != null && promoterUserProfileMSTEntity.get().getBlockExpiryDate().isBefore(LocalDateTime.now())) || (promoterUserProfileMSTEntity.get().getBlockExpiryDate() == null))) {
                        logger.info("Forgot Password Flow, User is SignedUp. Account is not blocked. {} :", mobileNo);
                        int count = promoterUserProfileMSTDAO.updateProfile(encPassword, mobileNo);
                        logger.info("LOGIN_UPDATE_USERDEVICE_DTLS count:  {} for mobileNo: {}:", count, mobileNo);
                        return proceedSuccess(response, json, mobileNo);
                    } else {
                        logger.info("SignUp || isSignedUp {}, isWhiteListed {}, appFlowName {} Flow for {} :", isSignedUp, isWhiteListed, appFlowName, mobileNo);
                        return loginResponse(response, json, prop.getProperty(Constants.FAILURE_STATUS_CODE), prop.getProperty(Constants.FAILURE_ERROR_MESSAGE), prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
                    }


                case 0:

                    if (StringUtils.equalsIgnoreCase(appFlowName, "forgotpassword")) {
                        logger.info("Can not Forgot Pwd if User is not SignedUp {} :", mobileNo);
                        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                        response.setMessage(prop.getProperty(Constants.USER_IS_NOT_REGISTERED));
                        response.setResponse(json);
                        return response;
                    } else if (StringUtils.equalsIgnoreCase(appFlowName, "signup")) {

                        // This condtion serves: If user is UnRegistered and clicked on Signup, Login credential is created without any Ekyc.
                        logger.info("[Only for old APPs] User is whitelisted and Trying Signup  {} :", mobileNo);

                        PromoterUserProfileMSTEntity promoter = new PromoterUserProfileMSTEntity();
                        promoter.setUserNo(mobileNo);
                        promoter.setPassword(encPassword);
                        promoter.setDeviceId(deviceID);
                        promoter.setPromoterUserMSTEntity(promoterUserMSTEntity.get());
                        promoter.setUserType(promoterUserMSTEntity.get().getUserType());
                        promoter.setStatus(UserProfileStatus.A.getCode());
                        promoter.setChannel("PAPP");
                        promoterUserProfileMSTDAO.saveUserProfile(promoter);
                        logger.info("User Profile Created for {} :", mobileNo);
                        return proceedSuccess(response, json, mobileNo);

                    } else {
                        logger.info("NotSignUp || isSignedUp {}, isWhiteListed {}, appFlowName {} Flow for {} :", isSignedUp, isWhiteListed, appFlowName, mobileNo);
                        return loginResponse(response, json, prop.getProperty(Constants.FAILURE_STATUS_CODE), prop.getProperty(Constants.FAILURE_ERROR_MESSAGE), prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
                    }

                default:
                    logger.info("Default CASE: isSignedUp {}, isWhiteListed {}, appFlowName {} Flow for {} :", isSignedUp, isWhiteListed, appFlowName, mobileNo);
                    return loginResponse(response, json, prop.getProperty(Constants.FAILURE_STATUS_CODE), prop.getProperty(Constants.FAILURE_ERROR_MESSAGE), prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));


            }

        } catch (Exception exe) {
            logger.error("setPasswordDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    @Override
    public SnapWorkResponse fetchUserProfile_V2(SnapWorkRequest request) throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        String userName = "";
        String promoterType = "";
        JSONObject json = new JSONObject();

        logger.info("Inside fetchUserProfile() method in LoginServiceImpl class.. {}:", "");
        String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();

        // Fetch Promoter details from PROMOTER_USER_MST
        Optional<PromoterUserMSTEntity> promoterUserMSTEntity = loginDao.fetchUserByPhoneNumber(mobileNo);

        if (promoterUserMSTEntity.isPresent()) {
            promoterType = promoterUserMSTEntity.get().getUserType().toString();

            if (StringUtils.isNotBlank(promoterType)) {
                userName = promoterUserMSTEntity.get().getUsername();
                logger.info("LOGIN_FETCH_USERNAME_DTLS userName:  {} for mobileNo: {}:", userName, mobileNo);

                json.put("role", "PR"); // It has to be removed.
                json.put("promoterType", promoterType);
                json.put("mobileNo", mobileNo);
                json.put("userName", userName);

                if (promoterUserMSTEntity.isPresent() && promoterUserMSTEntity.get().getSelfieId() != null)
                {
                    String url = prop.getProperty(Constants.GET_PROFILE_URL_KEY) + promoterUserMSTEntity.get().getSelfieId();
                    Profile profile = httpUtil.hitRequest(url, null, Profile.class, null, HttpMethod.GET);
                    if(profile != null)
                    {
                        CommonUtils commonUtils = new CommonUtils();
                        json.put("encProfileImage", commonUtils.getByteArrayFromImageURL(profile.getData().getFileURL()));
                    }
                    else
                    {
                        json.put("encProfileImage", "");
                    }

                } else {
                    json.put("encProfileImage", "");
                }

                //Fetching Circle Data
                Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity =
                        loginDao.fetchCircleByCircleId(promoterUserMSTEntity.get().getPromoterCircleMSTEntity().getCircleId());
                if (promoterCircleMSTEntity.isPresent()) {
                    String circleId = promoterCircleMSTEntity.get().getCircleId();
                    String circleName = promoterCircleMSTEntity.get().getCircleName();
                    logger.info("circleId {}:", circleId);
                    logger.info("circleName {}:", circleName);
                    json.put("circleId", circleId);
                    json.put("circleName", circleName);
                }else{
                    logger.info("PromoterCircleMStEntity not present for mobileNo {}:" , mobileNo);
                }
                response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                response.setMessage(prop.getProperty(Constants.FETCH_PROFILE_SUCC_MSG));
                response.setResponse(json);

                logger.info("fetchUserProfile() Fetched Success {}:", response);
                logger.info("fetchUserProfile() API Success response generated:  {} for mobileNo: {}:", "", mobileNo);
            } else {
                logger.error("fetchUserProfile() promoter Type is blank: {} :", "");
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setResponse(json);
            }
        } else {
            logger.error("fetchUserProfile() trackerJsonArr is empty: {} :", "");
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.NO_USER_MESSAGE));
            response.setResponse(json);
            logger.info("fetchUserProfile() Fail Response generated for proMobileNo: {}:", mobileNo);
        }

        logger.info("fetchUserProfile() Response generated: {} for mobileNo: {}:", "", mobileNo);
        return response;
    }

    public SnapWorkResponse createFailedResponse(JSONObject json) {
        SnapWorkResponse response = new SnapWorkResponse();

        logger.error("sendOTP() jsonMetaObj error: {} :", "");
        response.setMessage(prop.getProperty(Constants.LOGIN_SEND_OTP_FAIL_MSG));
        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
        response.setResponse(json);
        return response;
    }

    public SnapWorkResponse callOTPService(String mobileNo, JSONObject json) throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        logger.info("Calling OTP Service {}:", mobileNo);
        JSONObject sendOtpJsonReq = new JSONObject();
        sendOtpJsonReq.put("ver", prop.getProperty(Constants.OTP_API_VER));
        sendOtpJsonReq.put("feSessionId", RestClientUtil.generateFeSessionID());
        sendOtpJsonReq.put("languageId", prop.getProperty(Constants.OTP_LANG_ID));
        sendOtpJsonReq.put("customerId", mobileNo);
        sendOtpJsonReq.put("custType", "SBA");
        sendOtpJsonReq.put("requestType", "ONBOARDING");
        sendOtpJsonReq.put("partnerId", "84657");
        sendOtpJsonReq.put("reference1", "");
        sendOtpJsonReq.put("reference2", "");
        sendOtpJsonReq.put("reference3", "");
        sendOtpJsonReq.put("reference4", "");
        sendOtpJsonReq.put("reference5", "");

        String apiResponse = "";

        try {
            String reqParams = new EncryptionRSA().simpleEncrypt(sendOtpJsonReq.toString(),
                    Base64.decodeBase64(PUB_KEY));
            String url = prop.getProperty(Constants.API_SEND_OTP_URL);
            apiResponse = restClient.sendPostRequest(url, reqParams);
        } catch (Exception e) {
            logger.error("Exception occurred in OTP Rest Call: {}", mobileNo);
            throw e;
        }

        if (StringUtils.isBlank(apiResponse)) {
            logger.error("ApiResponse Blank from OTP API error: {} :", mobileNo);
            throw new Exception("OTP Api response Blank");
        }

        JSONParser parser = new JSONParser();
        JSONObject jsonApiResObj = (JSONObject) parser.parse(apiResponse);
        logger.info("Send OTP Respose {}:", jsonApiResObj);
        JSONObject jsonMetaObj = (JSONObject) jsonApiResObj.get("meta");
        JSONObject jsonDataObj = (JSONObject) jsonApiResObj.get("data");

        if (jsonMetaObj.containsKey("status") && jsonMetaObj.containsKey("code") &&
                jsonMetaObj.get("code").equals("000")
                && jsonDataObj.containsKey("verificationToken")) {
            json.put("mobileNo", mobileNo);
            json.put("otpVerficatonCode", jsonDataObj.get("verificationToken") == null ? ""
                    : jsonDataObj.get("verificationToken"));
            json.put("ver", prop.getProperty(Constants.OTP_API_VER));
            json.put("feSessionId", sendOtpJsonReq.getOrDefault("feSessionId", RestClientUtil.generateFeSessionID()));
            json.put("langId", prop.getProperty(Constants.OTP_LANG_ID));

            response.setMessage(prop.getProperty(Constants.LOGIN_SEND_OTP_SUCC_MSG));
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
            response.setResponse(json);
            logger.info(SUCCESS_LOGGER, "", mobileNo);

            return response;
        } else {
            logger.error("Key Param Missing from OTP API error: {} :", mobileNo);
            throw new Exception("Key Param Missing from OTP API");
        }
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public SnapWorkResponse sendOTP(String mobileNo, SnapWorkRequest request) {
        JSONObject json = new JSONObject();
        logger.info("Inside sendOTP() method in LoginServiceImpl class.. {}:", "");
        String deviceId = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
        logger.info("deviceId {}:", deviceId);
        logger.info(MOBILENOLOGGER, mobileNo);

        if (StringUtils.isBlank(mobileNo) || !StringUtils.isNumeric(mobileNo) || StringUtils.isBlank(deviceId)) {
            logger.error("MobileNo or Device Id Missing or Invalid {}:", mobileNo);
            return createFailedResponse(json);
        }

        try {
            SnapWorkResponse snapWorkResponse = callOTPService(mobileNo, json);
            return snapWorkResponse;
        } catch (Exception e) {
            logger.error("Exception occurred {} cause: {} in sending otp for {}:", e.getMessage(), e.getLocalizedMessage(), mobileNo);
        }

        logger.error("sendOTP() error: {} :", "");
        return createFailedResponse(json);
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public SnapWorkResponse verifyOTP(String mobileNo, String otpVerificationCode, String otp, SnapWorkRequest
            request) {
        SnapWorkResponse response = new SnapWorkResponse();

        String jwtToken = "";

        JSONObject json = new JSONObject();


        try {
            logger.info("Inside verifyOTP() method in LoginServiceImpl class.. {}:", "");
            String isUserDeviceExist = request.getIsUserDeviceExist() == null ? ""
                    : request.getIsUserDeviceExist().trim();

            String deviceId = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
            if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNotBlank(otpVerificationCode)
                    && StringUtils.isNotBlank(otp) && StringUtils.isNotBlank(deviceId)) {

                JSONObject verifyOtpJsonReq = new JSONObject();
                verifyOtpJsonReq.put("ver", "1.0");
                verifyOtpJsonReq.put("feSessionId", RestClientUtil.generateFeSessionID());
                verifyOtpJsonReq.put("languageId", "001");
                verifyOtpJsonReq.put("customerId", mobileNo);
                verifyOtpJsonReq.put("custType", "SBA");
                verifyOtpJsonReq.put("requestType", "ONBOARDING");
                verifyOtpJsonReq.put("partnerId", "84657");
                verifyOtpJsonReq.put("reference1", "");
                verifyOtpJsonReq.put("reference2", "");
                verifyOtpJsonReq.put("reference3", "");
                verifyOtpJsonReq.put("reference4", "");
                verifyOtpJsonReq.put("reference5", "");
                verifyOtpJsonReq.put("verificationToken", otpVerificationCode);
                verifyOtpJsonReq.put("otpCode", otp);
                logger.info("isUserDeviceExist {}:", isUserDeviceExist);
                String reqParams = new EncryptionRSA().simpleEncrypt(verifyOtpJsonReq.toString(),
                        Base64.decodeBase64(PUB_KEY));
                String url = prop.getProperty(Constants.API_VERIFY_OTP_URL);
                String apiResponse = restClient.sendPostRequest(url, reqParams);

                if (StringUtils.isNotBlank(apiResponse)) {
                    JSONParser parser = new JSONParser();
                    JSONObject jsonApiResObj = (JSONObject) parser.parse(apiResponse);
                    logger.info("Verify OTP Response {}:", jsonApiResObj);
                    JSONObject jsonMetaObj = (JSONObject) jsonApiResObj.get("meta");

                    if (jsonMetaObj.containsKey("status") && jsonMetaObj.containsKey("code")) {

                        if (jsonMetaObj.get("code").equals("000") && jsonMetaObj.containsKey("description")
                                && jsonMetaObj.get("description").equals("OTP verified")) {

                            if (isUserDeviceExist.equals("Y") && StringUtils.isNotBlank(deviceId)) {
                                int count = loginDao.updateDeleteBlockFlag(deviceId, mobileNo);
                                logger.info("LOGIN_CHECK_UPDATE_DEACTIVE_DEL_FLAG count:  {} for mobileNo: {}:", count, mobileNo);
                                logger.info("multiplle device update count {}:", count);
                                if (count >= 1) {
                                    json.put("isMultiDevice", "Y");
                                } else {
                                    json.put("isMultiDevice", "N");
                                }
                            } else if (isUserDeviceExist.equals("N") && StringUtils.isNotBlank(deviceId)) {
                                int count = loginDao.updateDeviceId(mobileNo, deviceId, request);
                                logger.info("LOGIN_UPDATE_MULTIPLE_USERDEVICE_DTLS count:  {} for mobileNo: {}:", count, mobileNo);
                                if (count >= 1) {
                                    json.put("isMultiDevice", "Y");
                                } else {
                                    json.put("isMultiDevice", "N");
                                }
                                logger.info("isMultiDevice {}:", json);
                                int insertCount = loginDao.saveMultipleDeviceLoginDetails(mobileNo, deviceId, request);
                                logger.info("LOGIN_SAVE_MULTI_DEVICE_INFO_TRACKER_DTLS insertCount:  {} for mobileNo: {}:", insertCount, mobileNo);
                                logger.info("Saved saveMultipleDeviceLoginDetails , insertCount {}:", insertCount);
                            } else {
                                json.put("isMultiDevice", "N");
                            }

                            int isMobileRegisterCount = loginDao.fetchMobileRegisterCount(mobileNo);
                            logger.info("LOGIN_FETCH_MOB_COUNT_DTLS isMobileRegisterCount:  {} for mobileNo: {}:", isMobileRegisterCount, mobileNo);
                            json.put("mobileNo", mobileNo);
                            json.put("isMobileRegister", String.valueOf(isMobileRegisterCount));

                            // *****************

                            UserDevicesBean obj = new UserDevicesBean();
                            obj.setMobileNo(request.getMobileNo() == null ? "" : request.getMobileNo().trim());
                            obj.setDeviceId(request.getDeviceId() == null ? "" : request.getDeviceId().trim());
                            obj.setFcmToken(request.getFcmToken() == null ? "" : request.getFcmToken().trim());
                            obj.setAppVersion(request.getAppVersion() == null ? "" : request.getAppVersion());
                            obj.setDeviceModel(request.getDeviceModel() == null ? "" : request.getDeviceModel().trim());
                            obj.setImei(request.getImei() == null ? "" : request.getImei().trim());
                            obj.setOs(request.getDeviceType() == null ? "" : request.getDeviceType().trim());
                            obj.setPassword("NA");
                            obj.setLanguage(request.getLanguage() == null ? "En" : request.getLanguage().trim());
                            obj.setDelBlockFlag(0);
                            obj.setDelBlockBy("NA");
                            obj.setDelBlockReason("NA");

                            int count = 0;

                            if (StringUtils.isNotBlank(request.getDeviceId())) {
                                boolean isDeviceExist = loginDao.isUserDeviceExist(request.getDeviceId(), mobileNo);
                                logger.info("LOGIN_CHECK_USERDEVICE_DTLS isDeviceExist:  {} for mobileNo: {}:", isDeviceExist, mobileNo);
                                logger.info("isDeviceExist {}:", isDeviceExist);

                                if (isDeviceExist) {
                                    count = loginDao.updateUserDeviceDetails(obj);
                                    logger.info("LOGIN_UPDATE_USERDEVICE_DTLS count:  {} for mobileNo: {}:", count, mobileNo);
                                } else {
                                    count = loginDao.saveUserDeviceDetailsWithPassword(obj);
                                    logger.info("LOGIN_SAVE_USERDEVICES_DTLS count:  {} for mobileNo: {}:", count, mobileNo);
                                }
                            }

                            // Logic for JWT Token save and return in api response
                            jwtToken = commonUtil.generateJwtToken(mobileNo, 0, "mobile");
                            json.put("jwtToken", jwtToken);
                            logger.info(JWTTOKENLOGGER, jwtToken);
                            // Updating JWT Token
                            loginDao.updateJWT(jwtToken, mobileNo);

                            response.setMessage(prop.getProperty(Constants.LOGIN_VERIFY_OTP_SUCC_MSG));
                            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                            response.setResponse(json);
                            logger.info(SUCCESS_LOGGER, "", mobileNo);
                        } else {
                            logger.error("verifyOTP() jsonMetaObj error: {} :", "");
                            logger.info("contoler in else part now {}:", "");
                            json.put("mobileNo", mobileNo);
                            json.put("isMultiDevice", "N");
                            String errorMessage = jsonMetaObj.get("description") == null ? ""
                                    : (String) jsonMetaObj.get("description");
                            response.setMessage(errorMessage);
                            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                            response.setResponse(json);
                        }
                    } else {
                        logger.error("verifyOTP() jsonMetaObj error: {} :", "");
                        response.setMessage(prop.getProperty(Constants.LOGIN_VERIFY_OTP_FAIL_MSG));
                        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                        response.setResponse(json);
                    }

                } else {
                    logger.error("verifyOTP() apiResponse is blank: {} :", "");
                    response.setMessage(prop.getProperty(Constants.LOGIN_VERIFY_OTP_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setResponse(json);
                }

            } else {
                logger.error("verifyOTP() mobileNo/deviceId/otp is blank: {} :", "");
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_RESPONSE_CODE));
                response.setResponse(json);
            }
            logger.info("verifyOTP() Response generated:  {} for mobileNo: {}", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("verifyOTP() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings("unchecked")
    public SnapWorkResponse logOutAttendance(SnapWorkRequest request) {

        SnapWorkResponse response = new SnapWorkResponse();

        JSONObject json = new JSONObject();

        try {
            logger.info("Inside logOutAttendanceUpload() method in LoginServiceImpl class.. {}:", "");
            String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
            String latitude = request.getLatitude() == null ? "" : request.getLatitude().trim();
            String longitude = request.getLongitude() == null ? "" : request.getLongitude().trim();
            String userName = request.getUserName() == null ? "NA" : request.getUserName().trim();
            String udid = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
            String isGpsEnable = request.getIsGpsEnabled() == null ? "N" : request.getIsGpsEnabled().trim();

            if (latitude.contains("exception")) {
                throw new Exception();
            }

            logger.info("mobileNo  {}:", mobileNo);
            logger.info("latitude  {}:", latitude);
            logger.info("longitude {}:", longitude);
            logger.info("userName  {}:", userName);
            logger.info("udid      {}:", udid);
            logger.info("isGpsEnable {}:", isGpsEnable);

            if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo)) {

                // Fetch Promoter details from PROMOTER_USER_MST
                Optional<PromoterUserMSTEntity> promoterUserMSTEntity = promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(mobileNo);

                if (promoterUserMSTEntity.isPresent()) {

                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.LOGOUT_SUCC_MSG));
                    response.setResponse(json);
                    logger.info(SUCCESS_LOGGER, "", mobileNo);

                } else {
                    logger.error("logOutAttendanceUpload() insertCount <= zero>: {} :", "");
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.LOGOUT_FAIL_MSG));
                    response.setResponse(json);
                }
            } else {
                logger.error("logOutAttendanceUpload() mobileNo is blank: {} :", "");
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("logOutAttendanceUpload() Response generated: {} for mobileNo: {}:", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("logOutAttendanceUpload() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    public boolean logOut(String userName, String appType) throws Exception {
        boolean isExpire = false;
        if (StringUtils.isNotBlank(userName)) {
            if (appType.equalsIgnoreCase("mobile"))
                isExpire = jtiToken.expire(userName, prop.getProperty("jwt.request.app.channel"));
            else
                isExpire = jtiToken.expire(userName, prop.getProperty("jwt.request.portal.channel"));
        }
        return isExpire;
    }

    @SuppressWarnings("unchecked")
    public SnapWorkResponse isUserExist(String mobileNo, SnapWorkRequest request) {
        SnapWorkResponse response = new SnapWorkResponse();

        JSONObject json = new JSONObject();

        try {
            logger.info("Inside isUserExist() method in LoginServiceImpl class.. {}:", "");
            String deviceId = request.getDeviceId() == null ? "" : request.getDeviceId().trim();
            logger.info("deviceId {}:", deviceId);

            if (deviceId.contains("exception")) {
                throw new Exception();
            }

            boolean userExist = loginDao.isAppUserExist(mobileNo);
            logger.info("LOGIN_CHECK_APP_USER_EXIST_DTLS rows:  {} for mobileNo: {}:", userExist, mobileNo);
            boolean isMobileNoExist = loginDao.isMobileNoExist(mobileNo);
            logger.info("LOGIN_CHECK_MOBILE_EXIST_DTLS rows:  {} for mobileNo: {}:", isMobileNoExist, mobileNo);
            boolean userDeviceExist = loginDao.isDeviceExist(mobileNo, deviceId);
            logger.info("LOGIN_CHECK_APP_DEVICE_EXIST_DTLS rows:  {} for mobileNo: {}:", userDeviceExist, mobileNo);

            logger.info("userExist {}:", userExist);
            logger.info("isMobileNoExist {}:", isMobileNoExist);
            logger.info("userDeviceExist {}:", userDeviceExist);

            json.put("isWhiteListed", userExist);
            json.put("isSignedUp", isMobileNoExist);
            json.put("isUserDeviceExist", userDeviceExist);

            response.setResponse(json);
            response.setMessage(prop.getProperty(Constants.USER_EXIST));
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));

            logger.info("isUserExist() Response generated: {} for mobileNo: {}:", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("isUserExist() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public SnapWorkResponse profileUploadDetails(String mobileNo, MultipartFile file) {
        SnapWorkResponse response = new SnapWorkResponse();

        JSONObject json = new JSONObject();

        try {
            logger.info("Inside profileUploadDetails() method in LoginServiceImpl class.. {}:", "");
            logger.info(MOBILENOLOGGER, mobileNo);
            String selfieId = uploadDocuments.uploadDocument(file).getData().getFileRequestId();

            if (StringUtils.isNotBlank(selfieId)) {
                boolean selfieIdSaveResponse = uploadDocumentsDAO.saveUserSelfieId(selfieId, mobileNo);
                if (selfieIdSaveResponse) {
                    json.put("mobileNo", mobileNo);
                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.UPLOAD_PROFILE_SUCC_MSG));
                    response.setResponse(json);
                    logger.info(SUCCESS_LOGGER, "", mobileNo);
                } else {
                    logger.error("profileUploadDetails() couldn't save selfieId in db");
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
                    response.setResponse(json);
                }
            } else {
                logger.error("profileUploadDetails() selfieId is blank: {} :", "");
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
                response.setResponse(json);
            }

            logger.info("profileUploadDetails() Response generated: {} for mobileNo: {}:", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("profileUploadDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public SnapWorkResponse attendanceUploadDetails(String mobileNo, MultipartFile file, AttendanceBean obj, String encStatus) {
        SnapWorkResponse response = new SnapWorkResponse();

        JSONObject json = new JSONObject();

        try
        {
            logger.info("Inside attendanceUploadDetails() method in LoginServiceImpl class.. {}:", "");
            logger.info(MOBILENOLOGGER, mobileNo);
            String selfieId = uploadDocuments.uploadDocument(file).getData().getFileRequestId();

            if (StringUtils.isNotBlank(selfieId)) {
                obj.setSelfiePath(selfieId);
                int insertCount = uploadDocumentsDAO.saveAttendanceDetails(obj);
                logger.info("LOGIN_ATTENDANCE_UPLOAD_DTLS insertCount:  {} for mobileNo: {}:", insertCount, mobileNo);

                if (insertCount > 0) {

                    boolean isSubmitEodAttendance = false;
                    logger.info("LOGIN_CHECK_EOD_ATTEN_DTLS isSubmitEodAttendance:  {} for mobileNo: {}:", isSubmitEodAttendance, mobileNo);

                    json.put("submitedEODAttendance", "N");


                    json.put("mobileNo", mobileNo);
                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.UPLOAD_ATTENDANCE_SUCC_MSG));
                    response.setResponse(json);
                    logger.info(SUCCESS_LOGGER, "", mobileNo);
                }
                else
                {
                    logger.error("attendanceUploadDetails() insertCount <= zero: {} :", "");
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
                    response.setResponse(json);
                }
            }
            else
            {
                logger.error("attendanceUploadDetails() selfieId is blank: {} :", "");
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
                response.setResponse(json);
            }

            logger.info("attendanceUploadDetails() Response generated: {} for mobileNo: {}:", "", mobileNo);
            return response;

        } catch (Exception exe) {
            logger.error("attendanceUploadDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public SnapWorkResponse attendanceViewDetails(String deviceID, String mobileNo, SnapWorkRequest request, String lat, String lng) {
        SnapWorkResponse response = new SnapWorkResponse();

        JSONObject json = null;

        JSONArray jsonArray = new JSONArray();
        JSONObject jsonAttendanceObj = new JSONObject();

        try {
            logger.info("Inside attendanceViewDetails() method in LoginServiceImplV2 class {}:", "");
            logger.info(MOBILENOLOGGER, mobileNo);
            logger.info(DEVICEIDLOGGER, deviceID);
            logger.info("latitude {}:", lat);
            logger.info("longitude {}:", lng);

            String formatedAdress = ReverseGeoCoderUtil.getFormatedAdress(
                    Double.parseDouble(lat),
                    Double.parseDouble(lng),
                    prop.getProperty(Constants.GOOGLE_API_KEY));

            logger.info("ADDRESS from Google API {}:", formatedAdress);

            String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
            String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

            logger.info("startDate {}:", startDate);
            logger.info("endDate   {}:", endDate);

            List<PromoterAttendanceAuditEntity> rows =
                    loginDao.getAttendanceDetails_V2(mobileNo, startDate, endDate);

            if (rows != null && !rows.isEmpty()) {
                logger.info("LOGIN_ATTENDANCE_VIEW_DTLS rows: {} for mobileNo: {}:", rows.size(), mobileNo);

                for (PromoterAttendanceAuditEntity row : rows) {
                    logger.info("attendanceViewDetails() setting json :{} :", row);
                    json = new JSONObject();
                    json.put("dateTime", row.getCreatedDate().format(DateTimeFormatter.ofPattern("HH:mm")));
                    json.put("mobileNo", mobileNo);
                    json.put("latitude", lat);
                    json.put("longitude", lng);
                    json.put("address", row.getAddress());
                    json.put("displayDate", row.getCreatedDate().format(DateTimeFormatter.ofPattern("dd-MMM-yy")));

                    jsonArray.add(json);
                }

                jsonAttendanceObj.put("address", formatedAdress);
                jsonAttendanceObj.put("attendance", jsonArray);
                response.setMessage(prop.getProperty(Constants.VIEW_ATTENDANCE_SUCC_MSG));
                response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                response.setResponse(jsonAttendanceObj);
                logger.info(SUCCESS_LOGGER, "", mobileNo);
            } else {
                logger.error("attendanceViewDetails() rows null: {} :", "");
                jsonAttendanceObj.put("address", formatedAdress);
                jsonAttendanceObj.put("attendance", jsonArray);
                response.setMessage(prop.getProperty(Constants.VIEW_ATTENDANCE_FAIL_MSG));
                response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                response.setResponse(jsonAttendanceObj);
            }

            logger.info("attendanceViewDetails() Response generated:  {} for mobileNo: {}", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("attendanceViewDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(jsonAttendanceObj);
            return response;
        }
    }

    @Override
    public SnapWorkResponse isRefreshToKen(SnapWorkRequest request) throws Exception {
        SnapWorkResponse response = new SnapWorkResponse();

        logger.info("Inside isRefreshToKen() method in LoginServiceImplV2 class {}:", "");

        JSONObject json = new JSONObject();
        String jwtToken = commonUtil.generateJwtToken(request.getMobileNo(), 0, "mobile");
        json.put("jwtToken", jwtToken);

        loginDao.updateJWT(jwtToken, request.getMobileNo());

        response.setMessage(prop.getProperty(Constants.JWT_GENERATED_SUCCESSFULLY));
        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setResponse(json);

        logger.info("Success Response generated:  {}:", "");

        return response;
    }

    public String imageUpload(String mobileNo, MultipartFile file, String selfieName) {
        Path path = null;
        boolean result = false;
        boolean subDirResult = false;

        try {

            String uploadFolder = prop.getProperty(Constants.IMAGE_PATH);
            logger.info("Inside imageUpload() method in LoginServiceImplV2 class {}:", "");

            if (StringUtils.isNotBlank(mobileNo)) {

                File theDir = new File(uploadFolder + selfieName);

                try {
                    theDir.mkdir();
                    result = true;
                    uploadFolder = theDir.toString();
                    File subDir = new File(uploadFolder + slash + mobileNo);

                    if (result && !subDir.exists()) {
                        subDir.mkdir();
                        subDirResult = true;
                        uploadFolder = subDir.toString();
                        if (subDirResult) {
                            byte[] bytes = file.getBytes();
                            path = Paths.get(uploadFolder + slash + file.getOriginalFilename());
                            logger.info("path ---> {}:", path);
                            Files.write(path, bytes);
                        }

                    } else {
                        for (File fileList : subDir.listFiles()) {
                            if (!fileList.isDirectory()) {
                                boolean fileDeleted = fileList.delete();

                                logger.info("File Deleted {}:", fileDeleted);

                            }
                        }
                        subDir = new File(uploadFolder + slash + mobileNo);
                        byte[] bytes = file.getBytes();
                        path = Paths.get(subDir.toString() + slash + file.getOriginalFilename());
                        logger.info("path {}:", path);
                        Files.write(path, bytes);
                    }

                } catch (Exception e) {
                    logger.error("Error {}:", e.getMessage());
                }
            }

        } catch (Exception e) {
            logger.error("Exception for imageUpload() method in LoginServiceImpl class, {}:", e.getMessage(), e.getCause());
        }

            logger.info("imageUpload() Response generated:  {} for mobileNo: {}:", "", mobileNo);
        if (path != null) {
            return path.toString();
        }else{
            return "";
        }
    }

}