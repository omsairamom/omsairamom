package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PromoterUserMSTRepository extends JpaRepository<PromoterUserMSTEntity, Long>
{

    Optional<PromoterUserMSTEntity> findOneByUserNo(String userPhoneNumber);

    List<PromoterUserMSTEntity> findAllByUserNo(String userPhoneNumber);

    @Query(value = "SELECT * FROM PROMOTER_USER_MST where USER_NO = :mobileNumber and STATUS = :status", nativeQuery=true)
    Optional<PromoterUserMSTEntity> findOneByUserNoWithStatus(@Param("mobileNumber") String mobileNumber, @Param("status") String status);

    @Query(value = "SELECT * FROM PROMOTER_USER_MST where id = :id and STATUS = :status", nativeQuery=true)
    Optional<PromoterUserMSTEntity> findOneByIdWithStatus(@Param("id") Long id, @Param("status") String status);
}