package com.airtelbank.common;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Oct 03, 2019 04:24:15 PM
 */

public class CommonException {
	
	private static Logger logger = LoggerFactory.getLogger(CommonException.class);

		public static String getPrintStackTrace(Throwable e) 
		{
			final StringWriter sw = new StringWriter();
			final PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			logger.info(sw.toString());
			logger.error(e.getMessage());
			return sw.toString();
		}
		
		public static void printStackTraceForDAO(Throwable e) throws Exception 
		{
			final StringWriter sw = new StringWriter();
			final PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			logger.info(e.toString());
			logger.error(e.getMessage());
			throw new Exception(AppConstant.exception_exception);
		}
}
