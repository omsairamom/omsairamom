package com.airtelbank.myteam.service.impl;

import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.dao.UploadDocumentsDAO;
import com.airtelbank.myteam.common.CommonException;
import com.airtelbank.myteam.service.CaptureComplianceService;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import com.airtelbank.util.UploadDocuments;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileOutputStream;

@Service
public class CaptureComplianceServiceImpl implements CaptureComplianceService
{
	private static final Logger logger = LoggerFactory.getLogger(CaptureComplianceServiceImpl.class);

	@Autowired
	PropertyManager prop;

	@Autowired
	private UploadDocumentsDAO uploadDocumentsDAO;

	@Autowired
	private UploadDocuments uploadDocuments;

	@SuppressWarnings({ "unchecked" })
	public SnapWorkResponse captureComplianceDetails(MultipartFile file, String mobileNo, String action) throws Exception
	{
		SnapWorkResponse response = new SnapWorkResponse();

		JSONObject json = new JSONObject();
		String delFileName = "";
		String addFileName = "";

		try
		{
			String fileName = file.getOriginalFilename();
			logger.info("Inside captureComplianceDetails() method in CaptureComplianceServiceImpl class.. {}" , "");
			logger.info("mobileNo {}:" , mobileNo);
			logger.info("fileName {}:" , fileName);
			logger.info("action   {}:" , action);

			if (StringUtils.isNotBlank(mobileNo) && !file.isEmpty())
			{
				String uploadPath = prop.getProperty(Constants.FILE_SAVE_COMPLIANCE_PATH);
				logger.info("uploadPath :  {} for mobileNo: {}:" , uploadPath,mobileNo);
				if (StringUtils.isNumeric(mobileNo))
				{
					if (action.equalsIgnoreCase("add"))
					{
						logger.info("action is add here:{} for mobileNo:  {}:" , "",mobileNo);

						if (fileName.indexOf('.') > 0)
						{
							addFileName = fileName.substring(0, fileName.lastIndexOf('.'));
						}

						boolean isPdfGenerated = convertImageToPdf(mobileNo, addFileName, uploadPath, file);
						logger.info("isPdfGenerated:  {} for mobileNo: {}:" , isPdfGenerated,mobileNo);
						if (isPdfGenerated)
						{
							json.put("mobileNo", mobileNo);
							json.put("fileName", fileName);
							json.put("action", action);
							response.setMessage(prop.getProperty(Constants.COMPLIANCE_CAPTURE_ADD_SUCC_MSG));
							response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
							response.setResponse(json);
						}
						else
						{
							logger.error("captureComplianceDetails() trackerJsonArr is empty: {} :" , "");
							response.setMessage(prop.getProperty(Constants.COMPLIANCE_CAPTURE_ADD_FAIL_MSG));
							response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
							response.setResponse(json);
						}

					}
					else if (action.equalsIgnoreCase("delete"))
					{
						logger.info("action is delete here {}:" ,"");

						if (fileName.indexOf('.') > 0)
						{
							delFileName = fileName.substring(0, fileName.lastIndexOf('.'));
						}

						String filePath = uploadPath + mobileNo + "/" + delFileName + ".pdf";
						File delFile = new File(filePath);

						if (delFile.exists())
						{
							boolean deleteFlag = delFile.delete();

							if (deleteFlag)
							{
								json.put("mobileNo", mobileNo);
								json.put("fileName", fileName);
								json.put("action", action);
								response.setMessage(prop.getProperty(Constants.COMPLIANCE_CAPTURE_DEL_SUCC_MSG));
								response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
								response.setResponse(json);
								logger.info("Success Response generated:  {} for mobileNo: {}:", "",mobileNo);
							}
							else
							{
								logger.error("captureComplianceDetails() deleteFlag is empty: {} :" , "");
								response.setMessage(prop.getProperty(Constants.COMPLIANCE_CAPTURE_DEL_FAIL_MSG));
								response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
								response.setResponse(json);
							}
						}
						else
						{
							logger.error("captureComplianceDetails() delFile doesn't exist:  {} for mobileNo: {}:" , "",mobileNo);
							response.setMessage(prop.getProperty(Constants.COMPLIANCE_CAPTURE_DEL_FILE_NOT_EXIST_MSG));
							response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
							response.setResponse(json);
						}
					}
				}
				else
				{
					logger.error("captureComplianceDetails() mobileNo is Blank: {} :" , "");
					response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
				}
			}
			logger.info("captureComplianceDetails() Response generated: {} for mobileNo: {}:" , "",mobileNo);
			return response;

		}
		catch (Exception exe)
		{
			logger.error("captureComplianceDetails() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
			return response;
		}
	}

	private boolean convertImageToPdf(String mobileNo, String fileName, String uploadPath, MultipartFile file)
	{
		boolean isPdfGenerated = false;
		Document document = null;

		try
		{
			logger.info("Inside convertBase64ImageToPdf() method in CaptureComplianceServiceImpl class.... {}:" ,"");
			File subDir = new File(uploadPath + "/" + mobileNo);
			logger.info("subDir {}:" , subDir);
			if (!subDir.exists())
			{
				subDir.mkdir();
			}

			logger.info("fileName {}:" , file.getOriginalFilename());
			document = new Document();
			File convFile = new File(file.getOriginalFilename().substring(0,file.getOriginalFilename().lastIndexOf("."))+".pdf");
			PdfWriter.getInstance(document, new FileOutputStream(convFile)); // was uploadFolder
			document.open();
			document.newPage();
			byte[] bytes = file.getBytes();
			document.add(Image.getInstance(bytes));
			Image image = Image.getInstance(bytes);
			image.setAbsolutePosition(0, 0);
			image.setBorderWidth(0);
			image.scaleAbsoluteHeight(PageSize.A4.getHeight());
			image.scaleAbsoluteWidth(PageSize.A4.getWidth());
			document.add(image);
			document.close();
			String documentId = uploadDocuments.uploadDocument(convFile, file.getOriginalFilename()).getData().getFileRequestId();

			if (StringUtils.isNotBlank(documentId))
			{
				isPdfGenerated = uploadDocumentsDAO.captureCompliance(documentId, mobileNo);
			}
			else
			{
				logger.error("profileUploadDetails() documentId is blank: {} :", "");
				return false;
			}
		}
		catch (Exception e)
		{
			logger.error("convertBase64ImageToPdf() Internal Exception {}, {}:" , e.getMessage(), e.getCause());
			CommonException.getPrintStackTrace(e);
		}

		logger.info("convertBase64ImageToPdf() Response generated: {} :" , "");
		return isPdfGenerated;
	}
}