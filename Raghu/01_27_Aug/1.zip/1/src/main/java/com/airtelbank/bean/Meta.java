package com.airtelbank.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Meta {

    private String code;
    private String description;
    private int status;

    public Meta(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public Meta(String code, int status) {
        this.code = code;
        this.status = status;
    }

}
