package com.airtelbank.myteam.service;

import com.airtelbank.common.SnapWorkResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface CaptureComplianceService {

	SnapWorkResponse captureComplianceDetails(MultipartFile file, String mobileNo, String action)throws Exception;

}
