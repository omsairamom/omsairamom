
package com.airtelbank.model.Retailer;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Data {

    @SerializedName("size")
    @Expose
    private Integer size;
    @SerializedName("retailers")
    @Expose
    private List<RetailerResp> retailers = null;

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public List<RetailerResp> getRetailers() {
        return retailers;
    }

    public void setRetailers(List<RetailerResp> retailers) {
        this.retailers = retailers;
    }

}
