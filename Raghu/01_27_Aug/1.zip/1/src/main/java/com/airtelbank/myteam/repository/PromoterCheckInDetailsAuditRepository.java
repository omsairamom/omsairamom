package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional
public interface PromoterCheckInDetailsAuditRepository extends JpaRepository<PromoterCheckInDetailsAuditEntity, Long>
{
    Optional<PromoterCheckInDetailsAuditEntity> findByPromoterUserMSTEntity(PromoterUserMSTEntity promoterUserMSTEntity);

    @Query(value = "SELECT * FROM PROMOTER_CHECKIN_DETAILS_AUDIT where PROMOTER_ID = :id and STATUS = 'Success' Order by UPDATED_DATE desc", nativeQuery=true)
    List<PromoterCheckInDetailsAuditEntity> getPromoterDetailsByID(@Param("id") Long id);
}
