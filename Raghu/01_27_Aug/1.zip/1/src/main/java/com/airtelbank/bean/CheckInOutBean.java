package com.airtelbank.bean;

/**
 * @author Mayuri Patil
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 18, 2019 11:34:45 AM
 */
public class CheckInOutBean {

	private String retMobileNo;
	private String proMobileNo;
	private String type;
	private String storeName;
	private String dateOfVisit;
	private String latitude;
	private String longitude;
	private String inOrOut;
	private String marryDist;
	private String field1;
	private String field2;
	private String field3;
	private String field4;
	private String field5;
	private String createdDt;
	private String updatedDt;
	private String remarks;

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getRetMobileNo() {
		return retMobileNo;
	}

	public void setRetMobileNo(String retMobileNo) {
		this.retMobileNo = retMobileNo;
	}

	public String getProMobileNo() {
		return proMobileNo;
	}

	public void setProMobileNo(String proMobileNo) {
		this.proMobileNo = proMobileNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getDateOfVisit() {
		return dateOfVisit;
	}

	public void setDateOfVisit(String dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getInOrOut() {
		return inOrOut;
	}

	public void setInOrOut(String inOrOut) {
		this.inOrOut = inOrOut;
	}

	public String getMarryDist() {
		return marryDist;
	}

	public void setMarryDist(String marryDist) {
		this.marryDist = marryDist;
	}

	public String getField1() {
		return field1;
	}

	public void setField1(String field1) {
		this.field1 = field1;
	}

	public String getField2() {
		return field2;
	}

	public void setField2(String field2) {
		this.field2 = field2;
	}

	public String getField3() {
		return field3;
	}

	public void setField3(String field3) {
		this.field3 = field3;
	}

	public String getField4() {
		return field4;
	}

	public void setField4(String field4) {
		this.field4 = field4;
	}

	public String getField5() {
		return field5;
	}

	public void setField5(String field5) {
		this.field5 = field5;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

}
