package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.service.ActivityTrackerService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class ActivityTrackerController {

	private static Logger logger = LoggerFactory.getLogger(ActivityTrackerController.class);

	@Autowired
	ActivityTrackerService activityTrackerService;

	@Autowired
	PropertyManager prop;
	
	@Autowired
	CommonUtils commonUtil;

	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;	
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();

	@PostMapping(path = "/v1/myoutlet/activity-tracker")
	public ResponseEntity<Object> activityTrackerDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		try 
		{
			startTime = System.currentTimeMillis();
			logger.info("Activity Tracker Details, Request start timeInMillis {}:" , startTime);
			logger.info("Activity Tracker Details, Request params {}:", gson.toJson(request));
			JSONArray trackerJsonArr = request.getTrackerInfo();

			if (!trackerJsonArr.isEmpty()) 
			{
				response = activityTrackerService.activityTrackerDetails(request);
			} 
			else 
			{
				response.setMessage(prop.getProperty(Constants.ACTIVITY_TRACKER_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Activity Tracker Details, response {}: "  ,gson.toJson(response));
			endTime = System.currentTimeMillis();
			logger.info("Activity Tracker Details, Request end timeInMillis {}:"  , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("************************************************************************************************************************************* {}:" , "");
		}
		catch (Exception exe) 
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
