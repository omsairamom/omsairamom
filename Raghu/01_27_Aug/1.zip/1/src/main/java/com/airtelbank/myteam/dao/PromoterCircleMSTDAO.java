package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterCircleMSTEntity;
import com.airtelbank.myteam.repository.PromoterCircleMSTRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class PromoterCircleMSTDAO
{
    @Autowired
    PromoterCircleMSTRepository promoterCircleMSTRepository;

    public Optional<PromoterCircleMSTEntity> fetchCircleByCircleId(String circleId)
    {
        return promoterCircleMSTRepository.findOneByCircleId(circleId);
    }
}
