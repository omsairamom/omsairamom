package com.airtelbank.myteam.service.impl;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterCircleMSTEntity;
import com.airtelbank.entity.PromoterOutletMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.jwt.AeroCache;
import com.airtelbank.myteam.apbop.Merchant;
import com.airtelbank.myteam.apbop.Retailer;
import com.airtelbank.myteam.apbop.UserShopLatitudeLongitudeModel;
import com.airtelbank.myteam.common.CommonException;
import com.airtelbank.myteam.dao.CheckInAndOutDAO;
import com.airtelbank.myteam.dao.PromoterCheckInDetailsAuditDAO;
import com.airtelbank.myteam.dao.PromoterCircleMSTDAO;
import com.airtelbank.myteam.dao.PromoterUserMSTDAO;
import com.airtelbank.myteam.repository.PromoterCheckInDetailsAuditRepository;
import com.airtelbank.myteam.repository.PromoterOutletMSTRepository;
import com.airtelbank.myteam.service.CheckInAndOutService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * This class is used for Check-in Check-out functionality
 */
@Service
@Transactional
public class CheckInAndOutServiceImpl implements CheckInAndOutService
{
	private static final Logger logger = LoggerFactory.getLogger(CheckInAndOutServiceImpl.class);

	@Autowired
	PropertyManager prop;

	@Autowired
	SnapWorkRequest request;

	@Autowired
	CheckInAndOutDAO checkInAndOutDao;

	@Autowired
	PromoterCheckInDetailsAuditRepository promoterCheckInDetailsAuditRepository;

	@Autowired
	PromoterOutletMSTRepository promoterOutletMSTRepository;

	@Autowired
	AeroCache aeroCache;

	@Autowired
	Merchant merchant;

	@Autowired
	Retailer retailer;

	@Autowired
	PromoterUserMSTDAO promoterUserMSTDAO;

	@Autowired
	PromoterCircleMSTDAO promoterCircleMSTDAO;

	@Autowired
	PromoterCheckInDetailsAuditDAO promoterCheckInDetailsAuditDAO;

	private static final String setName = "OUTLET_MGMT";

	@SuppressWarnings("unchecked")
	@Override
	public SnapWorkResponse checkInDetailsV2(String promoterNo, String outletNo, String latitude, String longitude)
	{
		boolean isCheckInAllowed = false;

		SnapWorkResponse response = new SnapWorkResponse();

		JSONObject json = new JSONObject();
		CommonUtils commonUtils = new CommonUtils();

		String shopLatitude = null;
		String shopLongitude = null;
		UserShopLatitudeLongitudeModel userShopLatitudeLongitudeModel = null;

		try
		{
			// Step 1 : Lat Long of Promoter would come in API.
			if (StringUtils.isNotBlank(promoterNo) && StringUtils.isNotBlank(outletNo) && StringUtils.isNotBlank(latitude)
					&& StringUtils.isNotBlank(longitude))
			{
				Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity = promoterOutletMSTRepository.findByPromoterNoANDOutletNo(promoterNo, outletNo);

				if (promoterOutletMSTEntity.isPresent())
				{
					// Fetch Promoter details from PROMOTER_USER_MST
					Optional<PromoterUserMSTEntity> promoterUserMSTEntity = promoterUserMSTDAO.fetchUserByIDWithStatus(promoterOutletMSTEntity.get().getPromoterUserMSTEntity().getId());

					// Step 2: Check If data cached in AeroSpike currently
					Map<String, String> map = (Map<String, String>) aeroCache.getOutletDetails(setName, outletNo, AeroCache.defaultColumn);

					if (map == null)
					{
						map = new HashMap<String, String>(2);
						map.put("shopLatitude", "NA");
						map.put("shopLongitude", "NA");
						aeroCache.putOutletDetails(setName, outletNo, aeroCache.defaultColumn, map);
					}

					// Step 3: If Data is not cached then HIT API and Cache data
					if (map.get("shopLatitude").equalsIgnoreCase("NA"))
					{
						String category = "";

						// Read User Type
						if (promoterUserMSTEntity.isPresent())
						{
							category = promoterUserMSTEntity.get().getCategory();
						}
						else
						{
							category = "";
						}


						// Get Data from External API
						if (category.equalsIgnoreCase(prop.getProperty(Constants.KEY_MERCHANT)))
						{
							//This MSISDN is success case number
							//"msisdn": 8200921256
							userShopLatitudeLongitudeModel = merchant.userTypeDetails(category, outletNo);
						}
						else if (category.equalsIgnoreCase(Constants.KEY_RETAILER))
						{
							// This MSISDN is success case number
							//"msisdn": 8130678555
							userShopLatitudeLongitudeModel = retailer.userTypeDetails(category, outletNo);
						}

						if (userShopLatitudeLongitudeModel != null && userShopLatitudeLongitudeModel.getShopLatitude() != null && userShopLatitudeLongitudeModel.getShopLongitude() != null)
						{
							shopLatitude = userShopLatitudeLongitudeModel.getShopLatitude();
							shopLongitude = userShopLatitudeLongitudeModel.getShopLongitude();

							map.put("shopLatitude", shopLatitude);
							map.put("shopLongitude", shopLongitude);
							aeroCache.putOutletDetails(setName, outletNo, aeroCache.defaultColumn, map);
							aeroCache.saveOutletDetails(Integer.valueOf(prop.getProperty(Constants.EXPIRY_SESSION_IN_SECONDS_FOR_CHECKIN)), setName, outletNo, map);
						}
						else
						{
							logger.error("checkInDetails() shop lat lng not found: {} :", "");
							response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
							response.setMessage(prop.getProperty(Constants.SHOP_LAT_LNG_NA));
							response.setResponse(json);
							logger.info("Fail Response generated for proMobileNo: {}:", outletNo);
							logger.info("checkInDetailsV2() Response generated:  {} for proMobileNo: {}", "", outletNo);
							return response;
						}
					}
					else
					{
						// Step 4: Fetch AeroSpike data
						shopLatitude = map.get("shopLatitude");
						shopLongitude = map.get("shopLongitude");
					}

					// Fetch Circle details from PROMOTER_CIRCLE_MST
					if (promoterOutletMSTEntity.isPresent())
					{

						Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity =
								promoterCircleMSTDAO.fetchCircleByCircleId(promoterUserMSTEntity.get().getPromoterCircleMSTEntity().getCircleId());

						// Create a new entry for Check-In Attempt whenever there is an attempt for checkin
						PromoterCheckInDetailsAuditEntity promoterCheckInDetailsAuditEntity = new PromoterCheckInDetailsAuditEntity();
						promoterCheckInDetailsAuditEntity.setCheckInType(prop.getProperty(Constants.KEY_CHECK_IN));
						promoterCheckInDetailsAuditEntity.setStatus("Pending");

						if (promoterUserMSTEntity.isPresent()) {
							promoterCheckInDetailsAuditEntity.setPromoterUserMSTEntity(promoterUserMSTEntity.get());
							promoterCheckInDetailsAuditEntity.setPromoterNo(promoterUserMSTEntity.get().getUserNo());

						}
						if (promoterOutletMSTEntity.isPresent()) {
							promoterCheckInDetailsAuditEntity.setPromoterOutletMSTEntity(promoterOutletMSTEntity.get());
							promoterCheckInDetailsAuditEntity.setOutletNo(promoterOutletMSTEntity.get().getOutletNo());
						}
						if (promoterCircleMSTEntity.isPresent()) {
							promoterCheckInDetailsAuditEntity.setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());
						}

						promoterCheckInDetailsAuditEntity.setOutletLatitude(shopLatitude);
						promoterCheckInDetailsAuditEntity.setOutletLongitude(shopLongitude);
						promoterCheckInDetailsAuditEntity.setPromoterLatitude(latitude);
						promoterCheckInDetailsAuditEntity.setPromoterLongitude(longitude);
						promoterCheckInDetailsAuditEntity.setMarryDistance("");
						PromoterCheckInDetailsAuditEntity prom = promoterCheckInDetailsAuditDAO.saveAndFlushCheckInDetails(promoterCheckInDetailsAuditEntity);

						// Calculate Marry Distance Logic
						String marryDist = commonUtils.calculateMarryDistance(latitude, shopLatitude, longitude, shopLongitude);

						double marryDistance = Double.parseDouble(marryDist);

						logger.info("Deepak marryDist promoterNo outletNo latitude longitude shopLatitude shopLongitude {}, {}, {}, {}, {}, {}, {}:"
								, marryDist, promoterNo, outletNo, latitude, longitude, shopLatitude, shopLongitude);

						if (marryDistance <= Double.parseDouble(prop.getProperty(Constants.GEO_CHECKIN_LIMIT_VALUE_IN_METERS)))
						{
							isCheckInAllowed = true;

							logger.info("checkInDetailsV2() Success isCheckedInAllowed: {}:", isCheckInAllowed);
						}
						else
						{
							isCheckInAllowed = false;
						}

						// Update the status of newly created entry
						if (isCheckInAllowed)
						{
							prom.setStatus("Success");
							logger.info("checkInDetailsV2() Success isCheckedInAllowed: {}:", "SUCCESS");
						}
						else
						{
							logger.info("checkInDetailsV2() Success isCheckedInAllowed: {}:", "FAIL");
							prom.setStatus("Fail");
						}

						prom.setMarryDistance(marryDist);
						prom.setId(prom.getId());
						promoterCheckInDetailsAuditRepository.save(prom);

						// 	Successfull Checkin: Add lat long val in Promoter_Outlet_MST lat long columns.

						if (isCheckInAllowed)
						{
							// Add Lat Lng in Promoter_Outlet_MST else update Lat Lng in Promoter_Outlet_MST
							if (promoterOutletMSTEntity.isPresent())
							{
								promoterOutletMSTEntity.get().setLatitude(latitude);
								promoterOutletMSTEntity.get().setLongitude(longitude);
								promoterOutletMSTEntity.get().setUpdatedDate(LocalDateTime.now());
								promoterOutletMSTRepository.save(promoterOutletMSTEntity.get());

								json.put("Mobile_No" , outletNo);
								json.put("retailerName", promoterOutletMSTEntity.get().getOutletName());
								json.put("retailerAddress","");

								response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
								response.setMessage(prop.getProperty(Constants.DASHBOARD_CHECKIN_SUCC_MSG));
								response.setResponse(json);
								logger.info("checkInDetailsV2() Success Response generated for proMobileNo: {}:", json.toString());
							}
							else
							{
								logger.error("checkInDetails() trackerJsonArr is empty: {} :", promoterNo);
								response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
								response.setMessage(prop.getProperty(Constants.INCORRECT_MAPPING_MESSAGE));
								response.setResponse(json);
								logger.info("checkInDetailsV2() Fail Response generated for proMobileNo: {}:", outletNo);
							}
						}
						else
						{
							logger.error("checkInDetails() Geo Distance Exceeded the limit : {} :", promoterNo);
							response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
							response.setMessage(prop.getProperty(Constants.DASHBOARD_CHECKIN_MARRY_DISTANCE_MSG));
							response.setResponse(json);
						}
					}
					else
					{
						logger.error("checkInDetails() No Mapping between Promoter_Outlet_MST Table and Promoter Mobile Number: {} :", promoterNo);
						response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
						response.setMessage(prop.getProperty(Constants.INCORRECT_MAPPING_MESSAGE));
						response.setResponse(json);
						logger.info("checkInDetailsV2() Fail Response generated for proMobileNo: {}:", outletNo);
					}
				}
				else
				{
					logger.error("checkInDetails() trackerJsonArr is empty: {} :", promoterNo);
					logger.error("checkInDetails() trackerJsonArr is empty: {} :", prop.getProperty(Constants.NO_USER_MESSAGE));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setMessage(prop.getProperty(Constants.NO_USER_MESSAGE));
					response.setResponse(json);
					logger.info("checkInDetailsV2() Fail Response generated for proMobileNo: {}:", outletNo);
				}
			}
			else
			{
				logger.error("checkInDetails() PromoterNo, OutletNo is empty: {} : {}" , promoterNo, outletNo);
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("checkInDetailsV2() Response generated:  {} for proMobileNo: {}" , "", outletNo);
			return response;
		}
		catch (Exception exe)
		{
			logger.error("checkInDetailsV2() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			logger.error(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			CommonException.getPrintStackTrace(exe);
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setResponse(json);
			return response;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public SnapWorkResponse checkOutDetailsV2(String promoterNo, String outletNo, String latitude, String longitude, String remark)
	{
		boolean isCheckOutAllowed = false;

		logger.info("In ServiceImpl.checkOutDetailsV2() : {}, {}, {}, {}", promoterNo, outletNo, latitude, longitude);
		SnapWorkResponse response = new SnapWorkResponse();

		JSONObject json = new JSONObject();
		CommonUtils commonUtils = new CommonUtils();
		String marryDist = "";
		double marryDistance = 0.0;
		String shopLatitude = null;
		String shopLongitude = null;

		try
		{
			String latitudeFromReq = latitude;
			String longitudeFromReq = longitude;

			// Step 1: Lat Long of Promoter would come in API.
			if (StringUtils.isNotBlank(promoterNo) && StringUtils.isNotBlank(outletNo) && StringUtils.isNotBlank(latitudeFromReq)
					&& StringUtils.isNotBlank(longitudeFromReq))
			{
				// Fetch Promoter details from PROMOTER_USER_MST
				Optional<PromoterOutletMSTEntity> promoterOutletMSTEntity = promoterOutletMSTRepository.findByPromoterNoANDOutletNo(promoterNo, outletNo);

				if (promoterOutletMSTEntity.isPresent())
				{
					// Fetch Promoter details from PROMOTER_USER_MST
					Optional<PromoterUserMSTEntity> promoterUserMSTEntity = promoterUserMSTDAO.fetchUserByIDWithStatus(promoterOutletMSTEntity.get().getPromoterUserMSTEntity().getId());

					if (promoterUserMSTEntity.isPresent())
					{
						shopLatitude = promoterOutletMSTEntity.get().getLatitude();
						shopLongitude = promoterOutletMSTEntity.get().getLongitude();

						Optional<PromoterCircleMSTEntity> promoterCircleMSTEntity = null;

						if (promoterUserMSTEntity.isPresent())
						{
							// Fetch Circle details from PROMOTER_CIRCLE_MST
							promoterCircleMSTEntity =
									promoterCircleMSTDAO.fetchCircleByCircleId(promoterUserMSTEntity.get().getPromoterCircleMSTEntity().getCircleId());

						}

						// Create a new entry for Check-In Attempt whenever there is an attempt for checkin
						PromoterCheckInDetailsAuditEntity promoterCheckInDetailsAuditEntity = new PromoterCheckInDetailsAuditEntity();
						promoterCheckInDetailsAuditEntity.setCheckInType(prop.getProperty(Constants.KEY_CHECK_OUT));
						promoterCheckInDetailsAuditEntity.setStatus("Pending");

						if (promoterUserMSTEntity.isPresent())
						{
							promoterCheckInDetailsAuditEntity.setPromoterUserMSTEntity(promoterUserMSTEntity.get());
						}
						if (promoterOutletMSTEntity.isPresent())
						{
							promoterCheckInDetailsAuditEntity.setOutletNo(promoterOutletMSTEntity.get().getOutletNo());
							promoterCheckInDetailsAuditEntity.setPromoterOutletMSTEntity(promoterOutletMSTEntity.get());
						}
						if (promoterCircleMSTEntity.isPresent())
						{
							promoterCheckInDetailsAuditEntity.setPromoterCircleMSTEntity(promoterCircleMSTEntity.get());
						}

						promoterCheckInDetailsAuditEntity.setPromoterNo(promoterUserMSTEntity.get().getUserNo());
						promoterCheckInDetailsAuditEntity.setOutletLatitude(promoterOutletMSTEntity.get().getLatitude());
						promoterCheckInDetailsAuditEntity.setOutletLongitude(promoterOutletMSTEntity.get().getLongitude());
						promoterCheckInDetailsAuditEntity.setPromoterLatitude(latitudeFromReq);
						promoterCheckInDetailsAuditEntity.setPromoterLongitude(longitudeFromReq);
						promoterCheckInDetailsAuditEntity.setMarryDistance(marryDist);
						promoterCheckInDetailsAuditEntity.setRemark(remark);
						PromoterCheckInDetailsAuditEntity prom = promoterCheckInDetailsAuditDAO.saveAndFlushCheckInDetails(promoterCheckInDetailsAuditEntity);

						// Calculate Marry Distance Logic
						marryDist = commonUtils.calculateMarryDistance(latitudeFromReq, shopLatitude, longitudeFromReq, shopLongitude);
						logger.info("marryDist {}:", marryDist);
						marryDistance = Double.parseDouble(marryDist);

						if (marryDistance < Double.parseDouble(prop.getProperty(Constants.GEO_CHECKIN_LIMIT_VALUE_IN_METERS)))
						{
							isCheckOutAllowed = true;
						}

						// Update the status of newly created entry
						if (isCheckOutAllowed == true)
						{
							prom.setStatus("Success");
						}
						else
						{
							prom.setStatus("Fail");
						}

						prom.setMarryDistance(marryDist);
						prom.setId(prom.getId());
						promoterCheckInDetailsAuditRepository.save(prom);

						if (isCheckOutAllowed)
						{
							response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
							response.setMessage(prop.getProperty(Constants.DASHBOARD_CHECKOUT_SUCC_MSG));
							response.setResponse(json);
							logger.info("Success Response generated:  {} for proMobileNo: {}:", "",promoterNo);
						}
						else
						{
							response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
							response.setMessage(prop.getProperty(Constants.DASHBOARD_CHECKOUT_FAIL_MSG));
							response.setResponse(json);
						}
					}
					else
					{
						logger.error("checkOutDetailsV2() trackerJsonArr is empty: {} :", promoterNo);
						response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
						response.setMessage("Shop Lat Lng NA");
						response.setResponse(json);
						logger.info("Fail Response generated for proMobileNo: {}:", promoterNo);
					}
				}
				else
				{
					logger.error("checkOutDetailsV2() trackerJsonArr is empty: {} :", promoterNo);
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setMessage(prop.getProperty(Constants.NO_USER_MESSAGE));
					response.setResponse(json);
					logger.info("Fail Response generated for proMobileNo: {}:", promoterNo);
				}
			}
			else
			{
				logger.error("checkOutDetailsV2() retMobileNo is empty: {} :" , promoterNo);
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("checkOutDetailsV2() Response generated:  {} for proMobileNo: {}" , "",promoterNo);
			return response;
		}
		catch (Exception exe)
		{
			logger.error("checkOutDetailsV2() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setResponse(json);
			return response;
		}
	}

	/**
	 * This method used to get latest CheckInOutStatus Of Promoter
	 * @param promoterNo
	 * @return SnapWorkResponse
	 */
	@SuppressWarnings("unchecked")
	@Override
	public SnapWorkResponse checkInOutStatus(String promoterNo)
	{
		SnapWorkResponse response = new SnapWorkResponse();
		JSONObject json = new JSONObject();

		try
		{
			logger.info("Inside checkInOutStatus() method in CheckInAndOutServiceImpl class {}:", promoterNo);

			if (StringUtils.isNotBlank(promoterNo))
			{
				Optional<PromoterUserMSTEntity> promoterUserMSTEntity = promoterUserMSTDAO.fetchUserByPhoneNumberWithStatus(promoterNo);

				if (promoterUserMSTEntity.isPresent())
				{
					List<PromoterCheckInDetailsAuditEntity> promoterCheckInDetailsAuditEntity =
							checkInAndOutDao.getCheckInCheckOutDetails_V2(promoterUserMSTEntity);

					if (promoterCheckInDetailsAuditEntity != null && !promoterCheckInDetailsAuditEntity.isEmpty())
					{
						List<PromoterOutletMSTEntity> promoterOutletMSTEntity =
								promoterOutletMSTRepository.findByOutletNo(promoterCheckInDetailsAuditEntity.get(0).getOutletNo());

						if (promoterOutletMSTEntity != null)
						{
							json.put("Mobile_No", promoterOutletMSTEntity.get(0).getOutletNo());
							json.put("retailerName", promoterOutletMSTEntity.get(0).getOutletName());
							json.put("retailerAddress", "");
							json.put("longitude", promoterOutletMSTEntity.get(0).getLatitude());
							json.put("latitude", promoterOutletMSTEntity.get(0).getLongitude());
						}
						else
						{
							json.put("Mobile_No", "");
							json.put("retailerName", "");
							json.put("retailerAddress", "");
							json.put("longitude", "");
							json.put("latitude", "");
						}

						json.put("inOrOut", promoterCheckInDetailsAuditEntity.get(0).getCheckInType());
						response.setResponse(json);
						response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
						response.setMessage(prop.getProperty(Constants.DASHBOARD_CHECKINANDOUT_DETAILS_MSG));
						logger.info("Success Response generated:  {} for proMobileNo: {}:", "", promoterNo);
					}
					else
					{
						json.put("Mobile_No", "");
						json.put("retailerName", "");
						json.put("retailerAddress", "");
						json.put("longitude", "");
						json.put("latitude", "");

						json.put("inOrOut", prop.getProperty(Constants.IN_OUT_STATUS_FAIL));
						response.setResponse(json);
						logger.error("checkInOutStatus() proMobileNo is blank: {} :", "");
						response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
						response.setMessage(prop.getProperty(Constants.DASHBOARD_CHECKINANDOUT_NO_RECORD_MSG_KEY));
						response.setResponse(json);
					}
				}
				else
				{
					// MSG No User With this Mobile Number Present
					logger.error("checkInOutStatus() No user mapped with this proMobileNo :{} :", promoterNo);
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setMessage(prop.getProperty(Constants.NO_USER_MESSAGE));
					response.setResponse(json);
				}
			}
			else
			{
				logger.error("checkInOutStatus() proMobileNo is blank: {} :", promoterNo);
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setMessage(prop.getProperty(Constants.DASHBOARD_CHECKINANDOUT_DETAILS_MSG_FAIL));
				response.setResponse(json);
			}
			logger.info("checkInOutStatus() Response generated: {} for proMobileNo: {}:", "", promoterNo);
			return response;
		}
		catch (Exception exe)
		{
			logger.error("checkInOutStatus() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setResponse(json);
			return response;
		}
	}
}