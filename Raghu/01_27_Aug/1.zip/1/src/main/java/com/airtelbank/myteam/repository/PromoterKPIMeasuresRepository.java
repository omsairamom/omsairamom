package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterKPIDetailsMSTEntity;
import com.airtelbank.entity.PromoterKPIMeasuresEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromoterKPIMeasuresRepository extends JpaRepository<PromoterKPIMeasuresEntity, Long> {

    List<PromoterKPIMeasuresEntity> findAllByKpiId(Long kpiId);

}
