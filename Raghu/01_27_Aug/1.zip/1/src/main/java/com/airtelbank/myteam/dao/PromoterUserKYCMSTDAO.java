package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterUserKYCMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterUserKYCMSTRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class PromoterUserKYCMSTDAO
{
    @Autowired
    PromoterUserKYCMSTRepository promoterUserKYCMSTRepository;

    public Optional<PromoterUserKYCMSTEntity> fetchPromoterUserKYCMST(PromoterUserMSTEntity promoterUserMSTEntity)
    {
        return promoterUserKYCMSTRepository.findByPromoterUserMSTEntity(promoterUserMSTEntity);
    }
}
