package com.airtelbank.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.lang.Nullable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Getter
@Setter
@Table(name = "PROMOTER_CAPTURE_COMPLIANCE")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class PromoterCaptureComplianceEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "promoter_id", nullable = false, referencedColumnName = "id")
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    private String documentId;

    @Nullable
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "outlet_id", nullable = false, referencedColumnName = "id")
    private PromoterOutletMSTEntity promoterOutletMSTEntity;

    @Column
    @Nullable
    private String remark;

    @Column
    @CreatedDate
    private LocalDateTime createdDate;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDate;

    @Column
    private String custom_field1;

    @Column
    private String custom_field2;

    @Column
    private String custom_field3;

    @Column
    private String custom_field4;

    @Column
    private String custom_field5;

}