package com.airtelbank.myteam.service;

import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.util.CustomException;
import org.springframework.stereotype.Service;


@Service
public interface CheckInAndOutService
{
	SnapWorkResponse checkInDetailsV2(String promoterNo, String outletNo, String latitude, String longitude)throws CustomException;

	SnapWorkResponse checkOutDetailsV2(String promoterNo, String outletNo, String latitude, String longitude, String remark)throws CustomException;
	
	SnapWorkResponse checkInOutStatus(String promoterNo)throws CustomException;
}
