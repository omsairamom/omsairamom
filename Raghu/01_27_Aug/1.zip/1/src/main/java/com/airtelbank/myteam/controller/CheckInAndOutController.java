package com.airtelbank.myteam.controller;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.jwt.AeroCache;
import com.airtelbank.myteam.dao.CheckInAndOutDAO;
import com.airtelbank.myteam.service.CheckInAndOutService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
public class CheckInAndOutController
{
	private static Logger logger = LoggerFactory.getLogger(CheckInAndOutController.class);
	private static final String JWT_PAYLOAD = "jwt_payload";
	private static final String MOBILENO = "mobileno";
	@Autowired
	CheckInAndOutDAO checkInAndOutDao;

	@Autowired
	CheckInAndOutService chkInOutService;

	@Autowired
	PropertyManager prop;

	@Autowired
	CommonUtils commonUtil;

	@Autowired
	HttpServletRequest httpServletRequest;

	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();

	@PostMapping(path = "/v1/dashboard/check-in")
	public ResponseEntity<Object> checkInDetailsV2(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		String promoterNo = "";

		try
		{
			// Get Promoter_Mobile_Number from Auth-Token
			String payload = httpServletRequest.getHeader(JWT_PAYLOAD);

			if (payload != null)
			{
				org.json.JSONObject json1 = new org.json.JSONObject(payload);
				promoterNo = json1.getString(MOBILENO);
			}

			logger.info("Promoter Mobile Number: {}:", promoterNo);

			String latitude = httpServletRequest.getHeader("latitude");
			String longitude = httpServletRequest.getHeader("longitude");

			startTime = System.currentTimeMillis();
			logger.info("Check-in Details, Request start timeInMillis {}:" , startTime);
			logger.info("Check-in Details, Request params {}:" , response.getResponse());
			String outletNo = request.getOutletNo() == null ? "" : request.getOutletNo().trim();
			logger.info("Outlet Mobile Number{}:" , outletNo);

			if (StringUtils.isNotBlank(promoterNo) && StringUtils.isNotBlank(outletNo))
			{
				response = chkInOutService.checkInDetailsV2(promoterNo, outletNo, latitude, longitude);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Check-in Details, response {}: " , response.getResponse());
			endTime = System.currentTimeMillis();
			logger.info("Check-in Details, Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("*************************************************** {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/dashboard/check-out")
	public ResponseEntity<Object> checkOutDetailsV2(@Valid @RequestBody SnapWorkRequest request)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		String promoterNo = "";
		String outletNo = "";

		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Check-out Details, Request start timeInMillis {}:" , startTime);
			logger.info("Check-out Details, Request params {}:", request);

			// Get Promoter_Mobile_Number from Auth-Token
			String payload = httpServletRequest.getHeader(JWT_PAYLOAD);
			org.json.JSONObject json1 = new org.json.JSONObject(payload);

			if (payload != null)
			{
				promoterNo = json1.getString(MOBILENO);
				logger.info("Check-out Details, Promoter Mobile Number {}:", promoterNo);
			}

			outletNo = request.getOutletNo() == null ? "" : request.getOutletNo().trim();

			if (outletNo != null && !outletNo.trim().isEmpty())
			{
				logger.info("Outlet Mobile Number: {}:", outletNo);
			}

			String remarks = request.getRemarks() == null ? "" : request.getRemarks().trim();

			String latitude = httpServletRequest.getHeader("latitude");
			String longitude = httpServletRequest.getHeader("longitude");

			if (StringUtils.isNotBlank(promoterNo) && StringUtils.isNotBlank(outletNo)
					&& outletNo != null && !outletNo.trim().isEmpty())
			{
				response = chkInOutService.checkOutDetailsV2(promoterNo, outletNo, latitude, longitude, remarks);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Check-out Details, Response {}: " , response.getResponse());
			endTime = System.currentTimeMillis();
			logger.info("Check-out Details, Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("************************************************************************************************ {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/dashboard/checkinoutdetails")
	public ResponseEntity<Object> checkInOutStatus()
	{
		SnapWorkResponse response = new SnapWorkResponse();
		String promoterNo = "";

		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Check-out Details, Request start timeInMillis {}:" , startTime);

			// Get Promoter_Mobile_Number from Auth-Token
			String payload = httpServletRequest.getHeader(JWT_PAYLOAD);

			if (payload != null)
			{
				org.json.JSONObject json1 = new org.json.JSONObject(payload);
				promoterNo = json1.getString(MOBILENO);
				logger.info("Promoter Mobile Number: {}:", promoterNo);
			}

			if (StringUtils.isNotBlank(promoterNo))
			{
				response = chkInOutService.checkInOutStatus(promoterNo);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			logger.info("Check-out Details, Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("****************************************************** {}:" , "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// Aerospike
	@Autowired
	AeroCache aeroCache;

	private static final String setName = "OUTLET_MGMT";

	@GetMapping(path = "/v1/dashboard/addDataInAerospike/{outletNumber}/{latitude}/{longitude}")
	public ResponseEntity<Object> putAerospikeData(@PathVariable("outletNumber") String outletNumber,
												   @PathVariable("latitude") String latitude,
												   @PathVariable("longitude") String longitude)
	{
		SnapWorkResponse response = new SnapWorkResponse();

		Map<String, String> map = new HashMap<String, String>(2);
		map.put("shopLatitude", latitude);
		map.put("shopLongitude", longitude);
		boolean status = aeroCache.saveOutletDetails(Integer.valueOf(prop.getProperty(Constants.EXPIRY_SESSION_IN_SECONDS_FOR_CHECKIN)), setName, outletNumber, map);

		response.setMessage("Aerospike Data Added Successfully For " + outletNumber + " " + status);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}