
package com.airtelbank.model.Merchant;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Settings {

    @SerializedName("SecurePayOn")
    @Expose
    private Object securePayOn;

    public Object getSecurePayOn() {
        return securePayOn;
    }

    public void setSecurePayOn(Object securePayOn) {
        this.securePayOn = securePayOn;
    }

}
