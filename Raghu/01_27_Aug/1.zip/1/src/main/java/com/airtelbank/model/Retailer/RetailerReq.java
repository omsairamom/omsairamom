
package com.airtelbank.model.Retailer;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class RetailerReq {

    @SerializedName("retailerName")
    @Expose
    private String retailerName;
    @SerializedName("lapuNumber")
    @Expose
    private String lapuNumber;
    @SerializedName("pinCode")
    @Expose
    private String pinCode;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("state")
    @Expose
    private String state;
    @SerializedName("shopName")
    @Expose
    private String shopName;
    @SerializedName("shopDisplayName")
    @Expose
    private String shopDisplayName;
    @SerializedName("distance")
    @Expose
    private Object distance;
    @SerializedName("completeAddress")
    @Expose
    private String completeAddress;
    @SerializedName("location")
    @Expose
    private Location location;
    @SerializedName("currentMcashBal")
    @Expose
    private Double currentMcashBal;
    @SerializedName("mtPrevMonth")
    @Expose
    private Object mtPrevMonth;
    @SerializedName("biometricAuthStatus")
    @Expose
    private Boolean biometricAuthStatus;
    @SerializedName("locDeviationFlg")
    @Expose
    private Object locDeviationFlg;

    public String getRetailerName() {
        return retailerName;
    }

    public void setRetailerName(String retailerName) {
        this.retailerName = retailerName;
    }

    public String getLapuNumber() {
        return lapuNumber;
    }

    public void setLapuNumber(String lapuNumber) {
        this.lapuNumber = lapuNumber;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getShopDisplayName() {
        return shopDisplayName;
    }

    public void setShopDisplayName(String shopDisplayName) {
        this.shopDisplayName = shopDisplayName;
    }

    public Object getDistance() {
        return distance;
    }

    public void setDistance(Object distance) {
        this.distance = distance;
    }

    public String getCompleteAddress() {
        return completeAddress;
    }

    public void setCompleteAddress(String completeAddress) {
        this.completeAddress = completeAddress;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Double getCurrentMcashBal() {
        return currentMcashBal;
    }

    public void setCurrentMcashBal(Double currentMcashBal) {
        this.currentMcashBal = currentMcashBal;
    }

    public Object getMtPrevMonth() {
        return mtPrevMonth;
    }

    public void setMtPrevMonth(Object mtPrevMonth) {
        this.mtPrevMonth = mtPrevMonth;
    }

    public Boolean getBiometricAuthStatus() {
        return biometricAuthStatus;
    }

    public void setBiometricAuthStatus(Boolean biometricAuthStatus) {
        this.biometricAuthStatus = biometricAuthStatus;
    }

    public Object getLocDeviationFlg() {
        return locDeviationFlg;
    }

    public void setLocDeviationFlg(Object locDeviationFlg) {
        this.locDeviationFlg = locDeviationFlg;
    }

}
