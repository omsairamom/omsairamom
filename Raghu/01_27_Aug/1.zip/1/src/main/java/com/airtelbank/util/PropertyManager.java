package com.airtelbank.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 05, 2019 07:34:45 PM
 */

@Configuration
public class PropertyManager {

	@Autowired
    private Environment env;

    public String getProperty(String pPropertyKey)
    {
        return env.getProperty(pPropertyKey);
    }
}
