
package com.airtelbank.model.Retailer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("jsonschema2pojo")
public class RetailerMSDIN {

    @SerializedName("location")
    @Expose
    private Location location;
    @SerializedName("maxLimit")
    @Expose
    private Integer maxLimit;
    @SerializedName("msisdn")
    @Expose
    private Long msisdn;
    @SerializedName("productName")
    @Expose
    private List<String> productName = null;
    @SerializedName("radius")
    @Expose
    private Integer radius;
    @SerializedName("sortOn")
    @Expose
    private String sortOn;
    @SerializedName("sortOrder")
    @Expose
    private String sortOrder;

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Integer getMaxLimit() {
        return maxLimit;
    }

    public void setMaxLimit(Integer maxLimit) {
        this.maxLimit = maxLimit;
    }

    public Long getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(Long msisdn) {
        this.msisdn = msisdn;
    }

    public List<String> getProductName() {
        return productName;
    }

    public void setProductName(List<String> productName) {
        this.productName = productName;
    }

    public Integer getRadius() {
        return radius;
    }

    public void setRadius(Integer radius) {
        this.radius = radius;
    }

    public String getSortOn() {
        return sortOn;
    }

    public void setSortOn(String sortOn) {
        this.sortOn = sortOn;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

}
