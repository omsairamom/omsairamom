package com.airtelbank.dao;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.bean.LoginInfoTrackerBean;
import com.airtelbank.bean.UserDevicesBean;
import com.airtelbank.common.CommonException;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.entity.*;
import com.airtelbank.myteam.repository.*;
import com.airtelbank.util.Constants;
import com.airtelbank.util.CustomException;
import com.airtelbank.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class LoginDAO  {

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	@Autowired
	PromoterUserProfileMSTRepository promoterUserProfileMSTRepository;

	@Autowired
	PromoterLoginTrackerAuditRepository promoterLoginTrackerAuditRepository;

	@Autowired
	PromoterUserMSTRepository promoterUserMSTRepository;

	@Autowired
	PromoterCircleMSTRepository promoterCircleMSTRepository;

	@Autowired
	PromoterAttendanceAuditRepository promoterAttendanceAuditRepository;

	private final Logger logger = LoggerFactory.getLogger(LoginDAO.class.getClass());

	public int getDeviceCount(String mobileNo)throws Exception
	{
		String query = "";
		int deviceIdCount = 0;
		List<Map<String, Object>> rows = null;
		try
		{
			query = prop.getProperty(Constants.LOGIN_ATTENDANCE_DEVICE_COUNT);
			rows = jdbctemplate.queryForList(query,  mobileNo);

			if (rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					deviceIdCount = (Integer) (row.get("DEVICE_ID") == null ? "" : Integer.parseInt(row.get("DEVICE_ID").toString()));
				}
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return deviceIdCount;
	}

	public void setBlockCounterToXAndBlockExpiryY(PromoterUserProfileMSTEntity profileMSTEntity, Integer x, LocalDateTime y)
	{
		profileMSTEntity.setAttempts(x);
		profileMSTEntity.setBlockExpiryDate(y);
	}

	public boolean validatePassword(String deviceID,String mobileNo,String origPassword,String encPassword) throws CustomException
	{
		boolean isValidate = false;
		String dbPassword = "";
		List<Map<String, Object>> rows = null ;

		String query = prop.getProperty(Constants.LOGIN_FETCH_PASSWD_DTLS);
		rows =  jdbctemplate.queryForList(query, mobileNo);

		if(rows != null && !rows.isEmpty())
		{
			for(Map<String, Object> row : rows )
			{
				dbPassword = row.get("USER_PWD") == null ? "" : row.get("USER_PWD").toString();

				if(dbPassword.equals(encPassword))
				{
					isValidate = true ;
				}
			}
		}

		return isValidate ;
	}


	public Optional<PromoterUserProfileMSTEntity> fetchUserProfileForChannel(String mobileNo, String channel) throws CustomException
	{
		Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
				promoterUserProfileMSTRepository.findOneByUserNoAndChannel(mobileNo, channel);

		return promoterUserProfileMSTEntity;
	}

	public boolean validatePassword_V2(String mobileNo, String encPassword) throws CustomException
	{
		Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
				promoterUserProfileMSTRepository.findOneByUserNoWithStatus(mobileNo, "A");

		boolean isValidate = false;
		String dbPassword = "";

		if(promoterUserProfileMSTEntity.isPresent())
		{
			dbPassword = promoterUserProfileMSTEntity.get().getPassword();

			if (!promoterUserProfileMSTEntity.get().getChannel().equalsIgnoreCase("PADMIN"))
			{
				if (dbPassword.equals(encPassword))
				{
					isValidate = true;
				}
			}
		}
		return isValidate ;
	}

	public int updateFCMTokenDetails(String deviceId, String fcmToken) throws Exception
	{
		int count = 0;
		String query = "";

		query = prop.getProperty(Constants.LOGIN_UPDATE_FCMTOKEN_DTLS);
		count = jdbctemplate.update(query, fcmToken, deviceId);

		return count;
	}

	public int updateJWT(String jwtToken, String lapuNo) throws CustomException
	{
		int count = 0;
		String query = "";

		query = prop.getProperty(Constants.LOGIN_UPDATE_JWT_TOKEN);
		count = jdbctemplate.update(query, jwtToken, lapuNo);

		return count;
	}

	public String getRollDetails(String mobileNo) throws Exception
	{
		String roleName = "";

		try
		{
			String query = prop.getProperty(Constants.LOGIN_FETCH_ROLE_DTLS_OTHER_HIERARCHY);
			List<Map<String, Object>> rows =  jdbctemplate.queryForList(query, mobileNo);

			if(rows != null && !rows.isEmpty())
			{
				Map<String, Object> promotype  = rows.get(0);
				roleName = (String) promotype.get("USER_TYPE") == null ? "" : promotype.get("USER_TYPE").toString();
			}
		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return roleName ;
	}

	public boolean checkFirtstTimeLoginDtls(String  mobileNo) throws Exception
	{
		boolean flag = false;
		List<Map<String, Object>> rows = null;

		try
		{

			String query = prop.getProperty(Constants.LOGIN_CHECK_ATTENDANCE_DTLS);
			rows =  jdbctemplate.queryForList(query, mobileNo);
			logger.info("rows {}:" , rows);
			if(!rows.isEmpty())
			{
				flag = true;
			}
		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return flag;
	}

	public boolean fetchEODSubmitAttendanceDtls(String  mobileNo) throws Exception
	{
		boolean flag = false;
		List<Map<String, Object>> rows = null;

		try
		{
			String query = prop.getProperty(Constants.LOGIN_CHECK_EOD_ATTEN_DTLS);
			rows =  jdbctemplate.queryForList(query, mobileNo);
			logger.info("fetchEODSubmitAttendanceDtls {}:" , rows);
			if(!rows.isEmpty())
			{
				flag = true;
			}
		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return flag;
	}

	public  List<Map<String, Object>> getTrainingDueDate(String mobileNo) throws Exception
	{
		List<Map<String, Object>> rows = null;

		try
		{
			String query = prop.getProperty(Constants.TRAINING_DUE_DATE_DTLS);
			rows =  jdbctemplate.queryForList(query, mobileNo);

		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return rows ;
	}

	public String getPromoterType (String mobileNo) throws Exception
	{
		String promoterType = "";

		try
		{
			String query = prop.getProperty(Constants.LOGIN_FETCH_PROMOTER_TYPE);

			List<Map<String, Object>> rows = jdbctemplate.queryForList(query, mobileNo);

			if (rows != null && !rows.isEmpty())
			{

				Map<String, Object> promotype  = rows.get(0);
				promoterType = (String) promotype.get("PROMOTER_TYPE");
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return promoterType;
	}

	public String getUserNameDetails(String mobileNo) throws Exception
	{
		String userName = "";

		try
		{
			String query = prop.getProperty(Constants.LOGIN_FETCH_USERNAME_DTLS);
			List<Map<String, Object>> rows =  jdbctemplate.queryForList(query, mobileNo);
			if(rows != null && !rows.isEmpty())
			{
				for(Map<String, Object> row : rows )
				{
					userName = row.get("USER_NAME") == null ? "" : row.get("USER_NAME").toString();
				}
			}

		}
		catch(Exception e)
		{
			logger.error("Exception Inside getUserNameDetails() method in passwordDAO class... {}, {}:", e.getMessage(), e.getCause());
			CommonException.printStackTraceForDAO(e);
		}

		return userName;
	}

	public boolean isUserDeviceExist(String deviceId,String mobileNo) throws Exception
	{
		boolean flag = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try
		{
			logger.info("deviceId {}:" , deviceId);
			logger.info("mobileNo {}:" ,mobileNo);
			query = prop.getProperty(Constants.LOGIN_CHECK_USERDEVICE_DTLS);
			rows = jdbctemplate.queryForList(query, new Object[] {deviceId, mobileNo});
			logger.info("isUserDeviceExist, rows {}:" , rows);
			if(!rows.isEmpty())
			{
				flag = true;
			}
		}
		catch (Exception e)
		{
			logger.error("Exception Inside isUserDeviceExist() method in passwordDAO class... {}, {}:", e.getMessage(), e.getCause());
			CommonException.printStackTraceForDAO(e);
		}

		return flag;
	}

	public boolean isUserExist(String mobileNo) throws Exception
	{

		boolean flag = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try {

			logger.info("mobileNo {}:" ,mobileNo);
			query = prop.getProperty(Constants.LOGIN_CHECK_USER_DTLS);
			rows = jdbctemplate.queryForList(query, new Object[] {mobileNo});
			logger.info("isUserExist, rows {}:" , rows);
			if(!rows.isEmpty()) {
				flag = true;
			}
		} catch (Exception e) {
			logger.error("Exception Inside isUserExist() method in passwordDAO class... {}, {}:", e.getMessage(), e.getCause());
			CommonException.printStackTraceForDAO(e);
		}

		return flag;
	}

	public int updateUserDeviceDetails(final UserDevicesBean obj) throws Exception
	{
		int count = 0;
		String query = "";

		try
		{
			logger.info("Inside updatePassword() method in passwordDAO class... {}:" , "");

			query = prop.getProperty(Constants.LOGIN_UPDATE_USERDEVICE_DTLS);

			count = jdbctemplate.update(query, new Object[] {obj.getPassword(), obj.getLanguage(), obj.getImei(),
					obj.getFcmToken(),obj.getAppVersion(), obj.getOs(),	obj.getDeviceModel(), obj.getDelBlockFlag(),
					obj.getDelBlockBy(), obj.getDelBlockReason() ,obj.getMobileNo()});
			logger.info("updatePassword count {}:" , count);
		}
		catch (Exception e)
		{
			logger.error("Exception Inside updatePassword() method in passwordDAO class... {}, {}:", e.getMessage(), e.getCause());
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public int saveUserDeviceDetailsWithPassword(final UserDevicesBean obj) throws Exception
	{

		int row = 0;

		try {
			logger.info("Inside saveDeviceDetails() method in LoginDAO class... {}:" , "");

			final String INSERT_SQL = prop.getProperty(Constants.LOGIN_SAVE_USERDEVICES_DTLS);

			row = jdbctemplate.update(INSERT_SQL, new Object[] {obj.getMobileNo(),obj.getPassword(),obj.getLanguage(),
					obj.getDeviceId(), obj.getImei(), obj.getFcmToken(),
					obj.getAppVersion(),obj.getOs(), obj.getDeviceModel(),
					obj.getDelBlockFlag(), obj.getDelBlockBy(),obj.getDelBlockReason()});

		} catch (Exception e) {
			logger.error("Exception Inside saveDeviceDetails() method in passwordDAO class... {}, {}:", e.getMessage(), e.getCause());
			CommonException.printStackTraceForDAO(e);
		}

		return row;
	}

	public int updateDeleteBlockFlag(String deviceId, String mobileNo) throws Exception
	{
		int count = 0;
		String query = "";

		try
		{
			logger.info("deviceId {}:" , deviceId);
			query = prop.getProperty(Constants.LOGIN_CHECK_UPDATE_DEACTIVE_DEL_FLAG);
			count = jdbctemplate.update(query, deviceId, mobileNo);
			logger.info("updateDeleteBlockFlag for deactive lapu_no, rows {}:" , count);
			if (count > 0)
			{
				query = prop.getProperty(Constants.LOGIN_CHECK_UPDATE_ACTIVE_DEL_FLAG);
				count = jdbctemplate.update(query, deviceId, mobileNo);
				logger.info("updateDeleteBlockFlag for active lapu_no, rows {}:" , count);
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public List<Map<String, Object>> getCircleZoneDtls(String mobileNo) throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows =  null;

		try
		{
			logger.info("Inside of getCircleZoneDtls() method in LoginDAO class {}:" , "");
			query = prop.getProperty(Constants.LOGIN_USER_CIRCLE_ZONE_DTLS);
			rows =  jdbctemplate.queryForList(query, mobileNo);
			logger.info("rows {}:" , rows);

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}

	public String getRollName(String mobileNo) throws Exception
	{
		String roleName = "";

		try
		{
			String query = prop.getProperty(Constants.LOGIN_FETCH_ROLE_NAME);
			List<Map<String, Object>> rows =  jdbctemplate.queryForList(query, mobileNo);
			if(rows != null && !rows.isEmpty())
			{
				for(Map<String, Object> roles : rows )
				{
					logger.info("roleName {}:" , roles);
					for (Map.Entry<String, Object> entry : roles.entrySet())
					{
						if(entry.getValue().toString().equals("0"))
						{
							roleName = entry.getKey();
						}
					}
				}
			}

		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return roleName ;
	}

	public boolean isAppUserExist(String mobileNo) throws Exception
	{
		boolean flag = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try
		{
			query = prop.getProperty(Constants.LOGIN_CHECK_APP_USER_EXIST_DTLS);
			rows = jdbctemplate.queryForList(query, mobileNo);

			if(!rows.isEmpty())
			{
				flag = true;
			}
		} catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return flag;
	}

	public boolean isMobileNoExist(String mobileNo) throws Exception
	{
		boolean flag = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try
		{
			query = prop.getProperty(Constants.LOGIN_CHECK_MOBILE_EXIST_DTLS);
			rows = jdbctemplate.queryForList(query, mobileNo);
			if(!rows.isEmpty())
			{
				flag = true;
			}

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return flag;
	}

	public boolean isDeviceExist(String mobileNo,String deviceId) throws Exception
	{
		boolean flag = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try
		{
			query = prop.getProperty(Constants.LOGIN_CHECK_APP_DEVICE_EXIST_DTLS);
			rows = jdbctemplate.queryForList(query, mobileNo);

			if(!rows.isEmpty())
			{
				flag = true;
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return flag;
	}

	public int updateDeviceId(String mobileNo,String deviceId,SnapWorkRequest request) throws Exception
	{
		int count = 0;
		String query = "";

		try
		{
			logger.info("Inside updateDeviceId() method in LoginDAO class... {}:" , "");
			String imeino = request.getImei() == null ? "" : request.getImei().trim();
			String fcmId = request.getFcmToken() == null ? "" : request.getFcmToken().trim();
			String appVersion = request.getAppVersion() == null ? "" : request.getAppVersion().trim();
			String os = request.getDeviceType() == null ? "" : request.getDeviceType().trim();
			String model = request.getDeviceModel() == null ? "" : request.getDeviceModel().trim();

			query = prop.getProperty(Constants.LOGIN_UPDATE_MULTIPLE_USERDEVICE_DTLS);
			count = jdbctemplate.update(query, mobileNo, deviceId,imeino,fcmId,appVersion,os,model,mobileNo);

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public int saveMultipleDeviceLoginDetails(String mobileNo,String deviceId,SnapWorkRequest request) throws Exception
	{
		int count = 0;

		try
		{
			String osType = request.getDeviceType() == null ? "" : request.getDeviceType().trim();
			final String INSERT_SQL = prop.getProperty(Constants.LOGIN_SAVE_MULTI_DEVICE_INFO_TRACKER_DTLS);
			count = jdbctemplate.update(INSERT_SQL, mobileNo,deviceId,osType);

		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return count;
	}

	public int fetchMobileRegisterCount(String mobileNo) throws Exception
	{
		int count = 0;
		String query = "";
		List<Map<String, Object>> rows = null;

		try
		{
			logger.info("Inside fetchMobileRegisterCount() method in LoginDAO class... {}:" , "");
			query = prop.getProperty(Constants.LOGIN_FETCH_MOB_COUNT_DTLS);
			rows = jdbctemplate.queryForList(query, mobileNo);

			if(rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					count = Integer.valueOf(row.get("COUNT") == null ? "" : row.get("COUNT").toString());
				}
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public int saveLoginAndLogOutDetails(final LoginInfoTrackerBean obj) throws Exception
	{
		int row = 0;

		try
		{
			logger.info("Inside saveLoginAndLogOutDetails() method in LoginDAO class... {}:" , "");

			final String INSERT_SQL = prop.getProperty(Constants.LOGIN_SAVE_LOGIN_INFO_TRACKER_DTLS);

			row = jdbctemplate.update(INSERT_SQL, new Object[] {obj.getMobileNo(),obj.getUserName(),obj.getLoginType(),obj.getLatitude(),
					obj.getLongitude(),obj.getIsGpsEnabled(),obj.getUdid(),obj.getField1(),obj.getField2(),obj.getField3(),
					obj.getField4(),obj.getField5()});
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return row;
	}

	public PromoterLoginTrackerAuditEntity saveLoginAndLogOutDetails_V2(PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity) throws Exception
	{
		return promoterLoginTrackerAuditRepository.saveAndFlush(promoterLoginTrackerAuditEntity);
	}

	public int saveAttendanceDetails(AttendanceBean obj) throws Exception
	{
		String query = "";
		int row = 0;

		try
		{
			logger.info("Inside saveAttendanceDetails() method in LoginDAO class... {}:" ,"");

			query = prop.getProperty(Constants.LOGIN_ATTENDANCE_UPLOAD_DTLS);

			row = jdbctemplate.update(query, new Object[] {obj.getMobileNo(),obj.getLatitude(),
					obj.getType(),obj.getLongitude(),obj.getAddress(),
					obj.getSelfiePath(),obj.getField1(),obj.getField2(),
					obj.getField3(),obj.getField4(),obj.getField5()});
			logger.info("saveAttendanceDetails() rows {}:" , row);

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return row;
	}

	public List<Map<String, Object>> getAttendanceDetails(String mobileNo, String startDate, String endDate) throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows = null;

		try
		{
			logger.info("Inside getAttendanceDetails() method in LoginDAO class... {}:" , "");
			query = prop.getProperty(Constants.LOGIN_ATTENDANCE_VIEW_DTLS);
			rows = jdbctemplate.queryForList(query, mobileNo, startDate, endDate);
			logger.info("getAttendanceDetails() rows {}:" ,rows);
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return rows;
	}

	public List<PromoterAttendanceAuditEntity> getAttendanceDetails_V2(String mobileNo, String startDate, String endDate) throws Exception
	{
		List<PromoterAttendanceAuditEntity> findAttendanceByDateRange = null;
		
		Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
				promoterUserMSTRepository.findOneByUserNo(mobileNo);

		if (promoterUserMSTEntity.isPresent())
		{
			findAttendanceByDateRange =
					promoterAttendanceAuditRepository.findAttendanceByDateRange(promoterUserMSTEntity.get().getId(), startDate, endDate);

			return findAttendanceByDateRange;
		}
		else
		{
			return findAttendanceByDateRange;
		}
	}

	public String checkPromoterType(String mobileNo) throws Exception
	{
		String promoterType="";
		String query = "";
		List<Map<String, Object>> rows = null;
		try
		{
			query = prop.getProperty(Constants.LOGIN_GET_PROMOTERTYPE);
			rows = jdbctemplate.queryForList(query, mobileNo);
			if(rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					promoterType =  (row.get("promoter_type") == null ? "" : row.get("promoter_type").toString());
				}
			}
			logger.info("get promoterType, rows {}:" , promoterType);
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return promoterType;
	}

	public String getJWT(String mobileNo) throws Exception
	{
		String jwt = "";
		try
		{
			String query = prop.getProperty(Constants.LOGIN_FETCH_JWT_TOKEN);

			List<Map<String, Object>> rows = jdbctemplate.queryForList(query, mobileNo);

			if (rows != null && !rows.isEmpty())
			{
				Map<String, Object> promotype  = rows.get(0);
				jwt = (String) promotype.get("JWT_TOKEN") == null ? "" : promotype.get("JWT_TOKEN").toString();
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return jwt;
	}
	
	public Optional<PromoterUserMSTEntity> fetchUserByPhoneNumber(String outletPhoneNumber) {
		return promoterUserMSTRepository.findOneByUserNo(outletPhoneNumber);
	}
	
	public Optional<PromoterCircleMSTEntity> fetchCircleByCircleId(String circleId) {
		return promoterCircleMSTRepository.findOneByCircleId(circleId);
	}
}