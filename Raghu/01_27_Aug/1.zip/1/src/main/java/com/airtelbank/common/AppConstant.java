package com.airtelbank.common;

public interface AppConstant {

	String FAILURE_STATUS_CODE ="500";
	String FAILURE_ERROR_MESSAGE = "Server Error, please try after sometime";
	String FAILURE_INVALID_REQUEST="Invalid Request Parameters";
	String exception_exception="1000";
}
