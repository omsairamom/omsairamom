package com.airtelbank.util;

import com.airtelbank.common.CommonException;
import com.airtelbank.common.SnapWorkResponse;
import org.apache.shiro.codec.Base64;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 18, 2019 11:34:45 AM
 */
@Service
public class CommonUtils
{
	private static Logger logger = LoggerFactory.getLogger(CommonUtils.class);
	
	public String calculateMarryDistance(String lat1, String lat2, String lon1, String lon2)
	{
		double distance = 0;
		DecimalFormat decimalFormat = new DecimalFormat("#.0000");
		
		try
		{
			double latitude1 = Double.parseDouble(lat1);
			double latitude2 = Double.parseDouble(lat2);
			double longitude1 = Double.parseDouble(lon1);
			double longitude2 = Double.parseDouble(lon2);

			// Radius of earth in kilometers. Use 3956
			// for miles
			final int R = 6371;

			double latDistance = Math.toRadians(latitude2 - latitude1);
			double lonDistance = Math.toRadians(longitude2 - longitude1);

			double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(latitude1))
					* Math.cos(Math.toRadians(latitude2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);

			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
			
			distance = R * c * 1000;

		}
		catch (Exception exe)
		{
			CommonException.getPrintStackTrace(exe);
		}

		return decimalFormat.format(distance);
	}

	public double calculateOutletDistance(String lat1, String lat2, String lon1, String lon2) {

		double distance = 0;

		try {
			double latitude1 = Double.parseDouble(lat1);
			double latitude2 = Double.parseDouble(lat2);
			double longitude1 = Double.parseDouble(lon1);
			double longitude2 = Double.parseDouble(lon2);

			final int R = 6371;

			double latDistance = Math.toRadians(latitude2 - latitude1);
			double lonDistance = Math.toRadians(longitude2 - longitude1);

			double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(latitude1))
					* Math.cos(Math.toRadians(latitude2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);

			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

			distance = R * c * 1000 ;

		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		}
		
		return distance;

	}

	public double distance(double lat1, double lat2, double lon1, double lon2)
	{

		// The math module contains a function
		// named toRadians which converts from
		// degrees to radians.
		lon1 = Math.toRadians(lon1);
		lon2 = Math.toRadians(lon2);
		lat1 = Math.toRadians(lat1);
		lat2 = Math.toRadians(lat2);

		// Haversine formula
		double dlon = lon2 - lon1;
		double dlat = lat2 - lat1;
		double a = Math.pow(Math.sin(dlat / 2), 2)
				+ Math.cos(lat1) * Math.cos(lat2)
				* Math.pow(Math.sin(dlon / 2),2);

		double c = 2 * Math.asin(Math.sqrt(a));

		// Radius of earth in kilometers. Use 3956
		// for miles
		double r = 6371;

		// calculate the result
		return(c * r * 1000);
	}


	public String convertMillis(long totalMilliseconds){
		String time = "";
		try {
			int seconds = (int) (totalMilliseconds / 1000) % 60 ;
			int minutes = (int) ((totalMilliseconds / (1000*60)) % 60);
			int hours   = (int) ((totalMilliseconds / (1000*60*60)) % 24);
			int milliSeconds = (int) (totalMilliseconds / 1000);
			time = "Total Time in HH:mm:ss:SSS ===> " + hours + ":" + minutes + ":" + seconds + ":" + milliSeconds;
			logger.info(time);
			
		}catch(Exception exe){
			CommonException.getPrintStackTrace(exe);
		}
		return time;
	}

	public void exceptionHandler(PropertyManager prop, Exception exe, SnapWorkResponse response, JSONObject json)
	{
		response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
		response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
		response.setResponse(json);
		response.setExpMsg(exe.getMessage());
		response.setExpLocalMsg(exe.getLocalizedMessage());
		String cause="";
		if(null != exe.getCause()) {
			cause= exe.getCause().toString();
		}
		response.setExpCause(cause);
		CommonException.getPrintStackTrace(exe);
	}

//	public String convertImageToBase64(String url)
//	{
//		byte[] bytesInput = url.getBytes();
//		System.out.println("URL : " +url);
//		//Encode URL to Base64
//		Base64.Encoder base64Encoder = Base64.getUrlEncoder();
//		String encodedString = base64Encoder.encodeToString(bytesInput);
//		System.out.println("Encoded URL :" + encodedString);
//		return encodedString;
//	}

	public String getByteArrayFromImageURL(String url)
	{
		try
		{
			URL imageUrl = new URL(url);
			URLConnection ucon = imageUrl.openConnection();
			InputStream is = ucon.getInputStream();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int read = 0;
			while ((read = is.read(buffer, 0, buffer.length)) != -1)
			{
				baos.write(buffer, 0, read);
			}
			baos.flush();
			return Base64.encodeToString(baos.toByteArray());
		}
		catch (Exception e)
		{
			logger.error("Error {}:", e.toString());
		}
		return null;
	}
}
