package com.airtelbank.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import javax.persistence.Index;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "PROMOTER_ATTENDANCE_AUDIT",indexes = 
{
		@Index(name = "IndexPromoterID",  columnList="promoter_id"),
		@Index(name = "IndexCircleId_Attendance", columnList = "circle_id"),
		@Index(name = "IndexPromoterNo_Attendance", columnList = "promoterNo")
})
@EntityListeners(AuditingEntityListener.class)
public class PromoterAttendanceAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "promoter_id", nullable = false, referencedColumnName = "id")
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    private String promoterNo;

    @Column
    private String latitude;

    @Column
    private String longitude;

    @Column
    private String address;

    @Column
    private String selfieId;

    @ManyToOne
    @JoinColumn(name = "circle_id", referencedColumnName = "id")
    private PromoterCircleMSTEntity promoterCircleMSTEntity;

    @Column
    @CreatedDate
    private LocalDateTime createdDate;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDate;
    
    @Column
    private String custom_field1;
    
    @Column
    private String custom_field2;
    
    @Column
    private String custom_field3;
    
    @Column
    private String custom_field4;
    
    @Column
    private String custom_field5;

}
