package com.airtelbank.myteam.dao;

import com.airtelbank.bean.ActivityTrackerBean;
import com.airtelbank.myteam.common.CommonException;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ActivityTrackerDAO
{
	private final Logger logger = LoggerFactory.getLogger(ActivityTrackerDAO.class.getClass());

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;
		
	public int saveActivityTrackerDtls(final ActivityTrackerBean obj) throws Exception
	{
		int row = 0;
		try 
		{
			logger.info("Inside saveActivityTrackerDtls() method in ActivityTrackerDAO class...{}:", "");

			final String INSERT_SQL = prop.getProperty(Constants.ACTIVITY_TRACKER_SAVE_DTLS);

			row = jdbctemplate.update(INSERT_SQL, obj.getMobileNo(), obj.getLatitude(),obj.getLongitude());
			logger.info("saveActivityTrackerDtls() method, row {}:" , row);
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return row;
	}
}
