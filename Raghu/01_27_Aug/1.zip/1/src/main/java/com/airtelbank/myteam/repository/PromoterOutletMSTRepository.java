package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterOutletMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PromoterOutletMSTRepository extends JpaRepository<PromoterOutletMSTEntity, Long>
{
    public Optional<PromoterOutletMSTEntity> findOneByPromoterNo(String promoterNo);

    public Optional<PromoterOutletMSTEntity> findOneByOutletNo(String outletNo);

    @Query(value = "SELECT * FROM PROMOTER_OUTLET_MST where OUTLET_NO = :outletNo and STATUS = 'A'", nativeQuery=true)
    List<PromoterOutletMSTEntity> findByOutletNo(@Param("outletNo") String outletNo);

    @Query(value = "SELECT * FROM PROMOTER_OUTLET_MST where PROMOTER_NO = :promoterNo and OUTLET_NO = :outletNo and STATUS = 'A'", nativeQuery=true)
    Optional<PromoterOutletMSTEntity> findByPromoterNoANDOutletNo(@Param("promoterNo") String promoterNo, @Param("outletNo") String outletNo);
}
