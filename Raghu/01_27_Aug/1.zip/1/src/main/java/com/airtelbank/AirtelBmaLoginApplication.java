package com.airtelbank;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@EnableAutoConfiguration
@PropertySource(value = "file:properties/application.properties", ignoreResourceNotFound = true)
public class AirtelBmaLoginApplication
{
	private static Logger logger = LoggerFactory.getLogger(AirtelBmaLoginApplication.class);

	public static void main(String[] args)
	{
		try
		{
			new SpringApplicationBuilder(AirtelBmaLoginApplication.class)
					.logStartupInfo(true)
					.run(args);
			System.out.println("App Login Services Started.......................");
			logger.info("App Login Services Started.......................{}:" ,"");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}