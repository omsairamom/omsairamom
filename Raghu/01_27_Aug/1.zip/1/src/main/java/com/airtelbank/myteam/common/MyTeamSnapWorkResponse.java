package com.airtelbank.myteam.common;

import org.json.simple.JSONObject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jul 01, 2019 02:34:45 PM
 */
@Configuration
public class MyTeamSnapWorkResponse {

	private String message;
	private String statusCode;
	private JSONObject response;
	
//	@Bean
//	public MyTeamSnapWorkResponse response()
//	{
//		return new MyTeamSnapWorkResponse();
//	}

	public JSONObject getResponse() {
		return response;
	}
	public void setResponse(JSONObject response) {
		this.response = response;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	
	@Override
	public String toString(){
		return "message ="+message+": statusCode ="+statusCode+": response="+response;
	}

}
