package com.airtelbank.common;

import javax.validation.constraints.Pattern;

import org.json.simple.JSONArray;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.lang.NonNull;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 05, 2019 07:34:45 PM
 */
@Configuration
public class SnapWorkRequest {

	private final String LATITUDE_PATTERN = "^(\\+|-)?(?:90(?:(?:\\.0{1,6})?)|(?:[0-9]|[1-8][0-9])(?:(?:\\.[0-9]{1,6})?))$";
	private final String LONGITUDE_PATTERN = "^(\\+|-)?(?:180(?:(?:\\.0{1,6})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\\.[0-9]{1,6})?))$";

	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid mobileNo.")
	private String mobileNo;
	
	@Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid deviceId.")
	private String deviceId;
	
	@Pattern(regexp ="^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid fcmToken.")
	private String fcmToken;
	
	@Pattern(regexp = "\\d+(\\.\\d{1,2})?" , message = "Please enter valid appVersion.")
	private String appVersion;
	
	@Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid device model.")
	private String deviceModel;
	
	@Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid device model.")
	private String imei;
	
	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter valid device type.")
	private String deviceType;
	
	@NumberFormat
	private String otp;
	
	@Pattern(regexp = "^((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20})$",  message = "Please enter valid password with atleast 8 charcters with uppercase, lowercase, numeric and special symbol.")
	private String password;
	
	@Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid address.")
	private String address;

	@Pattern(regexp = LATITUDE_PATTERN, message = "Please enter valid latitude.")
	private String latitude;

	@Pattern(regexp = LONGITUDE_PATTERN, message = "Please enter valid longitude.")
	private String longitude;

	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter valid language.")
	private String language;

	@Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$",  message = "Please enter valid otpVerficatonCode.")
	private String otpVerficatonCode;

	//@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter valid username.")
	private String userName;

	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter only true or false for isGpsEnabled.")
	private String isGpsEnabled;

	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid proMobileNo.")
	private String proMobileNo;
	
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid retMobileNo.")
	private String retMobileNo;

	private String googleCaptchaToken;

	private String appFlowName;

	private String outletNo;

	public String getOutletNo() {
		return outletNo;
	}

	public void setOutletNo(String outletNo) {
		this.outletNo = outletNo;
	}

	public String getGoogleCaptchaToken() {
		return googleCaptchaToken;
	}

	public void setGoogleCaptchaToken(String googleCaptchaToken) {
		this.googleCaptchaToken = googleCaptchaToken;
	}

	public String getRetMobileNo() {
		return retMobileNo;
	}

	public void setRetMobileNo(String retMobileNo) {
		this.retMobileNo = retMobileNo;
	}


	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter type.")
	private String type;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid storeName.")
	private String storeName;

	@DateTimeFormat(pattern = "dd-MM-yyyy hh:mm:ss")
	private String dateOfVisit;

	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter only true or false for isUserDeviceExist.")
	private String isUserDeviceExist;
	
	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter only true or false for isUserExist.")
	private String isUserExist;

	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter valid typeOfCustomer")
	private String typeOfCustomer;
	
	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter valid issueName")
	private String issueName;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid description.")
	private String description;
	
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid loginNo.")
	private String loginNo;

	@Pattern(regexp = "\\d+(\\.\\d{1,2})?" , message = "Please enter valid ver.")
	private String ver;

	@Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid channel.")
	private String channel;

	@Pattern(regexp = "^([0-9a-zA-z]).{0,20}$", message = "Please enter valid feSessionId.")
	private String feSessionId;

	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private String startDate;

	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private String endDate;

	@Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid jwtToken.")
	private String jwtToken;

	//*****
	@Pattern(regexp = "^[^*&%\\s]+$", message = "Please enter valid fileName.")
	private String fileName;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid encImage.")
	private String encImage;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid action.")
	private String action;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid roleName.")
	private String roleName;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid roleId.")
	private String roleId;
	

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid circleName.")
	private String circleName;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid zoneName.")
	private String zoneName;
	
	private JSONArray notifDetails;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid catId.")
	private String catId;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid CategoryName.")
	private String CategoryName;

	//@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid remarks.")
    @NonNull
	private String remarks;
	
	private JSONArray trackerInfo;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getEncImage() {
		return encImage;
	}

	public void setEncImage(String encImage) {
		this.encImage = encImage;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getCircleName() {
		return circleName;
	}

	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}

	public String getZoneName() {
		return zoneName;
	}

	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}

	public JSONArray getNotifDetails() {
		return notifDetails;
	}

	public void setNotifDetails(JSONArray notifDetails) {
		this.notifDetails = notifDetails;
	}

	public String getCatId() {
		return catId;
	}

	public void setCatId(String catId) {
		this.catId = catId;
	}

	public String getCategoryName() {
		return CategoryName;
	}

	public void setCategoryName(String categoryName) {
		CategoryName = categoryName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getJwtToken()
	{
		return jwtToken;
	}

	public void setJwtToken(String jwtToken)
	{
		this.jwtToken = jwtToken;
	}

	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getFeSessionId() {
		return feSessionId;
	}

	public void setFeSessionId(String feSessionId) {
		this.feSessionId = feSessionId;
	}

	public String getLoginNo() {
		return loginNo;
	}

	public void setLoginNo(String loginNo) {
		this.loginNo = loginNo;
	}

	public String getTypeOfCustomer() {
		return typeOfCustomer;
	}

	public void setTypeOfCustomer(String typeOfCustomer) {
		this.typeOfCustomer = typeOfCustomer;
	}

	public String getIssueName() {
		return issueName;
	}

	public void setIssueName(String issueName) {
		this.issueName = issueName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}



	public String getIsUserExist() {
		return isUserExist;
	}

	public void setIsUserExist(String isUserExist) {
		this.isUserExist = isUserExist;
	}

	public String getIsUserDeviceExist() {
		return isUserDeviceExist;
	}

	public void setIsUserDeviceExist(String isUserDeviceExist) {
		this.isUserDeviceExist = isUserDeviceExist;
	}

	public String getProMobileNo() {
		return proMobileNo;
	}

	public void setProMobileNo(String proMobileNo) {
		this.proMobileNo = proMobileNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getDateOfVisit() {
		return dateOfVisit;
	}

	public void setDateOfVisit(String dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}

	public String getIsGpsEnabled() {
		return isGpsEnabled;
	}

	public void setIsGpsEnabled(String isGpsEnabled) {
		this.isGpsEnabled = isGpsEnabled;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Bean
	public SnapWorkRequest request()
	{
		return new SnapWorkRequest();
	}

	public String getOtpVerficatonCode() {
		return otpVerficatonCode;
	}
	public void setOtpVerficatonCode(String otpVerficatonCode) {
		this.otpVerficatonCode = otpVerficatonCode;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getFcmToken() {
		return fcmToken;
	}
	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}
	public String getAppVersion() {
		return appVersion;
	}
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getAppFlowName() {
		return appFlowName;
	}

	public void setAppFlowName(String appFlowName) {
		this.appFlowName = appFlowName;
	}

	public JSONArray getTrackerInfo() {
		return trackerInfo;
	}

	public void setTrackerInfo(JSONArray trackerInfo) {
		this.trackerInfo = trackerInfo;
	}


	@Override
	public String toString() {
		return "mobileNo=" + mobileNo + ",deviceId=" + deviceId + ",fcmToken=" + fcmToken + ",appVersion=" + appVersion
				+ ",deviceModel=" + deviceModel + ",imei=" + imei + ",deviceType=" + deviceType + ",otp=" + otp
				+ ",password=" + "NA" + ",address=" + address + ",latitude=" + latitude + ",language=" + language
				+ ",otpVerficatonCode=" + otpVerficatonCode + ",appFlowName=" + appFlowName + ",OutletNumber="+outletNo;
	}
}
