package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterKPIProfileMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromoterKPIProfileMSTRepository extends JpaRepository<PromoterKPIProfileMSTEntity, Long> {

    List<PromoterKPIProfileMSTEntity> findAllByLapuNoAndCatNameAndKpiName(String lapuNo, String catName, String kpiName);
}
