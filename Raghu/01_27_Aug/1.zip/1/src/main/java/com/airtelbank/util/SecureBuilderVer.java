package com.airtelbank.util;

import java.security.spec.AlgorithmParameterSpec;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;

import com.airtelbank.common.CommonException;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SecureBuilderVer {

	private static Logger logger = LoggerFactory.getLogger(SecureBuilderVer.class);

	public static String encrypt(String encrandomKey, String Value) throws Exception {
		String result = "";

		String strKey = generateEncKey(encrandomKey);

		SecretKey key = new SecretKeySpec(Base64.decodeBase64(strKey), "AES");

		AlgorithmParameterSpec iv = new IvParameterSpec(Base64.decodeBase64(strKey));

		byte[] decodeBase64 = Value.getBytes();

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		cipher.init(Cipher.ENCRYPT_MODE, key, iv);

		result = Base64.encodeBase64String(cipher.doFinal(decodeBase64));

		return result;

	}

	public static String decrypt(String Key, String Value) throws Exception
	{

		//String Key = generateEncKey(encrandomKey);

		SecretKey key = new SecretKeySpec(Key.getBytes(), "AES");

		AlgorithmParameterSpec iv = new IvParameterSpec(Base64.decodeBase64(Key));

		byte[] decodeBase64 = Base64.decodeBase64(Value);

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		cipher.init(Cipher.DECRYPT_MODE, key, iv);

		return new String(cipher.doFinal(decodeBase64), "UTF-8");
	}

	public static String decryptRamdomKey(String Value) throws Exception {
		String Key = "NWJiMDQxMWIxOGI0YTkwZQ==";

		SecretKey key = new SecretKeySpec(Base64.decodeBase64(Key), "AES");

		AlgorithmParameterSpec iv = new IvParameterSpec(Base64.decodeBase64(Key));

		byte[] decodeBase64 = Base64.decodeBase64(Value);

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		cipher.init(Cipher.DECRYPT_MODE, key, iv);

		return new String(cipher.doFinal(decodeBase64), "UTF-8");

	}

	public static String encryptRamdomKey(String Value) throws Exception {

		String Key = "NWJiMDQxMWIxOGI0YTkwZQ==";

		SecretKey key = new SecretKeySpec(Base64.decodeBase64(Key), "AES");

		AlgorithmParameterSpec iv = new IvParameterSpec(Base64.decodeBase64(Key));

		byte[] decodeBase64 = Value.getBytes();

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		cipher.init(Cipher.ENCRYPT_MODE, key, iv);

		String result = Base64.encodeBase64String(cipher.doFinal(decodeBase64));

		return result;
	}

	public static String getRandomKey(int len) {

		StringBuffer AB = new StringBuffer("123456789");

		if (len > AB.length()) {
			return null;
		}

		StringBuilder sb = new StringBuilder(len);
		Random rnd = new Random();
		for (int i = 0; i < len; i++) {
			int char1 = rnd.nextInt(AB.length());
			sb.append(AB.charAt(char1));
			AB.deleteCharAt(char1);
		}

		return sb.toString();
	}

	public static String generateEncKey(String randomsaltkey) {
		String enckey = "";
		try {
			randomsaltkey = decryptRamdomKey(randomsaltkey);
			logger.info("rankey----" + randomsaltkey);
			String keypartcert = getKeyGenerationString(randomsaltkey);
			String input = keypartcert;
			logger.info("input  -- " + input);
			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(randomsaltkey.getBytes(), "HmacSHA256");
			sha256_HMAC.init(secret_key);
			enckey = Base64.encodeBase64String(sha256_HMAC.doFinal(input.getBytes()));
			logger.info("ios gnke----" + enckey);
			enckey = enckey.substring(0, 4) + enckey.substring(8, 12) + enckey.substring(16, 20)
			+ enckey.substring(24, 28);
			logger.info("ios gnke 2----" + enckey);
			enckey = Base64.encodeBase64String(enckey.getBytes());
			logger.info("enckey ----" + enckey);
		} catch (Exception e) {
			CommonException.getPrintStackTrace(e);
		}
		return enckey;
	}

	public static String getKeyGenerationString(String randomsaltkey) {
		
		String certthumb = "7e2f8b054a76b935c33d980023b5ffc6616e0b0b";
		String keystr = "";
		try {
			int firstdigit = Integer.parseInt(randomsaltkey.substring(0, 1));
			int seconfdigit = Integer.parseInt(randomsaltkey.substring(1, 2));
			keystr = certthumb.substring(firstdigit, firstdigit + seconfdigit);
			logger.info("getKeyGenerationString Key " + keystr);
		} catch (Exception ex) {
			CommonException.getPrintStackTrace(ex);
		}
		return keystr;

	}

	public String encryptPayload(String plainText) {
		String encryption = "";
		try {
			String encrandomkey = SecureBuilderVer.encryptRamdomKey("95");

			encryption = SecureBuilderVer.encrypt(encrandomkey, plainText);
			return encryption;
		} catch (Exception e) {
			CommonException.getPrintStackTrace(e);
		}
		return encryption;

	}

	public String decryptPayload(String encryption) {
		String decryption = "";
		try {
			String encrandomkey = SecureBuilderVer.encryptRamdomKey("95");

			decryption = SecureBuilderVer.decrypt(encrandomkey, encryption);
			return decryption;
		} catch (Exception e) {
			CommonException.getPrintStackTrace(e);
		}
		return decryption;

	}

}