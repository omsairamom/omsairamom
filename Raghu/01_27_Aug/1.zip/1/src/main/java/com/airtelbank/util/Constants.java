package com.airtelbank.util;

public class Constants {

    public static final String TR_TITLE = "TR_TITLE";
    public static final String DUE_DATE = "DUE_DATE";
    public static final String COMPLETED_DATE = "COMPLETED_DATE";

    public static final String FAILURE_INVALID_REQUEST = "FAILURE_INVALID_REQUEST";

    public static final String FAILURE_STATUS_CODE = "FAILURE_STATUS_CODE";

    public static final String BAD_REQUEST_CODE = "BAD_REQUEST";

    public static final String FAILURE_ERROR_MESSAGE = "FAILURE_ERROR_MESSAGE";

    public static final String USER_IS_NOT_REGISTERED = "USER_IS_NOT_REGISTERED";

    public static final String LOGIN_UPLOAD_INVALID_FILE_EXTN_MSG = "LOGIN_UPLOAD_INVALID_FILE_EXTN_MSG";

    public static final String LOGIN_UPLOAD_INVALID_CONTENT_TYPE_MSG = "LOGIN_UPLOAD_INVALID_CONTENT_TYPE_MSG";

    public static final String SUCCESS_STATUS_CODE = "SUCCESS_STATUS_CODE";

    public static final String LOGIN_WITH_PASWD_SUCC_MSG = "LOGIN_WITH_PASWD_SUCC_MSG";

    public static final String LOGIN_JWT_TOKEN_GEN_FAILED = "LOGIN_JWT_TOKEN_GEN_FAILED";

    public static final String LOGIN_WITH_PASWD_FAIL_MSG = "LOGIN_WITH_PASWD_FAIL_MSG";

    public static final String LOGIN_API_LOGIN_WITH_PASSWD_NAME = "LOGIN_API_LOGIN_WITH_PASSWD_NAME";

    public static final String FETCH_PROFILE_SUCC_MSG = "FETCH_PROFILE_SUCC_MSG";

    public static final String SET_PASSWORD_SUCC_MSG = "SET_PASSWORD_SUCC_MSG";

    public static final String LOGIN_API_PASSWD_SET_NAME = "LOGIN_API_PASSWD_SET_NAME";

    public static final String API_SEND_OTP_URL = "API_SEND_OTP_URL";

    public static final String LOGIN_SEND_OTP_SUCC_MSG = "LOGIN_SEND_OTP_SUCC_MSG";

    public static final String LOGIN_SEND_OTP_FAIL_MSG = "LOGIN_SEND_OTP_FAIL_MSG";

    public static final String LOGIN_USER_NOT_EXIST_MSG = "LOGIN_USER_NOT_EXIST_MSG";

    public static final String LOGIN_WITH_RETAILER_FAIL_MSG = "LOGIN_WITH_RETAILER_FAIL_MSG";

    public static final String LOGIN_API_SEND_OTP_NAME = "LOGIN_API_SEND_OTP_NAME";

    public static final String API_VERIFY_OTP_URL = "API_VERIFY_OTP_URL";

    public static final String LOGIN_VERIFY_OTP_SUCC_MSG = "API_VERIFY_OTP_URL";

    public static final String LOGIN_VERIFY_OTP_FAIL_MSG = "LOGIN_VERIFY_OTP_FAIL_MSG";

    public static final String FAILURE_RESPONSE_CODE = "FAILURE_RESPONSE_CODE";

    public static final String LOGIN_API_VERIFY_OTP_NAME = "LOGIN_API_VERIFY_OTP_NAME";

    public static final String LOGOUT_SUCC_MSG = "LOGOUT_SUCC_MSG";

    public static final String LOGOUT_FAIL_MSG = "LOGOUT_FAIL_MSG";

    public static final String LOGIN_API_LOGOUT_NAME = "LOGIN_API_LOGOUT_NAME";

    public static final String USER_EXIST = "USER_EXIST";

    public static final String UPLOAD_PROFILE_DIR_NAME = "UPLOAD_PROFILE_DIR_NAME";

    public static final String UPLOAD_PROFILE_SUCC_MSG = "UPLOAD_PROFILE_SUCC_MSG";

    public static final String LOGIN_API_PROFILE_UPLOAD_NAME = "LOGIN_API_PROFILE_UPLOAD_NAME";

    public static final String UPLOAD_ATTENDANCE_DIR_NAME = "UPLOAD_ATTENDANCE_DIR_NAME";

    public static final String UPLOAD_ATTENDANCE_SUCC_MSG = "UPLOAD_ATTENDANCE_SUCC_MSG";

    public static final String LOGIN_API_ATTEND_UPLOAD_NAME = "LOGIN_API_ATTEND_UPLOAD_NAME";

    public static final String VIEW_ATTENDANCE_SUCC_MSG = "VIEW_ATTENDANCE_SUCC_MSG";

    public static final String VIEW_ATTENDANCE_FAIL_MSG = "VIEW_ATTENDANCE_FAIL_MSG";

    public static final String LOGIN_API_ATTEND_VIEW_NAME = "LOGIN_API_ATTEND_VIEW_NAME";

    public static final String JWT_GENERATED_SUCCESSFULLY = "JWT_GENERATED_SUCCESSFULLY";

    public static final String MERCHANT_SIGNUP = "MERCHANT_SIGNUP";

    public static final String IMAGE_PATH = "IMAGE_PATH";

    public static final String LOGIN_ATTENDANCE_DEVICE_COUNT = "LOGIN_ATTENDANCE_DEVICE_COUNT";

    public static final String LOGIN_FETCH_PASSWD_DTLS = "LOGIN_FETCH_PASSWD_DTLS";

    public static final String LOGIN_UPDATE_FCMTOKEN_DTLS = "LOGIN_UPDATE_FCMTOKEN_DTLS";

    public static final String LOGIN_UPDATE_JWT_TOKEN = "LOGIN_UPDATE_JWT_TOKEN";

    public static final String LOGIN_FETCH_ROLE_DTLS_OTHER_HIERARCHY = "LOGIN_FETCH_ROLE_DTLS_OTHER_HIERARCHY";

    public static final String LOGIN_CHECK_ATTENDANCE_DTLS = "LOGIN_CHECK_ATTENDANCE_DTLS";

    public static final String LOGIN_CHECK_EOD_ATTEN_DTLS = "LOGIN_CHECK_EOD_ATTEN_DTLS";

    public static final String TRAINING_DUE_DATE_DTLS = "TRAINING_DUE_DATE_DTLS";

    public static final String LOGIN_FETCH_PROMOTER_TYPE = "LOGIN_FETCH_PROMOTER_TYPE";

    public static final String LOGIN_FETCH_USERNAME_DTLS = "LOGIN_FETCH_USERNAME_DTLS";

    public static final String LOGIN_CHECK_USERDEVICE_DTLS = "LOGIN_CHECK_USERDEVICE_DTLS";

    public static final String LOGIN_UPDATE_USERDEVICE_DTLS = "LOGIN_UPDATE_USERDEVICE_DTLS";

    public static final String LOGIN_SAVE_USERDEVICES_DTLS = "LOGIN_SAVE_USERDEVICES_DTLS";

    public static final String LOGIN_CHECK_UPDATE_DEACTIVE_DEL_FLAG = "LOGIN_CHECK_UPDATE_DEACTIVE_DEL_FLAG";

    public static final String LOGIN_CHECK_UPDATE_ACTIVE_DEL_FLAG = "LOGIN_CHECK_UPDATE_ACTIVE_DEL_FLAG";

    public static final String LOGIN_USER_CIRCLE_ZONE_DTLS = "LOGIN_USER_CIRCLE_ZONE_DTLS";

    public static final String LOGIN_FETCH_ROLE_NAME = "LOGIN_FETCH_ROLE_NAME";

    public static final String LOGIN_CHECK_APP_USER_EXIST_DTLS = "LOGIN_CHECK_APP_USER_EXIST_DTLS";

    public static final String LOGIN_CHECK_MOBILE_EXIST_DTLS = "LOGIN_CHECK_MOBILE_EXIST_DTLS";

    public static final String LOGIN_CHECK_APP_DEVICE_EXIST_DTLS = "LOGIN_CHECK_APP_DEVICE_EXIST_DTLS";

    public static final String LOGIN_UPDATE_MULTIPLE_USERDEVICE_DTLS = "LOGIN_UPDATE_MULTIPLE_USERDEVICE_DTLS";

    public static final String LOGIN_SAVE_MULTI_DEVICE_INFO_TRACKER_DTLS = "LOGIN_SAVE_MULTI_DEVICE_INFO_TRACKER_DTLS";

    public static final String LOGIN_FETCH_MOB_COUNT_DTLS = "LOGIN_FETCH_MOB_COUNT_DTLS";

    public static final String LOGIN_SAVE_LOGIN_INFO_TRACKER_DTLS = "LOGIN_SAVE_LOGIN_INFO_TRACKER_DTLS";

    public static final String LOGIN_ATTENDANCE_VIEW_DTLS = "LOGIN_ATTENDANCE_VIEW_DTLS";

    public static final String LOGIN_ATTENDANCE_UPLOAD_DTLS = "LOGIN_ATTENDANCE_UPLOAD_DTLS";

    public static final String LOGIN_GET_PROMOTERTYPE = "LOGIN_GET_PROMOTERTYPE";

    public static final String LOGIN_FETCH_JWT_TOKEN = "LOGIN_FETCH_JWT_TOKEN";

    public static final String ACTIVITY_TRACKER_INVALID_REQUEST = "ACTIVITY_TRACKER_INVALID_REQUEST";

    public static final String COMPLIANCE_UPLOAD_INVALID_FILE_EXTN_MSG = "COMPLIANCE_UPLOAD_INVALID_FILE_EXTN_MSG";

    public static final String COMPLIANCE_UPLOAD_INVALID_CONTENT_TYPE_MSG = "COMPLIANCE_UPLOAD_INVALID_CONTENT_TYPE_MSG";

    public static final String ACTIVITY_TRACKER_DTLS_SUCC_MSG = "ACTIVITY_TRACKER_DTLS_SUCC_MSG";

    public static final String ACTIVITY_TRACKER_API_NAME = "ACTIVITY_TRACKER_API_NAME";

    public static final String FILE_SAVE_COMPLIANCE_PATH = "FILE_SAVE_COMPLIANCE_PATH";

    public static final String COMPLIANCE_CAPTURE_ADD_SUCC_MSG = "COMPLIANCE_CAPTURE_ADD_SUCC_MSG";

    public static final String COMPLIANCE_CAPTURE_ADD_FAIL_MSG = "COMPLIANCE_CAPTURE_ADD_FAIL_MSG";

    public static final String COMPLIANCE_CAPTURE_DEL_SUCC_MSG = "COMPLIANCE_CAPTURE_DEL_SUCC_MSG";

    public static final String COMPLIANCE_CAPTURE_DEL_FAIL_MSG = "COMPLIANCE_CAPTURE_DEL_FAIL_MSG";

    public static final String COMPLIANCE_CAPTURE_DEL_FILE_NOT_EXIST_MSG = "COMPLIANCE_CAPTURE_DEL_FILE_NOT_EXIST_MSG";

    public static final String COMPLIANCE_CAPTURE_API_NAME = "COMPLIANCE_CAPTURE_API_NAME";

    public static final String DASHBOARD_CHECKIN_SUCC_MSG = "DASHBOARD_CHECKIN_SUCC_MSG";

    public static final String GET_PROMOTER_DETAIL_SUCCESS = "PROMOTER_DETAILS_FETCHED_SUCCESSFULLY";

    public static final String DASHBOARD_CHECKIN_FAIL_MSG = "DASHBOARD_CHECKIN_FAIL_MSG";

    public static final String DASHBOARD_CHECKIN_MARRY_DISTANCE_MSG = "DASHBOARD_CHECKIN_MARRY_DISTANCE_MSG";

    public static final String INCORRECT_MAPPING_MESSAGE = "INCORRECT_MAPPING_MESSAGE";

    public static final String NO_PROMOTER_EXIST = "NO_PROMOTER_EXIST";


    public static final String SHOP_LAT_LNG_NA = "SHOP_LAT_LNG_NA";

    public static final String NO_USER_MESSAGE = "NO_USER_MESSAGE";

    public static final String INCORRECT_MAPPING_CHECK = "INCORRECT_MAPPING_CHECK";

    public static final String DASHBOARD_CHECKIN_UNMAPPED_MSG = "DASHBOARD_CHECKIN_UNMAPPED_MSG";

    public static final String DASHBOARD_CHECKOUT_SUCC_MSG = "DASHBOARD_CHECKOUT_SUCC_MSG";

    public static final String DASHBOARD_CHECKOUT_FAIL_MSG = "DASHBOARD_CHECKOUT_FAIL_MSG";

    public static final String DASHBOARD_CHECKINANDOUT_DETAILS_MSG = "DASHBOARD_CHECKINANDOUT_DETAILS_MSG";


    public static final String DASHBOARD_CHECKINANDOUT_NO_RECORD_MSG_KEY = "DASHBOARD_CHECKINANDOUT_NO_RECORD_MSG";

    public static final String DASHBOARD_CHECKINANDOUT_DETAILS_MSG_FAIL = "DASHBOARD_CHECKINANDOUT_FAIL_MSG";

    public static final String DASHBOARD_RETAILR_NOT_EXIST_MSG = "DASHBOARD_RETAILR_NOT_EXIST_MSG";

    public static final String DASHBOARD_API_CHECK_IN_NAME = "DASHBOARD_API_CHECK_IN_NAME";

    public static final String DASHBOARD_API_CHECK_OUT_NAME = "DASHBOARD_API_CHECK_OUT_NAME";

    public static final String DASHBOARD_API_CHECKINOUT_STATUS = "DASHBOARD_API_CHECKINOUT_STATUS";

    public static final String ACTIVITY_TRACKER_SAVE_DTLS = "ACTIVITY_TRACKER_SAVE_DTLS";

    public static final String COMPLIANCE_FETCH_RETAILER_DTLS = "COMPLIANCE_FETCH_RETAILER_DTLS";

    public static final String CHECK_INOUT_APP_USER_EXIST_DTLS = "CHECK_INOUT_APP_USER_EXIST_DTLS";

    public static final String CHECK_IN_CHECKOUT_DTLS = "CHECK_IN_CHECKOUT_DTLS";

    public static final String CHECK_INOUT_MAPPED_USER_EXIST_DTLS = "CHECK_INOUT_MAPPED_USER_EXIST_DTLS";

    public static final String CHECK_INOUT_SAVE_CHECKINOUT_DTLS = "CHECK_INOUT_SAVE_CHECKINOUT_DTLS";

    public static final String CHECK_INOUT_FETCH_RETAILER_DTLS = "CHECK_INOUT_FETCH_RETAILER_DTLS";

    public static final String CHECK_INOUT_FETCH_RETAILER_ADDRESS_DTLS = "CHECK_INOUT_FETCH_RETAILER_ADDRESS_DTLS";

    public static final String PROMOTER_KPI_MST_V2_FETCH_CATID_PROMOTERTYPE = "PROMOTER_KPI_MST_V2_FETCH_CATID_PROMOTERTYPE";

    public static final String PROMOTER_KPI_MST_V2_FETCH_CATNAME_PAPPCATEGORYMST = "PROMOTER_KPI_MST_V2_FETCH_CATNAME_PAPPCATEGORYMST";


    public static final String PROMOTER_KPI_MST_V2_FETCH_ALLKPIS_PAPPCATEGORYMST_1 = "PROMOTER_KPI_MST_V2_FETCH_ALLKPIS_PAPPCATEGORYMST_1";
    public static final String PROMOTER_KPI_MST_V2_FETCH_ALLKPIS_PAPPCATEGORYMST_2 = "PROMOTER_KPI_MST_V2_FETCH_ALLKPIS_PAPPCATEGORYMST_2";
    public static final String PROMOTER_KPI_MST_V2_FETCH_TARGETS_PAPPCATEGORYMST = "PROMOTER_KPI_MST_V2_FETCH_TARGETS_PAPPCATEGORYMST";
    public static final String ADMIN_FETCH_KPI_DETAIL_SUCCESS = "ADMIN_FETCH_KPI_DETAIL_SUCCESS";
    public static final String ADMIN_FETCH_KPI_DETAIL_FAIL = "ADMIN_FETCH_KPI_DETAIL_FAIL";
    public static final String PROMOTER_KPI_MST_V2_FETCH_LAPUNO_PROMOTERKPIMST = "PROMOTER_KPI_MST_V2_FETCH_LAPUNO_PROMOTERKPIMST";

    public static final String submitedEODAttendance = "submitedEODAttendance";

    public static final String JWT_PAYLOAD = "jwt_payload";

    public static final String LOGIN_CHECK_USER_DTLS = "LOGIN_CHECK_USER_DTLS";

    public static final String GOOGLE_CAPTCHA_VERIFICATION_FAIL = "GOOGLE_CAPTCHA_VERIFICATION_FAIL";

    public static final String GEO_CHECKIN_LIMIT_KEY = "GEO_CHECKIN_LIMIT_KEY";
    public static final String GEO_CHECKIN_LIMIT_VALUE_IN_METERS = "GEO_CHECKIN_LIMIT_VALUE_IN_METERS";
    public static final String GEO_CHECKOUT_LIMIT_KEY = "GEO_CHECKOUT_LIMIT_KEY";
    public static final String GEO_CHECKOUT_LIMIT_VALUE_IN_METERS = "GEO_CHECKOUT_LIMIT_VALUE_IN_METERS";

    public static final String MAX_COUNT = "MAX_COUNT";

    public static final String USER_BLOCKED_FOR_WRONG_ATTEMPT = "USER_BLOCKED_FOR_WRONG_ATTEMPT";
    public static final String WRONG_ATTEMPT_STATUS_CODE = "WRONG_ATTEMPT_STATUS_CODE";
    public static final String ALREADY_SIGNUP_USER = "ALREADY_SIGNUP_USER";
    public static final String ALREADY_SIGNUP_USER_CODE = "ALREADY_SIGNUP_USER_CODE";

    public static final String EXPIRY_SESSION_IN_SECONDS_FOR_CHECKIN = "EXPIRY_SESSION_IN_SECONDS_FOR_CHECKIN";

    public static final String KEY_MERCHANT = "KEY_MERCHANT";
    public static final String KEY_RETAILER = "KEY_RETAILER";
    public static final String GOOGLE_API_KEY = "GOOGLE_API_KEY";

    public static final String OTP_API_VER="otp.api.version";
    public static final String OTP_LANG_ID="otp.api.language.id";

    public static final String ALLOWED_USERTYPES_FOR_WHITELISTING="allowed.usertypes.for.whitelisting";

    public static final String IN_OUT_STATUS_FAIL = "CHECK_IN_OUT_FAIL";

    public static final String MOBILE_NUMBER_NOT_WHITELISTED = "MOBILE_NUMBER_NOT_WHITELISTED";

    public static final String GET_PROFILE_URL_KEY = "GET_PROFILE_URL";

    public static final String MERCHANT_SHOP_API_URL_KEY = "MERCHANT_SHOP_API_URL";
    public static final String RETAILER_SHOP_API_URL_KEY = "RETAILER_SHOP_API_URL";
    public static final String KEY_CHECK_IN = "CHECK_IN";
    public static final String KEY_CHECK_OUT = "CHECK_OUT";
    public static final String THIRD_PARTY_ERROR_CODE = "7005";
    public static final String THIRD_PARTY_ERROR_MSG = "Third party error.";

}
