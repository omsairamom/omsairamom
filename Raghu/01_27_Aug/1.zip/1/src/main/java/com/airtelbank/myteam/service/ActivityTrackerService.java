package com.airtelbank.myteam.service;

import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import org.springframework.stereotype.Service;

@Service
public interface ActivityTrackerService
{
	SnapWorkResponse activityTrackerDetails(SnapWorkRequest request) throws Exception;
}
