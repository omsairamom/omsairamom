package com.airtelbank.model.PromoterDetail;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class AadharName
{
    @SerializedName("promoterFirstName")
    @Expose
    private String promoterFirstName;

    @SerializedName("promoterMName")
    @Expose
    private String promoterMName;

    @SerializedName("promoterLastName")
    @Expose
    private String promoterLastName;

    public String getPromoterFirstName()
    {
        return promoterFirstName;
    }

    public void setPromoterFirstName(String promoterFirstName)
    {
        this.promoterFirstName = promoterFirstName;
    }

    public String getPromoterMName()
    {
        return promoterMName;
    }

    public void setPromoterMName(String promoterMName)
    {
        this.promoterMName = promoterMName;
    }

    public String getPromoterLastName()
    {
        return promoterLastName;
    }

    public void setPromoterLastName(String promoterLastName)
    {
        this.promoterLastName = promoterLastName;
    }
}
