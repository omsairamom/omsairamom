package com.airtelbank.myteam.dao;

import com.airtelbank.bean.CheckInOutBean;
import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterCheckInDetailsAuditRepository;
import com.airtelbank.util.Constants;
import com.airtelbank.util.CustomException;
import com.airtelbank.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class CheckInAndOutDAO
{
	private final Logger logger = LoggerFactory.getLogger(CheckInAndOutDAO.class.getClass());
	
	@Autowired  
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	@Autowired
	PromoterCheckInDetailsAuditRepository promoterCheckInDetailsAuditRepository;
	
	public int saveCheckInOutDeatils(final CheckInOutBean obj) throws CustomException
	{
		int row = 0;

		logger.info("Inside saveDeviceDetails() method in CheckInAndOutDAO class... {}:" , "");

		final String INSERT_SQL = prop.getProperty(Constants.CHECK_INOUT_SAVE_CHECKINOUT_DTLS);

		row = jdbctemplate.update(INSERT_SQL, obj.getRetMobileNo(),obj.getProMobileNo(),
					obj.getType(), obj.getInOrOut(), obj.getLatitude(),obj.getLongitude(),obj.getStoreName(),
					obj.getMarryDist(),obj.getDateOfVisit(),obj.getField1(),obj.getField2(),obj.getField3(),
					obj.getField4(),obj.getField5(),obj.getRemarks());

		return row;
	}
	
	public List<Map<String, Object>> getRetailerDetails(String retMobileNo)
	{
		String query = "";
		List<Map<String, Object>> rows = null;
		query = prop.getProperty(Constants.CHECK_INOUT_FETCH_RETAILER_DTLS);
		rows = jdbctemplate.queryForList(query, retMobileNo);
		return rows;
	}

	public String getRetailerAddress(String mobileNo)
	{
		String address = "";
		String villageName = "";
		String blockTehsil = "";
		String destrict = "";
		String city = "";

			String query = prop.getProperty(Constants.CHECK_INOUT_FETCH_RETAILER_ADDRESS_DTLS);
			List<Map<String, Object>> rows = jdbctemplate.queryForList(query, mobileNo );

			if (rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					villageName = row.get("VILLAGE_NAME").toString().equalsIgnoreCase("NA") ? ""
							: row.get("VILLAGE_NAME").toString();
					blockTehsil = row.get("BLOCK_TEHSIL").toString().equalsIgnoreCase("NA") ? ""
							: row.get("BLOCK_TEHSIL").toString();
					destrict = row.get("DISTRICT").toString().equalsIgnoreCase("NA") ? ""
							: row.get("DISTRICT").toString();
					city = row.get("CITY").toString().equalsIgnoreCase("NA") ? "" : row.get("CITY").toString();
				}

				if (!villageName.equals(""))
					address = villageName;
				if (!blockTehsil.equals(""))
					address = address + ", " + blockTehsil;
				if (!city.equals(""))
					address = address +", " + city;
				if (!destrict.equals(""))
					address = address +", " + destrict;
				
				if (address.contains("NA")) {
					address = address.replaceAll("NA", "");
				}
			}

		return address;
	}
  
	public boolean isAppUserExist(String mobileNo) throws CustomException
	{
		boolean flag = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		logger.info("Inside isUserDeviceExist() method in CheckInAndOutDAO class...{}:" , "");
		query = prop.getProperty(Constants.CHECK_INOUT_APP_USER_EXIST_DTLS);
		rows = jdbctemplate.queryForList(query, mobileNo);

		if(!rows.isEmpty())
		{
				flag = true;
		}

		return flag;
	}

	public boolean isMappedUserExist(String proMobileNo,String retMobileNo, String roleName) throws CustomException
	{

		boolean flag = false;
		String query = "";
		List<Map<String, Object>> rows = null;


		query = prop.getProperty(Constants.CHECK_INOUT_MAPPED_USER_EXIST_DTLS) + " AND " +roleName+"ID=?";
		rows = jdbctemplate.queryForList(query, retMobileNo, proMobileNo);

		if(rows != null && !rows.isEmpty())
		{
			for(Map<String, Object> row : rows )
			{
				String retMobileNoFromDb= row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();

				if (retMobileNoFromDb.equalsIgnoreCase(retMobileNo))
				{
					flag=true;
				}
			}
		}

		return flag;
	}

	public List<Map<String, Object>> getCheckInCheckOutDetails(String proMobileNo)
	{
		String query = "";
		query = prop.getProperty(Constants.CHECK_IN_CHECKOUT_DTLS);

		List<Map<String, Object>> rows = jdbctemplate.queryForList(query, proMobileNo);

		return rows;
	}

	public List<PromoterCheckInDetailsAuditEntity> getCheckInCheckOutDetails_V2(Optional<PromoterUserMSTEntity> promoterUserMSTEntity)
	{
		List<PromoterCheckInDetailsAuditEntity> items = null;
		if (promoterUserMSTEntity.isPresent())
		{
			items =
					promoterCheckInDetailsAuditRepository.getPromoterDetailsByID(promoterUserMSTEntity.get().getId());
			return items;
		}
		return items;
	}
}