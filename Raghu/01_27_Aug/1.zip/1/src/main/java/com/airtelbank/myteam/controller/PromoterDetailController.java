package com.airtelbank.myteam.controller;

import com.airtelbank.myteam.service.PromoterDetailService;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class PromoterDetailController
{
    @Autowired
    PromoterDetailService promoterDetailService;

    @GetMapping(value = {"v1/promoter/{msisdn}", "/v1/promoter/{msisdn}/{status}"})
    public ResponseEntity<Object>
    getPromoterDetails(@PathVariable("msisdn") String msisdn,
                         @PathVariable Optional<String> status)
    {
        JSONObject response = promoterDetailService.getPromoterDetail(msisdn, status);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}