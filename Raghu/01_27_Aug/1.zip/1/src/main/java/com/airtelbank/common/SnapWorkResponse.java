package com.airtelbank.common;


import org.json.simple.JSONObject;
import org.springframework.context.annotation.Bean;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 05, 2019 07:34:45 PM
 */

public class SnapWorkResponse {
	
	private JSONObject response;
	private String message;
	private String statusCode;
	private String desc;
	private String expMsg; //NEW FIELD 
    private String expCause; //NEW FIELD
	private String  expLocalMsg; //NEW FILED
	
	
	@Bean
	public SnapWorkResponse response()
	{
		return new SnapWorkResponse();
	}

	public JSONObject getResponse()
	{
		return response;
	}
	
	public void setResponse(JSONObject response) 
	{
		this.response = response;
	}
	
	public String getMessage()
	{
		return message;
	}
	
	public void setMessage(String message)
	{
		this.message = message;
	}
	
	public String getStatusCode() 
	{
		return statusCode;
	}
	
	public void setStatusCode(String statusCode) 
	{
		this.statusCode = statusCode;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getExpMsg() {
		return expMsg;
	}

	public void setExpMsg(String expMsg) {
		this.expMsg = expMsg;
	}

	public String getExpCause() {
		return expCause;
	}

	public void setExpCause(String expCause) {
		this.expCause = expCause;
	}

	public String getExpLocalMsg() {
		return expLocalMsg;
	}

	public void setExpLocalMsg(String expLocalMsg) {
		this.expLocalMsg = expLocalMsg;
	}
	
	@Override
	public String toString()
	{
		return "message ="+message+": statusCode ="+statusCode+": response="+response + ": desc="+desc;
	}

}
