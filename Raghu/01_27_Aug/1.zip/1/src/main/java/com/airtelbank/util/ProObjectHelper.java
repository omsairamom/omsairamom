package com.airtelbank.util;

import com.airtelbank.entity.PromoterLoginTrackerAuditEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;

public class ProObjectHelper
{

    public static PromoterLoginTrackerAuditEntity getObjForLogInOutTracker(PromoterUserMSTEntity promoterUserMSTEntity, String mobileNo, String latitude,
                                                                           String longitude, String loginType, String udid, String channel)
    {
        PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity =
                new PromoterLoginTrackerAuditEntity();
        promoterLoginTrackerAuditEntity.setUserNo(mobileNo);
        promoterLoginTrackerAuditEntity.setPromoterUserMSTEntity(promoterUserMSTEntity);

        promoterLoginTrackerAuditEntity.setLatitude(latitude);
        promoterLoginTrackerAuditEntity.setLongitude(longitude);
        promoterLoginTrackerAuditEntity.setLogInType(loginType);
        promoterLoginTrackerAuditEntity.setDeviceId(udid);
        promoterLoginTrackerAuditEntity.setChannel(channel);
        promoterLoginTrackerAuditEntity.setCustom_field1("NA");
        promoterLoginTrackerAuditEntity.setCustom_field2("NA");
        promoterLoginTrackerAuditEntity.setCustom_field3("NA");
        promoterLoginTrackerAuditEntity.setCustom_field4("NA");
        promoterLoginTrackerAuditEntity.setCustom_field5("NA");

        return promoterLoginTrackerAuditEntity;
    }
}
