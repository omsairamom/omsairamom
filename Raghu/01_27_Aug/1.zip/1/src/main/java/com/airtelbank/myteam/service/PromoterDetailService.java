package com.airtelbank.myteam.service;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface PromoterDetailService
{
    JSONObject getPromoterDetail(String msisdn, Optional<String> status);
}
