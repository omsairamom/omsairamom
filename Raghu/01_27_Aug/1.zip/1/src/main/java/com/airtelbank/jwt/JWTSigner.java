package com.airtelbank.jwt;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.naming.OperationNotSupportedException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.util.PropertyManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonAppend.Prop;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Aug 02, 2019 10:14:45 PM
 */
@Service
public class JWTSigner {

	private static Logger logger = LoggerFactory.getLogger(JWTSigner.class);

	private byte[] secret;
	
	

	public byte[] getSignKeyBytes(String secretKey) {
		secret = secretKey.getBytes();
		return secret;
	}

	/**
	 * Generate a JSON Web Token. using the default algorithm HMAC SHA-256 ("HS256")
	 * and no claims automatically set.
	 *
	 * @param claims  A map of the JWT claims that form the payload. Registered
	 *                claims must be of appropriate Java datatype as following:
	 *                <ul>
	 *                <li>iss, sub: String
	 *                <li>exp, nbf, iat, jti: numeric, eg. Long
	 *                <li>aud: String, or Collection&lt;String&gt;
	 *                </ul>
	 *                All claims with a null value are left out the JWT. Any claims
	 *                set automatically as specified in the "options" parameter
	 *                override claims in this map.
	 *
	 *
	 * @param options Allow choosing the signing algorithm, and automatic setting of
	 *                some registered claims.
	 */

	/*
	 * public String sign(Map<String, Object> claims, Options options) {
	 * 
	 * logger.info("Inside sign() method in JWTSigner class :"); Algorithm algorithm
	 * = Algorithm.HS256; if (options != null && options.algorithm != null)
	 * algorithm = options.algorithm; logger.info("line no 69 :"); List<String>
	 * segments = new ArrayList<String>(); try {
	 * segments.add(encodedHeader(algorithm)); segments.add(encodedPayload(claims,
	 * options)); segments.add(encodedSignature(join(segments, "."), algorithm));
	 * logger.info("segments :" + segments); } catch (Exception e) {
	 * e.printStackTrace();
	 * logger.info("Exception for sign() method in JWTSigner class :" + e); throw (e
	 * instanceof RuntimeException) ? (RuntimeException) e : new
	 * RuntimeException(e); }
	 * 
	 * return join(segments, "."); }
	 */

	public String sign(Map<String, Object> claims, Options options,PropertyManager prop) {
		Algorithm algorithm = Algorithm.RS256;
		if (options != null && options.algorithm != null)
			algorithm = options.algorithm;

		List<String> segments = new ArrayList<String>();
		logger.info("Algorithm selected inside sign method: {}", algorithm.getValue());
		try {
			segments.add(encodedHeader(algorithm));
			segments.add(encodedPayload(claims, options));
			segments.add(encodedSignature(join(segments, "."), algorithm, prop));
		} catch (Exception e) {
			throw (e instanceof RuntimeException) ? (RuntimeException) e : new RuntimeException(e);
		}

		return join(segments, ".");
	}

	/**
	 * Generate a JSON Web Token using the default algorithm HMAC SHA-256 ("HS256")
	 * and no claims automatically set.
	 */
	public String sign(Map<String, Object> claims, PropertyManager prop) {
		return sign(claims, null, prop);
	}

	/**
	 * Generate the header part of a JSON web token.
	 */
	private String encodedHeader(Algorithm algorithm) throws UnsupportedEncodingException {
		if (algorithm == null) {
			algorithm = Algorithm.HS256;
		}

		ObjectNode header = JsonNodeFactory.instance.objectNode();
		header.put("typ", "JWT");
		header.put("alg", algorithm.name());

		return base64UrlEncode(header.toString().getBytes("UTF-8"));
	}

	/**
	 * Generate the JSON web token payload string from the claims.
	 * 
	 * @param options
	 */
	private String encodedPayload(Map<String, Object> _claims, Options options) throws Exception {
		Map<String, Object> claims = new HashMap<String, Object>(_claims);
		enforceStringOrURI(claims, "iss");
		enforceStringOrURI(claims, "sub");
		enforceStringOrURICollection(claims, "aud");
		enforceIntDate(claims, "exp");
		enforceIntDate(claims, "nbf");
		enforceIntDate(claims, "iat");
		enforceString(claims, "jti");

		if (options != null)
			processPayloadOptions(claims, options);

		String payload = new ObjectMapper().writeValueAsString(claims);
		logger.info("payload :" + payload);
		return base64UrlEncode(payload.getBytes("UTF-8"));
	}

	private void processPayloadOptions(Map<String, Object> claims, Options options) {
		long now = System.currentTimeMillis() / 1000l;
		if (options.expirySeconds != null)
			claims.put("exp", now + options.expirySeconds);
		if (options.notValidBeforeLeeway != null)
			claims.put("nbf", now - options.notValidBeforeLeeway);
		if (options.isIssuedAt())
			claims.put("iat", now);
		if (options.isJwtId())
			claims.put("jti", UUID.randomUUID().toString());
	}

	private void enforceIntDate(Map<String, Object> claims, String claimName) {
		Object value = handleNullValue(claims, claimName);
		if (value == null)
			return;
		if (!(value instanceof Number)) {
			throw new RuntimeException(
					String.format("Claim '%s' is invalid: must be an instance of Number", claimName));
		}
		long longValue = ((Number) value).longValue();
		if (longValue < 0)
			throw new RuntimeException(String.format("Claim '%s' is invalid: must be non-negative", claimName));
		claims.put(claimName, longValue);
	}

	private void enforceStringOrURICollection(Map<String, Object> claims, String claimName) {
		Object values = handleNullValue(claims, claimName);
		if (values == null)
			return;
		if (values instanceof Collection) {
			@SuppressWarnings({ "unchecked" })
			Iterator<Object> iterator = ((Collection<Object>) values).iterator();
			while (iterator.hasNext()) {
				Object value = iterator.next();
				String error = checkStringOrURI(value);
				if (error != null)
					throw new RuntimeException(String.format("Claim 'aud' element is invalid: %s", error));
			}
		} else {
			enforceStringOrURI(claims, "aud");
		}
	}

	private void enforceStringOrURI(Map<String, Object> claims, String claimName) {
		Object value = handleNullValue(claims, claimName);
		if (value == null)
			return;
		String error = checkStringOrURI(value);
		if (error != null)
			throw new RuntimeException(String.format("Claim '%s' is invalid: %s", claimName, error));
	}

	private void enforceString(Map<String, Object> claims, String claimName) {
		Object value = handleNullValue(claims, claimName);
		if (value == null)
			return;
		if (!(value instanceof String))
			throw new RuntimeException(String.format("Claim '%s' is invalid: not a string", claimName));
	}

	private Object handleNullValue(Map<String, Object> claims, String claimName) {
		if (!claims.containsKey(claimName))
			return null;
		Object value = claims.get(claimName);
		if (value == null) {
			claims.remove(claimName);
			return null;
		}
		return value;
	}

	private String checkStringOrURI(Object value) {
		if (!(value instanceof String))
			return "not a string";
		String stringOrUri = (String) value;
		if (!stringOrUri.contains(":"))
			return null;
		try {
			new URI(stringOrUri);
		} catch (URISyntaxException e) {
			return "not a valid URI";
		}
		return null;
	}

	/**
	 * Sign the header and payload
	 */
	private String encodedSignature(String signingInput, Algorithm algorithm, PropertyManager prop) throws Exception {
		byte[] signature = sign(algorithm, signingInput, secret, prop);
		return base64UrlEncode(signature);
	}

	/**
	 * Safe URL encode a byte array to a String
	 */
	private String base64UrlEncode(byte[] str) {
		return new String(Base64.encodeBase64URLSafe(str));
	}

	/**
	 * Switch the signing algorithm based on input, RSA not supported
	 */
	private static byte[] sign(Algorithm algorithm, String msg, byte[] secret,PropertyManager prop ) throws Exception {
		switch (algorithm) {
		case HS256:
		case HS384:
		case HS512:
			return signHmac(algorithm, msg, secret);
		case RS256:
		case RS384:
		case RS512:
			return signRSA(algorithm, msg, null, prop);
		default:
			throw new OperationNotSupportedException("Unsupported signing method");
		}
	}

	private static byte[] signRSA(Algorithm algorithm, String msg, byte[] secret,PropertyManager prop ) throws Exception {
		logger.info("Inside signRSA with algorithm : {}", algorithm.getValue());

		/* Generate private key. */
		String privateKey = null;
		if (StringUtils.isNotBlank(prop.getProperty("RSA_PRIVATE_KEY"))) {
			privateKey = prop.getProperty("RSA_PRIVATE_KEY");
		} else {
			logger.info("Empty private key");
			throw new NullPointerException("Not able to get Private Key");
		}
		PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey.getBytes()));
		KeyFactory kf = KeyFactory.getInstance("RSA");
		PrivateKey pvt = kf.generatePrivate(ks);
		logger.info("Inside signRSA: Private key generated succesfully");
		Signature sign = Signature.getInstance("SHA256withRSA");
		sign.initSign(pvt);

		sign.update(msg.getBytes(), 0, msg.length());
		logger.info("Inside signRSA: token signed with RS256 succesfully");
		return sign.sign();
	}

	/**
	 * Sign an input string using HMAC and return the encrypted bytes
	 */
	private static byte[] signHmac(Algorithm algorithm, String msg, byte[] secret) throws Exception {
		Mac mac = Mac.getInstance(algorithm.getValue());
		mac.init(new SecretKeySpec(secret, algorithm.getValue()));
		return mac.doFinal(msg.getBytes());
	}

	private String join(List<String> input, String on) {

		StringBuilder joined = new StringBuilder();
		try {
			int size = input.size();
			int count = 1;

			for (String string : input) {
				joined.append(string);
				if (count < size) {
					joined.append(on);
				}
				count++;
			}
		}
		catch (Exception exe)
		{
			exe.printStackTrace();
		}
		logger.info("joined.toString() :" + joined.toString());
		return joined.toString();
	}

	public static class Options {
		private Algorithm algorithm;
		private Integer expirySeconds;
		private Integer notValidBeforeLeeway;
		private boolean issuedAt;
		private boolean jwtId;

		public Algorithm getAlgorithm() {
			return algorithm;
		}

		/**
		 * Algorithm to sign JWT with. Default is <code>HS256</code>.
		 */
		public Options setAlgorithm(Algorithm algorithm) {
			this.algorithm = algorithm;
			return this;
		}

		public Integer getExpirySeconds() {
			return expirySeconds;
		}

		/**
		 * Set JWT claim "exp" to current timestamp plus this value. Overrides content
		 * of <code>claims</code> in <code>sign()</code>.
		 */
		public Options setExpirySeconds(Integer expirySeconds) {
			this.expirySeconds = expirySeconds;
			return this;
		}

		public Integer getNotValidBeforeLeeway() {
			return notValidBeforeLeeway;
		}

		/**
		 * Set JWT claim "nbf" to current timestamp minus this value. Overrides content
		 * of <code>claims</code> in <code>sign()</code>.
		 */
		public Options setNotValidBeforeLeeway(Integer notValidBeforeLeeway) {
			this.notValidBeforeLeeway = notValidBeforeLeeway;
			return this;
		}

		public boolean isIssuedAt() {
			return issuedAt;
		}

		/**
		 * Set JWT claim "iat" to current timestamp. Defaults to false. Overrides
		 * content of <code>claims</code> in <code>sign()</code>.
		 */
		public Options setIssuedAt(boolean issuedAt) {
			this.issuedAt = issuedAt;
			return this;
		}

		public boolean isJwtId() {
			return jwtId;
		}

		/**
		 * Set JWT claim "jti" to a pseudo random unique value (type 4 UUID). Defaults
		 * to false. Overrides content of <code>claims</code> in <code>sign()</code>.
		 */
		public Options setJwtId(boolean jwtId) {
			this.jwtId = jwtId;
			return this;
		}

	}

	public JSONObject getPayloadDatafromToken(String token) {

		String[] parts = token.split("\\.");

		JSONParser parser = new JSONParser();
		JSONObject json = null;
		try {
			json = (JSONObject) parser.parse(decode(parts[1]));

			System.out.println("=========json" + json);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return json;
	}

	private static String decode(String encodedString) {

		return new String(Base64.decodeBase64(encodedString));
	}

}
