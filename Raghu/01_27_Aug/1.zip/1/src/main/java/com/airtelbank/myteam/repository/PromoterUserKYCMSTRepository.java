package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterAttendanceAuditEntity;
import com.airtelbank.entity.PromoterUserKYCMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PromoterUserKYCMSTRepository extends JpaRepository<PromoterUserKYCMSTEntity, Long>
{
   // public Optional<PromoterUserKYCMSTEntity> findByUserId(Long id);

    Optional<PromoterUserKYCMSTEntity> findByPromoterUserMSTEntity(PromoterUserMSTEntity promoterUserMSTEntity);
}