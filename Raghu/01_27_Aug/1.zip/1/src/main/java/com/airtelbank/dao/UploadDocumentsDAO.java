package com.airtelbank.dao;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.entity.PromoterAttendanceAuditEntity;
import com.airtelbank.entity.PromoterCaptureComplianceEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterAttendanceAuditRepository;
import com.airtelbank.myteam.repository.PromoterCaptureComplianceRepository;
import com.airtelbank.myteam.repository.PromoterUserMSTRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UploadDocumentsDAO {

    @Autowired
    private PromoterUserMSTRepository promoterUserMSTRepository;

    @Autowired
    private PromoterAttendanceAuditRepository promoterAttendanceAuditRepository;

    @Autowired
    private PromoterCaptureComplianceRepository promoterCaptureComplianceRepository;

    public boolean fetchEODSubmitAttendanceDetails(String  mobileNo)
    {
        Optional<PromoterUserMSTEntity> optionalPromoterUserMSTEntity = promoterUserMSTRepository.findOneByUserNo(mobileNo);
        return false;
    }

    public int saveAttendanceDetails(AttendanceBean attendanceBean)
    {
        Optional<PromoterUserMSTEntity> optionalPromoterUserMSTEntity = promoterUserMSTRepository.findOneByUserNo(attendanceBean.getMobileNo());

        if (optionalPromoterUserMSTEntity.isPresent())
        {
            PromoterAttendanceAuditEntity promoterAttendanceAuditEntity = new PromoterAttendanceAuditEntity();
            promoterAttendanceAuditEntity.setPromoterUserMSTEntity(optionalPromoterUserMSTEntity.get());
            promoterAttendanceAuditEntity.setPromoterNo(optionalPromoterUserMSTEntity.get().getUserNo());
            promoterAttendanceAuditEntity.setAddress(attendanceBean.getAddress());
            promoterAttendanceAuditEntity.setLongitude(attendanceBean.getLongitude());
            promoterAttendanceAuditEntity.setLatitude(attendanceBean.getLatitude());
            promoterAttendanceAuditEntity.setPromoterCircleMSTEntity(optionalPromoterUserMSTEntity.get().getPromoterCircleMSTEntity());
            promoterAttendanceAuditEntity.setSelfieId(attendanceBean.getSelfiePath());
            promoterAttendanceAuditRepository.save(promoterAttendanceAuditEntity);
            return 1;
        }
        return 0;
    }

    public boolean saveUserSelfieId(String selfieId, String mobileNo)
    {
        Optional<PromoterUserMSTEntity> optionalPromoterUserMSTEntity = promoterUserMSTRepository.findOneByUserNo(mobileNo);

        if (optionalPromoterUserMSTEntity.isPresent())
        {
            optionalPromoterUserMSTEntity.get().setSelfieId(selfieId);
            promoterUserMSTRepository.save(optionalPromoterUserMSTEntity.get());
            return true;
        }

        return false;
    }

    public boolean captureCompliance(String documentId, String mobileNo)
    {
        Optional<PromoterUserMSTEntity> optionalPromoterUserMSTEntity = promoterUserMSTRepository.findOneByUserNo(mobileNo);

        if (optionalPromoterUserMSTEntity.isPresent())
        {
            PromoterCaptureComplianceEntity promoterCaptureComplianceEntity = new PromoterCaptureComplianceEntity();
            promoterCaptureComplianceEntity.setDocumentId(documentId);
            promoterCaptureComplianceEntity.setPromoterUserMSTEntity(optionalPromoterUserMSTEntity.get());
            promoterCaptureComplianceRepository.save(promoterCaptureComplianceEntity);
            return true;
        }
        return false;
    }
}