package com.airtelbank.myteam.common;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.json.simple.JSONArray;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jul 01, 2019 02:34:45 PM
 */
@Configuration
public class MyTeamSnapWorkRequest {

	private final String LATITUDE_PATTERN = "^(\\+|-)?(?:90(?:(?:\\.0{1,6})?)|(?:[0-9]|[1-8][0-9])(?:(?:\\.[0-9]{1,6})?))$";
	private final String LONGITUDE_PATTERN = "^(\\+|-)?(?:180(?:(?:\\.0{1,6})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\\.[0-9]{1,6})?))$";

	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid mobileNo.")
	private String mobileNo;

	@Pattern(regexp = "^[^*&%\\s]+$", message = "Please enter valid fileName.")
	private String fileName;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$")
	private String encImage;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid action.")
	private String action;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid roleName.")
	private String roleName;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid roleId.")
	private String roleId;

	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter valid username.")
	private String userName;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid deviceId.")
	private String deviceId;

	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid proMobileNo.")
	private String proMobileNo;

	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter valid type.")
	private String type;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid storeName.")
	private String storeName;

	@DateTimeFormat(pattern = "dd-MM-yyyy hh:mm:ss")
	private String dateOfVisit;

	@Pattern(regexp = LATITUDE_PATTERN, message = "Please enter valid latitude.")
	private String latitude;

	@Pattern(regexp = LONGITUDE_PATTERN, message = "Please enter valid longitude.")
	private String longitude;

	@Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter only true or false.")
	private String isGpsEnabled;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid typeOfCustomer.")
	private String typeOfCustomer;
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid issueName.")
	private String issueName;
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid Description.")
	private String description;

	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid loginNo.")
	private String loginNo;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid circleName.")
	private String circleName;
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid zoneName.")
	private String zoneName;

	private JSONArray notifDetails;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid catId.")
	private String catId;
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid CategoryName.")
	private String CategoryName;

	@Pattern(regexp = "\\d+(\\.\\d{1,2})?" , message = "Please enter valid ver.")
	private String ver;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid channel.")
	private String channel;
	
	@Pattern(regexp = "^([0-9a-zA-z]).{0,20}$", message = "Please enter valid feSessionId.")
	private String feSessionId;

	@Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid remarks.")
	private String remarks;
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getFeSessionId() {
		return feSessionId;
	}

	public void setFeSessionId(String feSessionId) {
		this.feSessionId = feSessionId;
	}

	public String getCategoryName() {
		return CategoryName;
	}

	public void setCategoryName(String categoryName) {
		CategoryName = categoryName;
	}


	public String getCatId() {
		return catId;
	}

	public void setCatId(String catId) {
		this.catId = catId;
	}

	public JSONArray getNotifDetails() {
		return notifDetails;
	}

	public void setNotifDetails(JSONArray notifDetails) {
		this.notifDetails = notifDetails;
	}

	public String getCircleName() {
		return circleName;
	}

	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}

	public String getZoneName() {
		return zoneName;
	}

	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}

	
	
	public String getTypeOfCustomer() {
		return typeOfCustomer;
	}

	public void setTypeOfCustomer(String typeOfCustomer) {
		this.typeOfCustomer = typeOfCustomer;
	}

	public String getIssueName() {
		return issueName;
	}

	public void setIssueName(String issueName) {
		this.issueName = issueName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLoginNo() {
		return loginNo;
	}

	public void setLoginNo(String loginNo) {
		this.loginNo = loginNo;
	}

	public String getIsGpsEnabled() {
		return isGpsEnabled;
	}

	public void setIsGpsEnabled(String isGpsEnabled) {
		this.isGpsEnabled = isGpsEnabled;
	}

	private JSONArray trackerInfo;	

	
	public JSONArray getTrackerInfo() {
		return trackerInfo;
	}

	public void setTrackerInfo(JSONArray trackerInfo) {
		this.trackerInfo = trackerInfo;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getProMobileNo() {
		return proMobileNo;
	}

	public void setProMobileNo(String proMobileNo) {
		this.proMobileNo = proMobileNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getDateOfVisit() {
		return dateOfVisit;
	}

	public void setDateOfVisit(String dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getEncImage() {
		return encImage;
	}

	public void setEncImage(String encImage) {
		this.encImage = encImage;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	

//	@Bean
//	public MyTeamSnapWorkRequest request()
//	{
//		return new MyTeamSnapWorkRequest();
//	}

	@Override
	public String toString(){
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
