package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterCircleMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface PromoterCircleMSTRepository extends JpaRepository<PromoterCircleMSTEntity, Long>
{
    public Optional<PromoterCircleMSTEntity> findOneByCircleId(String circleId);
}















