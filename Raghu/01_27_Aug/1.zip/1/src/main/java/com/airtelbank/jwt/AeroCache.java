package com.airtelbank.jwt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.AerospikeException;
import com.aerospike.client.Bin;
import com.aerospike.client.Host;
import com.aerospike.client.Key;
import com.aerospike.client.Record;
import com.aerospike.client.policy.BatchPolicy;
import com.aerospike.client.policy.ClientPolicy;
import com.aerospike.client.policy.WritePolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.airtelbank.common.CommonException;
import com.airtelbank.util.PropertyManager;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Aug 02, 2019 10:14:45 PM
 */
@Service
public class AeroCache {

   private static Logger logger = LoggerFactory.getLogger(AeroCache.class);
	
   @Autowired
   private PropertyManager prop;

   private static volatile AerospikeClient client;
   private static ClientPolicy policy = new ClientPolicy();
   private static String defaultNS;
   private static String defaultSet;
   public final static String defaultColumn = "value";
   static final Gson gson = new GsonBuilder().setDateFormat("yyyyMMddHHmmss").create();

   long expiration = Long.parseLong(StringUtils.defaultIfBlank("32400000", "-1"));
  
   
   public void loadConfig() {
      try {
    	 logger.info("Inside  loadConfig() method in AeroCache class :");
         defaultNS = prop.getProperty("AEROSPIKE_NAMESPACE");
         defaultSet = prop.getProperty("AEROSPIKE_SETNAME");
         
         logger.info("defaultNS  :"+defaultNS);
         logger.info("defaultSet :"+defaultSet);
         
         long expiration = Long.parseLong(StringUtils.defaultIfBlank(prop.getProperty("AEROSPIKE_EXPIRATION"), "-1"));
         logger.info(" expiration config AEROSPIKE_EXPIRATION : " + expiration);
         policy.writePolicyDefault.expiration = (int) Math.min(expiration, Integer.MAX_VALUE);
         
         logger.info("AEROSPIKE_USERNAME  :"+prop.getProperty("AEROSPIKE_USERNAME"));
         logger.info("AEROSPIKE_PASSWORD  :"+prop.getProperty("AEROSPIKE_PASSWORD"));
         
         policy.user = prop.getProperty("AEROSPIKE_USERNAME");
         policy.password = prop.getProperty("AEROSPIKE_PASSWORD");
         logger.info(" expiration set to : " + policy.writePolicyDefault.expiration);
         client = null;
      } catch (Exception e) {
    	  CommonException.getPrintStackTrace(e);
      }
   }
    
   private AerospikeClient getClient() {

      if (client != null && client.isConnected())
         return client;
      synchronized (AeroCache.class) {
         if (client != null && client.isConnected())
            return client;
         List<Host> hosts = new ArrayList<Host>();
         try {
            
            int count = 0;
            while (true) {
               String host = prop.getProperty("AEROSPIKE_HOST" + (count == 0 ? "" : count));
               if (StringUtils.isNotBlank(host)) {
                  hosts.add(new Host(host, Integer.parseInt(prop.getProperty("AEROSPIKE_PORT" + (count == 0 ? "" : count)))));
                  logger.info("adding host:" + host);
                  count++;
               } else break;
            }
            
         } catch (Exception e) {
        	  e.printStackTrace();
            throw new AerospikeException("Unable to load configurations");
         }
         client = new AerospikeClient(policy, hosts.toArray(new Host[hosts.size()]));
      }
      return client;
   }

   private WritePolicy getWritePolicy(int expiry) {
      if (expiry < -1 || expiry == 0)
         return null;
      WritePolicy wp = new WritePolicy();
      wp.expiration = (int) Math.min(expiry, Integer.MAX_VALUE);
      return wp;
   }

   private Key getKey(String setName, String key) {
	   logger.info("Inside getKey() method in AeroCache class :");
	   defaultNS = prop.getProperty("AEROSPIKE_NAMESPACE");
       defaultSet = prop.getProperty("AEROSPIKE_SETNAME");
       logger.info("defaultNS  :"+defaultNS);
       logger.info("defaultSet :"+defaultSet);
       logger.info("setName :"+setName);
       logger.info("key     :"+key);
      return new Key(defaultNS, StringUtils.defaultIfBlank(setName, defaultSet), key);
   }

   public boolean put(String key, Object obj) {
      return put(defaultSet, key, obj);
   }

   public boolean put(String setName, String key, Object obj) {
      return put(setName, key, defaultColumn, obj);
   }

   public boolean put(String setName, String key, String binKey, Object obj) {
      return put(policy.writePolicyDefault, setName, key, binKey, obj);
   }

   public boolean put(int expiry, String key, Object obj) {
      return put(expiry, defaultSet, key, defaultColumn, obj);
   }

   public boolean put(int expiry, String setName, String key, String binKey, Object obj) {
      return put(getWritePolicy(expiry), setName, key, binKey, obj);
   }

   public boolean put(WritePolicy writePolicy, String setName, String key, String binKey, Object obj) {
      try {
         if (getClient() != null) {
        	loadConfig();
        	
        	defaultSet = prop.getProperty("AEROSPIKE_SETNAME");
            logger.info("defaultSet :"+defaultSet);
        	        	
        	logger.info("setName:"+setName);
        	logger.info("key :"+key);
        	logger.info("binKey:"+binKey);
        	logger.info("writePolicy:"+writePolicy);
        	        	
            binKey = StringUtils.defaultIfBlank(binKey, defaultColumn);
            setName = StringUtils.defaultIfBlank(setName, defaultSet);
            getClient().put(writePolicy, getKey(setName, key), new Bin("a_key", key), new Bin(binKey, obj));
            logger.info(setName + "->" + key + "->" + binKey + " added");
            return true;
         }
      } catch (Exception e) {
    	  e.printStackTrace();
         logger.info("could not add " + setName + "->" + key + "->" + binKey + ". " + e.getMessage());
         logger.error("", e);
      }
      return false;
   }

   public boolean putBins(String key, Map<String, Object> map) {
      return put(defaultSet, key, map);
   }

   public boolean putBins(String setName, String key, Map<String, Object> map) {
      return putBins(null, setName, key, map);
   }

   public boolean putBins(WritePolicy writePolicy, String setName, String key, Map<String, Object> map) {
      if (map != null && getClient() != null) {
         Bin[] bins = new Bin[map.size()];
         int index = 0;
         for (Map.Entry<String, Object> entry : map.entrySet())
            bins[index++] = new Bin(entry.getKey(), entry.getValue());
         getClient().put(writePolicy, getKey(setName, key), bins);
         logger.info("Added:" + setName + "->" + key + "->" + map);
         return true;
      }
      return false;
   }

   public Object get(String key) {
      return get(key, defaultColumn);
   }

   public Object get(String key, String binKey) {
      return get(defaultSet, key, binKey);
   }

   public Object get(String setName, String key, String binKey) {
      if (StringUtils.isBlank(setName))
         return get(key, binKey);
      try {
         logger.debug("getting " + setName + "->" + key + "->" + binKey);
         if (setName != null && getClient() != null) {
            Record record = getClient().get(null, getKey(setName, key), binKey);
            logger.debug("value received " + setName + "->" + key + "->" + binKey + "->" + record);
            return record != null ? record.getValue(binKey) : null;
         }
      } catch (Exception e) {
    	  e.printStackTrace();
         logger.info("could not get " + setName + "->" + key + "->" + binKey + ". " + e.getMessage());
      }
      return null;
   }

   public Map<String, Object> get(String key, List<String> bins) {
      return get(defaultSet, key, bins);
   }

   public Map<String, Object> get(String setName, String key, List<String> bins) {
      String[] binNames = new String[bins.size()];
      binNames = bins.toArray(binNames);
      logger.debug("getting " + setName + "->" + key + "->" + bins);
      if (getClient() != null && setName != null) {
         Record record = getClient().get(null, getKey(setName, key), binNames);
         if (record != null) {
            Map<String, Object> map = new HashMap<String, Object>(binNames.length);
            for (int i = 0; i < binNames.length; i++)
               map.put(binNames[i], record.getValue(binNames[i]));
            logger.debug("Got :" + setName + "->" + key + "->" + map);
            return map;
         }
      }
      return new HashMap<String, Object>(0);
   }

   public boolean remove(String key) {
      return remove(defaultSet, key);
   }

   public boolean remove(String setName, String key) {
      try {
         if (getClient() != null) {
            logger.debug("deleting " + setName + "->" + key);
            return getClient().delete(null, getKey(setName, key));
         }
      } catch (AerospikeException e) {
    	  e.printStackTrace();
         logger.info("could not delete " + setName + "->" + key + ". " + e.getMessage());
      }
      return false;
   }

   public <T> boolean save(String setName, String key, T entity) {
      return save(-1, setName, key, entity);
   }

   public <T> boolean save(int expiry, String setName, String key, T entity) {
      Map<String, Object> map = gson.fromJson(gson.toJson(entity), Map.class);
      return putBins(getWritePolicy(expiry), setName, key, map);
   }



   public <T> T load(String setName, String key, Class<T> typeClass)
   {
      Map<String, Object> result = get(setName, key, CommonJWTUtil.getDeclcaredFieldNames(typeClass));
      if (result == null || result.isEmpty())
         return null;
      return gson.fromJson(gson.toJson(result), typeClass);
   }

   public Map<String, Map<String, Object>> bulkRead(String set, String[] bins, Key[] keys, BatchPolicy batchPolicy)
         throws Exception {
      Map<String, Map<String, Object>> mobileRecordDetail = new HashMap<>();
      logger.info("Before getting records: size : " + keys.length);
      long reqMillis = System.currentTimeMillis();
      Record[] records = getClient().get(batchPolicy, keys, bins);
      logger.info("After getting records" + " ,Time Taken : " + (System.currentTimeMillis() - reqMillis));
      Map<String, Object> recordDetail = null;
      String mobileNum = null;
      if (null != records && records.length > 0) {
         for (int i = 0; i < records.length; i++) {
            Record record = records[i];
            if (record != null) {
               recordDetail = new HashMap<>();
               for (String bin : bins) {
                  if ("MOBILENO".equalsIgnoreCase(bin))
                     mobileNum = (String) record.getValue(bin);
                  recordDetail.put(bin, record.getValue(bin));
               }
            }
            mobileRecordDetail.put(mobileNum, recordDetail);
         }
         logger.info("After inserting in List");
      }
      return mobileRecordDetail;
   }

   // Written by HCL
   public Object getOutletDetails(String setName, String key, String binKey) {
      if (StringUtils.isBlank(setName))
         return get(key, binKey);
      try {
         logger.debug("getting " + setName + "->" + key + "->" + binKey);
         if (setName != null && getClient() != null)
         {
            Record record = getClient().get(null, getKey(setName, key), binKey);
            logger.debug("value received " + setName + "->" + key + "->" + binKey + "->" + record);
            return record != null ? record.getValue(binKey) : null;
         }
      } catch (Exception e) {
         e.printStackTrace();
         logger.info("could not get " + setName + "->" + key + "->" + binKey + ". " + e.getMessage());
      }
      return null;
   }

   // Written by HCL
   public <T> boolean saveOutletDetails(int expiry, String setName, String key, T entity)
   {
      Map<String, Object> map = gson.fromJson(gson.toJson(entity), Map.class);
      return putBins(getWritePolicy(expiry), setName, key, map);
   }

   // Written by HCL
   public boolean putOutletDetails(String setName, String key, String binKey, Object obj) {
      return put(policy.writePolicyDefault, setName, key, binKey, obj);
   }
}
