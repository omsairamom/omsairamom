package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.myteam.repository.PromoterCheckInDetailsAuditRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PromoterCheckInDetailsAuditDAO
{
    @Autowired
    PromoterCheckInDetailsAuditRepository promoterCheckInDetailsAuditRepository;

    public PromoterCheckInDetailsAuditEntity saveAndFlushCheckInDetails(PromoterCheckInDetailsAuditEntity promoterCheckInDetailsAuditEntity)
    {
        return promoterCheckInDetailsAuditRepository.saveAndFlush(promoterCheckInDetailsAuditEntity);
    }
}
