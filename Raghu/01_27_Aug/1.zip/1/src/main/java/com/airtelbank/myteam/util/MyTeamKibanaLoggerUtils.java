package com.airtelbank.myteam.util;

import com.airtelbank.bean.KibanaLoggerBean;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.myteam.common.CommonException;
import com.airtelbank.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jul 01, 2019 02:34:45 PM
 */
@Service
public class MyTeamKibanaLoggerUtils {

	public static Logger kibanaLogger = LoggerFactory.getLogger("kibanaLogger");
	private static Logger logger = LoggerFactory.getLogger(MyTeamKibanaLoggerUtils.class);

	@Autowired
	PropertyManager prop;
	
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();
	
	@SuppressWarnings("unchecked")
	public void saveMyteamOutletKibanaLoggers(SnapWorkRequest request, SnapWorkResponse response, long totalTime, String apiName) {

		try {
			logger.info("Inside saveMyteamOutletKibanaLoggers() method in KibanaLoggerUtils class.....");
			
			JSONParser parser = new JSONParser();
			JSONObject jsonReqObj = (JSONObject) parser.parse(gson.toJson(request));
			
			JSONObject jsonResObj = (JSONObject) parser.parse(gson.toJson(response));
			JSONObject jsonInnerResObj = (JSONObject) jsonResObj.get("response");
			if(jsonInnerResObj.has("images")) {
				JSONArray imageJsonArr = (JSONArray) jsonInnerResObj.get("images");
				 for(int i=0;i<imageJsonArr.length();i++)
		            {
		               JSONObject jsonImageObj = (JSONObject) imageJsonArr.get(i);
		                String encPdf = (String) jsonImageObj.get("encPdf");
						encPdf = encPdf.replace(encPdf, "******");
		                jsonImageObj.put("encPdf",encPdf);
		            }			
			}
		
			SimpleDateFormat dtf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			Date date = cal.getTime();
			String currentDate = dtf.format(date);
			KibanaLoggerBean obj = new KibanaLoggerBean();
			obj.setServiceid(apiName == null ? "" : apiName);
			obj.setApiId("");
			obj.setCustMobileNo(request.getMobileNo());
			obj.setContentId("");
			obj.setTranId("");
			obj.setAmount("");
			obj.setId1("Promoter App");
			//obj.setId2("");
			obj.setId3("");
			obj.setId4("");
			obj.setId5("");
			obj.setId6("");
			obj.setId7("");
			obj.setId8("");
			obj.setId9("");
			obj.setId10("");
			obj.setNumber1("");
			obj.setNumber2("");
			obj.setNumber3("");
			obj.setDate1(currentDate);
			obj.setDate2("");
			obj.setRequest(jsonReqObj);
			obj.setResponse(jsonResObj.toString());

//			if(response.getStatusCode().equals("200")) {
//				obj.setStatus("0");
//			}else {
//				obj.setStatus("1");
//			}
//
//			obj.setErrorCode(response.getStatusCode());
//			obj.setErrorMsg(response.getMessage());

			obj.setTotalTime(totalTime);

			printKibanaLogs(obj);
			logger.info("Admin Kibana logs generated Successful..");
		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		}
	}

	public void printKibanaLogs(KibanaLoggerBean obj) {
//		String message = "";
//
//		try {
//			message = obj.getServiceid() + "~#~" + obj.getApiId() + "~#~" + obj.getCustMobileNo() + "~#~"
//					+ obj.getContentId() + "~#~" + obj.getTranId() + "~#~" + obj.getAmount() + "~#~" + obj.getId1()
//					+ "~#~" + obj.getId2() + "~#~" + obj.getId3() + "~#~" + obj.getId4() + "~#~" + obj.getId5() + "~#~"
//					+ obj.getId6() + "~#~" + obj.getId7() + "~#~" + obj.getId8() + "~#~" + obj.getId9() + "~#~"
//					+ obj.getId10() + "~#~" + obj.getNumber1() + "~#~" + obj.getNumber2() + "~#~" + obj.getNumber3()
//					+ "~#~" + obj.getDate1() + "~#~" + obj.getDate2() + "~#~" + obj.getRequest() + "~#~"
//					+ obj.getResponse() + "~#~" + obj.getStatus() + "~#~" + obj.getErrorCode() + "~#~"
//					+ obj.getErrorMsg() + "~#~" + obj.getTotalTime();
//
//			kibanaLogger.info(message);
//
//		} catch (Exception exe) {
//			CommonException.getPrintStackTrace(exe);
//		}
	}

}
