package com.airtelbank.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum UserStatus {

    A(1, "Active", "A"),
    D(0, "Deactivated", "D");

    int id;
    String desc;
    String code;

    private UserStatus(int id, String desc, String code){
        this.id=id;
        this.desc = desc;
        this.code =code;
    }

    private static final Map<String,UserStatus> lookup = new HashMap<>();


    static {
        for(UserStatus s : EnumSet.allOf(UserStatus.class))
            lookup.put(s.getCode(), s);
    }

    public static UserStatus get(String code) {
        return lookup.get(code);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
