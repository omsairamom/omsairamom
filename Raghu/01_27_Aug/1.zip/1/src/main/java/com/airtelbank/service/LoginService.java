package com.airtelbank.service;

import com.airtelbank.bean.AttendanceBean;
import com.airtelbank.util.CustomException;
import org.springframework.web.multipart.MultipartFile;
import com.airtelbank.common.SnapWorkRequest;
import com.airtelbank.common.SnapWorkResponse;

public interface LoginService
{
    SnapWorkResponse loginWithPasswordCheck(SnapWorkRequest request) throws CustomException;

    SnapWorkResponse fetchUserProfile_V2(SnapWorkRequest request) throws Exception;

    SnapWorkResponse setPasswordDetailsV2(SnapWorkRequest request);

    SnapWorkResponse sendOTP(String mobileNo, SnapWorkRequest request) throws CustomException;

    SnapWorkResponse verifyOTP(String mobileNo, String otpVerificationCode, String otp, SnapWorkRequest request) throws CustomException;

    SnapWorkResponse logOutAttendance(SnapWorkRequest request) throws CustomException;

    SnapWorkResponse isUserExist(String mobileNo, SnapWorkRequest request) throws CustomException;

    SnapWorkResponse profileUploadDetails(String mobileNo, MultipartFile file) throws CustomException;

    SnapWorkResponse attendanceUploadDetails(String mobileNo, MultipartFile file, AttendanceBean obj, String encStatus) throws CustomException;

    SnapWorkResponse attendanceViewDetails(String deviceID, String mobileNo, SnapWorkRequest request, String lat, String lng) throws CustomException;

    SnapWorkResponse isRefreshToKen(SnapWorkRequest request) throws Exception;
}