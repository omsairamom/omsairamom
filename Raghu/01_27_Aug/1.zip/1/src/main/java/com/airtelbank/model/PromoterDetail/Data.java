
package com.airtelbank.model.PromoterDetail;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Data
{
    @SerializedName("msisdn")
    @Expose
    private String msisdn;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("dob")
    @Expose
    private String dob;

    @SerializedName("aadharRefNo")
    @Expose
    private String aadharRefNo;

    @SerializedName("aadharName")
    @Expose
    private AadharName aadharName;

    @SerializedName("status")
    @Expose
    private String status;

    @SerializedName("user_type")
    @Expose
    private String userType;

    @SerializedName("category")
    @Expose
    private String category;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getAadharRefNo() {
        return aadharRefNo;
    }

    public void setAadharRefNo(String aadharRefNo) {
        this.aadharRefNo = aadharRefNo;
    }

    public AadharName getAadharName() {
        return aadharName;
    }

    public void setAadharName(AadharName aadharName) {
        this.aadharName = aadharName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

}
