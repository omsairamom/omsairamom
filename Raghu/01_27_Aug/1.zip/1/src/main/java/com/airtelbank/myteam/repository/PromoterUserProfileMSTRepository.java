package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.enums.UserProfileStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;
import java.util.Optional;

@Repository
@Transactional
public interface PromoterUserProfileMSTRepository
        extends JpaRepository<PromoterUserProfileMSTEntity, Long>
{
    Optional<PromoterUserProfileMSTEntity> findOneByUserNo(String mobileNumber);

    @Query(value = "SELECT * FROM PROMOTER_USER_PROFILE_MST where USER_NO = :mobileNumber and STATUS = :status", nativeQuery=true)
    Optional<PromoterUserProfileMSTEntity> findOneByUserNoWithStatus(@Param("mobileNumber") String mobileNumber, @Param("status") String status);


    Optional<PromoterUserProfileMSTEntity> findOneByUserNoAndChannel(String mobileNumber, String channel);

    Optional<PromoterUserProfileMSTEntity> findOneByUserNoAndStatus(String mobileNumber, String status);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE PROMOTER_USER_PROFILE_MST p SET p.password = :password WHERE p.user_No = :userNo", nativeQuery=true)
    public int updatePassword(@Param("password") String password, @Param("userNo") String userNo);
}