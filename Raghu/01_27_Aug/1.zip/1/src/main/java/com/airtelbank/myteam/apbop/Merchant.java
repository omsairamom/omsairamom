package com.airtelbank.myteam.apbop;

import com.airtelbank.model.Merchant.GetProfileMsisdn;
import com.airtelbank.myteam.util.HttpUtil;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class Merchant implements UserType
{
    @Autowired
    HttpUtil httpUtil;

    @Autowired
    PropertyManager prop;

    @Override
    public UserShopLatitudeLongitudeModel userTypeDetails(String flg_cust_typ, String msisdn)
    {
        String shopLatitude = null;
        String shopLongitude = null;

        UserShopLatitudeLongitudeModel userShopLatitudeLongitudeModel = new UserShopLatitudeLongitudeModel();

        // Hit API from RestTemplate
        String url = prop.getProperty(Constants.MERCHANT_SHOP_API_URL_KEY);

        Map<String, String> headers = new HashMap<>();
        headers.put("flg_cust_typ", flg_cust_typ);
        headers.put("msisdn", msisdn);

        GetProfileMsisdn mer_profile_model = httpUtil.hitRequest(url, null, GetProfileMsisdn.class, headers, HttpMethod.GET);

        if (mer_profile_model != null)
        {
            if (mer_profile_model.getMeta().getDescription().equalsIgnoreCase("SUCCESS"))
            {
                if (mer_profile_model.getData().getProfile().get(0).getShopLat() != null &&
                        mer_profile_model.getData().getProfile().get(0).getShopLang() != null)
                {
                    shopLatitude = mer_profile_model.getData().getProfile().get(0).getShopLat().toString();
                    shopLongitude = mer_profile_model.getData().getProfile().get(0).getShopLang().toString();
                }
                else
                {
                    // When API response is null for Lat Lng values then By Default Lat Lng value are below
                    shopLatitude = null;
                    shopLongitude = null;
                }
            }
            else
            {
                // When API response is null for Lat Lng values then By Default Lat Lng value are below
                shopLatitude = null;
                shopLongitude = null;
            }
        }
        else
        {
            shopLatitude = null;
            shopLongitude = null;
        }

        userShopLatitudeLongitudeModel.setShopLatitude(shopLatitude);
        userShopLatitudeLongitudeModel.setShopLongitude(shopLongitude);

        return userShopLatitudeLongitudeModel;
    }
}