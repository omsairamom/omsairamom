package com.airtelbank.myteam.dao;

import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.PromoterUserMSTRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class PromoterUserMSTDAO
{
    @Autowired
    PromoterUserMSTRepository promoterUserMSTRepository;

    public Optional<PromoterUserMSTEntity> fetchUserByPhoneNumber(String outletPhoneNumber) {
        return promoterUserMSTRepository.findOneByUserNo(outletPhoneNumber);
    }

    public Optional<PromoterUserMSTEntity> fetchUserByPhoneNumberWithStatus(String outletPhoneNumber) {
        return promoterUserMSTRepository.findOneByUserNoWithStatus(outletPhoneNumber, "A");
    }

    public Optional<PromoterUserMSTEntity> fetchUserByIDWithStatus(Long id) {
        return promoterUserMSTRepository.findOneByIdWithStatus(id, "A");
    }
}