package com.airtelbank.myteam.service.impl;

import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.entity.PromoterUserKYCMSTEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.model.PromoterDetail.AadharName;
import com.airtelbank.model.PromoterDetail.Data;
import com.airtelbank.model.PromoterDetail.Meta;
import com.airtelbank.model.PromoterDetail.PromoterDetail;
import com.airtelbank.myteam.common.CommonException;
import com.airtelbank.myteam.dao.PromoterUserKYCMSTDAO;
import com.airtelbank.myteam.dao.PromoterUserMSTDAO;
import com.airtelbank.myteam.service.PromoterDetailService;
import com.airtelbank.util.CommonUtils;
import com.airtelbank.util.PropertyManager;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Transactional
@Service
public class PromoterDetailServiceImpl implements PromoterDetailService
{
    private static final Logger logger = LoggerFactory.getLogger(PromoterDetailServiceImpl.class);

    @Autowired
    CommonUtils commonUtil;

    @Autowired
    PropertyManager prop;

    JSONObject json = new JSONObject();

    JSONParser parser = new JSONParser();

    @Autowired
    PromoterUserMSTDAO promoterUserMSTDAO;

    @Autowired
    PromoterUserKYCMSTDAO promoterUserKYCMSTDAO;

    long startTime = 0;
    long endTime = 0;
    long elapsedTimeMillis = 0;

    @Override
    public JSONObject getPromoterDetail(String msisdn, Optional<String> status)
    {
        SnapWorkResponse response = new SnapWorkResponse();

            try
            {
                startTime = System.currentTimeMillis();
                logger.info("GetPromoterDetails, Request start timeInMillis {}:", startTime);
                logger.info("Inside getPromoterDetail() method in PromoterDetailServiceImpl class {}:", "");

                if (StringUtils.isNotBlank(msisdn))
                {
                    Optional<PromoterUserMSTEntity> promoterUserMSTEntity =
                            promoterUserMSTDAO.fetchUserByPhoneNumber(msisdn);

                    PromoterDetail promoterDetail = new PromoterDetail();

                    if (promoterUserMSTEntity.isPresent())
                    {
                        String currStatus =  promoterUserMSTEntity.get().getStatus();

                        if (status.isPresent())
                        {
                            if (status.get().equalsIgnoreCase("A"))
                            {
                                if (currStatus.equals(status.get()))
                                {
                                    promoterDetail = showValidUser(promoterUserMSTEntity, promoterDetail);
                                }
                                else
                                {
                                    promoterDetail = showInvalidUser(msisdn, promoterDetail);
                                    json = (JSONObject) parser.parse(new Gson().toJson(promoterDetail));
                                }
                            }
                            else if (status.get().equalsIgnoreCase("D"))
                            {
                                if (currStatus.equals(status.get()))
                                {
                                    promoterDetail = showValidUser(promoterUserMSTEntity, promoterDetail);
                                }
                                else
                                {
                                    promoterDetail = showInvalidUser(msisdn, promoterDetail);
                                    json = (JSONObject) parser.parse(new Gson().toJson(promoterDetail));
                                }
                            }
                            else
                            {
                                promoterDetail = showInvalidUser(msisdn, promoterDetail);
                                json = (JSONObject) parser.parse(new Gson().toJson(promoterDetail));
                            }
                        }
                        else
                        {
                            promoterDetail = showValidUser(promoterUserMSTEntity, promoterDetail);
                        }

                        json = (JSONObject) parser.parse(new Gson().toJson(promoterDetail));
                        logger.info("Success Response generated for getPromoterDetail(): {}:", msisdn);
                    }
                    else
                    {
                        promoterDetail = showInvalidUser(msisdn, promoterDetail);

                        json = (JSONObject) parser.parse(new Gson().toJson(promoterDetail));

                        logger.error("checkInDetails() trackerJsonArr is empty: {} :", "");
                        logger.info("Fail Response generated for proMobileNo: {}:", msisdn);
                    }
                }
                else
                {
                    logger.error("getPromoterDetail() msisdn is empty: {} :", "");
                }

                logger.info("getPromoterDetail(), response");
                endTime = System.currentTimeMillis();
                logger.info("getPromoterDetail(), Request end timeInMillis {}:", endTime);
                elapsedTimeMillis = (endTime - startTime);
                commonUtil.convertMillis(elapsedTimeMillis);
                logger.info("********************************************************** {}:", "");
            }
            catch (Exception exe)
            {
                commonUtil.exceptionHandler(prop, exe, response, json);
                logger.error("getPromoterDetail() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
                CommonException.getPrintStackTrace(exe);

                return json;
            }

        logger.info("getPromoterDetail() Response generated:  {} for msisdn No: {}" , "", msisdn);
        return json;
    }

    /**
     * This method create an object of Invalid User
     * @param msisdn MobileNumber
     * @param promoterDetail Promoter Detail
     * @return promoterDetails
     */
    private PromoterDetail showInvalidUser(String msisdn, PromoterDetail promoterDetail)
    {
        Meta meta = new Meta();
        Data data = new Data();

        meta.setCode("000");
        meta.setStatus(500);
        meta.setDescription("Invalid User");

        data.setMsisdn(msisdn);

        promoterDetail.setMeta(meta);
        promoterDetail.setData(data);

        return promoterDetail;
    }

    /**
     * This method create an object of valid User
     * @param promoterUserMSTEntity User
     * @param promoterDetail UserDetail
     * @return Return Valid User
     */
    private PromoterDetail showValidUser(Optional<PromoterUserMSTEntity> promoterUserMSTEntity, PromoterDetail promoterDetail)
    {
        Meta meta = new Meta();
        Data data = new Data();
        AadharName aadharName = new AadharName();

        if (promoterUserMSTEntity.isPresent())
        {
            Optional<PromoterUserKYCMSTEntity> promoterUserKYCMSTEntity =
                    promoterUserKYCMSTDAO.fetchPromoterUserKYCMST(promoterUserMSTEntity.get());

            if(promoterUserKYCMSTEntity.isPresent())
            {
                logger.info("promoterDetails()  AdharRefNumber{}:" , promoterUserKYCMSTEntity.get().getAadhaarRefNumber());
                logger.info("promoterDetails()  First Name{}:" , promoterUserKYCMSTEntity.get().getKuaFirstName());
                logger.info("promoterDetails()  Middle Name{}:" , promoterUserKYCMSTEntity.get().getKuaMiddleName());
                logger.info("promoterDetails()  Last Name{}:" , promoterUserKYCMSTEntity.get().getKuaLastName());

                data.setAadharRefNo(promoterUserKYCMSTEntity.get().getAadhaarRefNumber());
                aadharName.setPromoterFirstName(promoterUserKYCMSTEntity.get().getKuaFirstName());
                aadharName.setPromoterMName(promoterUserKYCMSTEntity.get().getKuaMiddleName());
                aadharName.setPromoterLastName(promoterUserKYCMSTEntity.get().getKuaLastName());
                data.setAadharName(aadharName);
            }
            else
            {
                String NA = "Not Available";
                logger.info("promoterDetails()  AdharRefNumber{}:" , NA);
                logger.info("promoterDetails()  First Name{}:" , NA);
                logger.info("promoterDetails()  Middle Name{}:" , NA);
                logger.info("promoterDetails()  Last Name{}:" , NA);

                data.setAadharRefNo("Not Available");
                aadharName.setPromoterFirstName("Not Available");
                aadharName.setPromoterMName("Not Available");
                aadharName.setPromoterLastName("Not Available");
                data.setAadharName(aadharName);
            }

            meta.setCode("000");
            meta.setStatus(200);
            meta.setDescription("Success");

            data.setMsisdn(promoterUserMSTEntity.get().getUserNo());
            data.setName(promoterUserMSTEntity.get().getUsername());

            if (promoterUserMSTEntity.get().getDob() != null)
            {
                data.setDob(promoterUserMSTEntity.get().getDob().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")));
            }
            else
            {
                data.setDob("Not Available");
            }

            data.setStatus(promoterUserMSTEntity.get().getStatus());
            data.setUserType(promoterUserMSTEntity.get().getUserType());
            data.setCategory(promoterUserMSTEntity.get().getCategory());

            promoterDetail.setMeta(meta);
            promoterDetail.setData(data);
        }

        return promoterDetail;
    }
}
