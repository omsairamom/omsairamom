package com.airtelbank.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum UserProfileStatus {

    A(1, "Active", "A"),
    D(0, "Deactivated", "D"),
    L(-1, "Locked", "L");

    int id;
    String desc;
    String code;

    private UserProfileStatus(int id, String desc, String code){
        this.id=id;
        this.desc = desc;
        this.code =code;
    }

    private static final Map<String,UserProfileStatus> lookup = new HashMap<>();


    static {
        for(UserProfileStatus s : EnumSet.allOf(UserProfileStatus.class))
            lookup.put(s.getCode(), s);
    }

    public static UserProfileStatus get(String code) {
        return lookup.get(code);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
