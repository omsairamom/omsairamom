package com.airtelbank.myteam.dao.helper;

import com.airtelbank.common.SnapWorkResponse;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.myteam.repository.*;
import com.airtelbank.util.Constants;
import com.airtelbank.util.PropertyManager;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class PromoterKPIDAOHelper
{
    @Autowired
    PropertyManager prop;

    @Autowired
    private PromoterUserMSTRepository promoterUserMSTRepository;

    @Autowired
    private PromoterKPIProfileMSTRepository promoterKPIProfileMSTRepository;

    @Autowired
    private PromoterKPICategoryMSTRepository promoterKPICategoryMSTRepository;

    @Autowired
    private PromoterKPIDetailsMSTRepository promoterKPIDetailsMSTRepository;

    @Autowired
    private PromoterKPIMeasuresRepository promoterKPIMeasuresRepository;

    public SnapWorkResponse fetchKPIDetailsRevamp (String mobileNumber)
    {
        SnapWorkResponse response = new SnapWorkResponse();

        JSONArray jsonArray = new JSONArray();
        JSONObject json = new JSONObject();

        List<PromoterUserMSTEntity> promoterUserMSTEntities = promoterUserMSTRepository.findAllByUserNo(mobileNumber);
        if (!promoterUserMSTEntities.isEmpty()){
            promoterUserMSTEntities.stream().forEach(promoterUserMSTEntity -> {
                String catName = promoterUserMSTEntity.getCategory();
                String promoterType = promoterUserMSTEntity.getCategory();
                promoterKPICategoryMSTRepository.findAllByCatName(catName).stream().forEach(promoterKPICategoryMSTEntity -> {
                    Long catId = promoterKPICategoryMSTEntity.getCatId();
                    List<String> types = new ArrayList<>();
                    types.add(promoterType);

                    if (!promoterType.equals("Combined"))
                    {
                        types.add("Combined");
                    }
                    else
                    {
                        types.add("RET");
                        types.add("MER");
                    }
                    promoterKPIDetailsMSTRepository
                            .findAllByCatIdAndStatusEnableAndPromoterTypeIn(catId, "Y", types)
                            .stream().forEach(promoterKPIDetailsMSTEntity -> {
                        String kpiId = String.valueOf(promoterKPIDetailsMSTEntity.getKpiId());
                        String kpiType = promoterKPIDetailsMSTEntity.getKpiType();
                        JSONObject jsonObj = new JSONObject();
                        jsonObj.put("KPIID", kpiId);
                        jsonObj.put("KPITYPE", kpiType);
                        promoterKPIMeasuresRepository
                                .findAllByKpiId(promoterKPIDetailsMSTEntity.getKpiId()).stream().forEach(promoterKPIMeasuresEntity -> {
                            String TARGET = String.valueOf(promoterKPIMeasuresEntity.getTarget());
                            jsonObj.put("TARGET", TARGET);
                        });
                        promoterKPIProfileMSTRepository
                                .findAllByLapuNoAndCatNameAndKpiName(mobileNumber, catName, kpiType).stream().forEach(promoterKPIProfileMSTEntity -> {
                            String lmtd = promoterKPIProfileMSTEntity.getLMTD();
                            String mtd = promoterKPIProfileMSTEntity.getMTD();
                            String achievedPercentage = promoterKPIProfileMSTEntity.getAchievedPercentage();
                            jsonObj.put("LMTD", lmtd);
                            jsonObj.put("MTD", mtd);
                            jsonObj.put("ACHIEVED_PERCENTAGE", achievedPercentage);
                        });
                        jsonArray.add(jsonObj);
                    });
                });
            });

            json.put("data", jsonArray);
            response.setMessage(prop.getProperty(Constants.ADMIN_FETCH_KPI_DETAIL_SUCCESS));
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        }
        else
        {
            response.setMessage(prop.getProperty(Constants.ADMIN_FETCH_KPI_DETAIL_FAIL));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
        }
        response.setResponse(json);

        return response;
    }
}
