
package com.airtelbank.model.Merchant;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Profile {

    @SerializedName("nsdlPanName")
    @Expose
    private Object nsdlPanName;
    @SerializedName("onbDetails")
    @Expose
    private Object onbDetails;
    @SerializedName("riskScore")
    @Expose
    private Object riskScore;
    @SerializedName("upiQr")
    @Expose
    private Object upiQr;
    @SerializedName("upiQrLinkDate")
    @Expose
    private Object upiQrLinkDate;
    @SerializedName("npciAgentId")
    @Expose
    private Object npciAgentId;
    @SerializedName("bbpsConsent")
    @Expose
    private Object bbpsConsent;
    @SerializedName("exMerSettFlag")
    @Expose
    private Object exMerSettFlag;
    @SerializedName("shopLat")
    @Expose
    private Object shopLat;
    @SerializedName("shopLang")
    @Expose
    private Object shopLang;
    @SerializedName("isRekycDone")
    @Expose
    private Object isRekycDone;
    @SerializedName("clickedOnRekyc")
    @Expose
    private Object clickedOnRekyc;
    @SerializedName("rekycReason")
    @Expose
    private Object rekycReason;
    @SerializedName("medium")
    @Expose
    private Object medium;
    @SerializedName("commSentCount")
    @Expose
    private Integer commSentCount;
    @SerializedName("updatedDate")
    @Expose
    private Object updatedDate;
    @SerializedName("createdDate")
    @Expose
    private Object createdDate;
    @SerializedName("qrString")
    @Expose
    private Object qrString;
    @SerializedName("txtPermAdrZip")
    @Expose
    private String txtPermAdrZip;
    @SerializedName("activeDateTime")
    @Expose
    private Object activeDateTime;
    @SerializedName("cusField15")
    @Expose
    private String cusField15;
    @SerializedName("altMobNo1")
    @Expose
    private Object altMobNo1;
    @SerializedName("cod_cust_id")
    @Expose
    private String codCustId;
    @SerializedName("codCustNatlId")
    @Expose
    private String codCustNatlId;
    @SerializedName("flg_cust_typ")
    @Expose
    private String flgCustTyp;
    @SerializedName("nam_cust_full")
    @Expose
    private String namCustFull;
    @SerializedName("ref_cust_email")
    @Expose
    private String refCustEmail;
    @SerializedName("refCustItNum")
    @Expose
    private Object refCustItNum;
    @SerializedName("txtCustAdrAdd1")
    @Expose
    private String txtCustAdrAdd1;
    @SerializedName("txtCustAdrAdd2")
    @Expose
    private String txtCustAdrAdd2;
    @SerializedName("txtCustAdrAdd3")
    @Expose
    private String txtCustAdrAdd3;
    @SerializedName("nam_cust_cntry")
    @Expose
    private String namCustCntry;
    @SerializedName("nam_cust_state")
    @Expose
    private String namCustState;
    @SerializedName("nam_cust_city")
    @Expose
    private String namCustCity;
    @SerializedName("dat_cust_open")
    @Expose
    private String datCustOpen;
    @SerializedName("txt_cust_zip")
    @Expose
    private String txtCustZip;
    @SerializedName("circle")
    @Expose
    private Object circle;
    @SerializedName("parent_id")
    @Expose
    private Integer parentId;
    @SerializedName("parent_type")
    @Expose
    private Object parentType;
    @SerializedName("cod_category")
    @Expose
    private Integer codCategory;
    @SerializedName("cod_cc_brn")
    @Expose
    private String codCcBrn;
    @SerializedName("cod_acct_no")
    @Expose
    private String codAcctNo;
    @SerializedName("txt_category")
    @Expose
    private String txtCategory;
    @SerializedName("gst_number")
    @Expose
    private Object gstNumber;
    @SerializedName("shop_name")
    @Expose
    private String shopName;
    @SerializedName("prmnt_district")
    @Expose
    private String prmntDistrict;
    @SerializedName("tan_number")
    @Expose
    private Object tanNumber;
    @SerializedName("cod_acct_stat")
    @Expose
    private String codAcctStat;
    @SerializedName("aadhaar_no")
    @Expose
    private String aadhaarNo;
    @SerializedName("dat_birth_cust")
    @Expose
    private String datBirthCust;
    @SerializedName("bal_eod")
    @Expose
    private Object balEod;
    @SerializedName("cod_prod")
    @Expose
    private String codProd;
    @SerializedName("poi_type")
    @Expose
    private Object poiType;
    @SerializedName("poi_number")
    @Expose
    private Object poiNumber;
    @SerializedName("poa_type")
    @Expose
    private Object poaType;
    @SerializedName("poa_number")
    @Expose
    private Object poaNumber;
    @SerializedName("sett_acc_name")
    @Expose
    private Object settAccName;
    @SerializedName("sett_acc_type")
    @Expose
    private Object settAccType;
    @SerializedName("sett_acc_no")
    @Expose
    private Object settAccNo;
    @SerializedName("sett_ifsc")
    @Expose
    private Object settIfsc;
    @SerializedName("branch_addr")
    @Expose
    private Object branchAddr;
    @SerializedName("agentId")
    @Expose
    private Object agentId;
    @SerializedName("merTradeVal5")
    @Expose
    private Object merTradeVal5;
    @SerializedName("merTradeVal6")
    @Expose
    private Object merTradeVal6;
    @SerializedName("settings")
    @Expose
    private Settings settings;

    public Object getNsdlPanName() {
        return nsdlPanName;
    }

    public void setNsdlPanName(Object nsdlPanName) {
        this.nsdlPanName = nsdlPanName;
    }

    public Object getOnbDetails() {
        return onbDetails;
    }

    public void setOnbDetails(Object onbDetails) {
        this.onbDetails = onbDetails;
    }

    public Object getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(Object riskScore) {
        this.riskScore = riskScore;
    }

    public Object getUpiQr() {
        return upiQr;
    }

    public void setUpiQr(Object upiQr) {
        this.upiQr = upiQr;
    }

    public Object getUpiQrLinkDate() {
        return upiQrLinkDate;
    }

    public void setUpiQrLinkDate(Object upiQrLinkDate) {
        this.upiQrLinkDate = upiQrLinkDate;
    }

    public Object getNpciAgentId() {
        return npciAgentId;
    }

    public void setNpciAgentId(Object npciAgentId) {
        this.npciAgentId = npciAgentId;
    }

    public Object getBbpsConsent() {
        return bbpsConsent;
    }

    public void setBbpsConsent(Object bbpsConsent) {
        this.bbpsConsent = bbpsConsent;
    }

    public Object getExMerSettFlag() {
        return exMerSettFlag;
    }

    public void setExMerSettFlag(Object exMerSettFlag) {
        this.exMerSettFlag = exMerSettFlag;
    }

    public Object getShopLat() {
        return shopLat;
    }

    public void setShopLat(Object shopLat) {
        this.shopLat = shopLat;
    }

    public Object getShopLang() {
        return shopLang;
    }

    public void setShopLang(Object shopLang) {
        this.shopLang = shopLang;
    }

    public Object getIsRekycDone() {
        return isRekycDone;
    }

    public void setIsRekycDone(Object isRekycDone) {
        this.isRekycDone = isRekycDone;
    }

    public Object getClickedOnRekyc() {
        return clickedOnRekyc;
    }

    public void setClickedOnRekyc(Object clickedOnRekyc) {
        this.clickedOnRekyc = clickedOnRekyc;
    }

    public Object getRekycReason() {
        return rekycReason;
    }

    public void setRekycReason(Object rekycReason) {
        this.rekycReason = rekycReason;
    }

    public Object getMedium() {
        return medium;
    }

    public void setMedium(Object medium) {
        this.medium = medium;
    }

    public Integer getCommSentCount() {
        return commSentCount;
    }

    public void setCommSentCount(Integer commSentCount) {
        this.commSentCount = commSentCount;
    }

    public Object getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Object updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Object getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Object createdDate) {
        this.createdDate = createdDate;
    }

    public Object getQrString() {
        return qrString;
    }

    public void setQrString(Object qrString) {
        this.qrString = qrString;
    }

    public String getTxtPermAdrZip() {
        return txtPermAdrZip;
    }

    public void setTxtPermAdrZip(String txtPermAdrZip) {
        this.txtPermAdrZip = txtPermAdrZip;
    }

    public Object getActiveDateTime() {
        return activeDateTime;
    }

    public void setActiveDateTime(Object activeDateTime) {
        this.activeDateTime = activeDateTime;
    }

    public String getCusField15() {
        return cusField15;
    }

    public void setCusField15(String cusField15) {
        this.cusField15 = cusField15;
    }

    public Object getAltMobNo1() {
        return altMobNo1;
    }

    public void setAltMobNo1(Object altMobNo1) {
        this.altMobNo1 = altMobNo1;
    }

    public String getCodCustId() {
        return codCustId;
    }

    public void setCodCustId(String codCustId) {
        this.codCustId = codCustId;
    }

    public String getCodCustNatlId() {
        return codCustNatlId;
    }

    public void setCodCustNatlId(String codCustNatlId) {
        this.codCustNatlId = codCustNatlId;
    }

    public String getFlgCustTyp() {
        return flgCustTyp;
    }

    public void setFlgCustTyp(String flgCustTyp) {
        this.flgCustTyp = flgCustTyp;
    }

    public String getNamCustFull() {
        return namCustFull;
    }

    public void setNamCustFull(String namCustFull) {
        this.namCustFull = namCustFull;
    }

    public String getRefCustEmail() {
        return refCustEmail;
    }

    public void setRefCustEmail(String refCustEmail) {
        this.refCustEmail = refCustEmail;
    }

    public Object getRefCustItNum() {
        return refCustItNum;
    }

    public void setRefCustItNum(Object refCustItNum) {
        this.refCustItNum = refCustItNum;
    }

    public String getTxtCustAdrAdd1() {
        return txtCustAdrAdd1;
    }

    public void setTxtCustAdrAdd1(String txtCustAdrAdd1) {
        this.txtCustAdrAdd1 = txtCustAdrAdd1;
    }

    public String getTxtCustAdrAdd2() {
        return txtCustAdrAdd2;
    }

    public void setTxtCustAdrAdd2(String txtCustAdrAdd2) {
        this.txtCustAdrAdd2 = txtCustAdrAdd2;
    }

    public String getTxtCustAdrAdd3() {
        return txtCustAdrAdd3;
    }

    public void setTxtCustAdrAdd3(String txtCustAdrAdd3) {
        this.txtCustAdrAdd3 = txtCustAdrAdd3;
    }

    public String getNamCustCntry() {
        return namCustCntry;
    }

    public void setNamCustCntry(String namCustCntry) {
        this.namCustCntry = namCustCntry;
    }

    public String getNamCustState() {
        return namCustState;
    }

    public void setNamCustState(String namCustState) {
        this.namCustState = namCustState;
    }

    public String getNamCustCity() {
        return namCustCity;
    }

    public void setNamCustCity(String namCustCity) {
        this.namCustCity = namCustCity;
    }

    public String getDatCustOpen() {
        return datCustOpen;
    }

    public void setDatCustOpen(String datCustOpen) {
        this.datCustOpen = datCustOpen;
    }

    public String getTxtCustZip() {
        return txtCustZip;
    }

    public void setTxtCustZip(String txtCustZip) {
        this.txtCustZip = txtCustZip;
    }

    public Object getCircle() {
        return circle;
    }

    public void setCircle(Object circle) {
        this.circle = circle;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Object getParentType() {
        return parentType;
    }

    public void setParentType(Object parentType) {
        this.parentType = parentType;
    }

    public Integer getCodCategory() {
        return codCategory;
    }

    public void setCodCategory(Integer codCategory) {
        this.codCategory = codCategory;
    }

    public String getCodCcBrn() {
        return codCcBrn;
    }

    public void setCodCcBrn(String codCcBrn) {
        this.codCcBrn = codCcBrn;
    }

    public String getCodAcctNo() {
        return codAcctNo;
    }

    public void setCodAcctNo(String codAcctNo) {
        this.codAcctNo = codAcctNo;
    }

    public String getTxtCategory() {
        return txtCategory;
    }

    public void setTxtCategory(String txtCategory) {
        this.txtCategory = txtCategory;
    }

    public Object getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(Object gstNumber) {
        this.gstNumber = gstNumber;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getPrmntDistrict() {
        return prmntDistrict;
    }

    public void setPrmntDistrict(String prmntDistrict) {
        this.prmntDistrict = prmntDistrict;
    }

    public Object getTanNumber() {
        return tanNumber;
    }

    public void setTanNumber(Object tanNumber) {
        this.tanNumber = tanNumber;
    }

    public String getCodAcctStat() {
        return codAcctStat;
    }

    public void setCodAcctStat(String codAcctStat) {
        this.codAcctStat = codAcctStat;
    }

    public String getAadhaarNo() {
        return aadhaarNo;
    }

    public void setAadhaarNo(String aadhaarNo) {
        this.aadhaarNo = aadhaarNo;
    }

    public String getDatBirthCust() {
        return datBirthCust;
    }

    public void setDatBirthCust(String datBirthCust) {
        this.datBirthCust = datBirthCust;
    }

    public Object getBalEod() {
        return balEod;
    }

    public void setBalEod(Object balEod) {
        this.balEod = balEod;
    }

    public String getCodProd() {
        return codProd;
    }

    public void setCodProd(String codProd) {
        this.codProd = codProd;
    }

    public Object getPoiType() {
        return poiType;
    }

    public void setPoiType(Object poiType) {
        this.poiType = poiType;
    }

    public Object getPoiNumber() {
        return poiNumber;
    }

    public void setPoiNumber(Object poiNumber) {
        this.poiNumber = poiNumber;
    }

    public Object getPoaType() {
        return poaType;
    }

    public void setPoaType(Object poaType) {
        this.poaType = poaType;
    }

    public Object getPoaNumber() {
        return poaNumber;
    }

    public void setPoaNumber(Object poaNumber) {
        this.poaNumber = poaNumber;
    }

    public Object getSettAccName() {
        return settAccName;
    }

    public void setSettAccName(Object settAccName) {
        this.settAccName = settAccName;
    }

    public Object getSettAccType() {
        return settAccType;
    }

    public void setSettAccType(Object settAccType) {
        this.settAccType = settAccType;
    }

    public Object getSettAccNo() {
        return settAccNo;
    }

    public void setSettAccNo(Object settAccNo) {
        this.settAccNo = settAccNo;
    }

    public Object getSettIfsc() {
        return settIfsc;
    }

    public void setSettIfsc(Object settIfsc) {
        this.settIfsc = settIfsc;
    }

    public Object getBranchAddr() {
        return branchAddr;
    }

    public void setBranchAddr(Object branchAddr) {
        this.branchAddr = branchAddr;
    }

    public Object getAgentId() {
        return agentId;
    }

    public void setAgentId(Object agentId) {
        this.agentId = agentId;
    }

    public Object getMerTradeVal5() {
        return merTradeVal5;
    }

    public void setMerTradeVal5(Object merTradeVal5) {
        this.merTradeVal5 = merTradeVal5;
    }

    public Object getMerTradeVal6() {
        return merTradeVal6;
    }

    public void setMerTradeVal6(Object merTradeVal6) {
        this.merTradeVal6 = merTradeVal6;
    }

    public Settings getSettings() {
        return settings;
    }

    public void setSettings(Settings settings) {
        this.settings = settings;
    }

}
