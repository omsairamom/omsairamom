package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterKPICategoryMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromoterKPICategoryMSTRepository extends JpaRepository<PromoterKPICategoryMSTEntity, Long> {

    List<PromoterKPICategoryMSTEntity> findAllByCatId(Long catId);
    List<PromoterKPICategoryMSTEntity> findAllByCatName(String catName);

}
