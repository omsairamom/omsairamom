package com.airtelbank.myteam.repository;

import com.airtelbank.entity.PromoterAttendanceAuditEntity;
import com.airtelbank.entity.PromoterCheckInDetailsAuditEntity;
import com.airtelbank.entity.PromoterUserMSTEntity;
import com.airtelbank.entity.PromoterUserProfileMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface PromoterAttendanceAuditRepository extends JpaRepository<PromoterAttendanceAuditEntity, Long>
{

    Optional<PromoterAttendanceAuditEntity> findByPromoterUserMSTEntity(PromoterUserMSTEntity promoterUserMSTEntity);

    Optional<Long> countByPromoterUserMSTEntityAndCreatedDate(PromoterUserMSTEntity promoterUserMSTEntity, LocalDateTime createdDat);

    @Query(value = "SELECT * FROM PROMOTER_ATTENDANCE_AUDIT where PROMOTER_ID = :promoterId and CREATED_DATE between TO_DATE(:startDate, 'DD-MM-YYYY') and TO_DATE(:endDate, 'DD-MM-YYYY')", nativeQuery=true)
    List<PromoterAttendanceAuditEntity> findAttendanceByDateRange(@Param("promoterId") Long promoterId,
                                                                  @Param("startDate") String startDate,
                                                                  @Param("endDate") String endDate);
}