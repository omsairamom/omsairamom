package com.airtelbank.util;

import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.model.GeocodingResult;
import com.google.maps.model.LatLng;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.net.Proxy;

public class ReverseGeoCoderUtil
{
    private static Logger logger = LoggerFactory.getLogger(ReverseGeoCoderUtil.class);
    static String name = "";

    /**
     * Reverse Geocoding and returns formated Address .
     * eg:getFormatedAdress(40.714224, -73.961452);
     *
     * @param latitude     latitude value
     * @param longitude    longitude value
     * @param googleApiKey
     * @return formated Address
     * @throws Exception if a reverse geocoding error occurred
     */
    public static String getFormatedAdress(double latitude, double longitude, String googleApiKey) throws Exception
    {
        GeoApiContext context = new GeoApiContext.Builder()
                .proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.56.108.156", 4145)))
                .proxyAuthentication("", "*")
                .apiKey(googleApiKey).build();

        try
        {
            GeocodingResult[] results = GeocodingApi.reverseGeocode(context, new LatLng(latitude, longitude)).await();

            for (GeocodingResult result : results)
            {
                return result.formattedAddress;
            }
        }
        catch (Exception e)
        {
            logger.error("Exception occured in ReverseGeoCoderUtil.getFormatedAdress() For Latitude {}, Longitude {}:", latitude, longitude);
            e.printStackTrace();
            return "Not Available";
        }

        return name;
    }
}
