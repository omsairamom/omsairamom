package in.nareshit.raghu.service;

public interface AlertSystem {

	public void sendMessage();
}
