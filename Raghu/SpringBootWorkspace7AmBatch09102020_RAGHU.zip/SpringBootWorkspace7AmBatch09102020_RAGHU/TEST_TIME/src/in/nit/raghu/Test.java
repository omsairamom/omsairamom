package in.nit.raghu;

import java.util.concurrent.TimeUnit;

public class Test {

	public static void main(String[] args) {
		// TimeUnit.FROM.toMethod(value);
		//Days->Hrs
		System.out.println(TimeUnit.DAYS.toHours(3));
		//Days->Mins
		System.out.println(TimeUnit.DAYS.toMinutes(3));
		//Days->Sec
		System.out.println(TimeUnit.DAYS.toSeconds(3));
		
		System.out.println(TimeUnit.HOURS.toMinutes(2));
		//Hrs->Days
		System.out.println(TimeUnit.HOURS.toDays(48));
		
		System.out.println(TimeUnit.MINUTES.toNanos(4));
		//Sec->Mins
		System.out.println(TimeUnit.SECONDS.toMinutes(120));
		
		System.out.println(TimeUnit.SECONDS.toMillis(1));
		System.out.println(TimeUnit.SECONDS.toMicros(1));
		System.out.println(TimeUnit.SECONDS.toNanos(1));
	}
}
