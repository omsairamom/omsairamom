package in.nareshit.raghu.model;

import lombok.Data;

@Data
public class Vendor {

	private String vcode;
	private String addr;
}
