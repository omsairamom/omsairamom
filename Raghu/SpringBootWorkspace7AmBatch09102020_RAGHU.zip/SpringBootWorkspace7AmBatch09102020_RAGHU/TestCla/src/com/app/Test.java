package com.app;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		System.out.println(args[0]);
		System.out.println(Arrays.asList(args));
		System.out.println("done");
	}
}
