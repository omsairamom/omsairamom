package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.payments.model.TransactionStatusDetails;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.InitiatePaymentResponse;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionDetailsRequest;
import com.airtelbank.thirdpartypayments.model.order.OrderDetails;
import com.airtelbank.thirdpartypayments.service.PaymentInitializationService;
import com.airtelbank.thirdpartypayments.service.PostPaymentProcessingService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class InternalPaymentsControllerTest {
    @InjectMocks
    InternalPaymentsController internalPaymentsController;
    @Mock
    PaymentInitializationService paymentInitializationService;

    @Mock
    LoggerModel loggerModel;
    @Mock
    BindingResult result;
    @Mock
    private PostPaymentProcessingService postPaymentProcessingService;

    @Test
    public void executePayment() throws ThirdPartyPaymentsException {

        InitiatePaymentResponse reversePaymentResponse = new InitiatePaymentResponse();
        reversePaymentResponse.setCircleID("test");
        reversePaymentResponse.setEnquiryURL("test");
        reversePaymentResponse.setLobID("test");
        reversePaymentResponse.setMessageText("test");
        reversePaymentResponse.setRemarks("test");
        OrderDetails orderDetails = new OrderDetails();
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setKey("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        customEntries.add(customEntry);
        orderDetails.setDetails(customEntries);
        orderDetails.setMerchantTxnId("test");
        reversePaymentResponse.setOrderDetails(orderDetails);
        reversePaymentResponse.setPurposeCode("test");
        reversePaymentResponse.setPurposeIconUrl("test");
        reversePaymentResponse.setPurposeRefNo("test");
        reversePaymentResponse.setStatus("test");
        reversePaymentResponse.setTotalAmount(BigDecimal.ONE);
        reversePaymentResponse.setTransType("test");
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setAmount(BigDecimal.ONE);
        paymentRequest.setHash("test");
        Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
        stringBigDecimalMap.put("1", BigDecimal.ONE);
        paymentRequest.setAmountDetails(stringBigDecimalMap);
        TransactionDetailsRequest request = new TransactionDetailsRequest();
        request.setDetails(customEntries);
        request.setMerchantTxnId("test");
        paymentRequest.setTransactionDetailsRequest(request);
        paymentRequest.setMerchantId("test");

        when(result.hasErrors()).thenReturn(false);
        when(paymentInitializationService.paymentInitialize(Mockito.any(), Mockito.any())).thenReturn(reversePaymentResponse);
        ResponseEntity<RestApiResponse> restApiResponseResponseEntity = internalPaymentsController.executePayment(paymentRequest, "test", "tets", result);
        assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());
    }

    @Test
    public void executePaymentException() {
        try {
            InitiatePaymentResponse reversePaymentResponse = new InitiatePaymentResponse();
            reversePaymentResponse.setCircleID("test");
            reversePaymentResponse.setEnquiryURL("test");
            reversePaymentResponse.setLobID("test");
            reversePaymentResponse.setMessageText("test");
            reversePaymentResponse.setRemarks("test");
            OrderDetails orderDetails = new OrderDetails();
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            orderDetails.setDetails(customEntries);
            orderDetails.setMerchantTxnId("test");
            reversePaymentResponse.setOrderDetails(orderDetails);
            reversePaymentResponse.setPurposeCode("test");
            reversePaymentResponse.setPurposeIconUrl("test");
            reversePaymentResponse.setPurposeRefNo("test");
            reversePaymentResponse.setStatus("test");
            reversePaymentResponse.setTotalAmount(BigDecimal.ONE);
            reversePaymentResponse.setTransType("test");
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.ONE);
            paymentRequest.setHash("test");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");

            when(result.hasErrors()).thenReturn(false);
            when(paymentInitializationService.paymentInitialize(Mockito.any(), Mockito.any())).thenReturn(reversePaymentResponse);
            ResponseEntity<RestApiResponse> restApiResponseResponseEntity = internalPaymentsController.executePayment(paymentRequest, "test", "tets", result);
            assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void simulateKafka() throws ThirdPartyPaymentsException {


        com.airtelbank.payments.model.PaymentDetails paymentDetails = new com.airtelbank.payments.model.PaymentDetails();
        paymentDetails.setAddParam1("test");
        paymentDetails.setAddParam2("test");
        paymentDetails.setPurposeRefNo("test");
        paymentDetails.setTotalAmount(BigDecimal.ONE);
        paymentDetails.setCustomerNumber("test");
        paymentDetails.setNarration("test");
        Map<String, String> map = new HashMap<>();
        map.put("test", "test");
        paymentDetails.setParamaters(map);
        paymentDetails.setPrId("test");
        paymentDetails.setPuporseCode("test");
        paymentDetails.setRefPrid("test");
        TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
        transactionStatusDetails.setAmount("test");
        transactionStatusDetails.setStatus("test");
        transactionStatusDetails.setErrorCode("test");
        transactionStatusDetails.setPurposeRefNo("test");
        transactionStatusDetails.setTransactionDateTime(new Date());
        transactionStatusDetails.setAccessToken("test");
        transactionStatusDetails.setFtTxnId("test");
        transactionStatusDetails.setDescription("test");
        transactionStatusDetails.setPaymentMode("test");
        transactionStatusDetails.setPgTxnId("test");
        List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
        transactionStatusDetails1.add(transactionStatusDetails);
        paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
        paymentDetails.setTxnMessage("test");
        paymentDetails.setType("test");

        Mockito.doNothing().when(postPaymentProcessingService).processPayment(Mockito.any());
        ResponseEntity<RestApiResponse> restApiResponseResponseEntity = internalPaymentsController.simulateKafka(paymentDetails, "test");
        assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());

    }

    @Test
    public void simulateKafkaException() throws ThirdPartyPaymentsException {

        try {
            com.airtelbank.payments.model.PaymentDetails paymentDetails = new com.airtelbank.payments.model.PaymentDetails();
            paymentDetails.setAddParam1("test");
            paymentDetails.setAddParam2("test");
            paymentDetails.setPurposeRefNo("test");
            paymentDetails.setTotalAmount(BigDecimal.ONE);
            paymentDetails.setCustomerNumber("test");
            paymentDetails.setNarration("test");
            Map<String, String> map = new HashMap<>();
            map.put("test", "test");
            paymentDetails.setParamaters(map);
            paymentDetails.setPrId("test");
            paymentDetails.setPuporseCode("test");
            paymentDetails.setRefPrid("test");
            TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
            transactionStatusDetails.setAmount("test");
            transactionStatusDetails.setStatus("test");
            transactionStatusDetails.setErrorCode("test");
            transactionStatusDetails.setPurposeRefNo("test");
            transactionStatusDetails.setTransactionDateTime(new Date());
            transactionStatusDetails.setAccessToken("test");
            transactionStatusDetails.setFtTxnId("test");
            transactionStatusDetails.setDescription("test");
            transactionStatusDetails.setPaymentMode("test");
            transactionStatusDetails.setPgTxnId("test");
            List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
            transactionStatusDetails1.add(transactionStatusDetails);
            paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
            paymentDetails.setTxnMessage("test");
            paymentDetails.setType("test");

            Mockito.lenient().doNothing().when(postPaymentProcessingService).processPayment(null);
            ResponseEntity<RestApiResponse> restApiResponseResponseEntity = internalPaymentsController.simulateKafka(paymentDetails, "test");
            assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());
        } catch (Exception e) {
            assertNotNull(e);
        }
    }
}