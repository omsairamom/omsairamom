package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.OrderKeyValueTemplate;
import com.airtelbank.thirdpartypayments.model.OrderKeyValueTemplateAction;
import com.airtelbank.thirdpartypayments.model.OrderResponse;
import com.airtelbank.thirdpartypayments.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class OrderDetailsControllersTest {

    @InjectMocks
    OrderDetailsControllers orderDetailsControllers;
    @Mock
    OrderService orderService;

    @Mock
    ObjectMapper mapper;

    @Mock
    LoggerModel loggerModel;

    @Test
    public void getOrderDetail() throws ThirdPartyPaymentsException {
        OrderResponse orderResponse = new OrderResponse();
        List<OrderKeyValueTemplateAction> list = new ArrayList<>();
        OrderKeyValueTemplateAction orderKeyValueTemplateAction = new OrderKeyValueTemplateAction();
        orderKeyValueTemplateAction.setValue("test");
        orderKeyValueTemplateAction.setDisplayText("test");
        orderKeyValueTemplateAction.setField("test");
        list.add(orderKeyValueTemplateAction);
        List<OrderKeyValueTemplate> list1 = new ArrayList<>();
        OrderKeyValueTemplate orderKeyValueTemplate = new OrderKeyValueTemplate();
        orderKeyValueTemplate.setValue("test");
        orderKeyValueTemplate.setField("test");
        list.add(orderKeyValueTemplateAction);
        orderResponse.setAction(list);
        orderResponse.setContent(list1);
        orderResponse.setBenefit("test");
        orderResponse.setDescription("test");
        orderResponse.setPurpose(Object.class);
        orderResponse.setTitle("test");
        orderResponse.setTxnStatus(1);
        Mockito.when(orderService.getOrderDetail(Mockito.any())).thenReturn(orderResponse);
        ResponseEntity<RestApiResponse> response = orderDetailsControllers.getOrderDetail("test", "test", "test", "test", "test");
        Assert.assertEquals(0, Objects.requireNonNull(response.getBody()).getMeta().getStatus());
    }
}