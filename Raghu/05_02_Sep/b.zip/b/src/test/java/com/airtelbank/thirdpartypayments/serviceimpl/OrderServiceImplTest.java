package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomActions;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.OrderResponse;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.model.order.OrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsTxnRepo;
import com.airtelbank.thirdpartypayments.service.TransactionRefundService;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationService;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationServiceFactory;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class OrderServiceImplTest {

    @InjectMocks
    OrderServiceImpl orderService;
    @Mock
    private OrderConfirmationServiceFactory orderConfirmationServiceFactory;

    @Mock
    OrderConfirmationService orderConfirmationService;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    private TransactionRefundService refundService;

    @Mock
    private OrderDetailsTxnRepo orderDetailsTxnRepo;

    @Mock
    private MerchantTransactionDetailsRepo merchantRepo;

    @Test
    public void confirmOrder() throws ThirdPartyPaymentsException {
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        DefaultOrderConfirmationResponce defaultOrderConfirmationResponce = new DefaultOrderConfirmationResponce();
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setKey("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        customEntries.add(customEntry);
        CustomActions customActions = new CustomActions();
        customActions.setDisplayText("test");
        customActions.setKey("test");
        customActions.setValue("test");
        List<CustomActions> list = new ArrayList<>();
        list.add(customActions);
        OrderConfirmationResponce orderConfirmationResponce = OrderConfirmationResponce.builder().details(customEntries).actions(list).merchantTxnId("test").build();
        defaultOrderConfirmationResponce.setData(orderConfirmationResponce);
        Meta meta = new Meta();
        meta.setStatus(0);
        meta.setDescription("test");
        meta.setCode("test");
        defaultOrderConfirmationResponce.setMeta(meta);
        Mockito.when(orderConfirmationServiceFactory.getOrderConfirmationService(Mockito.any())).thenReturn(orderConfirmationService);
        Mockito.when(orderConfirmationService.doConfirm(Mockito.any(), Mockito.any())).thenReturn(defaultOrderConfirmationResponce);
        boolean response = orderService.confirmOrder(order, entity);
        assertTrue(response);
    }

    @Test
    public void confirmOrderStatusFailwithPendingCodes() throws ThirdPartyPaymentsException {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        orderDetailsTxn.setOrderDetailsEntity(orderDetailsEntity);
        orderDetailsEntity.setOrderDetailsTxn(orderDetailsTxnLIST);
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").pendingCodes("test").build();
        DefaultOrderConfirmationResponce defaultOrderConfirmationResponce = new DefaultOrderConfirmationResponce();
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setKey("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        CustomActions customActions = new CustomActions();
        customActions.setDisplayText("test");
        customActions.setKey("test");
        customActions.setValue("test");
        List<CustomActions> list = new ArrayList<>();
        OrderConfirmationResponce orderConfirmationResponce = OrderConfirmationResponce.builder().details(customEntries).actions(list).merchantTxnId("test").build();
        defaultOrderConfirmationResponce.setData(orderConfirmationResponce);
        Meta meta = new Meta();
        meta.setStatus(1);
        meta.setDescription("test");
        meta.setCode("test");
        defaultOrderConfirmationResponce.setMeta(meta);
        Mockito.when(orderConfirmationServiceFactory.getOrderConfirmationService(Mockito.any())).thenReturn(orderConfirmationService);
        Mockito.when(orderConfirmationService.doConfirm(Mockito.any(), Mockito.any())).thenReturn(defaultOrderConfirmationResponce);
        boolean response = orderService.confirmOrder(order, entity);
        assertTrue(response);
    }

    @Test
    public void confirmOrderStatusFailwithoutPendingCodes() throws ThirdPartyPaymentsException {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        orderDetailsTxn.setOrderDetailsEntity(orderDetailsEntity);
        orderDetailsEntity.setOrderDetailsTxn(orderDetailsTxnLIST);
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        DefaultOrderConfirmationResponce defaultOrderConfirmationResponce = new DefaultOrderConfirmationResponce();
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setKey("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        CustomActions customActions = new CustomActions();
        customActions.setDisplayText("test");
        customActions.setKey("test");
        customActions.setValue("test");
        List<CustomActions> list = new ArrayList<>();
        OrderConfirmationResponce orderConfirmationResponce = OrderConfirmationResponce.builder().details(customEntries).actions(list).merchantTxnId("test").build();
        defaultOrderConfirmationResponce.setData(orderConfirmationResponce);
        Meta meta = new Meta();
        meta.setStatus(1);
        meta.setDescription("test");
        meta.setCode("test");
        defaultOrderConfirmationResponce.setMeta(meta);
        Mockito.when(orderConfirmationServiceFactory.getOrderConfirmationService(Mockito.any())).thenReturn(orderConfirmationService);
        Mockito.when(orderConfirmationService.doConfirm(Mockito.any(), Mockito.any())).thenReturn(defaultOrderConfirmationResponce);
        boolean response = orderService.confirmOrder(order, entity);
        assertTrue(response);
    }

    @Test
    public void updateOrder() {
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        OrderDetailsEntity updateOrder = orderService.updateOrder(order);
        assertNotNull(updateOrder);
    }

    @Test
    public void getOrderDetail() throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        Mockito.when(orderDetailsTxnRepo.findbyMerchantTxnId(Mockito.any())).thenReturn(orderDetailsTxnLIST);
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        Mockito.when(merchantRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
        OrderResponse orderResponse = orderService.getOrderDetail("test");
        assertNotNull(orderResponse);
    }

    @Test
    public void getOrderDetailwithgetorderdetailsandpaymentrelationship() throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("DETAILS");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        orderDetailsTxn.setPaymentRelationship("POST_PAYMENT");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        Mockito.when(orderDetailsTxnRepo.findbyMerchantTxnId(Mockito.any())).thenReturn(orderDetailsTxnLIST);
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        Mockito.when(merchantRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
        OrderResponse orderResponse = orderService.getOrderDetail("test");
        assertNotNull(orderResponse);
    }

    @Test
    public void getOrderDetailwithorderstatusconfirmationfailed() throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("DETAILS");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        orderDetailsTxn.setPaymentRelationship("POST_PAYMENT");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.CONFIRMATION_FAILED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        Mockito.when(orderDetailsTxnRepo.findbyMerchantTxnId(Mockito.any())).thenReturn(orderDetailsTxnLIST);
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        Mockito.when(merchantRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
        OrderResponse orderResponse = orderService.getOrderDetail("test");
        assertNotNull(orderResponse);
    }

    @Test
    public void getOrderDetailwithorderstatusconfirmationpending() throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("DETAILS");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        orderDetailsTxn.setPaymentRelationship("POST_PAYMENT");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.CONFIRMATION_PENDING);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        Mockito.when(orderDetailsTxnRepo.findbyMerchantTxnId(Mockito.any())).thenReturn(orderDetailsTxnLIST);
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        Mockito.when(merchantRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
        OrderResponse orderResponse = orderService.getOrderDetail("test");
        assertNotNull(orderResponse);
    }

    @Test
    public void getOrderDetailwithorderstatusOTHER() throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("DETAILS");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        orderDetailsTxn.setPaymentRelationship("POST_PAYMENT");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.REFUNDED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        Mockito.when(orderDetailsTxnRepo.findbyMerchantTxnId(Mockito.any())).thenReturn(orderDetailsTxnLIST);
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        Mockito.when(merchantRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
        OrderResponse orderResponse = orderService.getOrderDetail("test");
        assertNotNull(orderResponse);
    }
}