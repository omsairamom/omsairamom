package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryRequest;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponse;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class TransactionEnquiryServiceImplTest {

    @InjectMocks
    TransactionEnquiryServiceImpl transactionEnquiryService;

    @Mock
    OrderDetailsRepo orderDetailsRepo;

    @Mock
    RefundDetailsRepo refundDetailsRepo;

    @Mock
    HttpUtil httpUtil;

    @Mock
    private ValidationService validationService;

    @Mock
    private Environment environment;

    @Test
    public void enquiryInitException() {
        try {
            TransactionEnquiryRequest request = new TransactionEnquiryRequest();
            request.setAmount(BigDecimal.ONE);
            request.setType("test");
            request.setMerchantTxnId("test");
            request.setFeSessionId("test");
            request.setRefundTxnId("test");
            TransactionEnquiryResponse transactionEnquiryResponse = transactionEnquiryService.enquiryInit(request, "test");
            assertNotNull(transactionEnquiryResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void enquiryInit() throws ThirdPartyPaymentsException {

        TransactionEnquiryRequest request = new TransactionEnquiryRequest();
        request.setAmount(BigDecimal.ONE);
        request.setType("FORWARD");
        request.setMerchantTxnId("test");
        request.setFeSessionId("test");
        request.setRefundTxnId("test");
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        Mockito.when(orderDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(order);
        TransactionEnquiryResponse transactionEnquiryResponse = transactionEnquiryService.enquiryInit(request, "test");
        assertNotNull(transactionEnquiryResponse);

    }

    @Test
    public void enquiryInitwhereTransactiontyperefundException() {
        try {
            TransactionEnquiryRequest request = new TransactionEnquiryRequest();
            request.setAmount(BigDecimal.ONE);
            request.setType("REFUND");
            request.setMerchantTxnId("test");
            request.setFeSessionId("test");
            request.setRefundTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            Mockito.when(orderDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(order);
            TransactionEnquiryResponse transactionEnquiryResponse = transactionEnquiryService.enquiryInit(request, "test");
            assertNotNull(transactionEnquiryResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }

    }

    @Test
    public void enquiryInitwhereTransactiontyperefund() throws ThirdPartyPaymentsException {

        TransactionEnquiryRequest request = new TransactionEnquiryRequest();
        request.setAmount(BigDecimal.ONE);
        request.setType("REFUND");
        request.setMerchantTxnId("test");
        request.setFeSessionId("test");
        request.setRefundTxnId("test");
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
        redBusPaymentRefundEntity.setFeSessionId("123");
        redBusPaymentRefundEntity.setMerchantId("456");
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String strDate = dateFormat.format(date);
        redBusPaymentRefundEntity.setTxnDate(strDate);
        redBusPaymentRefundEntity.setMerchantId("0909");
        redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
        redBusPaymentRefundEntity.setPurposeRefNo("345");
        redBusPaymentRefundEntity.setPrId("787");
        redBusPaymentRefundEntity.setRefundTxnId("test");
        redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
        List<TransactionRefundEntity> transactionRefundEntities = new ArrayList<>();
        transactionRefundEntities.add(redBusPaymentRefundEntity);
        Mockito.when(refundDetailsRepo.findByRefundTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
        Mockito.when(orderDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(order);
        TransactionEnquiryResponse transactionEnquiryResponse = transactionEnquiryService.enquiryInit(request, "test");
        assertNotNull(transactionEnquiryResponse);
    }


    @Test
    public void enquiryInitwhereRefundTransactionidisnull() throws ThirdPartyPaymentsException {

        TransactionEnquiryRequest request = new TransactionEnquiryRequest();
        request.setAmount(BigDecimal.ONE);
        request.setType("REFUND");
        request.setMerchantTxnId("test");
        request.setFeSessionId("test");
        request.setRefundTxnId(null);
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
        redBusPaymentRefundEntity.setFeSessionId("123");
        redBusPaymentRefundEntity.setMerchantId("456");
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String strDate = dateFormat.format(date);
        redBusPaymentRefundEntity.setTxnDate(strDate);
        redBusPaymentRefundEntity.setMerchantId("0909");
        redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
        redBusPaymentRefundEntity.setPurposeRefNo("345");
        redBusPaymentRefundEntity.setPrId("787");
        redBusPaymentRefundEntity.setRefundTxnId("test");
        redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
        List<TransactionRefundEntity> transactionRefundEntities = new ArrayList<>();
        transactionRefundEntities.add(redBusPaymentRefundEntity);
        Mockito.when(refundDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
        Mockito.lenient().when(refundDetailsRepo.findByRefundTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
        Mockito.when(orderDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(order);
        TransactionEnquiryResponse transactionEnquiryResponse = transactionEnquiryService.enquiryInit(request, "test");
        assertNotNull(transactionEnquiryResponse);
    }


}


