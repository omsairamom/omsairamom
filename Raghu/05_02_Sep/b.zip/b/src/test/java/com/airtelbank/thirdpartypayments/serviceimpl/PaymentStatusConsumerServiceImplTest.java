package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.hub.client.dto.kafka.PaymentStatus;
import com.airtelbank.payments.hub.client.model.OrderItemStatus;
import com.airtelbank.payments.hub.client.model.OrderStatus;
import com.airtelbank.payments.hub.client.model.TransactionDetails;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class PaymentStatusConsumerServiceImplTest {

    @InjectMocks
    private PaymentStatusConsumerServiceImpl paymentStatusConsumerServiceImpl;

    @Mock
    private RedBusPaymentRefundServiceImpl redBusPaymentRefundServiceImpl;


    @Mock
    private RefundDetailsRepo refundDetailsRepo;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    private RedBusPaymentServiceImpl redBusPaymentService;


    @Before
    public void setUp() {

        log.info("Loading RedBusPaymentServiceImplTest......");

        ReflectionTestUtils.setField(paymentStatusConsumerServiceImpl, "expiredTime", 390);
    }

    @Test
    public void txnStatusTestwithSuccess() {

        log.info("Entering into txnStatusTest() method....");
        List<TransactionDetails> debitDetails = new ArrayList<>();
        TransactionDetails transactionDetails = TransactionDetails.builder().transactionId("123")
                .amount("1").status("SUCCESS").build();
        debitDetails.add(transactionDetails);
        OrderStatus orderStatus = new OrderStatus();
        OrderItemStatus orderItemStatus = new OrderItemStatus();
        orderItemStatus.setAmount("1000");
        orderItemStatus.setOrderItemId("test");
        orderItemStatus.setItemLogoUrl("test");
        orderItemStatus.setCreditDetails(transactionDetails);
        List<OrderItemStatus> orderItemStatuses = new ArrayList<>();
        orderItemStatuses.add(orderItemStatus);
        orderStatus.setOrderItems(orderItemStatuses);
        PaymentStatus paymentStatus = PaymentStatus.builder().paymentReqId("123")
                .orderId("0909").useCase("abc").debitDetails(debitDetails).orderDetails(orderStatus).build();
        OrderDetailsEntity orderDetailsEntity = CommonTestObjectUtil.getOrderDetailsSuccess();
        Mockito.when(orderDetailsRepo.findByPrID(Mockito.anyString())).thenReturn(orderDetailsEntity);
        Mockito.when(orderDetailsRepo.save(Mockito.any())).thenReturn(orderDetailsEntity);
        Mockito.when(redBusPaymentService.updatePaymentStatus(Mockito.any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        paymentStatusConsumerServiceImpl.txnStatus(paymentStatus);
        Assert.assertNotNull(paymentStatusConsumerServiceImpl);
    }

    @Test
    public void txnStatusTestWithFailed() {

        log.info("Entering into txnStatusTest() method....");
        List<TransactionDetails> debitDetails = new ArrayList<>();
        TransactionDetails transactionDetails = TransactionDetails.builder().transactionId("123")
                .amount("1").status("FAILED").build();
        debitDetails.add(transactionDetails);
        OrderStatus orderStatus = new OrderStatus();
        OrderItemStatus orderItemStatus = new OrderItemStatus();
        orderItemStatus.setAmount("1000");
        orderItemStatus.setOrderItemId("test");
        orderItemStatus.setItemLogoUrl("test");
        orderItemStatus.setCreditDetails(transactionDetails);
        List<OrderItemStatus> orderItemStatuses = new ArrayList<>();
        orderItemStatuses.add(orderItemStatus);
        orderStatus.setOrderItems(orderItemStatuses);
        PaymentStatus paymentStatus = PaymentStatus.builder().paymentReqId("123")
                .orderId("0909").useCase("abc").debitDetails(debitDetails).orderDetails(orderStatus).build();
        OrderDetailsEntity orderDetailsEntity = CommonTestObjectUtil.getOrderDetailsFailed();
        Mockito.when(orderDetailsRepo.findByPrID(Mockito.anyString())).thenReturn(orderDetailsEntity);

        Mockito.when(orderDetailsRepo.save(Mockito.any())).thenReturn(orderDetailsEntity);
        Mockito.when(redBusPaymentService.updatePaymentStatus(Mockito.any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        paymentStatusConsumerServiceImpl.txnStatus(paymentStatus);
        Assert.assertNotNull(paymentStatusConsumerServiceImpl);
    }

    @Test
    public void refundStatusTest() {

        log.info("Entering into refundStatusTest() method....");

        TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
        Mockito.lenient().when(refundDetailsRepo.findByPrId(Mockito.anyString())).thenReturn(transactionRefundEntity);
        Mockito.lenient().when(refundDetailsRepo.save(Mockito.any())).thenReturn(transactionRefundEntity);
        Mockito.lenient().when(redBusPaymentRefundServiceImpl.updateRefundStatus(Mockito.any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        paymentStatusConsumerServiceImpl.refundStatus(CommonTestObjectUtil.getRefundRequests());
        Assert.assertNotNull(paymentStatusConsumerServiceImpl);
    }

    @Test
    public void refundStatussuccess() {

        log.info("Entering into refundStatusTest() method....");

        TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
        Mockito.lenient().when(refundDetailsRepo.findByPrId(Mockito.anyString())).thenReturn(transactionRefundEntity);
        Mockito.lenient().when(refundDetailsRepo.save(Mockito.any())).thenReturn(transactionRefundEntity);
        Mockito.lenient().when(redBusPaymentRefundServiceImpl.updateRefundStatus(Mockito.any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        paymentStatusConsumerServiceImpl.refundStatus(CommonTestObjectUtil.getRefundRequest());
        Assert.assertNotNull(paymentStatusConsumerServiceImpl);
    }

    @Test
    public void refundStatusfailed() {

        log.info("Entering into refundStatusTest() method....");

        TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
        Mockito.lenient().when(refundDetailsRepo.findByPrId(Mockito.anyString())).thenReturn(transactionRefundEntity);
        Mockito.lenient().when(refundDetailsRepo.save(Mockito.any())).thenReturn(transactionRefundEntity);
        Mockito.lenient().when(redBusPaymentRefundServiceImpl.updateRefundStatus(Mockito.any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        paymentStatusConsumerServiceImpl.refundStatus(CommonTestObjectUtil.getRefundRequestfailed());
        Assert.assertNotNull(paymentStatusConsumerServiceImpl);
    }

}
