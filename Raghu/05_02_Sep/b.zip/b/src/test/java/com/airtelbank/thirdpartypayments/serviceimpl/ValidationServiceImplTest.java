package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.CustomError;
import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import com.airtelbank.thirdpartypayments.entity.APBOAuthEnum;
import com.airtelbank.thirdpartypayments.entity.MerchantOAuthDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.OauthResponse;
import com.airtelbank.thirdpartypayments.model.OauthResponseAPB;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionDetailsRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.MerchantOAuthDetailsRepository;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class ValidationServiceImplTest {

    @InjectMocks
    ValidationServiceImpl validationService;
    @Mock
    MerchantOAuthDetailsRepository merchantOAuthDetailsRepository;

    @Mock
    OrderDetailsRepo orderDetailsRepo;

    @Mock
    Environment environment;

    @Mock
    RefundDetailsRepo refundDetailsRepo;

    @Mock
    HttpUtil httpUtil;


    @Mock
    MessageSource messageSource;
    @Mock
    ValidationServiceImpl validationService1;

    @Mock
    private MerchantTransactionDetailsRepo merchantTransactionDetailsRepo;

    @Before
    public void setUp() {

        ReflectionTestUtils.setField(validationService, "secretKey", "redbus");
    }


    @Test
    public void validateMerchant() throws ThirdPartyPaymentsException {
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setKey("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        customEntries.add(customEntry);
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setAmount(BigDecimal.ONE);
        paymentRequest.setHash("dce7083f40ff6d4147b889a5cc321fd4a8ed74d62db0ce9846f3b4fef21ea1e66966b924aab1f71ac2cab4c797318281defa6d0abf7de1c6febee98d6b9483bb");
        Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
        stringBigDecimalMap.put("1", BigDecimal.ONE);
        paymentRequest.setAmountDetails(stringBigDecimalMap);
        TransactionDetailsRequest request = new TransactionDetailsRequest();
        request.setDetails(customEntries);
        request.setMerchantTxnId("test");
        paymentRequest.setTransactionDetailsRequest(request);
        paymentRequest.setMerchantId("test");
        environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);
        String url = "test";
        OauthResponse oauthResponse = new OauthResponse();
        Meta meta = new Meta();
        meta.setDescription("test");
        meta.setStatus(0);
        meta.setCode("test");
        oauthResponse.setMeta(meta);
        OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
        oauthResponseAPB.setMerchantId("test");
        oauthResponseAPB.setAccessToken("test");
        oauthResponseAPB.setCreationDate(1000L);
        oauthResponseAPB.setExpiryDate(1000L);
        oauthResponseAPB.setMsisdn("9788288289");
        oauthResponseAPB.setExpiryStatus("test");
        oauthResponseAPB.setScope("test");
        oauthResponseAPB.setUpdationDate(1000L);
        oauthResponseAPB.setXappToken("test");
        oauthResponse.setData(oauthResponseAPB);
        CustomError customError = new CustomError();
        customError.setCode("test");
        customError.setDescription("test");
        customError.setField("test");
        List<CustomError> customErrors = new ArrayList<>();
        customErrors.add(customError);
        oauthResponse.setErrors(customErrors);
        MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
        merchantOAuthDetailsEntity.setMerchantId("test");
        merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
        merchantOAuthDetailsEntity.setCreationDate(new Date());
        merchantOAuthDetailsEntity.setUpdationDate(new Date());
        merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
        merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
        merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
        merchantOAuthDetailsEntity.setClientSecret("test");
        merchantOAuthDetailsEntity.setRedirectURI("test");
        merchantOAuthDetailsEntity.setXAppToken("test");
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();

        Mockito.when(merchantTransactionDetailsRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
        Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
        Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
        Mockito.when(environment.getProperty(Mockito.any())).thenReturn(url);
        MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
        assertNotNull(validateMerchant);
    }

    @Test
    public void validateMerchantCompareamount() {
        try {
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.valueOf(-1));
            paymentRequest.setHash("ac229fb1428ecf52d7b1000c02d8aa8de2ad0abdc48a5b36b15f5dee3bf0a3d2d9b5f126172371eb54c9b278da0fd89668b75ac4c87519cd85bbb5ab96bd8d42");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");
            environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);
            String url = "test";
            OauthResponse oauthResponse = new OauthResponse();
            Meta meta = new Meta();
            meta.setDescription("test");
            meta.setStatus(0);
            meta.setCode("test");
            oauthResponse.setMeta(meta);
            OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
            oauthResponseAPB.setMerchantId("test");
            oauthResponseAPB.setAccessToken("test");
            oauthResponseAPB.setCreationDate(1000L);
            oauthResponseAPB.setExpiryDate(1000L);
            oauthResponseAPB.setMsisdn("9788288289");
            oauthResponseAPB.setExpiryStatus("test");
            oauthResponseAPB.setScope("test");
            oauthResponseAPB.setUpdationDate(1000L);
            oauthResponseAPB.setXappToken("test");
            oauthResponse.setData(oauthResponseAPB);
            CustomError customError = new CustomError();
            customError.setCode("test");
            customError.setDescription("test");
            customError.setField("test");
            List<CustomError> customErrors = new ArrayList<>();
            customErrors.add(customError);
            oauthResponse.setErrors(customErrors);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("test");
            MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                    .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                    .purposeCode("OYO").build();

            Mockito.lenient().when(merchantTransactionDetailsRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
            Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
            Mockito.when(environment.getProperty(Mockito.any())).thenReturn(url);
            MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
            assertNotNull(validateMerchant);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateMerchantwhereMerchantEntitynull() {
        try {
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.ONE);
            paymentRequest.setHash("dce7083f40ff6d4147b889a5cc321fd4a8ed74d62db0ce9846f3b4fef21ea1e66966b924aab1f71ac2cab4c797318281defa6d0abf7de1c6febee98d6b9483bb");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");
            environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);
            String url = "test";
            OauthResponse oauthResponse = new OauthResponse();
            Meta meta = new Meta();
            meta.setDescription("test");
            meta.setStatus(0);
            meta.setCode("test");
            oauthResponse.setMeta(meta);
            OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
            oauthResponseAPB.setMerchantId("test");
            oauthResponseAPB.setAccessToken("test");
            oauthResponseAPB.setCreationDate(1000L);
            oauthResponseAPB.setExpiryDate(1000L);
            oauthResponseAPB.setMsisdn("9788288289");
            oauthResponseAPB.setExpiryStatus("test");
            oauthResponseAPB.setScope("test");
            oauthResponseAPB.setUpdationDate(1000L);
            oauthResponseAPB.setXappToken("test");
            oauthResponse.setData(oauthResponseAPB);
            CustomError customError = new CustomError();
            customError.setCode("test");
            customError.setDescription("test");
            customError.setField("test");
            List<CustomError> customErrors = new ArrayList<>();
            customErrors.add(customError);
            oauthResponse.setErrors(customErrors);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("test");

            Mockito.when(merchantTransactionDetailsRepo.findByMerchantId(Mockito.any())).thenReturn(null);
            Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
            Mockito.when(environment.getProperty(Mockito.any())).thenReturn(url);
            MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
            assertNotNull(validateMerchant);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateMerchantWithOquthresponsestatusone() {
        try {
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.ONE);
            paymentRequest.setHash("dce7083f40ff6d4147b889a5cc321fd4a8ed74d62db0ce9846f3b4fef21ea1e66966b924aab1f71ac2cab4c797318281defa6d0abf7de1c6febee98d6b9483bb");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");
            environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);
            String url = "test";
            OauthResponse oauthResponse = new OauthResponse();
            Meta meta = new Meta();
            meta.setDescription("test");
            meta.setStatus(1);
            meta.setCode("test");
            oauthResponse.setMeta(meta);
            OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
            oauthResponseAPB.setMerchantId("test");
            oauthResponseAPB.setAccessToken("test");
            oauthResponseAPB.setCreationDate(1000L);
            oauthResponseAPB.setExpiryDate(1000L);
            oauthResponseAPB.setMsisdn("9788288289");
            oauthResponseAPB.setExpiryStatus("test");
            oauthResponseAPB.setScope("test");
            oauthResponseAPB.setUpdationDate(1000L);
            oauthResponseAPB.setXappToken("test");
            oauthResponse.setData(oauthResponseAPB);
            CustomError customError = new CustomError();
            customError.setCode("test");
            customError.setDescription("test");
            customError.setField("test");
            List<CustomError> customErrors = new ArrayList<>();
            customErrors.add(customError);
            oauthResponse.setErrors(customErrors);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("test");
            MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                    .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                    .purposeCode("OYO").build();

            Mockito.lenient().when(merchantTransactionDetailsRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
            Mockito.lenient().when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
            Mockito.when(environment.getProperty(Mockito.any())).thenReturn(url);
            MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
            assertNotNull(validateMerchant);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateMerchantwhereorderentitynotnull() {
        try {
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.ONE);
            paymentRequest.setHash("dce7083f40ff6d4147b889a5cc321fd4a8ed74d62db0ce9846f3b4fef21ea1e66966b924aab1f71ac2cab4c797318281defa6d0abf7de1c6febee98d6b9483bb");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");
            environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);
            String url = "test";
            OauthResponse oauthResponse = new OauthResponse();
            Meta meta = new Meta();
            meta.setDescription("test");
            meta.setStatus(0);
            meta.setCode("test");
            oauthResponse.setMeta(meta);
            OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
            oauthResponseAPB.setMerchantId("test");
            oauthResponseAPB.setAccessToken("test");
            oauthResponseAPB.setCreationDate(1000L);
            oauthResponseAPB.setExpiryDate(1000L);
            oauthResponseAPB.setMsisdn("9788288289");
            oauthResponseAPB.setExpiryStatus("test");
            oauthResponseAPB.setScope("test");
            oauthResponseAPB.setUpdationDate(1000L);
            oauthResponseAPB.setXappToken("test");
            oauthResponse.setData(oauthResponseAPB);
            CustomError customError = new CustomError();
            customError.setCode("test");
            customError.setDescription("test");
            customError.setField("test");
            List<CustomError> customErrors = new ArrayList<>();
            customErrors.add(customError);
            oauthResponse.setErrors(customErrors);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("test");
            MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                    .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                    .purposeCode("OYO").build();
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            Mockito.when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            Mockito.lenient().when(merchantTransactionDetailsRepo.findByMerchantId(Mockito.any())).thenReturn(entity);
            Mockito.lenient().when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.lenient().when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
            Mockito.lenient().when(environment.getProperty(Mockito.any())).thenReturn(url);
            MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
            assertNotNull(validateMerchant);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateMerchantHtransatuionentitynull() {
        try {
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.ONE);
            paymentRequest.setHash("f39d9f5711efbcd2567597c7c88263ce71061fb54f6067f4eb1d0bb00d7ee3019fe9a8cda5d87998b4c0d9c31e81cf82724d4d1a26e738609423dea78f8b33d0");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");

            String url = "test";
            OauthResponse oauthResponse = new OauthResponse();
            Meta meta = new Meta();
            meta.setDescription("test");
            meta.setStatus(0);
            meta.setCode("test");
            oauthResponse.setMeta(meta);
            OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
            oauthResponseAPB.setMerchantId("test");
            oauthResponseAPB.setAccessToken("test");
            oauthResponseAPB.setCreationDate(1000L);
            oauthResponseAPB.setExpiryDate(1000L);
            oauthResponseAPB.setMsisdn("9788288289");
            oauthResponseAPB.setExpiryStatus("test");
            oauthResponseAPB.setScope("test");
            oauthResponseAPB.setUpdationDate(1000L);
            oauthResponseAPB.setXappToken("test");
            oauthResponse.setData(oauthResponseAPB);
            CustomError customError = new CustomError();
            customError.setCode("test");
            customError.setDescription("test");
            customError.setField("test");
            List<CustomError> customErrors = new ArrayList<>();
            customErrors.add(customError);
            oauthResponse.setErrors(customErrors);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("test");
            Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
            Mockito.when(environment.getProperty(Mockito.any())).thenReturn(url);
            MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
            assertNotNull(validateMerchant);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateMerchantHashnotmatched() {
        try {
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.ONE);
            paymentRequest.setHash("f39d9f5711efbcd2567597c7c88263ce71061fb54f6067f4eb1d0bb00d7ee3019fe9a8cda5d87998b4c0d9c31e81cf82724d4d1a26e738609423dea78f8b33d0");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");
            /*    environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);*/
            String url = "test";
            OauthResponse oauthResponse = new OauthResponse();
            Meta meta = new Meta();
            meta.setDescription("test");
            meta.setStatus(0);
            meta.setCode("test");
            oauthResponse.setMeta(meta);
            OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
            oauthResponseAPB.setMerchantId("test");
            oauthResponseAPB.setAccessToken("test");
            oauthResponseAPB.setCreationDate(1000L);
            oauthResponseAPB.setExpiryDate(1000L);
            oauthResponseAPB.setMsisdn("9788288289");
            oauthResponseAPB.setExpiryStatus("test");
            oauthResponseAPB.setScope("test");
            oauthResponseAPB.setUpdationDate(1000L);
            oauthResponseAPB.setXappToken("test");
            oauthResponse.setData(oauthResponseAPB);
            CustomError customError = new CustomError();
            customError.setCode("test");
            customError.setDescription("test");
            customError.setField("test");
            List<CustomError> customErrors = new ArrayList<>();
            customErrors.add(customError);
            oauthResponse.setErrors(customErrors);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("test");
            Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
            Mockito.when(environment.getProperty(Mockito.any())).thenReturn(url);
            MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
            assertNotNull(validateMerchant);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateMerchantExceptionwheremerchantoauthentitynull() {
        try {
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            PaymentRequest paymentRequest = new PaymentRequest();
            paymentRequest.setAmount(BigDecimal.ONE);
            paymentRequest.setHash("test");
            Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
            stringBigDecimalMap.put("1", BigDecimal.ONE);
            paymentRequest.setAmountDetails(stringBigDecimalMap);
            TransactionDetailsRequest request = new TransactionDetailsRequest();
            request.setDetails(customEntries);
            request.setMerchantTxnId("test");
            paymentRequest.setTransactionDetailsRequest(request);
            paymentRequest.setMerchantId("test");
            environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);
            String url = "test";
            OauthResponse oauthResponse = new OauthResponse();
            Meta meta = new Meta();
            meta.setDescription("test");
            meta.setStatus(0);
            meta.setCode("test");
            oauthResponse.setMeta(meta);
            OauthResponseAPB oauthResponseAPB = new OauthResponseAPB();
            oauthResponseAPB.setMerchantId("test");
            oauthResponseAPB.setAccessToken("test");
            oauthResponseAPB.setCreationDate(1000L);
            oauthResponseAPB.setExpiryDate(1000L);
            oauthResponseAPB.setMsisdn("9788288289");
            oauthResponseAPB.setExpiryStatus("test");
            oauthResponseAPB.setScope("test");
            oauthResponseAPB.setUpdationDate(1000L);
            oauthResponseAPB.setXappToken("test");
            oauthResponse.setData(oauthResponseAPB);
            CustomError customError = new CustomError();
            customError.setCode("test");
            customError.setDescription("test");
            customError.setField("test");
            List<CustomError> customErrors = new ArrayList<>();
            customErrors.add(customError);
            oauthResponse.setErrors(customErrors);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(oauthResponse);
            Mockito.when(environment.getProperty(Mockito.any())).thenReturn(url);
            MerchantTransactionDetailsEntity validateMerchant = validationService.validateMerchant(paymentRequest, "test");
            assertNotNull(validateMerchant);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateRefund() throws ThirdPartyPaymentsException {
        TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
        transactionRefundRequest.setRefundTxnId("test");
        transactionRefundRequest.setHash("test");
        transactionRefundRequest.setAmount(BigDecimal.TEN);
        transactionRefundRequest.setFeSessionId("test");
        transactionRefundRequest.setMerchantTxnId("test");
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
        redBusPaymentRefundEntity.setFeSessionId("123");
        redBusPaymentRefundEntity.setMerchantId("456");
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String strDate = dateFormat.format(date);
        redBusPaymentRefundEntity.setTxnDate(strDate);
        redBusPaymentRefundEntity.setMerchantId("0909");
        redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
        redBusPaymentRefundEntity.setPurposeRefNo("345");
        redBusPaymentRefundEntity.setPrId("787");
        redBusPaymentRefundEntity.setRefundTxnId("test");
        redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
        List<TransactionRefundEntity> transactionRefundEntities = new ArrayList<>();
        transactionRefundEntities.add(redBusPaymentRefundEntity);
        MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
        merchantOAuthDetailsEntity.setMerchantId("test");
        merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
        merchantOAuthDetailsEntity.setCreationDate(new Date());
        merchantOAuthDetailsEntity.setUpdationDate(new Date());
        merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
        merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
        merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
        merchantOAuthDetailsEntity.setClientSecret("test");
        merchantOAuthDetailsEntity.setRedirectURI("test");
        merchantOAuthDetailsEntity.setXAppToken("apptoken");
        Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
        Mockito.lenient().when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
        Mockito.lenient().when(refundDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
        String s = validationService.validateRefund(transactionRefundRequest, "AUTOREFUND", "test");
        assertNotNull(s);
    }

    @Test
    public void validateRefundhashnotmatched() {
        try {
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.TEN);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
            redBusPaymentRefundEntity.setFeSessionId("123");
            redBusPaymentRefundEntity.setMerchantId("456");
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            String strDate = dateFormat.format(date);
            redBusPaymentRefundEntity.setTxnDate(strDate);
            redBusPaymentRefundEntity.setMerchantId("0909");
            redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
            redBusPaymentRefundEntity.setPurposeRefNo("345");
            redBusPaymentRefundEntity.setPrId("787");
            redBusPaymentRefundEntity.setRefundTxnId("test");
            redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
            List<TransactionRefundEntity> transactionRefundEntities = new ArrayList<>();
            transactionRefundEntities.add(redBusPaymentRefundEntity);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("apptoken");
            Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.lenient().when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            Mockito.lenient().when(refundDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
            String s = validationService.validateRefund(transactionRefundRequest, "REFUND", "test");
            assertNotNull(s);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void validateRefundtransactionentitynull() {
        try {
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.TEN);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
            redBusPaymentRefundEntity.setFeSessionId("123");
            redBusPaymentRefundEntity.setMerchantId("456");
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            String strDate = dateFormat.format(date);
            redBusPaymentRefundEntity.setTxnDate(strDate);
            redBusPaymentRefundEntity.setMerchantId("0909");
            redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
            redBusPaymentRefundEntity.setPurposeRefNo("345");
            redBusPaymentRefundEntity.setPrId("787");
            redBusPaymentRefundEntity.setRefundTxnId("test");
            redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
            List<TransactionRefundEntity> transactionRefundEntities = new ArrayList<>();
            transactionRefundEntities.add(redBusPaymentRefundEntity);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("apptoken");
            Mockito.lenient().when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.lenient().when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            Mockito.lenient().when(refundDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
            String s = validationService.validateRefund(null, "REFUND", "test");
            assertNotNull(s);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void validateRefundtransactionrefundentitynull() {
        try {
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.TEN);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
            redBusPaymentRefundEntity.setFeSessionId("123");
            redBusPaymentRefundEntity.setMerchantId("456");
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            String strDate = dateFormat.format(date);
            redBusPaymentRefundEntity.setTxnDate(strDate);
            redBusPaymentRefundEntity.setMerchantId("0909");
            redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
            redBusPaymentRefundEntity.setPurposeRefNo("345");
            redBusPaymentRefundEntity.setPrId("787");
            redBusPaymentRefundEntity.setRefundTxnId("test");
            redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
            List<TransactionRefundEntity> transactionRefundEntities = new ArrayList<>();
            transactionRefundEntities.add(redBusPaymentRefundEntity);
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setMerchantId("test");
            merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
            merchantOAuthDetailsEntity.setCreationDate(new Date());
            merchantOAuthDetailsEntity.setUpdationDate(new Date());
            merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
            merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
            merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
            merchantOAuthDetailsEntity.setClientSecret("test");
            merchantOAuthDetailsEntity.setRedirectURI("test");
            merchantOAuthDetailsEntity.setXAppToken("apptoken");
            Mockito.when(refundDetailsRepo.getOne(Mockito.any())).thenReturn(redBusPaymentRefundEntity);
            Mockito.lenient().when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            Mockito.lenient().when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            Mockito.lenient().when(refundDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
            String s = validationService.validateRefund(transactionRefundRequest, "REFUND", "test");
            assertNotNull(s);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateRefundappTokennotmatched() throws ThirdPartyPaymentsException {
        TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
        transactionRefundRequest.setRefundTxnId("test");
        transactionRefundRequest.setHash("f39d9f5711efbcd2567597c7c88263ce71061fb54f6067f4eb1d0bb00d7ee3019fe9a8cda5d87998b4c0d9c31e81cf82724d4d1a26e738609423dea78f8b33d0");
        transactionRefundRequest.setAmount(BigDecimal.TEN);
        transactionRefundRequest.setFeSessionId("test");
        transactionRefundRequest.setMerchantTxnId("test");
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
        redBusPaymentRefundEntity.setFeSessionId("123");
        redBusPaymentRefundEntity.setMerchantId("456");
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String strDate = dateFormat.format(date);
        redBusPaymentRefundEntity.setTxnDate(strDate);
        redBusPaymentRefundEntity.setMerchantId("0909");
        redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
        redBusPaymentRefundEntity.setPurposeRefNo("345");
        redBusPaymentRefundEntity.setPrId("787");
        redBusPaymentRefundEntity.setRefundTxnId("test");
        redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
        List<TransactionRefundEntity> transactionRefundEntities = new ArrayList<>();
        transactionRefundEntities.add(redBusPaymentRefundEntity);
        MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
        merchantOAuthDetailsEntity.setMerchantId("test");
        merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
        merchantOAuthDetailsEntity.setCreationDate(new Date());
        merchantOAuthDetailsEntity.setUpdationDate(new Date());
        merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
        merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
        merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
        merchantOAuthDetailsEntity.setClientSecret("test");
        merchantOAuthDetailsEntity.setRedirectURI("test");
        merchantOAuthDetailsEntity.setXAppToken("test");
        Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
        Mockito.lenient().when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
        Mockito.lenient().when(refundDetailsRepo.findByMerchantTxnId(Mockito.any())).thenReturn(transactionRefundEntities);
        String s = validationService.validateRefund(transactionRefundRequest, "test", "test");
        assertNotNull(s);
    }


    @Test
    public void validateAppToken() throws ThirdPartyPaymentsException {
        MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
        merchantOAuthDetailsEntity.setMerchantId("test");
        merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
        merchantOAuthDetailsEntity.setCreationDate(new Date());
        merchantOAuthDetailsEntity.setUpdationDate(new Date());
        merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
        merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
        merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
        merchantOAuthDetailsEntity.setClientSecret("test");
        merchantOAuthDetailsEntity.setRedirectURI("test");
        merchantOAuthDetailsEntity.setXAppToken("test");
        Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
        validationService.validateAppToken("test", "test");
        Mockito.verify(merchantOAuthDetailsRepository, Mockito.times(1)).findByMerchantId(Mockito.any());
    }

    @Test
    public void getClientSecret() throws ThirdPartyPaymentsException {
        MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
        merchantOAuthDetailsEntity.setMerchantId("test");
        merchantOAuthDetailsEntity.setScope(APBOAuthEnum.OAuthScope.DEFAULT);
        merchantOAuthDetailsEntity.setCreationDate(new Date());
        merchantOAuthDetailsEntity.setUpdationDate(new Date());
        merchantOAuthDetailsEntity.setAuthCodeExpiryInSec(1);
        merchantOAuthDetailsEntity.setAccessTokenExpiryUnit(APBOAuthEnum.ExpiryUnit.DAYS);
        merchantOAuthDetailsEntity.setAccessTokenExpiryValue(1);
        merchantOAuthDetailsEntity.setClientSecret("test");
        merchantOAuthDetailsEntity.setRedirectURI("test");
        merchantOAuthDetailsEntity.setXAppToken("test");
        Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
        String s = validationService.getClientSecret("test");
        assertNotNull(s);
    }

    @Test
    public void sum() {
        int test = validationService.sum(10, 10);
        assertEquals(20, test);
    }

    @Test
    public void validateCustomerConsent() {
        try {
            validationService.validateCustomerConsent("");

            Mockito.verify(validationService1).validateCustomerConsent("");
        } catch (ConsentException e) {
            assertNotNull(e);
        }

    }

    @Test
    public void validateCustomerDetailsConsentEx() {
        try {

            CustomerConsentRequest request = new CustomerConsentRequest();
            request.setConsent(true);
            request.setConsentMode("");
            request.setConsentDescription("test");
            request.setConsentType("test");
            request.setConsentPurpose("test");
            request.setMobileNumber("");
            request.setValidTill("test");
            validationService.validateCustomerDetailsConsent(request);

            Mockito.verify(validationService1, Mockito.times(1)).validateCustomerDetailsConsent(request);
        } catch (ConsentException e) {

            assertNotNull(e);
        }


    }

    @Test
    public void validateAppTokentetsapptokennotmatched() {
        try {
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = new MerchantOAuthDetailsEntity();
            merchantOAuthDetailsEntity.setXAppToken("test");
            Mockito.when(merchantOAuthDetailsRepository.findByMerchantId(Mockito.any())).thenReturn(merchantOAuthDetailsEntity);
            validationService.validateAppToken("app", "test");
            verify(merchantOAuthDetailsRepository, Mockito.times(1)).findByMerchantId("test");
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void validateForSecretKey() {

        validationService.validateForSecretKey("redbus");
        assertNotNull(validationService);
    }

    @Test
    public void validateForSecretKeyException() {
        try {
            validationService.validateForSecretKey("test");
            assertNotNull(validationService);
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }
}