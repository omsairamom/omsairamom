package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.hub.client.service.PHPaymentRequestService;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.RedBusPaymentRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusBookingResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentEnquiry;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsTxnRepo;
import com.airtelbank.thirdpartypayments.util.CommonAppConsent;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import com.airtelbank.thirdpartypayments.util.EncryptionDencryptionUtils;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mockStatic;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class RedBusPaymentServiceImplTest extends CommonTestObjectUtil {

    @InjectMocks
    private RedBusPaymentServiceImpl redBusPaymentService;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;
    @Mock
    OrderDetailsTxnRepo orderDetailsTxnRepo;

    @Mock
    private PHPaymentRequestService phPaymentRequestService;

    @Mock
    private HttpUtil httpUtil;

    @Mock
    private ObjectMapper mapper;

    @Mock
    ValidationServiceImpl validationService;

    @Mock
    MessageSource messageSource;

    private static MockedStatic<EncryptionDencryptionUtils> mockedSettings;

    @BeforeClass
    public static void init() {

        mockedSettings = mockStatic(EncryptionDencryptionUtils.class);
    }

    @AfterClass
    public static void close() {
        mockedSettings.close();

    }


    @Before
    public void setUp() {

        log.info("Loading RedBusPaymentServiceImplTest......");

        // ReflectionTestUtils.setField(redBusPaymentService, "secretKey", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "paymentUpdateUrl", "https://localhost:8086");
        ReflectionTestUtils.setField(redBusPaymentService, "serverIp", "https://apbuat.airtelbank.com:5050/");
        ReflectionTestUtils.setField(redBusPaymentService, "decKey", "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJTkiP/f6ga4bVzybt98l2h0wt+PzmWRMMu9QkN8aDbM4qmyoVxNRR4xNurm80+JoJ2BgtU7fN3fit7kShygdDifS/+hk2EwKFx8BjcgZn4zNahCVNTmrfX5TRyLQMo9NlIumcaEuevdt78Ml+WPUcP73TQ63r/5kTQvvshI2RspAgMBAAECgYBbz8Ca55wLoNXvJp8vuEg05Sr1aFvBTZJlT8L4klJA2H48XiYaIJuqTnaqytbmCNu9xArFKfWJazrazrLUjCydfG6oQCzMwst0xzTUizOCYApCFMJ6VA/UDJnqgPJjr0m+0xUUQvEs55IMuZQt8yXKYzp/O+YSy3G5MITxRJAAcQJBANCZJTlNRqelbAJMhJrHxHlPgrfzlC/42CHneZqrHTgbQqEQuffLXRk8WEr6YnnblqkmVLCe0WbLiFIYaW6TqfMCQQC2uh8B5ci90skH9+f8sAwhqII8ouL395SAUdo2G/f2THVcGXxLn8eZIjTKRoa2Kcuo/PH/O02cPuOfbdpr4vFzAkAHfHeJhuxyN82Yh4Z6x5CVifT3BRbcYeHf1Z7Xnix+RvwtK5yA+BtvPGsuxa2jEe5mQ6nmbMy3E7bgu1+NSF9hAkAJle32fYVwX9Rn9JtY6CtawKpEYA8kDvrdWG3oFMOHSi+F61hX50PjRqYaTmTWvY6PiOVxDD1gCvSJ8otYyYj9AkEAy//gm6z4GljCq5HwloDVVe3/o4rXKvAyQGOjPqLMleuTd4zJhqYZS9Xub/ypc+ZszhMH0cLupcUQf63KiWe3Eg==");
        ReflectionTestUtils.setField(redBusPaymentService, "useCase", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "useCaseName", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "serverIp", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "partnerId", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "billerId", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "encKey", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "paymentStatus", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "merchantId", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "param1", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "param2", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "param3", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "androidDeepLink", "android");
        ReflectionTestUtils.setField(redBusPaymentService, "iosDeepLink", "ios");
        ReflectionTestUtils.setField(redBusPaymentService, "customerSegment", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "offersUseCase", "redbus");
        ReflectionTestUtils.setField(redBusPaymentService, "second", 300);
        ReflectionTestUtils.setField(redBusPaymentService, "bufferTime", 30);

    }

    @Test
    public void postDataToPaymentHubSuccessTest() {

        log.info("Entering into postDataToPaymentHubSuccessTest() method....");

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.anyString())).thenReturn(getOrderDetailsEntityDetails());
        Mockito.when(phPaymentRequestService.paymentRequest(Mockito.anyString(), Mockito.any(), Mockito.anyString()))
                .thenReturn(CommonTestObjectUtil.getInitPaymentResponse());
        Mockito.when(orderDetailsRepo.save(Mockito.any())).thenReturn(getOrderDetailsEntityDetails());
        BigDecimal orderId = BigDecimal.TEN;
        Mockito.when(orderDetailsTxnRepo.getNextSeriesId()).thenReturn(orderId);
        RedBusPaymentResponse redBusPaymentResponse = redBusPaymentService.postDataToPaymentHub(getCustomerDetailsPaymentRequest(), getHeaderRequestDTO());
        assertNotNull(redBusPaymentResponse);

        log.info("Execution completed postDataToPaymentHubSuccessTest() method......");
    }


    @Test
    public void postDataToPaymentHubIOSSuccessTest() {

        log.info("Entering into postDataToPaymentHubSuccessTest() method....");

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.anyString())).thenReturn(getOrderDetailsEntityDetails());
        Mockito.when(phPaymentRequestService.paymentRequest(Mockito.anyString(), Mockito.any(), Mockito.anyString()))
                .thenReturn(CommonTestObjectUtil.getInitPaymentResponse());
        Mockito.when(orderDetailsRepo.save(Mockito.any())).thenReturn(getOrderDetailsEntityDetails());
        BigDecimal orderId = BigDecimal.TEN;
        Mockito.when(orderDetailsTxnRepo.getNextSeriesId()).thenReturn(orderId);
        RedBusPaymentResponse redBusPaymentResponse = redBusPaymentService.postDataToPaymentHub(getCustomerDetailsPaymentRequest(), getHeaderRequestDTO());
        assertNotNull(redBusPaymentResponse);

        log.info("Execution completed postDataToPaymentHubSuccessTest() method......");
    }

    @Test
    public void postDataToPaymentHubOTHERSuccessTest() {
        try {
            log.info("Entering into postDataToPaymentHubSuccessTest() method....");

            Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.anyString())).thenReturn(getOrderDetailsEntityDetails());
            Mockito.lenient().when(phPaymentRequestService.paymentRequest(Mockito.anyString(), Mockito.any(), Mockito.anyString()))
                    .thenReturn(CommonTestObjectUtil.getInitPaymentResponse());
            Mockito.lenient().when(orderDetailsRepo.save(Mockito.any())).thenReturn(getOrderDetailsEntityDetails());
            BigDecimal orderId = BigDecimal.TEN;
            Mockito.lenient().when(orderDetailsTxnRepo.getNextSeriesId()).thenReturn(orderId);
            RedBusPaymentResponse redBusPaymentResponse = redBusPaymentService.postDataToPaymentHub(getCustomerDetailsPaymentRequest(), getHeaderRequestDTO());
            assertNotNull(redBusPaymentResponse);

            log.info("Execution completed postDataToPaymentHubSuccessTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }


    @Test(expected = GenericException.class)
    public void postDataToPaymentHubFailTest() {

        log.info("Entering into postDataToPaymentHubSuccessTest() method....");

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.anyString())).thenReturn(null);
        redBusPaymentService.postDataToPaymentHub(getCustomerDetailsPaymentRequest(), getHeaderRequestDTO());
        log.info("Execution completed postDataToPaymentHubSuccessTest() method......");
    }


    @Test
    public void getPaymentStatusEnquiryTest() {

        log.info("Entering into getPaymentStatusTest() method....");

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.anyString())).thenReturn(getOrderDetailsForPaymentStatus());
        RedBusPaymentStatusResponse redBusPaymentStatusResponse = redBusPaymentService.getPaymentStatusEnquiry("123");
        assertEquals("123", redBusPaymentStatusResponse.getPurposeRefNo());

        log.info("Execution completed getPaymentStatusTest() method......");
    }


    @Test
    public void saveRedBusBookingDetailsTest() throws Exception {

        log.info("Entering into saveRedBusBookingDetailsTest() method....");

        mockedSettings.when(() -> EncryptionDencryptionUtils.dataDecryptByPrivateKey(Mockito.any(), Mockito.any())).thenReturn(getRedbusPaymentRequest().toString());
        Mockito.when(mapper.readValue(anyString(), eq(RedBusPaymentRequest.class))).thenReturn(getRedbusPaymentRequest());
        Mockito.when(orderDetailsRepo.saveAndFlush(Mockito.any())).thenReturn(getOrderDetails());
        RedBusBookingResponse redBusBookingResponse = redBusPaymentService.saveRedBusBookingDetails(getRedbusPaymentRequestDTO(), getHeaderRequestDTO());
        assertEquals("123", redBusBookingResponse.getPurposeRefNo());

        log.info("Execution completed saveRedBusBookingDetailsTest() method......");
    }

    @Test
    public void saveRedBusBookingDetailsExceptionTest() throws Exception {
        try {
            log.info("Entering into saveRedBusBookingDetailsTest() method....");

            mockedSettings.when(() -> EncryptionDencryptionUtils.dataDecryptByPrivateKey(Mockito.any(), Mockito.any())).thenReturn(getRedbusPaymentRequest().toString());
            Mockito.when(mapper.readValue(anyString(), eq(RedBusPaymentRequest.class))).thenReturn(getRedbusPaymentRequest());
            Mockito.lenient().when(orderDetailsRepo.saveAndFlush(Mockito.any())).thenReturn(getOrderDetails());
            Mockito.when(orderDetailsRepo.existsByPurposeRefNo(Mockito.any())).thenReturn(true);
            RedBusBookingResponse redBusBookingResponse = redBusPaymentService.saveRedBusBookingDetails(getRedbusPaymentRequestDTO(), getHeaderRequestDTO());
            assertEquals("123", redBusBookingResponse.getPurposeRefNo());

            log.info("Execution completed saveRedBusBookingDetailsTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void updatePaymentStatusTest() throws Exception {

        log.info("Entering into updatePaymentStatusTest() method....");
        String encData = "1111111";
        PaymentData paymentUpdate = new PaymentData(encData);
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        String kafkapaymentResponseinString = "{\"purposeRefNo\":\"11234455\",\"paymentRefId\":\"987654321\",\"status\":\"SUCCESS\",\"totalAmount\":\"1\",\"errorCode\":null,\"errorMessage\":null,\"timestamp\":\"2021-06-25T08:26:28+05:30\",\"secretKey\":\"redbus\"}";
        Mockito.lenient().when(mapper.writeValueAsString(Mockito.anyString())).thenReturn(kafkapaymentResponseinString);
        mockedSettings.when(() -> EncryptionDencryptionUtils.dataEncryptByPublicKey(Mockito.any(), Mockito.any())).thenReturn(encData);
        Mockito.lenient().when(httpUtil.hitRequest(CommonAppConsent.PAYMENT_UPDATE_URL, paymentUpdate, String.class, headers, HttpMethod.POST, true)).thenReturn("ok");
        ResponseEntity<String> responseEntity = redBusPaymentService.updatePaymentStatus(getKafkapaymentResponse());
        assertEquals(200, responseEntity.getStatusCodeValue());

        log.info("Execution completed updatePaymentStatusTest() method......");

    }


    @Test
    public void updatePaymentStatusExceptionTest() throws Exception {
        try {
            log.info("Entering into updatePaymentStatusTest() method....");
            String encData = "1111111";
            PaymentData paymentUpdate = new PaymentData(encData);
            Map<String, String> headers = new HashMap<>();
            headers.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
            String kafkapaymentResponseinString = "{\"purposeRefNo\":\"11234455\",\"paymentRefId\":\"987654321\",\"status\":\"SUCCESS\",\"totalAmount\":\"1\",\"errorCode\":null,\"errorMessage\":null,\"timestamp\":\"2021-06-25T08:26:28+05:30\",\"secretKey\":\"redbus\"}";
            Mockito.lenient().when(mapper.writeValueAsString(Mockito.anyString())).thenReturn(kafkapaymentResponseinString);
            mockedSettings.when(() -> EncryptionDencryptionUtils.dataEncryptByPublicKey(Mockito.any(), Mockito.any())).thenReturn(encData);
            Mockito.lenient().when(httpUtil.hitRequest(CommonAppConsent.PAYMENT_UPDATE_URL, paymentUpdate, String.class, headers, HttpMethod.POST, true)).thenReturn("ok");
            ResponseEntity<String> responseEntity = redBusPaymentService.updatePaymentStatus(getKafkapaymentResponses());
            assertEquals(200, responseEntity.getStatusCodeValue());

            log.info("Execution completed updatePaymentStatusTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }

    }


    @Test
    public void saveRedBusPaymentRequestSuccessTest() {

        log.info("Entering into saveRedBusPaymentRequestSuccessTest() method....");

        Mockito.when(orderDetailsRepo.saveAndFlush(Mockito.any())).thenReturn(getOrderDetailsEntityDetails());
        OrderDetailsEntity orderDetailsEntityResponse = redBusPaymentService.saveRedBusBookingDetailsRequest(getRedbusPaymentRequest());
        assertEquals("1234", orderDetailsEntityResponse.getCustomerId());

        log.info("Execution completed saveRedBusPaymentRequestSuccessTest() method......");

    }

    @Test
    public void getFulfilmentStatusEnquiryFromPrId() {

        Mockito.doNothing().when(validationService).validateRequestParam(Mockito.any());
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.PAYMENT_COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        Mockito.when(orderDetailsRepo.findByPrID(Mockito.any())).thenReturn(order);
        RedBusPaymentEnquiry map = redBusPaymentService.getFulfilmentStatusEnquiryFromPrId("test", getHeaderRequestDTO());
        assertNotNull(map);

    }

    @Test
    public void getFulfilmentStatusEnquiryFromPrIdWhereOrderStatusPaymentFailed() {

        Mockito.doNothing().when(validationService).validateRequestParam(Mockito.any());
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.PAYMENT_FAILED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        Mockito.when(orderDetailsRepo.findByPrID(Mockito.any())).thenReturn(order);
        RedBusPaymentEnquiry map = redBusPaymentService.getFulfilmentStatusEnquiryFromPrId("test", getHeaderRequestDTO());
        assertNotNull(map);

    }


    @Test
    public void getFulfilmentStatusEnquiryFromPrIdforprepareFulfilmentEnquiryDeepLinkfailed() {
        try {
            Mockito.doNothing().when(validationService).validateRequestParam(Mockito.any());
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID("test");
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);

            Mockito.when(orderDetailsRepo.findByPrID(Mockito.any())).thenReturn(order);
            RedBusPaymentEnquiry map = redBusPaymentService.getFulfilmentStatusEnquiryFromPrId("test", getHeaderRequestDTO());
            assertNotNull(map);
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void getFulfilmentStatusEnquiryFromPrIdException() {

        try {
            RedBusPaymentEnquiry map = redBusPaymentService.getFulfilmentStatusEnquiryFromPrId("test", getHeaderRequestDTO());
            assertNotNull(map);
        } catch (GenericException e) {
            assertNotNull(e);
        }

    }
}

