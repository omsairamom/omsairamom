package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentRefundService;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.lenient;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class RedBusExternalPaymentsRefundControllerTest extends CommonTestObjectUtil {

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private RedBusExternalPaymentsRefundController redBusExternalPaymentsRefundController;

    @Mock
    private RedBusPaymentRefundService redBusPaymentRefundService;

    @Mock
    MessageSource messageSource;

    @Test
    public void initiateRefundSuccessTest() {
        log.info("Entering into initiateRefundSuccessTest() method....");


        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        lenient().when(redBusPaymentRefundService.initiateRefund(Mockito.any())).thenReturn(getRedBusRefundResponse());

        String data = "hhC+dxQ07u9xeKJFbN5TQ+ERuYecfaocp7DTAt6NiU2RDRkp3cSqTK2aiQMeSdG+AOCPm7UA6LpdUAACIY9fOa5v23lFMnk/vxAsBu9S/TVI/nkbA97lTqavmO9wUA1OUsSAKo8iSJO8G8cgEWAJC0uVWGDkazhXzFZPT2nvgXg=";
        PaymentData paymentData = PaymentData.builder().data(data).build();

        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsRefundController.initiateRefund(paymentData, headers);
        assertEquals(0, expectConsentResponse.getBody().getMeta().getStatus());

        log.info("Execution completed initiateRefundSuccessTest() method......");
    }

    /**
     * Test the InitiateRefund fail
     * Actual : "1"
     * Expected : "1"
     *
     * @throws Exception
     */
    @Test
    public void initiateRefundFailTest() throws Exception {

        log.info("Entering into initiateRefundFailTest() method....");

        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        lenient().when(redBusPaymentRefundService.initiateRefund(Mockito.any())).thenReturn(null);
        String data = "hhC+dxQ07u9xeKJFbN5TQ+ERuYecfaocp7DTAt6NiU2RDRkp3cSqTK2aiQMeSdG+AOCPm7UA6LpdUAACIY9fOa5v23lFMnk/vxAsBu9S/TVI/nkbA97lTqavmO9wUA1OUsSAKo8iSJO8G8cgEWAJC0uVWGDkazhXzFZPT2nvgXg=";
        PaymentData paymentData = PaymentData.builder().data(data).build();
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsRefundController.initiateRefund(paymentData, headers);

        assertEquals(1, expectConsentResponse.getBody().getMeta().getStatus());

        log.info("Execution completed initiateRefundFailTest() method......");
    }


    @Test
    public void getRefundStatusSuccessTest() {
        log.info("Entering into getRefundStatusSuccessTest() method....");


        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        String refundno = "12345";
        lenient().when(redBusPaymentRefundService.getRefundStatusEnquiry(Mockito.anyString())).thenReturn(getRedBusRefundStatusResponse());
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsRefundController.getRefundStatusEnquiry(refundno, headers);
        assertEquals(0, expectConsentResponse.getBody().getMeta().getStatus());

        log.info("Execution completed getRefundStatusSuccessTest() method......");
    }

    /**
     * Test the GetRefundStatus fail
     * Actual : "1"
     * Expected : "1"
     */
    @Test
    public void getRefundStatusFailTest() {
        log.info("Entering into getRefundStatusFailTest() method....");


        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        String refundno = "12345";
        lenient().when(redBusPaymentRefundService.getRefundStatusEnquiry(Mockito.any())).thenReturn(null);
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsRefundController.getRefundStatusEnquiry(refundno, headers);
        assertEquals(1, expectConsentResponse.getBody().getMeta().getStatus());

        log.info("Execution completed getRefundStatusFailTest() method......");
    }

}