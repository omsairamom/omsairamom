package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.HeaderRequestDTO;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusFulFilmentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentEnquiry;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentService;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mockStatic;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class RedbusExternalPaymentsControllerTests extends CommonTestObjectUtil {


    @InjectMocks
    private RedBusExternalPaymentsController redBusExternalPaymentsController;

    @Mock
    private RedBusPaymentService redBusPaymentService;

    @Autowired
    private ObjectMapper objectMapper;

    @Mock
    private MessageSource messageSource;


    /**
     * Test the PostPaymentDetails success
     * Actual : "0"
     * Expected : "0"
     *
     * @throws Exception
     */

    private static MockedStatic<CommonUtil> mockedSettings;

    @BeforeClass
    public static void init() {
        mockedSettings = mockStatic(CommonUtil.class);
    }

    @AfterClass
    public static void close() {
        mockedSettings.close();

    }

    @Test
    public void postPaymentDetailsSuccessFullTest() throws Exception {
        log.info("Entering into postPaymentDetailsSuccessFullTest() method....");
        Map<String, String> headers = new HashMap<>();
        HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
        headerRequestDTO.setChannel("IOS");
        //  Mockito.when(redBusPaymentService.getFulfilmentStatusEnquiryFromPrId(Mockito.anyString(),Mockito.any())).thenReturn(getRedBusFulFilmentRespone());

        Mockito.when(redBusPaymentService.postDataToPaymentHub(Mockito.any(), Mockito.any())).thenReturn(getRedBusPaymentResponse());
        Mockito.when(CommonUtil.convertMaptoObject(headers)).thenReturn(headerRequestDTO);
        lenient().when(redBusPaymentService.postDataToPaymentHub(Mockito.any(), Mockito.any())).thenReturn(getRedBusPaymentResponse());
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsController.postPaymentDetails(getPaymentRequestDTO(), headers);

        assertEquals(0, Objects.requireNonNull(expectConsentResponse.getBody()).getMeta().getStatus());

        log.info("Execution completed postPaymentDetailsSuccessFullTest() method......");
    }


    /**
     * Test the PostPaymentDetails fail
     * Actual : "1"
     * Expected : "1"
     *
     * @throws Exception
     */

    @Test
    public void postPaymentDetailsFailsTest() throws Exception {
        log.info("Entering into postPaymentDetailsFailsTest() method....");

        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        Mockito.lenient().when(redBusPaymentService.postDataToPaymentHub(getPaymentRequestDTO(), getHeaderRequestDTO())).thenReturn(null);
        HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
        headerRequestDTO.setChannel("test");
        //  Mockito.when(redBusPaymentService.getFulfilmentStatusEnquiryFromPrId(Mockito.anyString(),Mockito.any())).thenReturn(getRedBusFulFilmentRespone());
        Mockito.when(CommonUtil.convertMaptoObject(Mockito.any())).thenReturn(headerRequestDTO);
        lenient().when(redBusPaymentService.postDataToPaymentHub(getPaymentRequestDTO(), getHeaderRequestDTO())).thenReturn(null);
        ResponseEntity<RestApiResponse> expectConsentResponses = redBusExternalPaymentsController.postPaymentDetails(getPaymentRequestDTO(), headers);//redBusExternalPaymentsController.postPaymentDetails(getPaymentRequestDTO(),headers);

        assertEquals(1, expectConsentResponses.getBody().getMeta().getStatus());

        log.info("Execution completed postPaymentDetailsFailsTest() method......");
    }


    /**
     * Test the GetPaymentStatus success
     * Actual : "0"
     * Expected : "0"
     *
     * @throws Exception
     */

    @Test
    public void getPaymentStatusEnquiryTest() throws Exception {
        log.info("Entering into getPaymentStatusSuccessTest() method....");

        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        String purposeRefNo = "12345";
        Mockito.when(redBusPaymentService.getPaymentStatusEnquiry(anyString())).thenReturn(getRedBusPaymentStatusResponse());
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsController.getPaymentStatusEnquiry(purposeRefNo, headers);
        assertEquals(0, expectConsentResponse.getBody().getMeta().getStatus());

        log.info("Execution completed getPaymentStatusSuccessTest() method......");
    }


    /**
     * Test the GetPaymentStatus fail
     * Actual : "1"
     * Expected : "1"
     *
     * @throws Exception
     */

    @Test
    public void getPaymentStatusEnquiryFailTest() throws Exception {
        log.info("Entering into getPaymentStatusFailTest() method....");


        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        String purposeRefno = "12345";
        Mockito.when(redBusPaymentService.getPaymentStatusEnquiry(anyString())).thenReturn(null);
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsController.getPaymentStatusEnquiry(purposeRefno, headers);
        assertEquals(1, expectConsentResponse.getBody().getMeta().getStatus());

        log.info("Execution completed getPaymentStatusFailTest() method......");
    }


    /**
     * Test the SaveRedBusBookingDetails success
     * Actual : "0"
     * Expected : "0"
     *
     * @throws Exception
     */

    @Test
    public void saveRedBusBookingDetailsSuccessTest() throws Exception {
        log.info("Entering into saveRedBusBookingDetailsSuccessTest() method....");


        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
        headerRequestDTO.setChannel("test");
        Mockito.when(CommonUtil.convertMaptoObject(headers)).thenReturn(headerRequestDTO);

        Mockito.when(redBusPaymentService.saveRedBusBookingDetails(Mockito.any(), Mockito.any())).thenReturn(getRedBusBookingResponse());
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsController.saveRedBusBookingDetails(getRedbusPaymentRequestDTO(), headers);
        assertEquals(0, expectConsentResponse.getBody().getMeta().getStatus());

        log.info("Execution completed saveRedBusBookingDetailsSuccessTest() method......");
    }


    /**
     * Test the SaveRedBusBookingDetails fail
     * Actual : "1"
     * Expected : "1"
     *
     * @throws Exception
     */

    @Test
    public void saveRedBusBookingDetailsFailTest() throws Exception {
        log.info("Entering into saveRedBusBookingDetailsFailTest() method....");

        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
        headerRequestDTO.setChannel("test");
        Mockito.when(CommonUtil.convertMaptoObject(headers)).thenReturn(headerRequestDTO);


        Mockito.when(redBusPaymentService.saveRedBusBookingDetails(Mockito.any(), Mockito.any())).thenReturn(null);
        ResponseEntity<RestApiResponse> expectConsentResponse = redBusExternalPaymentsController.saveRedBusBookingDetails(getRedbusPaymentRequestDTO(), headers);
        assertEquals(1, Objects.requireNonNull(expectConsentResponse.getBody()).getMeta().getStatus());

        log.info("Execution completed saveRedBusBookingDetailsFailTest() method......");
    }

    @Test
    public void getFulfilmentStatusEnquirySuccessTest() {
        log.info("Entering into getFulfilmentStatusSuccessTest() method....");

        String prID = "1234";
        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        Map<String, String> map = new HashMap<>();
        Mockito.when(CommonUtil.prepareFulfilmentStatus(Mockito.any())).thenReturn(map);
        HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
        headerRequestDTO.setChannel("test");
        Mockito.when(CommonUtil.convertMaptoObject(headers)).thenReturn(headerRequestDTO);
        lenient().when(CommonUtil.prepareFulfilmentStatus(Mockito.any())).thenReturn(map);
        RedBusFulFilmentResponse redBusFulFilamentResponse = new RedBusFulFilmentResponse();
        redBusFulFilamentResponse.setPurposeRefNo("test");
        redBusFulFilamentResponse.setPaymentStatus("test");
        redBusFulFilamentResponse.setPaymentRefId("test");
        redBusFulFilamentResponse.setFulfilmentDeepLinkUrl("test");
        Map<String, String> stringMap = new HashMap<>();
        stringMap.put("STATUS_CODE", "0");
        stringMap.put("STATUS_DESC", "Success");
        Map<String, Object> maps = new HashMap<>();
        maps.put("statusMap", stringMap);
        maps.put("fulfilmentResponse", redBusFulFilamentResponse);
        RedBusPaymentEnquiry redBusPaymentEnquiry = new RedBusPaymentEnquiry();
        redBusPaymentEnquiry.setMap(maps);
        redBusPaymentEnquiry.setRedBusFulFilmentResponse(redBusFulFilamentResponse);
        Mockito.when(redBusPaymentService.getFulfilmentStatusEnquiryFromPrId(anyString(), Mockito.any())).thenReturn(redBusPaymentEnquiry);
        ResponseEntity<RestApiResponse> expectGetFulfilmentStatus = redBusExternalPaymentsController.getFulfilmentStatusEnquiry(prID, headers);
        assertEquals(0, Objects.requireNonNull(expectGetFulfilmentStatus.getBody()).getMeta().getStatus());

        log.info("Execution completed getFulfilmentStatusSuccessTest() method......");
    }

    @Test
    public void getFulfilmentStatusEnquiryFailTest() {
        log.info("Entering into getFulfilmentStatusFailTest() method....");

        String prID = "1234";
        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        headers.put("channel", "ANDROID");

        Map<String, String> map = new HashMap<>();
        Mockito.when(CommonUtil.prepareFulfilmentStatus(Mockito.any())).thenReturn(map);
        HeaderRequestDTO headerRequestDTO = new HeaderRequestDTO();
        headerRequestDTO.setChannel("test");
        Mockito.when(CommonUtil.convertMaptoObject(headers)).thenReturn(headerRequestDTO);
        lenient().when(CommonUtil.prepareFulfilmentStatus(Mockito.any())).thenReturn(map);
        RedBusFulFilmentResponse redBusFulFilmentResponse = null;
        Map<String, String> stringMap = new HashMap<>();
        stringMap.put("STATUS_CODE", "0");
        stringMap.put("STATUS_DESC", "Success");
        Map<String, Object> maps = new HashMap<>();
        maps.put("statusMap", stringMap);
        maps.put("fulfilmentResponse", redBusFulFilmentResponse);
        RedBusPaymentEnquiry redBusPaymentEnquiry = new RedBusPaymentEnquiry();
        redBusPaymentEnquiry.setMap(maps);
        redBusPaymentEnquiry.setRedBusFulFilmentResponse(redBusFulFilmentResponse);
        Mockito.when(redBusPaymentService.getFulfilmentStatusEnquiryFromPrId(anyString(), Mockito.any())).thenReturn(redBusPaymentEnquiry);
        ResponseEntity<RestApiResponse> expectGetFulfilmentStatus = redBusExternalPaymentsController.getFulfilmentStatusEnquiry(prID, headers);
        assertEquals(1, expectGetFulfilmentStatus.getBody().getMeta().getStatus());

        log.info("Execution completed getFulfilmentStatusFailTest() method......");
    }

}

