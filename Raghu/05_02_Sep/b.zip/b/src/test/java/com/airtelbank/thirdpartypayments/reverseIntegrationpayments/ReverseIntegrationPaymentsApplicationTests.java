package com.airtelbank.thirdpartypayments.reverseIntegrationpayments;

public class ReverseIntegrationPaymentsApplicationTests {


}
