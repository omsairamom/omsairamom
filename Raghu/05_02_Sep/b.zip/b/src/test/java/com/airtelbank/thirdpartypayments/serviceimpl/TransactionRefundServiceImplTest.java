package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.model.TransactionStatusDetails;
import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.PaymentDetails;
import com.airtelbank.thirdpartypayments.model.TransactionRefundPaymentResponse;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundResponse;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class TransactionRefundServiceImplTest {

    @InjectMocks
    TransactionRefundServiceImpl transactionRefundService;
    @Mock
    private RefundDetailsRepo refundDetailsRepo;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    HttpUtil httpUtil;

    @Mock
    private Environment environment;

    @Mock
    private ValidationService validationService;

    @Test
    public void refundInitException() {
        try {
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.TEN);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID("test");
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);

            Mockito.when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            TransactionRefundResponse transactionRefundResponse = transactionRefundService.refundInit(transactionRefundRequest, "test");
            assertNotNull(transactionRefundResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void refundInitOrderStatusREFUNDFAILEDException() {
        try {
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.ONE);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            Mockito.when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            TransactionRefundPaymentResponse transactionRefundPaymentResponse = new TransactionRefundPaymentResponse();
            PaymentDetails paymentDetails = new PaymentDetails();
            paymentDetails.setAddParam1("test");
            paymentDetails.setAddParam2("test");
            paymentDetails.setPurposeRefNo("test");
            paymentDetails.setTotalAmount(BigDecimal.ONE);
            paymentDetails.setCustomerNumber("test");
            paymentDetails.setNarration("test");
            Map<String, String> map = new HashMap<>();
            map.put("test", "test");
            paymentDetails.setParamaters(map);
            paymentDetails.setPrId("test");
            paymentDetails.setPuporseCode("test");
            paymentDetails.setRefPrid("test");
            TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
            transactionStatusDetails.setAmount("test");
            transactionStatusDetails.setStatus("test");
            transactionStatusDetails.setErrorCode("test");
            transactionStatusDetails.setPurposeRefNo("test");
            transactionStatusDetails.setTransactionDateTime(new Date());
            transactionStatusDetails.setAccessToken("test");
            transactionStatusDetails.setFtTxnId("test");
            transactionStatusDetails.setDescription("test");
            transactionStatusDetails.setPaymentMode("test");
            transactionStatusDetails.setPgTxnId("test");
            List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
            transactionStatusDetails1.add(transactionStatusDetails);
            paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
            paymentDetails.setTxnMessage("test");
            paymentDetails.setType("test");
            paymentDetails.setPaymentsStatus(1);
            Meta meta = new Meta();
            meta.setCode("test");
            meta.setStatus(0);
            meta.setDescription("test");

            transactionRefundPaymentResponse.setData(paymentDetails);

            transactionRefundPaymentResponse.setMeta(meta);


            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(transactionRefundPaymentResponse);
            TransactionRefundResponse transactionRefundResponse = transactionRefundService.refundInit(transactionRefundRequest, "test");
            assertNotNull(transactionRefundResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void refundInit() throws ThirdPartyPaymentsException {
        TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
        transactionRefundRequest.setRefundTxnId("test");
        transactionRefundRequest.setHash("test");
        transactionRefundRequest.setAmount(BigDecimal.ONE);
        transactionRefundRequest.setFeSessionId("test");
        transactionRefundRequest.setMerchantTxnId("test");
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        Mockito.when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
        TransactionRefundPaymentResponse transactionRefundPaymentResponse = new TransactionRefundPaymentResponse();
        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddParam1("test");
        paymentDetails.setAddParam2("test");
        paymentDetails.setPurposeRefNo("test");
        paymentDetails.setTotalAmount(BigDecimal.ONE);
        paymentDetails.setCustomerNumber("test");
        paymentDetails.setNarration("test");
        Map<String, String> map = new HashMap<>();
        map.put("test", "test");
        paymentDetails.setParamaters(map);
        paymentDetails.setPrId("test");
        paymentDetails.setPuporseCode("test");
        paymentDetails.setRefPrid("test");
        TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
        transactionStatusDetails.setAmount("test");
        transactionStatusDetails.setStatus("test");
        transactionStatusDetails.setErrorCode("test");
        transactionStatusDetails.setPurposeRefNo("test");
        transactionStatusDetails.setTransactionDateTime(new Date());
        transactionStatusDetails.setAccessToken("test");
        transactionStatusDetails.setFtTxnId("test");
        transactionStatusDetails.setDescription("test");
        transactionStatusDetails.setPaymentMode("test");
        transactionStatusDetails.setPgTxnId("test");
        List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
        transactionStatusDetails1.add(transactionStatusDetails);
        paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
        paymentDetails.setTxnMessage("test");
        paymentDetails.setType("test");
        paymentDetails.setPaymentsStatus(0);
        Meta meta = new Meta();
        meta.setCode("test");
        meta.setStatus(0);
        meta.setDescription("test");

        transactionRefundPaymentResponse.setData(paymentDetails);

        transactionRefundPaymentResponse.setMeta(meta);


        Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(transactionRefundPaymentResponse);
        TransactionRefundResponse transactionRefundResponse = transactionRefundService.refundInit(transactionRefundRequest, "test");
        assertNotNull(transactionRefundResponse);


    }

    @Test
    public void refundInitFailed() {
        try {
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.ONE);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            Mockito.when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            TransactionRefundPaymentResponse transactionRefundPaymentResponse = new TransactionRefundPaymentResponse();
            PaymentDetails paymentDetails = new PaymentDetails();
            paymentDetails.setAddParam1("test");
            paymentDetails.setAddParam2("test");
            paymentDetails.setPurposeRefNo("test");
            paymentDetails.setTotalAmount(BigDecimal.ONE);
            paymentDetails.setCustomerNumber("test");
            paymentDetails.setNarration("test");
            Map<String, String> map = new HashMap<>();
            map.put("test", "test");
            paymentDetails.setParamaters(map);
            paymentDetails.setPrId("test");
            paymentDetails.setPuporseCode("test");
            paymentDetails.setRefPrid("test");
            TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
            transactionStatusDetails.setAmount("test");
            transactionStatusDetails.setStatus("test");
            transactionStatusDetails.setErrorCode("test");
            transactionStatusDetails.setPurposeRefNo("test");
            transactionStatusDetails.setTransactionDateTime(new Date());
            transactionStatusDetails.setAccessToken("test");
            transactionStatusDetails.setFtTxnId("test");
            transactionStatusDetails.setDescription("test");
            transactionStatusDetails.setPaymentMode("test");
            transactionStatusDetails.setPgTxnId("test");
            List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
            transactionStatusDetails1.add(transactionStatusDetails);
            paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
            paymentDetails.setTxnMessage("test");
            paymentDetails.setType("test");
            paymentDetails.setPaymentsStatus(0);
            Meta meta = new Meta();
            meta.setCode("test");
            meta.setStatus(1);
            meta.setDescription("test");

            transactionRefundPaymentResponse.setData(paymentDetails);

            transactionRefundPaymentResponse.setMeta(meta);


            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(transactionRefundPaymentResponse);
            TransactionRefundResponse transactionRefundResponse = transactionRefundService.refundInit(transactionRefundRequest, "test");
            assertNotNull(transactionRefundResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void refundInitwheretransactionrefundamountcompare() {
        try {
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.TEN);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            Mockito.when(orderDetailsRepo.getOne(Mockito.any())).thenReturn(order);
            TransactionRefundPaymentResponse transactionRefundPaymentResponse = new TransactionRefundPaymentResponse();
            PaymentDetails paymentDetails = new PaymentDetails();
            paymentDetails.setAddParam1("test");
            paymentDetails.setAddParam2("test");
            paymentDetails.setPurposeRefNo("test");
            paymentDetails.setTotalAmount(BigDecimal.ONE);
            paymentDetails.setCustomerNumber("test");
            paymentDetails.setNarration("test");
            Map<String, String> map = new HashMap<>();
            map.put("test", "test");
            paymentDetails.setParamaters(map);
            paymentDetails.setPrId("test");
            paymentDetails.setPuporseCode("test");
            paymentDetails.setRefPrid("test");
            TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
            transactionStatusDetails.setAmount("test");
            transactionStatusDetails.setStatus("test");
            transactionStatusDetails.setErrorCode("test");
            transactionStatusDetails.setPurposeRefNo("test");
            transactionStatusDetails.setTransactionDateTime(new Date());
            transactionStatusDetails.setAccessToken("test");
            transactionStatusDetails.setFtTxnId("test");
            transactionStatusDetails.setDescription("test");
            transactionStatusDetails.setPaymentMode("test");
            transactionStatusDetails.setPgTxnId("test");
            List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
            transactionStatusDetails1.add(transactionStatusDetails);
            paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
            paymentDetails.setTxnMessage("test");
            paymentDetails.setType("test");
            paymentDetails.setPaymentsStatus(0);
            Meta meta = new Meta();
            meta.setCode("test");
            meta.setStatus(1);
            meta.setDescription("test");

            transactionRefundPaymentResponse.setData(paymentDetails);

            transactionRefundPaymentResponse.setMeta(meta);


            Mockito.lenient().when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(transactionRefundPaymentResponse);
            TransactionRefundResponse transactionRefundResponse = transactionRefundService.refundInit(transactionRefundRequest, "test");
            assertNotNull(transactionRefundResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }

}