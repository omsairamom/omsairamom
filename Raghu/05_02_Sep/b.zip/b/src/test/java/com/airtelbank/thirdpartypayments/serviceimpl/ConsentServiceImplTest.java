package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.entity.CustomerConsentDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.aeroskipe.ConsentConfigDetails;
import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.model.consent.Consent;
import com.airtelbank.thirdpartypayments.model.consent.ConsentDetailsResponse;
import com.airtelbank.thirdpartypayments.model.consent.Data;
import com.airtelbank.thirdpartypayments.model.consent.Meta;
import com.airtelbank.thirdpartypayments.model.consent.request.CreateConsentRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;
import com.airtelbank.thirdpartypayments.repository.CustomerConsentDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.aerospike.ConsentConfigDetailRepo;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.CipherUtil;
import com.airtelbank.thirdpartypayments.util.CommonAppConsent;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class ConsentServiceImplTest {

    @InjectMocks
    private ConsentServiceImpl consentService;

    @Mock
    private ValidationService validationService;

    @Mock
    private HttpUtil httpUtil;

    @Mock
    ConsentConfigDetailRepo consentConfigDetailRepo;

    @Mock
    private CustomerConsentDetailsRepo mockCustomerConsentDetailsRepo;

    @Mock
    CipherUtil cipherUtil;

    @Mock
    MessageSource messageSource;


    @Before
    public void setUp() {

        log.info("Loading ConsentServiceImplTest......");

        ReflectionTestUtils.setField(consentService, "saveConsentUrl", "http://localhost");
        ReflectionTestUtils.setField(consentService, "getConsentUrl", "http://localhost");
        ReflectionTestUtils.setField(consentService, "pwaLink", "http://localhost");
        ReflectionTestUtils.setField(consentService, "encryptionKey", "redbus");
    }


    @Test
    public void createCustomerConsentAllowSuccessfulTest() throws ConsentException {

        log.info("Entering into createCustomerConsentAllowSuccessfulTest() method....");
        ConsentConfigDetails consentConfigDetails = new ConsentConfigDetails();
        consentConfigDetails.setAppId("tets");
        consentConfigDetails.setMobileNo("7388289284");
        Mockito.when(consentConfigDetailRepo.findById(Mockito.any())).thenReturn(Optional.of(consentConfigDetails));
        CustomerConsentRequest request = CommonTestObjectUtil.createCustomerRequest();
        CreateConsentRequest createConsentRequest = CommonTestObjectUtil.createConsentRequest(request);
        CustomerConsentDetailsEntity customerConsentDetailsEntity = CommonTestObjectUtil.getCustomerConsentDetailsEntity();
        Mockito.when(mockCustomerConsentDetailsRepo.findByAppId(Mockito.anyString())).thenReturn(customerConsentDetailsEntity);
        ConsentDetailsResponse consentDetailsResponse = CommonTestObjectUtil.consentDetailsResponses();
        Map<String, String> headers = CommonTestObjectUtil.createConsentHeader();
        // Mockito.when(httpUtil.hitRequest(CommonAppConsent.CREATE_CONSENT_URL, createConsentRequest, ConsentDetailsResponse.class, headers, HttpMethod.POST)).thenReturn(consentDetailsResponse);
        Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(consentDetailsResponse);
        ConsentDetailsResponse expectConsentDetailsResponse = consentService.createCustomerConsent(request,
                CommonAppConsent.CHANNEL, CommonAppConsent.CONTENT_ID, CommonAppConsent.USER_AGENT);
        assertEquals("0", expectConsentDetailsResponse.getMeta().getStatus().toString());

        log.info("Execution completed createCustomerConsentAllowSuccessfulTest() method......");

    }

    @Test
    public void createCustomerConsentAllowWithallowN() throws ConsentException {

        log.info("Entering into createCustomerConsentAllowSuccessfulTest() method....");

        CustomerConsentRequest request = CommonTestObjectUtil.createCustomerRequestwithconsentfalse();
        CreateConsentRequest createConsentRequest = CommonTestObjectUtil.createConsentRequest(request);
        CustomerConsentDetailsEntity customerConsentDetailsEntity = CommonTestObjectUtil.getCustomerConsentDetailsEntityAllowN();
        Mockito.when(mockCustomerConsentDetailsRepo.findByAppId(Mockito.anyString())).thenReturn(null);
        ConsentDetailsResponse consentDetailsResponse = CommonTestObjectUtil.consentDetailsResponses();
        Map<String, String> headers = CommonTestObjectUtil.createConsentHeader();
        Mockito.lenient().when(httpUtil.hitRequest(CommonAppConsent.CREATE_CONSENT_URL, createConsentRequest, ConsentDetailsResponse.class, headers, HttpMethod.POST)).thenReturn(consentDetailsResponse);
        ConsentConfigDetails consentConfigDetails = new ConsentConfigDetails();
        consentConfigDetails.setAppId("tets");
        consentConfigDetails.setMobileNo("7388289284");
        Mockito.when(consentConfigDetailRepo.findById(Mockito.any())).thenReturn(Optional.of(consentConfigDetails));
        ConsentDetailsResponse expectConsentDetailsResponse = consentService.createCustomerConsent(request,
                CommonAppConsent.CHANNEL, CommonAppConsent.CONTENT_ID, CommonAppConsent.USER_AGENT);
        assertNotNull(expectConsentDetailsResponse);

        log.info("Execution completed createCustomerConsentAllowSuccessfulTest() method......");

    }


    @Test
    public void createCustomerConsentWithoutConsent() throws ConsentException {

        log.info("Entering into createCustomerConsentAllowSuccessfulTest() method....");

        CustomerConsentRequest request = CommonTestObjectUtil.createCustomerRequestWithFalse();
        //  CreateConsentRequest createConsentRequest = CommonTestObjectUtil.createConsentRequest(request);
        CustomerConsentDetailsEntity customerConsentDetailsEntity = CommonTestObjectUtil.getCustomerConsentDetailsEntityWithFalseFlag();
        Mockito.when(mockCustomerConsentDetailsRepo.findByAppId(Mockito.anyString())).thenReturn(customerConsentDetailsEntity);

        ConsentDetailsResponse expectConsentDetailsResponse = consentService.createCustomerConsent(request,
                CommonAppConsent.CHANNEL, CommonAppConsent.CONTENT_ID, CommonAppConsent.USER_AGENT);
        assertNotNull(expectConsentDetailsResponse);
        log.info("Execution completed createCustomerConsentAllowSuccessfulTest() method......");

    }


    @Test
    public void createCustomerConsentAllowButDataNotPresentDBSuccessfulTest() throws ConsentException {

        log.info("Entering into createCustomerConsentAllowButDataNotPresentDBSuccessfulTest() method....");

        CustomerConsentRequest request = CommonTestObjectUtil.createCustomerRequest();
        CreateConsentRequest createConsentRequest = CommonTestObjectUtil.createConsentRequest(request);
        Mockito.when(mockCustomerConsentDetailsRepo.findByAppId(Mockito.anyString())).thenReturn(null);
        ConsentDetailsResponse consentDetailsResponse = CommonTestObjectUtil.consentDetailsResponses();
        Map<String, String> headers = CommonTestObjectUtil.createConsentHeader();
        ConsentConfigDetails consentConfigDetails = new ConsentConfigDetails();
        consentConfigDetails.setAppId("tets");
        consentConfigDetails.setMobileNo("7388289284");
        Mockito.when(consentConfigDetailRepo.findById(Mockito.any())).thenReturn(Optional.of(consentConfigDetails));
        // Mockito.when(httpUtil.hitRequest(CommonAppConsent.CREATE_CONSENT_URL, createConsentRequest, ConsentDetailsResponse.class, headers, HttpMethod.POST)).thenReturn(consentDetailsResponse);
        Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(consentDetailsResponse);
        ConsentDetailsResponse expectConsentDetailsResponse = consentService.createCustomerConsent(request,
                CommonAppConsent.CHANNEL, CommonAppConsent.CONTENT_ID, CommonAppConsent.USER_AGENT);
        assertEquals("0", expectConsentDetailsResponse.getMeta().getStatus().toString());

        log.info("Execution completed createCustomerConsentAllowButDataNotPresentDBSuccessfulTest() method......");
    }


    @Test
    public void getCustomerConsentSuccessfulTest() throws ConsentException {

        log.info("Entering into getCustomerConsentSuccessfulTest() method....");

        // Mockito.doNothing().when(validationService).validateCustomerConsent(Mockito.anyString());
        Map<String, String> headers = CommonTestObjectUtil.getConsentDetailsHeader();
        ConsentDetailsResponse consentDetailsResponse = new ConsentDetailsResponse();
        Meta responseMeta = new Meta();
        responseMeta.setCode("000");
        responseMeta.setStatus(0);
        consentDetailsResponse.setMeta(responseMeta);
        Data data = new Data();
        data.setDescription("test");
        data.setPwaLink("test");
        Consent consent = new Consent();
        consent.setConsent(true);
        consent.setMobileNumber(null);
        consent.setConsentType("REDBUS");
        consent.setConsentPurpose("To share customer mobile number with Redbus");
        consent.setConsentMode("MANUAL");
        consent.setConsentToken("d35ce44435d546e696e21bafe32e9f1127");
        consent.setConsentDescription("consentDescription");
        List<Consent> consentList = new ArrayList<>();
        consentList.add(consent);
        data.setConsents(consentList);
        consentDetailsResponse.setData(data);
        ConsentConfigDetails consentConfigDetails = new ConsentConfigDetails();
        consentConfigDetails.setAppId("tets");
        consentConfigDetails.setMobileNo("7388289284");
        Mockito.when(consentConfigDetailRepo.findById(Mockito.any())).thenReturn(Optional.of(consentConfigDetails));
        String encrptedMobileNo = "9182899929";
        Mockito.when(cipherUtil.encryptData(Mockito.any())).thenReturn(encrptedMobileNo);
        //  Mockito.when(httpUtil.hitRequest(CommonAppConsent.GET_CONSENT_URL, null, ConsentDetailsResponse.class, headers, HttpMethod.GET)).thenReturn(consentDetailsResponse);
        Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(consentDetailsResponse);
        Consent expectedConsentDetailsResponse = consentService.getCustomerConsent(CommonAppConsent.APP_ID, CommonAppConsent.CONTENT_ID, CommonAppConsent.CHANNEL, CommonAppConsent.USER_AGENT);
        assertNotNull(expectedConsentDetailsResponse);

        log.info("Execution completed getCustomerConsentSuccessfulTest() method......");
    }

    @Test
    public void getCustomerConsentException() throws ConsentException {
        try {
            log.info("Entering into getCustomerConsentSuccessfulTest() method....");
            Map<String, String> headers = CommonTestObjectUtil.getConsentDetailsHeader();
            ConsentDetailsResponse consentDetailsResponse = new ConsentDetailsResponse();
            Meta responseMeta = new Meta();
            responseMeta.setCode("000");
            responseMeta.setStatus(0);
            consentDetailsResponse.setMeta(responseMeta);
            Data data = new Data();
            data.setDescription("test");
            data.setPwaLink("test");
            Consent consent = new Consent();
            consent.setConsent(true);
            consent.setMobileNumber(null);
            consent.setConsentType("REDBUS");
            consent.setConsentPurpose("To share customer mobile number with Redbus");
            consent.setConsentMode("MANUAL");
            consent.setConsentToken("d35ce44435d546e696e21bafe32e9f1127");
            consent.setConsentDescription("consentDescription");
            List<Consent> consentList = new ArrayList<>();
            consentList.add(consent);
            data.setConsents(consentList);
            consentDetailsResponse.setData(data);
            String encrptedMobileNo = "9182899929";
            ConsentConfigDetails consentConfigDetails = new ConsentConfigDetails();
            consentConfigDetails.setAppId("tets");
            consentConfigDetails.setMobileNo("7388289284");
            Mockito.when(consentConfigDetailRepo.findById(Mockito.any())).thenReturn(Optional.of(consentConfigDetails));
            Mockito.lenient().when(cipherUtil.encryptData(Mockito.any())).thenReturn(encrptedMobileNo);
            //   Mockito.when(httpUtil.hitRequest(CommonAppConsent.GET_CONSENT_URL, null, ConsentDetailsResponse.class, headers, HttpMethod.GET)).thenReturn(null);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(consentDetailsResponse);
            Consent expectedConsentDetailsResponse = consentService.getCustomerConsent(CommonAppConsent.APP_ID, CommonAppConsent.CONTENT_ID, CommonAppConsent.CHANNEL, CommonAppConsent.USER_AGENT);
            assertNotNull(expectedConsentDetailsResponse);

            log.info("Execution completed getCustomerConsentSuccessfulTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void getCustomerConsentforConsentException() throws ConsentException {
        try {
            log.info("Entering into getCustomerConsentSuccessfulTest() method....");
            Map<String, String> headers = CommonTestObjectUtil.getConsentDetailsHeader();
            ConsentDetailsResponse consentDetailsResponse = new ConsentDetailsResponse();
            Meta responseMeta = new Meta();
            responseMeta.setCode("000");
            responseMeta.setStatus(0);
            consentDetailsResponse.setMeta(responseMeta);
            Data data = new Data();
            data.setDescription("test");
            data.setPwaLink("test");
            Consent consent = null;
            List<Consent> consentList = new ArrayList<>();
            consentList.add(consent);
            data.setConsents(consentList);
            consentDetailsResponse.setData(data);
            String encrptedMobileNo = "9182899929";
            Mockito.lenient().when(cipherUtil.encryptData(Mockito.any())).thenReturn(encrptedMobileNo);
            //    Mockito.when(httpUtil.hitRequest(CommonAppConsent.GET_CONSENT_URL, null, ConsentDetailsResponse.class, headers, HttpMethod.GET)).thenReturn(consentDetailsResponse);
            Mockito.when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(consentDetailsResponse);
            ConsentConfigDetails consentConfigDetails = new ConsentConfigDetails();
            consentConfigDetails.setAppId("tets");
            consentConfigDetails.setMobileNo("7388289284");
            Mockito.when(consentConfigDetailRepo.findById(Mockito.any())).thenReturn(Optional.of(consentConfigDetails));
            Consent expectedConsentDetailsResponse = consentService.getCustomerConsent(CommonAppConsent.APP_ID, CommonAppConsent.CONTENT_ID, CommonAppConsent.CHANNEL, CommonAppConsent.USER_AGENT);
            assertNotNull(expectedConsentDetailsResponse);

            log.info("Execution completed getCustomerConsentSuccessfulTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }
}

