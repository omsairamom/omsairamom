package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryRequest;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponse;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.serviceimpl.TransactionEnquiryServiceImpl;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class TransactionEnquiryServiceTests {

    @InjectMocks
    private TransactionEnquiryServiceImpl sut;

    @Mock
    OrderDetailsRepo orderDetailsRepo;

    @Mock
    RefundDetailsRepo refundDetailsRepo;

    @Mock
    HttpUtil httpUtil;

    @Mock
    private ValidationService validationService;

    @Mock
    private Environment environment;

    @Before
    public void setup() {
        log.info("Loading TransactionEnquiryServiceTests....");

        sut = new TransactionEnquiryServiceImpl();
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void teardown() {
        sut = null;
    }

    @Test
    public void testOrderDetailsIsCalledFromEnquiry() throws ThirdPartyPaymentsException {
        log.info("Started execution TransactionEnquiryServiceTests of testOrderDetailsIsCalledFromEnquiry() method....");

        TransactionEnquiryRequest request = new TransactionEnquiryRequest();
        request.setType("type");
        request.setMerchantTxnId("txnId");
        request.setFeSessionId("feSessionId");
        request.setRefundTxnId(null);
        request.setAmount(BigDecimal.valueOf(100.0));
        OrderDetailsEntity entityMock = new OrderDetailsEntity();
        Mockito.lenient().when(validationService.getClientSecret(anyString())).thenReturn("someSecret");
        when(orderDetailsRepo.findByMerchantTxnId(anyString())).thenReturn(entityMock);
        sut.enquiryInit(request, "appToken");
        verify(orderDetailsRepo, atLeastOnce()).findByMerchantTxnId(anyString());
    }


    @Test
    public void testForwardEnquiryResponseWhenPaymentIsCompleted() throws ThirdPartyPaymentsException {
        log.info("Started execution TransactionEnquiryServiceTests of testForwardEnquiryResponseWhenPaymentIsCompleted() method....");

        TransactionEnquiryRequest request = getFakeTxnEnquiryRequest(EnquiryType.FORWARD);
        OrderDetailsEntity entityMock = getFakeForwardOrderDetailsEntity(OrderStatus.PAYMENT_COMPLETED);
        Mockito.lenient().when(validationService.getClientSecret(anyString())).thenReturn("someSecret");
        when(orderDetailsRepo.findByMerchantTxnId(anyString())).thenReturn(entityMock);
        TransactionEnquiryResponse response = sut.enquiryInit(request, "appToken");
        assertEquals("enquiry type is wrong", "FORWARD", response.getTransactionDetails().get(0).getType());
        assertEquals("no of list elements are not equal", 1, response.getTransactionDetails().size());
        assertEquals("merhcnat Txn Id is not same", "txnId", response.getTransactionDetails().get(0).getTxnId());
        assertEquals("transaction status is wrong", "SUCCESS", response.getTransactionDetails().get(0).getStatus());
        verifyZeroInteractions(httpUtil);

    }

    @Test
    public void testForwardEnquiryResponseWhenPaymentIsNotCompleted() throws ThirdPartyPaymentsException {
        log.info("Started execution TransactionEnquiryServiceTests of testForwardEnquiryResponseWhenPaymentIsNotCompleted() method....");

        TransactionEnquiryRequest request = getFakeTxnEnquiryRequest(EnquiryType.FORWARD);
        OrderDetailsEntity entityMock = getFakeForwardOrderDetailsEntity(OrderStatus.PAYMENT_FAILED);

        Mockito.lenient().when(validationService.getClientSecret(anyString())).thenReturn("someSecret");
        when(orderDetailsRepo.findByMerchantTxnId(anyString())).thenReturn(entityMock);
        TransactionEnquiryResponse response = sut.enquiryInit(request, "appToken");
        assertEquals("no of list elements are not equal", 1, response.getTransactionDetails().size());
        assertEquals("merhcnat Txn Id is not same", "txnId", response.getTransactionDetails().get(0).getTxnId());
        assertEquals("enquiry type is wrong", "FORWARD", response.getTransactionDetails().get(0).getType());
        assertEquals("transaction status is wrong", "FAILURE", response.getTransactionDetails().get(0).getStatus());
        verifyZeroInteractions(httpUtil);
    }


    @Test
    public void testRefundEnquiryResponseWhenRefundIsCompleted() throws ThirdPartyPaymentsException {
        log.info("Started execution TransactionEnquiryServiceTests of testRefundEnquiryResponseWhenRefundIsCompleted() method....");

        TransactionEnquiryRequest request = getFakeTxnEnquiryRequest(EnquiryType.REFUND);

        TransactionRefundEntity entityMock = getFakeRefundEntity(OrderStatus.REFUNDED);

        List<TransactionRefundEntity> refundEntities = new ArrayList<>();
        refundEntities.add(entityMock);
        when(orderDetailsRepo.findByMerchantTxnId(anyString())).thenReturn(new OrderDetailsEntity());
        Mockito.lenient().when(validationService.getClientSecret(anyString())).thenReturn("someSecret");
        when(refundDetailsRepo.findByRefundTxnId(anyString())).thenReturn(refundEntities);

        TransactionEnquiryResponse response = sut.enquiryInit(request, "appToken");

        assertEquals("no of list elements are not equal", 1, response.getTransactionDetails().size());
        assertEquals("merhcnat Txn Id is not same", "txnId", response.getTransactionDetails().get(0).getMerchantTxnId());
        assertEquals("enquiry type is wrong", "REFUND", response.getTransactionDetails().get(0).getType());
        assertEquals("transaction status is wrong", "REFUNDED", response.getTransactionDetails().get(0).getStatus());
        verifyZeroInteractions(httpUtil);
    }

    @Test
    public void testRefundEnquiryResponseWhenRefundIsNotCompleted() throws ThirdPartyPaymentsException {
        log.info("Started execution TransactionEnquiryServiceTests of testRefundEnquiryResponseWhenRefundIsNotCompleted() method....");

        TransactionEnquiryRequest request = getFakeTxnEnquiryRequest(EnquiryType.REFUND);

        TransactionRefundEntity entityMock = getFakeRefundEntity(OrderStatus.REFUND_FAILED);

        List<TransactionRefundEntity> refundEntities = new ArrayList<>();
        refundEntities.add(entityMock);
        when(orderDetailsRepo.findByMerchantTxnId(anyString())).thenReturn(new OrderDetailsEntity());
        Mockito.lenient().when(validationService.getClientSecret(anyString())).thenReturn("someSecret");
        when(refundDetailsRepo.findByRefundTxnId(anyString())).thenReturn(refundEntities);
        TransactionEnquiryResponse response = sut.enquiryInit(request, "appToken");
        assertEquals("no of list elements are not equal", 1, response.getTransactionDetails().size());
        assertEquals("merhcnat Txn Id is not same", "txnId", response.getTransactionDetails().get(0).getMerchantTxnId());
        assertEquals("enquiry type is wrong", "REFUND", response.getTransactionDetails().get(0).getType());
        assertEquals("transaction status is wrong", "REFUND_FAILED", response.getTransactionDetails().get(0).getStatus());
        verifyZeroInteractions(httpUtil);
    }

    @Test
    public void testRefundEnquiryResponseWhenRefundTxnIdIsNull() throws ThirdPartyPaymentsException {
        log.info("Started execution TransactionEnquiryServiceTests of testRefundEnquiryResponseWhenRefundTxnIdIsNull() method....");

        TransactionEnquiryRequest request = getFakeTxnEnquiryRequest(EnquiryType.REFUND_WITHOUT_REFUND_TXN_ID);

        TransactionRefundEntity entityMock = getFakeRefundEntity(OrderStatus.REFUND_FAILED);

        List<TransactionRefundEntity> refundEntities = new ArrayList<>();
        refundEntities.add(entityMock);
        when(orderDetailsRepo.findByMerchantTxnId(anyString())).thenReturn(new OrderDetailsEntity());
        Mockito.lenient().when(validationService.getClientSecret(anyString())).thenReturn("someSecret");
        when(refundDetailsRepo.findByMerchantTxnId(anyString())).thenReturn(refundEntities);
        TransactionEnquiryResponse response = sut.enquiryInit(request, "appToken");
        assertEquals("no of list elements are not equal", 1, response.getTransactionDetails().size());
        assertEquals("merhcnat Txn Id is not same", "txnId", response.getTransactionDetails().get(0).getMerchantTxnId());
        assertEquals("enquiry type is wrong", "REFUND", response.getTransactionDetails().get(0).getType());
        assertEquals("transaction status is wrong", "REFUND_FAILED", response.getTransactionDetails().get(0).getStatus());
        verifyZeroInteractions(httpUtil);
    }

    private TransactionRefundEntity getFakeRefundEntity(OrderStatus status) {
        log.info("Started execution TransactionEnquiryServiceTests of getFakeRefundEntity() method....");

        TransactionRefundEntity entityMock = new TransactionRefundEntity();
        entityMock.setUpdationDate(new Date());

        entityMock.setMerchantTxnId("txnId");
        entityMock.setRefundTxnId("refundTxnId");
        switch (status) {
            case REFUNDED:
                entityMock.setRefundStatus(OrderStatus.REFUNDED.toString());
                break;
            case REFUND_FAILED:
                entityMock.setRefundStatus(OrderStatus.REFUND_FAILED.toString());
                break;

            case REFUND_INITIATED:
                entityMock.setRefundStatus(OrderStatus.REFUND_INITIATED.toString());

                break;
            default:
                entityMock.setRefundStatus(OrderStatus.REFUND_FAILED.toString());
                break;
        }

        return entityMock;
    }


    private OrderDetailsEntity getFakeForwardOrderDetailsEntity(OrderStatus status) {
        log.info("Started execution TransactionEnquiryServiceTests of getFakeForwardOrderDetailsEntity() method....");

        OrderDetailsEntity entityMock = new OrderDetailsEntity();
        entityMock.setUpdationDate(new Date());
        entityMock.setMerchantTxnId("txnId");
        entityMock.setStatus(status);
        return entityMock;
    }

    private TransactionEnquiryRequest getFakeTxnEnquiryRequest(EnquiryType enquiryType) {
        log.info("Started execution TransactionEnquiryServiceTests of getFakeTxnEnquiryRequest() method....");

        TransactionEnquiryRequest request = new TransactionEnquiryRequest();
        request.setMerchantTxnId("txnId");
        request.setFeSessionId("feSessionId");
        request.setAmount(BigDecimal.valueOf(100.0));

        switch (enquiryType) {
            case FORWARD:
                request.setType("FORWARD");
                request.setRefundTxnId(null);
                break;
            case REFUND:
                request.setType("REFUND");
                request.setRefundTxnId("refundTxnId");
                break;
            case REFUND_WITHOUT_REFUND_TXN_ID:
                request.setType("REFUND");
                request.setRefundTxnId(null);
                break;
            default:
                request.setType("REFUND");
                request.setRefundTxnId("refundTxnId");
                break;
        }

        return request;
    }


    enum EnquiryType {
        FORWARD,
        REFUND,
        REFUND_WITHOUT_REFUND_TXN_ID
    }
}


