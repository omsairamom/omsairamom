package com.airtelbank.thirdpartypayments.util;

/**
 * Define test case related constants
 */
public class CommonAppConsent {

    public static String GET_CONSENT_URL = "http://10.56.110.189:3109/v3/consents?appId=d35ce44435d546e696e21bafe32e9f1127";
    public static String CREATE_CONSENT_URL = "http://10.56.110.189:3109/v3/consents";
    public static String CHANNEL = "CUSTOMER";
    public static String CONTENT_ID = "1611830313573";
    public static String CUSTOMER_HANDLE_TYPE = "MER";
    public static String CONTENT_TYPE = "application/json";
    public static String USER_AGENT = "userAgent";
    public static String CUSTOMER_HANDLE_NUMBER = "9742011234";
    public static String APP_ID = "d35ce44435d546e696e21bafe32e9f1127";
    public static String PAYMENT_UPDATE_URL = "https://paaspreprod.redbus.com/PGResponse/AirtelResponse";
    public static String UPDATE_REFUND_URL = "https://irispublic.redbus.com/stream/Airtelrefundcallback";
}
