package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.service.ConsentService;
import com.airtelbank.thirdpartypayments.serviceimpl.ValidationServiceImpl;
import com.airtelbank.thirdpartypayments.util.CommonAppConsent;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import java.util.Objects;

import static org.junit.Assert.assertEquals;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class ConsentControllerTest extends CommonAppConsent {

    @InjectMocks
    private ConsentController consentController;

    @Mock
    private ConsentService consentService;

    @Mock
    ValidationServiceImpl validationService;

    @Test
    public void testGetConsentDetails() throws ConsentException {

        log.info("Entering into testGetConsentDetails() method....");

        Mockito.doNothing().when(validationService).validateRequestParam(Mockito.any());
        Mockito.when(consentService.getCustomerConsent(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(CommonTestObjectUtil.consentDetailsResponse());
        ResponseEntity<RestApiResponse> expectConsentResponse = consentController.getConsentDetails("9584115077", CommonTestObjectUtil.getConsentDetailsHeader());
        assertEquals(0, Objects.requireNonNull(expectConsentResponse.getBody()).getMeta().getStatus());

        log.info("Execution completed testGetConsentDetails() method......");
    }


    @Test
    public void testCreateConsent() throws ConsentException {

        log.info("Entering into testCreateConsent() method....");

        Mockito.doNothing().when(validationService).validateRequestParam(Mockito.any());
        Mockito.when(consentService.createCustomerConsent(Mockito.any(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(CommonTestObjectUtil.consentDetailsResponses());
        ResponseEntity<RestApiResponse> expectConsentResponse = consentController.saveConsent(CommonTestObjectUtil.createCustomerConsentRequest(), CommonTestObjectUtil.getConsentDetailsHeader());
        assertEquals(0, Objects.requireNonNull(expectConsentResponse.getBody()).getMeta().getStatus());

        log.info("Execution completed testCreateConsent() method......");
    }

}
