package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.InitiatePaymentResponse;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionDetailsRequest;
import com.airtelbank.thirdpartypayments.repository.OrderAmountDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.serviceimpl.PaymentInitializationServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class PaymentInitializationServiceTests {

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    private OrderAmountDetailsRepo orderAmountDetailsRepo;

    @Mock
    private ValidationService validationService;

    @InjectMocks
    private PaymentInitializationServiceImpl sut;

    @Before
    public void setup() {
        log.info("Loading PaymentInitializationServiceTests....");

        sut = new PaymentInitializationServiceImpl();
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void teardown() {
        sut = null;
    }

    @Test
    public void testValidationServiceIsCalledOnPaymentInit() throws Exception {
        log.info("Started execution PaymentInitializationServiceTests of testValidationServiceIsCalledOnPaymentInit() method....");

        PaymentRequest paymentRequest = createPaymentRequestStub();
        String customerId = "9000000000";
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        when(validationService.validateMerchant(any(), any())).thenReturn(entity);
        sut.paymentInitialize(createPaymentRequestStub(), customerId);
        verify(validationService, atLeast(1)).validateMerchant(any(), any(String.class));
    }

    @Test
    public void testOrderDetailsAreRightlySetInPaymentInitializationResponse() throws Exception {
        log.info("Started execution PaymentInitializationServiceTests  of testOrderDetailsAreRightlySetInPaymentInitializationResponse() method....");

        PaymentRequest request = createPaymentRequestStub();
        String customerId = "90000000000";
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        when(validationService.validateMerchant(request, customerId)).thenReturn(entity);
        InitiatePaymentResponse paymentResponse = sut.paymentInitialize(request, customerId);
        assertNotNull("merchant Txn Id is null", paymentResponse.getOrderDetails().getMerchantTxnId());
        assertNotNull("order detials custom entries list in empty", paymentResponse.getOrderDetails().getDetails());
        CustomEntry entry = paymentResponse.getOrderDetails().getDetails().get(0);
        String[] expectedOutput = {"key", "amount"};
        String[] methodOutput = {entry.getKey(), entry.getDisplayText()};
        assertArrayEquals("InitiatePaymentResponse->orderDetials[0]->CustomEntry data does not match", expectedOutput,
                methodOutput);
    }

    @Test
    public void testInitializationResponseFirstLevelDataAreSetWithRightValues() throws Exception {
        log.info("Started execution PaymentInitializationServiceTests of testInitializationResponseFirstLevelDataAreSetWithRightValues() method....");

        PaymentRequest request = createPaymentRequestStub();
        String customerId = "90000000000";
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        when(validationService.validateMerchant(request, customerId)).thenReturn(entity);
        InitiatePaymentResponse paymentResponse = sut.paymentInitialize(request, customerId);
        String[] expectedOutput = {"lob", "circle", "OYO"};
        String[] methodOutput = {paymentResponse.getLobID(), paymentResponse.getCircleID(), paymentResponse.getPurposeCode()};
        assertArrayEquals("InitiatePaymentResponse data data does not match", expectedOutput,
                methodOutput);
    }

    public PaymentRequest createPaymentRequestStub() {
        log.info("Started execution PaymentInitializationServiceTests of createPaymentRequestStub() method....");

        PaymentRequest request = new PaymentRequest();
        Map<String, BigDecimal> entry = new HashMap<>();

        entry.put("amount", new BigDecimal("100.0"));
        request.setAmountDetails(entry);
        request.setAmount(new BigDecimal("100.0"));
        request.setHash("somehash");

        TransactionDetailsRequest txnDetReq = new TransactionDetailsRequest();
        txnDetReq.setMerchantTxnId("123456");
        List<CustomEntry> details = new ArrayList<CustomEntry>();
        details.add(new CustomEntry("key", "100.0", "amount"));
        txnDetReq.setDetails(details);

        request.setTransactionDetailsRequest(txnDetReq);
        return request;
    }
}
