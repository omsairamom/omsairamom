package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionDetailsRequest;
import com.airtelbank.thirdpartypayments.repository.MerchantOAuthDetailsRepository;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.serviceimpl.ValidationServiceImpl;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class ValidationServiceTests extends CommonTestObjectUtil {

    @InjectMocks
    private ValidationServiceImpl validationServiceImpl;

    @Mock
    private MerchantOAuthDetailsRepository merchantOAuthDetailsRepository;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    private Environment environment;

    @Mock
    private RefundDetailsRepo refundDetailsRepo;

    @Mock
    private HttpUtil httpUtil;

    @Mock
    private MerchantTransactionDetailsRepo merchantTransactionDetailsRepo;


    @Before
    public void setup() {
        log.info("Loading ValidationServiceTests....");

        MockitoAnnotations.initMocks(this);
    }

    @Test()
    public void testMerchantValidation() throws ThirdPartyPaymentsException {
        log.info("Started execution ValidationServiceTests of testMerchantValidation() method....");

        PaymentRequest request = new PaymentRequest();
        TransactionDetailsRequest txnDetReq = new TransactionDetailsRequest();
        txnDetReq.setMerchantTxnId("123456");
        request.setTransactionDetailsRequest(txnDetReq);
        request.setAmount(new BigDecimal("100.0"));
        request.setHash("somehash");

        String customerId = "9000000000";

        Mockito.lenient().when(orderDetailsRepo.getOne(Mockito.anyString())).thenReturn(getOrderDetailsEntityDetails());

        try {
            validationServiceImpl.validateMerchant(request, customerId);
        } catch (ThirdPartyPaymentsException e) {
            assertEquals(ResponseErrorCode.DUPLICATE_MERCHANTTXNID, e.getErrorCode());
        }
    }
}
