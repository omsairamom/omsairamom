package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.model.TransactionStatusDetails;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class PostPaymentProcessingServiceImplTest {

    @InjectMocks
    PostPaymentProcessingServiceImpl postPaymentProcessingService;
    @Mock
    private OrderService orderService;

    @Mock
    private MerchantTransactionDetailsRepo merchantTransactionDetailsRepo;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Test
    public void processPayment() throws ThirdPartyPaymentsException {
        com.airtelbank.payments.model.PaymentDetails paymentDetails = new com.airtelbank.payments.model.PaymentDetails();
        paymentDetails.setAddParam1("test");
        paymentDetails.setAddParam2("test");
        paymentDetails.setPurposeRefNo("test");
        paymentDetails.setTotalAmount(BigDecimal.ONE);
        paymentDetails.setCustomerNumber("test");
        paymentDetails.setNarration("test");
        Map<String, String> map = new HashMap<>();
        map.put("test", "test");
        paymentDetails.setParamaters(map);
        paymentDetails.setPrId("test");
        paymentDetails.setPuporseCode("test");
        paymentDetails.setRefPrid("test");
        TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
        transactionStatusDetails.setAmount("test");
        transactionStatusDetails.setStatus("test");
        transactionStatusDetails.setErrorCode("test");
        transactionStatusDetails.setPurposeRefNo("test");
        transactionStatusDetails.setTransactionDateTime(new Date());
        transactionStatusDetails.setAccessToken("test");
        transactionStatusDetails.setFtTxnId("test");
        transactionStatusDetails.setDescription("test");
        transactionStatusDetails.setPaymentMode("test");
        transactionStatusDetails.setPgTxnId("test");
        List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
        transactionStatusDetails1.add(transactionStatusDetails);
        paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
        paymentDetails.setTxnMessage("test");
        paymentDetails.setType("test");

        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        postPaymentProcessingService.processPayment(paymentDetails);
        Mockito.verify(orderService, Mockito.times(1)).confirmOrder(Mockito.any(), Mockito.any());


    }

    @Test
    public void processPaymentwhereorderpridisnull() throws ThirdPartyPaymentsException {
        com.airtelbank.payments.model.PaymentDetails paymentDetails = new com.airtelbank.payments.model.PaymentDetails();
        paymentDetails.setAddParam1("test");
        paymentDetails.setAddParam2("test");
        paymentDetails.setPurposeRefNo("test");
        paymentDetails.setTotalAmount(BigDecimal.ONE);
        paymentDetails.setCustomerNumber("test");
        paymentDetails.setNarration("test");
        Map<String, String> map = new HashMap<>();
        map.put("test", "test");
        paymentDetails.setParamaters(map);
        paymentDetails.setPrId("test");
        paymentDetails.setPuporseCode("test");
        paymentDetails.setRefPrid("test");
        TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
        transactionStatusDetails.setAmount("test");
        transactionStatusDetails.setStatus("test");
        transactionStatusDetails.setErrorCode("test");
        transactionStatusDetails.setPurposeRefNo("test");
        transactionStatusDetails.setTransactionDateTime(new Date());
        transactionStatusDetails.setAccessToken("test");
        transactionStatusDetails.setFtTxnId("test");
        transactionStatusDetails.setDescription("test");
        transactionStatusDetails.setPaymentMode("test");
        transactionStatusDetails.setPgTxnId("test");
        List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
        transactionStatusDetails1.add(transactionStatusDetails);
        paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
        paymentDetails.setTxnMessage("test");
        paymentDetails.setType("test");

        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        postPaymentProcessingService.processPayment(paymentDetails);
        Mockito.verify(orderService, Mockito.times(1)).confirmOrder(Mockito.any(), Mockito.any());

    }
}