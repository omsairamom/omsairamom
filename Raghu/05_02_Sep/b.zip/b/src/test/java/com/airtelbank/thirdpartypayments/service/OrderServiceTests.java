package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomActions;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.model.order.OrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsTxnRepo;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationService;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationServiceFactory;
import com.airtelbank.thirdpartypayments.serviceimpl.OrderServiceImpl;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class OrderServiceTests extends CommonTestObjectUtil {

    @Mock
    private OrderConfirmationServiceFactory orderConfirmationServiceFactory;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    private TransactionRefundService refundService;

    @Mock
    private OrderDetailsTxnRepo orderDetailsTxnRepo;

    @Mock
    private MerchantTransactionDetailsRepo merchantRepo;

    @InjectMocks
    private OrderServiceImpl sut;

    @Before
    public void setup() {
        log.info("Loading OrderServiceTests....");

        sut = new OrderServiceImpl();
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void teardown() {
        sut = null;
    }

    @Test
    public void validConfirmationResponseShouldCallRepoSave() throws ThirdPartyPaymentsException {

        log.info("Started execution OrderServiceTests of validConfirmationResponseShouldCallRepoSave() method....");

        OrderDetailsEntity entity = getOrderDetailsEntity();
        MerchantTransactionDetailsEntity merTxnDetEntity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").merchantId("OYO").build();
        OrderConfirmationService orderConfirmationService = mock(OrderConfirmationService.class);
        Mockito.when(orderConfirmationService.doConfirm(any(), any())).thenReturn(getOrderConfirmationResponse(DefaultOrderConfirmationResponceType.Success));
        Mockito.when(orderConfirmationServiceFactory.getOrderConfirmationService("DEFAULT"))
                .thenReturn(orderConfirmationService);
        Mockito.when(orderDetailsRepo.save(Mockito.any())).thenReturn(getOrderDetailsEntity());
        ArgumentCaptor<OrderDetailsEntity> captor = ArgumentCaptor.forClass(OrderDetailsEntity.class);
        sut.confirmOrder(new OrderDetailsEntity(), new MerchantTransactionDetailsEntity());
        verify(orderDetailsRepo, times(1)).save(captor.capture());

    }

    private OrderDetailsEntity getOrderDetailsEntity() {
        log.info("Started execution OrderServiceTests of getOrderDetailsEntity() method....");

        OrderDetailsEntity entity = OrderDetailsEntity.builder().amount(new BigDecimal("100.0"))
                .customerId("0000000000").merchantId("OYO").merchantTxnId("txnId").prID("prid")
                .purposeRefNo("purposeRef").build();
        return entity;
    }

    public DefaultOrderConfirmationResponce getOrderConfirmationResponse(DefaultOrderConfirmationResponceType type) {
        log.info("Started execution OrderServiceTests of getOrderConfirmationResponse() method....");

        DefaultOrderConfirmationResponce response = null;

        CustomActions entry = new CustomActions();
        entry.setKey("actionKey");
        entry.setValue("actionValue");
        entry.setDisplayText("actionDisplayText");
        List<CustomActions> actionList = new ArrayList<CustomActions>();
        actionList.add(entry);

        CustomEntry detailsEntry = new CustomEntry("detailKey", "detailValue", "detailsDisplayText");
        List<CustomEntry> detailsList = new ArrayList<CustomEntry>();
        detailsList.add(detailsEntry);

        switch (type) {
            case Success:
                OrderConfirmationResponce confResponse = null;
                Meta meta = new Meta();
                meta.setCode("000");
                meta.setStatus(0);
                meta.setDescription("Success");

                confResponse = OrderConfirmationResponce.builder().details(detailsList).actions(actionList)
                        .merchantTxnId("1234567890").build();
                response = DefaultOrderConfirmationResponce.builder().meta(meta).data(confResponse).build();
                break;
            case Type2:

                break;
            case Type3:

                break;
            case Type4:

                break;
            default:

                break;
        }

        return response;
    }


    enum DefaultOrderConfirmationResponceType {
        Success, Type2, Type3, Type4;
    }

}
