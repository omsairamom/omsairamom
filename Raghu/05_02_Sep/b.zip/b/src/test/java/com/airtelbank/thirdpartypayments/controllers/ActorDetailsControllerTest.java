package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.ActorResponse;
import com.airtelbank.thirdpartypayments.model.Customer;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import java.util.Objects;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class ActorDetailsControllerTest {

    @InjectMocks
    ActorDetailsController actorDetailsController;

    @Mock
    private PaymentService paymentService;

    @Mock
    LoggerModel loggerModel;

    @Test
    public void getPurposeDetails() throws ThirdPartyPaymentsException {
        ActorResponse actorResponse = new ActorResponse();
        Customer customer = new Customer();
        customer.setCustType("test");
        customer.setAccNumber("test");
        customer.setMsisdn("test");
        customer.setName("test");
        customer.setSegment("test");
        customer.setProductCode("test");
        actorResponse.setCustomer(customer);
        actorResponse.setDiffParameter1("test");
        actorResponse.setDiffParameter2("test");
        actorResponse.setFromNarration("test");
        actorResponse.setFromSms("test");
        actorResponse.setRequestTimestamp("test");
        actorResponse.setToNarration("test");
        actorResponse.setTxnAmount("test");
        Mockito.when(paymentService.sendPurposeDetails(Mockito.any(), Mockito.any())).thenReturn(actorResponse);
        ResponseEntity<RestApiResponse> restApiResponseResponseEntity = actorDetailsController.getPurposeDetails("test", "test");
        assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());

    }
}