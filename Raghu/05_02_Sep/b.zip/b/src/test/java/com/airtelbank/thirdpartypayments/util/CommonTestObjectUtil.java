package com.airtelbank.thirdpartypayments.util;

import com.airtelbank.payments.hub.client.dto.kafka.PaymentStatus;
import com.airtelbank.payments.hub.client.dto.kafka.RefundStatus;
import com.airtelbank.payments.hub.client.dto.response.PaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.RefundResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.model.RefundStatusDetails;
import com.airtelbank.payments.hub.client.model.TransactionDetails;
import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.entity.CustomerConsentDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.model.consent.ConsentDetailsResponse;
import com.airtelbank.thirdpartypayments.model.consent.Meta;
import com.airtelbank.thirdpartypayments.model.consent.request.Consent;
import com.airtelbank.thirdpartypayments.model.consent.request.CreateConsentRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.Data;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.CustomerDetailsPaymentRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.HeaderRequestDTO;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.PaymentRefundRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.RedBusPaymentRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusBookingResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusFulFilmentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentStatusResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaPaymentResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaRefundResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * In this class, create the data object for test case
 * this class use for the test cases.
 */
public class CommonTestObjectUtil {

    public static CreateConsentRequest createConsentRequest() {
        CreateConsentRequest createConsentRequest = new CreateConsentRequest();
        Data data = new Data();
        List<Consent> listConsent = new ArrayList<>();
        Consent consent = new Consent();
        consent.setConsent(true);
        consent.setMobileNumber("7838659104");
        consent.setConsentMode("MANUAL");
        listConsent.add(consent);
        data.setConsents(listConsent);
        createConsentRequest.setData(data);

        com.airtelbank.thirdpartypayments.model.consent.request.Meta meta = new com.airtelbank.thirdpartypayments.model.consent.request.Meta();
        meta.setAppId("123");
        meta.setAppId("REDBUS-2");
        createConsentRequest.setMeta(meta);
        return createConsentRequest;
    }


    public static CreateConsentRequest createConsentRequestWithNullMobile() {
        CreateConsentRequest createConsentRequest = new CreateConsentRequest();
        Consent consent = new Consent();
        consent.setConsent(true);
        consent.setMobileNumber(null);
        consent.setConsentType("REDBUS");
        consent.setConsentPurpose("To share customer mobile number with Redbus");
        consent.setConsentMode("MANUAL");
        consent.setConsentToken("d35ce44435d546e696e21bafe32e9f1127");
        consent.setConsentDescription("consentDescription");
        return createConsentRequest;
    }


    public static com.airtelbank.thirdpartypayments.model.consent.Consent consentDetailsResponse() {
        com.airtelbank.thirdpartypayments.model.consent.Consent consentDetailsResponse = new com.airtelbank.thirdpartypayments.model.consent.Consent();
        consentDetailsResponse.setConsent(true);
        consentDetailsResponse.setConsentMode("test");
        consentDetailsResponse.setConsentDescription("test");
        consentDetailsResponse.setConsentToken("test");
        consentDetailsResponse.setConsentType("test");
        consentDetailsResponse.setConsentPurpose("test");
        consentDetailsResponse.setMobileNumber("7738389280");
        consentDetailsResponse.setPwaLink("http://localhost:8080");
        consentDetailsResponse.setCreatedDate(new Date().toString());
        return consentDetailsResponse;
    }


    public static ConsentDetailsResponse consentDetailsResponseWithFalseFlag() {
        ConsentDetailsResponse consentDetailsResponse = new ConsentDetailsResponse();
        com.airtelbank.thirdpartypayments.model.consent.Meta responseMeta = new com.airtelbank.thirdpartypayments.model.consent.Meta();
        responseMeta.setCode("000");
        responseMeta.setStatus(0);
        consentDetailsResponse.setMeta(responseMeta);
        com.airtelbank.thirdpartypayments.model.consent.Data data = new com.airtelbank.thirdpartypayments.model.consent.Data();
        data.setPwaLink("http");
        data.setDescription("Data Saved Successfully");
        consentDetailsResponse.setData(data);
        return consentDetailsResponse;
    }

    public static Map<String, String> createConsentHeader() {
        Map<String, String> headers = new HashMap<>();
        headers.put(AppConstants.CHANNEL_KEY, "CUSTOMER");
        headers.put(AppConstants.CONTENT_ID_KEY, "1611830313573");
        //headers.put(AppConstants.CONTENT_HANDLE_TYPE, "MER");
        headers.put(AppConstants.CONTENT_TYPE, "application/json");
        //headers.put(AppConstants.CUSTOMER_HANDLE_NUMBER, "9742011234");
        return headers;
    }

    public static Map<String, String> getConsentDetailsHeader() {
        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234567");
        headers.put("channel", "IOS");
        headers.put("user-agent", "ANDROID");
        return headers;
    }

    public static CustomerConsentRequest createCustomerConsentRequest() {

        CustomerConsentRequest customerConsentRequest = new CustomerConsentRequest();
        customerConsentRequest.setConsent(true);
        customerConsentRequest.setMobileNumber("1234567890");
        customerConsentRequest.setConsentType("consent-type");
        customerConsentRequest.setConsentPurpose("consent-purpose");
        customerConsentRequest.setConsentMode("consent-mode");
        customerConsentRequest.setConsentDescription("consent-description");
        customerConsentRequest.setValidTill("validity");
        return customerConsentRequest;
    }

    public static CustomerConsentRequest createCustomerRequest() {
        CustomerConsentRequest request = new CustomerConsentRequest();
        request.setConsent(true);
        request.setMobileNumber("7838659104");
        request.setConsentType("REDBUS-2");
        request.setConsentPurpose("To share customer mobile number with Redbus");
        request.setConsentMode("MANUAL");
        request.setConsentDescription("To share customer mobile number with Redbus");
        request.setValidTill("123");
        return request;
    }

    public static CustomerConsentRequest createCustomerRequestwithconsentfalse() {
        CustomerConsentRequest request = new CustomerConsentRequest();
        request.setConsent(false);
        request.setMobileNumber("7838659104");
        request.setConsentType("REDBUS-2");
        request.setConsentPurpose("To share customer mobile number with Redbus");
        request.setConsentMode("MANUAL");
        request.setConsentDescription("To share customer mobile number with Redbus");
        request.setValidTill("123");
        return request;
    }

    public static CustomerConsentRequest createCustomerRequestWithFalse() {
        CustomerConsentRequest request = new CustomerConsentRequest();
        request.setConsent(false);
        request.setMobileNumber("7838659104");
        request.setConsentType("REDBUS-2");
        request.setConsentPurpose("To share customer mobile number with Redbus");
        request.setConsentMode("MANUAL");
        request.setConsentDescription("To share customer mobile number with Redbus");
        request.setValidTill("123");
        return request;
    }

    public static CreateConsentRequest createConsentRequest(CustomerConsentRequest request) {
        CreateConsentRequest createConsentRequest = new CreateConsentRequest();
        Data data = new Data();
        List<Consent> listConsent = new ArrayList<>();
        Consent consent = new Consent();
        consent.setConsent(request.getConsent());
        consent.setMobileNumber(request.getMobileNumber());
        consent.setConsentType(request.getConsentType());
        consent.setConsentPurpose(request.getConsentPurpose());
        consent.setConsentMode(request.getConsentMode());
        consent.setConsentDescription(request.getConsentDescription());
        consent.setValidityTill(request.getValidTill());
        listConsent.add(consent);
        data.setConsents(listConsent);
        createConsentRequest.setData(data);
        com.airtelbank.thirdpartypayments.model.consent.request.Meta meta = new com.airtelbank.thirdpartypayments.model.consent.request.Meta();
        meta.setAppType(request.getConsentType());
        createConsentRequest.setMeta(meta);
        return createConsentRequest;
    }

    public static CustomerConsentDetailsEntity getCustomerConsentDetailsEntity() {
        CustomerConsentDetailsEntity customerConsentDetailsEntity = new CustomerConsentDetailsEntity();
        customerConsentDetailsEntity.setId(1L);
        customerConsentDetailsEntity.setConsentAllow("Y");
        customerConsentDetailsEntity.setConsentDescription("Test");
        customerConsentDetailsEntity.setAppType("RedBus");
        return customerConsentDetailsEntity;
    }

    public static CustomerConsentDetailsEntity getCustomerConsentDetailsEntityAllowN() {
        CustomerConsentDetailsEntity customerConsentDetailsEntity = new CustomerConsentDetailsEntity();
        customerConsentDetailsEntity.setId(1L);
        customerConsentDetailsEntity.setConsentAllow("N");
        customerConsentDetailsEntity.setConsentDescription("Test");
        customerConsentDetailsEntity.setAppType("RedBus");
        return customerConsentDetailsEntity;
    }

    public static CustomerConsentDetailsEntity getCustomerConsentDetailsEntityWithFalseFlag() {
        CustomerConsentDetailsEntity customerConsentDetailsEntity = new CustomerConsentDetailsEntity();
        customerConsentDetailsEntity.setId(1L);
        customerConsentDetailsEntity.setConsentAllow("N");
        customerConsentDetailsEntity.setConsentDescription("Test");
        customerConsentDetailsEntity.setAppType("RedBus");
        return customerConsentDetailsEntity;
    }

    public static RedBusPaymentResponse getRedBusPaymentResponse() {
        return RedBusPaymentResponse.builder().paymentId("12345").redirectionUrl("https://localhost:8086").build();
    }

    public static RedBusRefundResponse getRedBusRefundResponse() {
        return RedBusRefundResponse.builder().purposeRefNo("9876").refundRefId("859437598334434").refundRefNo("13233789436").build();
    }

    public static RedBusPaymentStatusResponse getRedBusPaymentStatusResponse() {
        return RedBusPaymentStatusResponse.builder().paymentRefId("12345").purposeRefNo("9876").paymentStatus("SUCCESS").build();
    }

    public static RedBusRefundStatusResponse getRedBusRefundStatusResponse() {
        return RedBusRefundStatusResponse.builder().paymentId("12345").purposeRefNo("9876").refundRefNo("13233789436").refundStatus("SUCCESS").build();
    }

    public static RedBusBookingResponse getRedBusBookingResponse() {
        return RedBusBookingResponse.builder().paymentRefId("12345").purposeRefNo("9876").build();
    }

    public static RedBusFulFilmentResponse getRedBusFulFilmentRespone() {

        return RedBusFulFilmentResponse.builder().paymentRefId("12345").purposeRefNo("9876").build();
    }

    public static ConsentDetailsResponse consentDetailsResponses() {
        ConsentDetailsResponse consentDetailsResponse = new ConsentDetailsResponse();
        com.airtelbank.thirdpartypayments.model.consent.Data data = new com.airtelbank.thirdpartypayments.model.consent.Data();
        List<com.airtelbank.thirdpartypayments.model.consent.Consent> listConsent = new ArrayList<>();
        com.airtelbank.thirdpartypayments.model.consent.Consent consent = new com.airtelbank.thirdpartypayments.model.consent.Consent();
        consent.setConsent(true);
        consent.setMobileNumber("9999999999");
        consent.setConsentMode("OTP");
        listConsent.add(consent);
        data.setConsents(listConsent);
        consentDetailsResponse.setData(data);
        Meta meta = new Meta();
        meta.setStatus(0);
        meta.setCode("000");
        meta.setDescription("test");
        consentDetailsResponse.setMeta(meta);
        return consentDetailsResponse;
    }

    public HeaderRequestDTO getHeaderRequestDTO() {
        return HeaderRequestDTO.builder().contentId("12345")
                .channel("IOS").contentType("application/json").build();
    }

    public CustomerDetailsPaymentRequest getPaymentRequestDTO() {
        CustomerDetailsPaymentRequest customerDetailsPaymentRequest = new CustomerDetailsPaymentRequest();
        customerDetailsPaymentRequest.setCustomerName("ABC");
        customerDetailsPaymentRequest.setMobileNo("7838659104");
        customerDetailsPaymentRequest.setPurposeRefNo("987");
        return customerDetailsPaymentRequest;
    }

    public static CustomerDetailsPaymentRequest getCustomerDetailsPaymentRequest() {
        CustomerDetailsPaymentRequest customerDetailsPaymentRequest = new CustomerDetailsPaymentRequest();
        customerDetailsPaymentRequest.setCustomerName("Ranjeet Singh");
        customerDetailsPaymentRequest.setMobileNo("7838659104");
        customerDetailsPaymentRequest.setPurposeRefNo("987");
        return customerDetailsPaymentRequest;
    }

    public PaymentData getRedbusPaymentRequestDTO() {

        String data = "G4LT8YWvvf7wD7w8qbn4SbiXtfxK44n0BM0Rt1CW2fcdI0WDUOh8IKTF5v03yczL1+KicBy45dfWDSKxdTLq2jUGPy6vfTXG6MUOVo0WNVvzzhztb+jYMaa8gN3xu3Wsv9Ak+fPINmFks7QDyK3R8oAZIo0n2JSy3k+pEJ8FvVNmcbY0fjJvqG3fGzP3on77PvPE70JsRRICCNWUPsLNsT4eGXgWBhxQW1J6Jdw8DodTb3cqDhgAEyfj61HsKbL9UHoTQK75E+4MyzBkdn0Vqj8pXChKbD2Y4k5imZ9wSwza3FIJ2MEnsARlvEj2nmPBKSWKPTKCvxVsc3cNPgnDRQ==";

        return PaymentData.builder().data(data).build();
    }

    public PaymentData getRedbusPaymengBookindRequest() {

        String data = "G4LT8YWvvf7wD7w8qbn4SbiXtfxK44n0BM0Rt1CW2fcdI0WDUOh8IKTF5v03yczL1+KicBy45dfWDSKxdTLq2jUGPy6vfTXG6MUOVo0WNVvzzhztb+jYMaa8gN3xu3Wsv9Ak+fPINmFks7QDyK3R8oAZIo0n2JSy3k+pEJ8FvVNmcbY0fjJvqG3fGzP3on77PvPE70JsRRICCNWUPsLNsT4eGXgWBhxQW1J6Jdw8DodTb3cqDhgAEyfj61HsKbL9UHoTQK75E+4MyzBkdn0Vqj8pXChKbD2Y4k5imZ9wSwza3FIJ2MEnsARlvEj2nmPBKSWKPTKCvxVsc3cNPgnDRQ==";

        return PaymentData.builder().data(data).build();
    }

    public PaymentData getPaymentInitRefundRequest() {
        String data = "FRdxHjDdKKsxZmzBPaEnsS9XNgEUab5nXq2J6E8lNIY+BrRFnZUmBN9FdsuEZStRV+wAuiPq6sxgGNTeIT8sSneRKua9S21sQviL15Y3mcwstFpPuu+BXlXqUnOEVAvMHow3VPTo18ErRdkDo+LJa90Hq9A26Pr5MgGsSPeoneQ=";
        return PaymentData.builder().data(data).build();

    }

    public RedBusPaymentRequest getRedbusPaymentRequest() {
        return RedBusPaymentRequest.builder().secretKey("redbus").purposeRefNo("123").totalAmount(1.1).currency("INR").
                redirectionURL("https://localhost:8086")
                .build();
    }

    public PaymentRefundRequest paymentRefundRequest() {
        return PaymentRefundRequest.builder().secretKey("redbus").purposeRefNo("123").refundRefNo("345").totalRefundAmount("1").build();
    }

    public PaymentRefundRequest paymentRefundRequestwithsomeamount() {
        return PaymentRefundRequest.builder().secretKey("redbus").purposeRefNo("345").refundRefNo("345").totalRefundAmount("1").build();
    }


    public PaymentRefundRequest getPaymentRefundRequestDTO() {
        PaymentRefundRequest RefundRequest = new PaymentRefundRequest();
      /*  RefundRequest.setSecretKey("secret-key");
        RefundRequest.setRefundRefNo("inr");
        RefundRequest.setPurposeRefNo("12345");
        RefundRequest.setTotalRefundAmount("1000.0");*/
        /*paymentRequestDTO.setSecretKey("secret-key");
        paymentRequestDTO.setCurrency("inr");
        paymentRequestDTO.setPurposeRefNo("12345");
        paymentRequestDTO.setRedirectionURL("url");
        paymentRequestDTO.setTotalAmount(1000.0);*/
        return RefundRequest;

    }

    public PaymentRefundRequest getPaymentRefundRequest() {
        return PaymentRefundRequest.builder().secretKey("redbus").totalRefundAmount("1").purposeRefNo("PUR-123").refundRefNo("REF-123").build();
    }


    public static OrderDetailsEntity getFulfilmentStatus() {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        orderDetailsEntity.setPurposeRefNo("456");
        orderDetailsEntity.setAmount(new BigDecimal(1));
        orderDetailsEntity.setPrID("123");
        orderDetailsEntity.setStatus(OrderStatus.COMPLETED);
        orderDetailsEntity.setBusType("AC");
        orderDetailsEntity.setCreationDate(new Date());
        orderDetailsEntity.setUpdationDate(new Date());
        orderDetailsEntity.setDestination("ABC");
        orderDetailsEntity.setSource("XYZ");
        return orderDetailsEntity;
    }

    public static OrderDetailsEntity getOrderDetailsSuccess() {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        orderDetailsEntity.setPurposeRefNo("123");
        orderDetailsEntity.setAmount(new BigDecimal(1));
        orderDetailsEntity.setPrID("234");
        orderDetailsEntity.setStatus(OrderStatus.COMPLETED);
        orderDetailsEntity.setUpdationDate(new Date());
        orderDetailsEntity.setCreationDate(new Date());
        return orderDetailsEntity;
    }

    public static OrderDetailsEntity getOrderDetails() {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        orderDetailsEntity.setPurposeRefNo("123");
        orderDetailsEntity.setAmount(BigDecimal.ONE);
        orderDetailsEntity.setPrID(null);
        orderDetailsEntity.setStatus(null);
        orderDetailsEntity.setUpdationDate(new Date());
        orderDetailsEntity.setCreationDate(new Date());
        return orderDetailsEntity;
    }

    public static OrderDetailsEntity getOrderDetailsForPaymentStatus() {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        orderDetailsEntity.setPurposeRefNo("123");
        orderDetailsEntity.setAmount(BigDecimal.ONE);
        orderDetailsEntity.setPrID("567");
        orderDetailsEntity.setStatus(OrderStatus.PAYMENT_COMPLETED);
        orderDetailsEntity.setUpdationDate(new Date());
        orderDetailsEntity.setCreationDate(new Date());
        return orderDetailsEntity;
    }

    public static OrderDetailsEntity getOrderDetailsFailed() {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        orderDetailsEntity.setPurposeRefNo("123");
        orderDetailsEntity.setAmount(new BigDecimal(1));
        orderDetailsEntity.setPrID("234");
        orderDetailsEntity.setStatus(OrderStatus.COMPLETED);
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY, -2);
        orderDetailsEntity.setCreationDate(new Date());
        orderDetailsEntity.setUpdationDate(calendar.getTime());
        return orderDetailsEntity;
    }

    public static TransactionRefundEntity getRefundDetails() {
        TransactionRefundEntity transactionRefundEntity = new TransactionRefundEntity();
        transactionRefundEntity.setRefundTxnId("123");
        transactionRefundEntity.setRefundReqId("345");
        transactionRefundEntity.setAmount(new BigDecimal(1));
        transactionRefundEntity.setPrId("0909");
        transactionRefundEntity.setRefundStatus("Initiated");
        transactionRefundEntity.setPurposeRefNo("9876");
        transactionRefundEntity.setMerchantId("MERCHANT");
        return transactionRefundEntity;
    }

    public static KafkaPaymentResponse paymentRequest() {
        return KafkaPaymentResponse.builder()
                .secretKey("123").purposeRefNo("123")
                .paymentRefId("234").status("SUCCESS")
                .totalAmount("1").errorCode(null)
                .errorMessage(null)
                .build();
    }

    public static KafkaPaymentResponse getKafkapaymentResponse() {
        return KafkaPaymentResponse.builder()
                .secretKey("redbus").purposeRefNo("123")
                .paymentRefId("234").status("SUCCESS")
                .totalAmount("1").errorCode(null)
                .errorMessage(null)
                .build();
    }

    public static KafkaPaymentResponse getKafkapaymentResponses() {
        return KafkaPaymentResponse.builder()
                .secretKey("test").purposeRefNo("123")
                .paymentRefId("234").status("SUCCESS")
                .totalAmount("1").errorCode(null)
                .errorMessage(null)
                .build();
    }

    public static KafkaRefundResponse getKafkaRefundResponse() {
        return KafkaRefundResponse.builder()
                .secretKey("123").purposeRefNo("123")
                .status("SUCCESS")
                .build();
    }

    public static PaymentStatus getKafkaPaymentStatus() {
        List<TransactionDetails> debitDetails = new ArrayList<>();
        TransactionDetails transactionDetails = TransactionDetails.builder().transactionId("123")
                .amount("1").status("SUCCESS").build();
        debitDetails.add(transactionDetails);
        PaymentStatus paymentStatus = PaymentStatus.builder().paymentReqId("123")
                .orderId("0909").useCase("abc").debitDetails(debitDetails).build();
        return paymentStatus;
    }

    public static RefundStatus getRefundRequest() {
        List<RefundStatusDetails> refundDetails = new ArrayList<>();
        RefundStatusDetails refundStatusDetails = RefundStatusDetails.builder().transactionId("123")
                .status("SUCCESS").amount(new BigDecimal("1")).build();
        refundDetails.add(refundStatusDetails);
        RefundStatus refundStatus = RefundStatus.builder().paymentReqId("8787")
                .orderId("0909").useCase("abc").refundDetails(refundDetails).build();
        return refundStatus;
    }

    public static RefundStatus getRefundRequests() {
        List<RefundStatusDetails> refundDetails = new ArrayList<>();
        RefundStatusDetails refundStatusDetails = RefundStatusDetails.builder().transactionId("123")
                .status("SUCCESS").amount(new BigDecimal("1")).transactionTime(String.valueOf(new Date().getTime())).build();
        refundDetails.add(refundStatusDetails);
        RefundStatus refundStatus = RefundStatus.builder().paymentReqId("8787")
                .orderId("0909").useCase("abc").refundDetails(refundDetails).build();
        return refundStatus;
    }

    public static RefundStatus getRefundRequestfailed() {
        List<RefundStatusDetails> refundDetails = new ArrayList<>();
        RefundStatusDetails refundStatusDetails = RefundStatusDetails.builder().transactionId("123")
                .status("FAILED").amount(new BigDecimal("1")).build();
        refundDetails.add(refundStatusDetails);
        RefundStatus refundStatus = RefundStatus.builder().paymentReqId("8787")
                .orderId("0909").useCase("abc").refundDetails(refundDetails).build();
        return refundStatus;
    }

    public static OrderDetailsEntity getOrderDetailsEntityDetails() {

        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        List<OrderDetailsTxn> orderDetailsTxns = new ArrayList<>();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsEntity(orderDetailsEntity);
        orderDetailsTxn.setCreationDate(new Timestamp(new Date().getTime()));
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setKey("1234ABC");
        orderDetailsTxn.setType("inr");
        orderDetailsTxn.setOrderDetailsTxnId("12345");
        orderDetailsTxn.setUpdationDate(new Timestamp(new Date().getTime()));
        orderDetailsTxn.setPaymentRelationship("1234");
        orderDetailsTxn.setValue("value");
        orderDetailsTxns.add(orderDetailsTxn);

        orderDetailsEntity.setAmount(BigDecimal.valueOf(1001));
        orderDetailsEntity.setCustomerId("1234");
        orderDetailsEntity.setCreationDate(new Timestamp(new Date().getTime()));
        orderDetailsEntity.setUpdationDate(new Timestamp(new Date().getTime()));
        orderDetailsEntity.setErrorCode("102");
        orderDetailsEntity.setPurposeRefNo("12349");
        orderDetailsEntity.setErrorMessage("error");
        orderDetailsEntity.setMerchantId("10349");
        orderDetailsEntity.setMerchantTxnId("12347");
        orderDetailsEntity.setPrID("784839");
        orderDetailsEntity.setOrderDetailsTxn(orderDetailsTxns);
        orderDetailsEntity.setStatus(OrderStatus.INITIATED);
        return orderDetailsEntity;
    }

    public static String getInitRefundRequest() {
        String data = "FRdxHjDdKKsxZmzBPaEnsS9XNgEUab5nXq2J6E8lNIY+BrRFnZUmBN9FdsuEZStRV+wAuiPq6sxgGNTeIT8sSneRKua9S21sQviL15Y3mcwstFpPuu+BXlXqUnOEVAvMHow3VPTo18ErRdkDo+LJa90Hq9A26Pr5MgGsSPeoneQ=";
        return data;
    }

    public static OrderDetailsEntity getPaymentOrderDetail() {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        orderDetailsEntity.setAmount(new BigDecimal(1));
        orderDetailsEntity.setPrID("123");
        orderDetailsEntity.setPurposeRefNo("345");
        orderDetailsEntity.setMerchantId("MERCHANT");
        orderDetailsEntity.setMerchantTxnId("MER-123");
        return orderDetailsEntity;
    }

    public static ResponseDTO<RefundResponse> refundTransactionResponse() {
        ResponseDTO<RefundResponse> transactionResponse = new ResponseDTO<>();
        com.airtelbank.payments.hub.client.dto.response.Meta responseMeta = new com.airtelbank.payments.hub.client.dto.response.Meta();
        responseMeta.setCode("0");
        responseMeta.setStatus(0);
        responseMeta.setDescription("SUCCESS");
        RefundResponse responseData = new RefundResponse();
        responseData.setRefundReqId(generateUniqueKey());
        responseData.setOrderRefundId(generateUniqueKey());
        transactionResponse.setMeta(responseMeta);
        transactionResponse.setData(responseData);
        return transactionResponse;
    }


    public static TransactionRefundEntity getTransactionRefundEntity() {
        TransactionRefundEntity redBusPaymentRefundEntity = new TransactionRefundEntity();
        redBusPaymentRefundEntity.setFeSessionId("123");
        redBusPaymentRefundEntity.setMerchantId("456");
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
        String strDate = dateFormat.format(date);
        redBusPaymentRefundEntity.setTxnDate(strDate);
        redBusPaymentRefundEntity.setMerchantId("0909");
        redBusPaymentRefundEntity.setAmount(new BigDecimal(1));
        redBusPaymentRefundEntity.setPurposeRefNo("345");
        redBusPaymentRefundEntity.setPrId("787");
        redBusPaymentRefundEntity.setRefundStatus("SUCCESS");
        return redBusPaymentRefundEntity;
    }

    public static String generateUniqueKey() {
        return new StringBuffer()
                .append(new SimpleDateFormat("DDDMMyyyyHHmmssSSS").format(new Date(System.currentTimeMillis())))
                .append(new Random().nextInt(10)).toString();
    }


    public static ResponseDTO<PaymentResponse> getInitPaymentResponse() {
        ResponseDTO<PaymentResponse> transactionResponse = new ResponseDTO<>();
        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setPaymentId("5218642128792");
        paymentResponse.setRedirectionUrl("http://localhost:8080//");
        transactionResponse.setData(paymentResponse);
        return transactionResponse;
    }


}
