package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.InitiatePaymentResponse;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionDetailsRequest;
import com.airtelbank.thirdpartypayments.repository.OrderAmountDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class PaymentInitializationServiceImplTest {

    @InjectMocks
    PaymentInitializationServiceImpl paymentInitializationService;
    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    private OrderAmountDetailsRepo orderAmountDetailsRepo;

    @Mock
    private ValidationService validationService;


    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(paymentInitializationService, "orderConfirmationURLForApp", "https://apbuat.airtelbank.com:5050/thirdPartyPayments/sit/api/v1/payment/bookingDetails");
    }

    @Test
    public void paymentInitialize() throws ThirdPartyPaymentsException {
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setMerchantId("test");
        paymentRequest.setAmount(BigDecimal.ONE);
        paymentRequest.setHash("test");
        Map<String, BigDecimal> stringBigDecimalMap = new HashMap<>();
        stringBigDecimalMap.put("test", BigDecimal.ONE);
        paymentRequest.setAmountDetails(stringBigDecimalMap);
        TransactionDetailsRequest transactionDetailsRequest = new TransactionDetailsRequest();
        transactionDetailsRequest.setMerchantTxnId("test");
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setValue("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        customEntries.add(customEntry);
        transactionDetailsRequest.setDetails(customEntries);
        paymentRequest.setTransactionDetailsRequest(transactionDetailsRequest);
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        Mockito.when(validationService.validateMerchant(Mockito.any(), Mockito.any())).thenReturn(entity);
        InitiatePaymentResponse initiatePaymentResponse = paymentInitializationService.paymentInitialize(paymentRequest, "test");
        assertNotNull(initiatePaymentResponse);

    }


}