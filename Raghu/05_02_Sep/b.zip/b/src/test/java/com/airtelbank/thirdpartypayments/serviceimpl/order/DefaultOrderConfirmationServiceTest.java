package com.airtelbank.thirdpartypayments.serviceimpl.order;

import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomActions;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationRequest;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.model.order.OrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.model.order.OrderRequest;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.service.LogErrorService;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class DefaultOrderConfirmationServiceTest extends CommonTestObjectUtil {

    @InjectMocks
    private DefaultOrderConfirmationService defaultOrderConfirmationService;

    @Mock
    private DefaultRequestBuilder defaultRequestBuilder;

    @Mock
    private HttpUtil httpUtil;

    @Mock
    private LogErrorService errorService;

    @Test
    public void doConfirm() throws ThirdPartyPaymentsException {
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        DefaultOrderConfirmationResponce defaultOrderConfirmationResponce = new DefaultOrderConfirmationResponce();
        Meta meta = new Meta();
        meta.setCode("test");
        meta.setDescription("test");
        meta.setStatus(0);
        defaultOrderConfirmationResponce.setMeta(meta);
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setKey("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        customEntries.add(customEntry);
        CustomActions customActions = new CustomActions();
        customActions.setDisplayText("test");
        customActions.setKey("test");
        customActions.setValue("test");
        List<CustomActions> list = new ArrayList<>();
        list.add(customActions);
        OrderConfirmationResponce orderConfirmationResponce = OrderConfirmationResponce.builder().details(customEntries).actions(list).merchantTxnId("test").build();
        defaultOrderConfirmationResponce.setData(orderConfirmationResponce);
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setData(Object.class);
        Mockito.when(defaultRequestBuilder.buildRequest(Mockito.any(), Mockito.any())).thenReturn(orderRequest);
        Mockito.lenient().when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(defaultOrderConfirmationResponce);
        DefaultOrderConfirmationResponce defaultOrderConfirmationResponce1 = defaultOrderConfirmationService.doConfirm(order, entity);
        assertNull(defaultOrderConfirmationResponce1);

    }

    @Test
    public void doConfirmException() {
        try {
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID("test");
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                    .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                    .purposeCode("OYO").build();
            DefaultOrderConfirmationResponce defaultOrderConfirmationResponce = defaultOrderConfirmationService.doConfirm(order, entity);
            assertNotNull(defaultOrderConfirmationResponce);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }

    }

    @Test(expected = ThirdPartyPaymentsException.class)
    public void recover() throws ThirdPartyPaymentsException {
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        DefaultOrderConfirmationResponce defaultOrderConfirmationResponce = new DefaultOrderConfirmationResponce();
        Meta meta = new Meta();
        meta.setCode("test1");
        meta.setDescription("test11");
        meta.setStatus(0);
        defaultOrderConfirmationResponce.setMeta(meta);
        CustomEntry customEntry = new CustomEntry();
        customEntry.setKey("test");
        customEntry.setDisplayText("test");
        customEntry.setKey("test");
        List<CustomEntry> customEntries = new ArrayList<>();
        customEntries.add(customEntry);
        CustomActions customActions = new CustomActions();
        customActions.setDisplayText("test");
        customActions.setKey("test");
        customActions.setValue("test");
        List<CustomActions> list = new ArrayList<>();
        list.add(customActions);
        OrderRequest<DefaultOrderConfirmationRequest> orderRequest = new OrderRequest<>();
        Map<String, String> headers = new HashMap<>();
        OrderConfirmationResponce orderConfirmationResponce = OrderConfirmationResponce.builder().details(customEntries).actions(list).merchantTxnId("test").build();
        defaultOrderConfirmationResponce.setData(orderConfirmationResponce);
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").merchantId("test").build();
        DefaultOrderConfirmationRequest build = DefaultOrderConfirmationRequest.builder().amount(BigDecimal.ONE).merchantId("abc").merchantTxnId("123")
                .status("abc").build();
        orderRequest.setHeaders(headers);
        orderRequest.setData(build);

        Mockito.when(defaultRequestBuilder.buildRequest(Mockito.any(), Mockito.any())).thenReturn(orderRequest);
        Mockito.lenient().when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(defaultOrderConfirmationResponce);

        DefaultOrderConfirmationResponce defaultOrderConfirmationResponce1 = defaultOrderConfirmationService.recover(order, entity);
        assertNotNull(defaultOrderConfirmationResponce1);

    }

    @Test
    public void recoverException() {

        try {
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID("test");
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            DefaultOrderConfirmationResponce defaultOrderConfirmationResponce = new DefaultOrderConfirmationResponce();
            Meta meta = new Meta();
            meta.setCode("test");
            meta.setDescription("test");
            meta.setStatus(0);
            defaultOrderConfirmationResponce.setMeta(meta);
            CustomEntry customEntry = new CustomEntry();
            customEntry.setKey("test");
            customEntry.setDisplayText("test");
            customEntry.setKey("test");
            List<CustomEntry> customEntries = new ArrayList<>();
            customEntries.add(customEntry);
            CustomActions customActions = new CustomActions();
            customActions.setDisplayText("test");
            customActions.setKey("test");
            customActions.setValue("test");
            List<CustomActions> list = new ArrayList<>();
            list.add(customActions);
            OrderConfirmationResponce orderConfirmationResponce = OrderConfirmationResponce.builder().details(customEntries).actions(list).merchantTxnId("test").build();
            defaultOrderConfirmationResponce.setData(orderConfirmationResponce);
            MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                    .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                    .purposeCode("OYO").build();
            OrderRequest orderRequest = new OrderRequest();
            orderRequest.setData(Object.class);
            Mockito.when(defaultRequestBuilder.buildRequest(Mockito.any(), Mockito.any())).thenReturn(orderRequest);
            Mockito.lenient().when(httpUtil.hitRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(defaultOrderConfirmationResponce);
            DefaultOrderConfirmationResponce defaultOrderConfirmationResponce1 = defaultOrderConfirmationService.recover(order, entity);
            assertNotNull(defaultOrderConfirmationResponce1);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }
    }
}

