package com.airtelbank.thirdpartypayments.serviceimpl.order;

import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class OrderConfirmationServiceFactoryImplTest {

    @InjectMocks
    OrderConfirmationServiceFactoryImpl orderConfirmationServiceFactory;
    @Mock
    private DefaultOrderConfirmationService defaultOrderConfirmationService;
    @Mock
    Map<String, OrderConfirmationService> reqBuilderMap;

    @Test
    public void getOrderConfirmationService() {

        OrderConfirmationService orderConfirmationService = orderConfirmationServiceFactory.getOrderConfirmationService("DEFAULT");
        assertNotNull(orderConfirmationService);
    }

    @Test
    public void getOrderConfirmationServicenotdefault() {

        reqBuilderMap.get("test");
        OrderConfirmationService orderConfirmationService = orderConfirmationServiceFactory.getOrderConfirmationService("test");
        assertNull(orderConfirmationService);
    }
}