package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.model.Merchant;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class MerchantDetailServiceImplTest {

    @InjectMocks
    MerchantDetailServiceImpl merchantDetailService;

    @Test
    public void getMerchantByPuporseCode() {
        Merchant merchant = merchantDetailService.getMerchantByPuporseCode("test");
        assertNull(merchant);
    }
}