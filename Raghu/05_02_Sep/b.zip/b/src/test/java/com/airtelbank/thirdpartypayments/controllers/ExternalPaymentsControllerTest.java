package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryRequest;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponse;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponseDetail;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundResponse;
import com.airtelbank.thirdpartypayments.service.TransactionEnquiryService;
import com.airtelbank.thirdpartypayments.service.TransactionRefundService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class ExternalPaymentsControllerTest {

    @InjectMocks
    ExternalPaymentsController externalPaymentsController;
    @Mock
    TransactionEnquiryService transactionEnquiryService;

    @Mock
    TransactionRefundService transactionRefundService;

    @Mock
    LoggerModel loggerModel;

    @Mock
    BindingResult bindingResult;

    @Test
    public void transactionEnquiry() throws Exception {
        TransactionEnquiryResponseDetail transactionEnquiryDetails1 = new TransactionEnquiryResponseDetail();
        transactionEnquiryDetails1.setAmount(BigDecimal.ONE);
        transactionEnquiryDetails1.setHash("test");
        transactionEnquiryDetails1.setStatus("test");
        transactionEnquiryDetails1.setTxnDate("test");
        transactionEnquiryDetails1.setType("test");
        transactionEnquiryDetails1.setMerchantTxnId("test");
        transactionEnquiryDetails1.setTxnId("test");
        List<TransactionEnquiryResponseDetail> transactionEnquiryResponseDetails = new ArrayList<>();
        transactionEnquiryResponseDetails.add(transactionEnquiryDetails1);
        TransactionEnquiryResponse transactionEnquiryResponse = new TransactionEnquiryResponse();
        transactionEnquiryResponse.setTransactionDetails(transactionEnquiryResponseDetails);
        TransactionEnquiryRequest request = new TransactionEnquiryRequest();
        request.setAmount(BigDecimal.ONE);
        request.setType("test");
        request.setMerchantTxnId("test");
        request.setFeSessionId("test");
        request.setRefundTxnId("test");
        Mockito.when(bindingResult.hasErrors()).thenReturn(false);
        Mockito.when(transactionEnquiryService.enquiryInit(Mockito.any(), Mockito.any())).thenReturn(transactionEnquiryResponse);
        ResponseEntity<RestApiResponse> restApiResponseResponseEntity = externalPaymentsController.transactionEnquiry(request, "test", bindingResult);
        assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());
    }

    @Test
    public void transactionEnquiryException() throws Exception {
        try {
            TransactionEnquiryResponseDetail transactionEnquiryDetails1 = new TransactionEnquiryResponseDetail();
            transactionEnquiryDetails1.setAmount(BigDecimal.ONE);
            transactionEnquiryDetails1.setHash("test");
            transactionEnquiryDetails1.setStatus("test");
            transactionEnquiryDetails1.setTxnDate("test");
            transactionEnquiryDetails1.setType("test");
            transactionEnquiryDetails1.setMerchantTxnId("test");
            transactionEnquiryDetails1.setTxnId("test");
            List<TransactionEnquiryResponseDetail> transactionEnquiryResponseDetails = new ArrayList<>();
            transactionEnquiryResponseDetails.add(transactionEnquiryDetails1);
            TransactionEnquiryResponse transactionEnquiryResponse = new TransactionEnquiryResponse();
            transactionEnquiryResponse.setTransactionDetails(transactionEnquiryResponseDetails);
            TransactionEnquiryRequest request = new TransactionEnquiryRequest();
            request.setAmount(BigDecimal.ONE);
            request.setType("test");
            request.setMerchantTxnId("test");
            request.setFeSessionId("test");
            request.setRefundTxnId("test");
            Mockito.when(bindingResult.hasErrors()).thenReturn(true);
            Mockito.lenient().when(transactionEnquiryService.enquiryInit(Mockito.any(), Mockito.any())).thenReturn(transactionEnquiryResponse);
            ResponseEntity<RestApiResponse> restApiResponseResponseEntity = externalPaymentsController.transactionEnquiry(request, "test", bindingResult);
            assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }

    }

    @Test
    public void transactionRefund() throws Exception {
        TransactionRefundResponse transactionRefundResponse = new TransactionRefundResponse();
        transactionRefundResponse.setRefundTxnId("test");
        transactionRefundResponse.setHash("test");
        transactionRefundResponse.setAmount(BigDecimal.ONE);
        transactionRefundResponse.setStatus("test");
        transactionRefundResponse.setReversalTxnDate("test");
        TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
        transactionRefundRequest.setRefundTxnId("test");
        transactionRefundRequest.setHash("test");
        transactionRefundRequest.setAmount(BigDecimal.ONE);
        transactionRefundRequest.setFeSessionId("test");
        transactionRefundRequest.setMerchantTxnId("test");
        Mockito.when(transactionRefundService.refundInit(Mockito.any(), Mockito.any())).thenReturn(transactionRefundResponse);
        ResponseEntity<RestApiResponse> restApiResponseResponseEntity = externalPaymentsController.transactionRefund(transactionRefundRequest, "test", bindingResult);
        assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());


    }

    @Test
    public void transactionRefundException() throws Exception {
        try {
            TransactionRefundResponse transactionRefundResponse = new TransactionRefundResponse();
            transactionRefundResponse.setRefundTxnId("test");
            transactionRefundResponse.setHash("test");
            transactionRefundResponse.setAmount(BigDecimal.ONE);
            transactionRefundResponse.setStatus("test");
            transactionRefundResponse.setReversalTxnDate("test");
            TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
            transactionRefundRequest.setRefundTxnId("test");
            transactionRefundRequest.setHash("test");
            transactionRefundRequest.setAmount(BigDecimal.ONE);
            transactionRefundRequest.setFeSessionId("test");
            transactionRefundRequest.setMerchantTxnId("test");
            Mockito.when(bindingResult.hasErrors()).thenReturn(true);
            Mockito.lenient().when(transactionRefundService.refundInit(Mockito.any(), Mockito.any())).thenReturn(transactionRefundResponse);
            ResponseEntity<RestApiResponse> restApiResponseResponseEntity = externalPaymentsController.transactionRefund(transactionRefundRequest, "test", bindingResult);
            assertEquals(0, Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getMeta().getStatus());
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }

    }
}