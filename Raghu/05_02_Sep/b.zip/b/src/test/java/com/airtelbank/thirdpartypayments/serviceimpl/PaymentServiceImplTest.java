package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.ActorResponse;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class PaymentServiceImplTest {

    @InjectMocks
    PaymentServiceImpl paymentService;


    @Mock
    private MerchantTransactionDetailsRepo merchantTransactionDetailsRepo;

    @Mock
    private OrderDetailsRepo orderDetailsRepo;

    @Mock
    LoggerModel loggerModel;

    @Test
    public void sendPurposeDetailsException() {

        try {
            ActorResponse actorResponse = paymentService.sendPurposeDetails("test", "test");
            assertNotNull(actorResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }


    }

    @Test
    public void sendPurposeDetailsnullException() {

        try {
            ActorResponse actorResponse = paymentService.sendPurposeDetails(null, "test");
            assertNotNull(actorResponse);
        } catch (ThirdPartyPaymentsException e) {
            assertNotNull(e);
        }


    }

    @Test
    public void sendPurposeDetails() throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity entity = MerchantTransactionDetailsEntity.builder().accNumber("123456789")
                .name("name").circleID("circle").confirmationUrl("url").custType("SBA").lobID("lob").msisdn("123456789")
                .purposeCode("OYO").build();
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        Mockito.when(merchantTransactionDetailsRepo.getOne(Mockito.any())).thenReturn(entity);

        ActorResponse actorResponse = paymentService.sendPurposeDetails("test", "test");
        assertNotNull(actorResponse);

    }
}