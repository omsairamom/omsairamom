package com.airtelbank.thirdpartypayments.serviceimpl;


import com.airtelbank.payments.model.TransactionStatusDetails;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.service.PostPaymentProcessingService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class KafkaConsumerServiceImplTest {

    @InjectMocks
    KafkaConsumerServiceImpl kafkaConsumerService;
    @Mock
    PostPaymentProcessingService postPaymentProcessingService;

    @Test
    public void thirdPartyPaymentListener() throws ThirdPartyPaymentsException {

        com.airtelbank.payments.model.PaymentDetails paymentDetails = new com.airtelbank.payments.model.PaymentDetails();
        paymentDetails.setAddParam1("test");
        paymentDetails.setAddParam2("test");
        paymentDetails.setPurposeRefNo("test");
        paymentDetails.setTotalAmount(BigDecimal.ONE);
        paymentDetails.setCustomerNumber("test");
        paymentDetails.setNarration("test");
        Map<String, String> map = new HashMap<>();
        map.put("test", "test");
        paymentDetails.setParamaters(map);
        paymentDetails.setPrId("test");
        paymentDetails.setPuporseCode("test");
        paymentDetails.setRefPrid("test");
        paymentDetails.setType("test");
        paymentDetails.setStatus(1);
        paymentDetails.setBillerName("test");
        TransactionStatusDetails transactionStatusDetails = new TransactionStatusDetails();
        transactionStatusDetails.setAmount("test");
        transactionStatusDetails.setStatus("test");
        transactionStatusDetails.setErrorCode("test");
        transactionStatusDetails.setPurposeRefNo("test");
        transactionStatusDetails.setTransactionDateTime(new Date());
        transactionStatusDetails.setAccessToken("test");
        transactionStatusDetails.setFtTxnId("test");
        transactionStatusDetails.setDescription("test");
        transactionStatusDetails.setPaymentMode("test");
        transactionStatusDetails.setPgTxnId("test");
        List<TransactionStatusDetails> transactionStatusDetails1 = new ArrayList<>();
        transactionStatusDetails1.add(transactionStatusDetails);
        paymentDetails.setTransactionStatusDetails(transactionStatusDetails1);
        paymentDetails.setTxnMessage("test");
        paymentDetails.setType("test");
        Mockito.doNothing().when(postPaymentProcessingService).processPayment(Mockito.any());
        kafkaConsumerService.thirdPartyPaymentListener(paymentDetails);
        Mockito.verify(postPaymentProcessingService, Mockito.times(1)).processPayment(Mockito.any());

    }
}