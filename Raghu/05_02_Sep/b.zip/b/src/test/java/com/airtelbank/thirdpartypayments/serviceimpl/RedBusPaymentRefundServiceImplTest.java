package com.airtelbank.thirdpartypayments.serviceimpl;


import com.airtelbank.payments.hub.client.service.PHPaymentRequestService;
import com.airtelbank.payments.hub.client.service.impl.PHRefundRequestServiceImpl;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.model.entityresult.CustomResult;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.PaymentRefundRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaRefundResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.util.CommonAppConsent;
import com.airtelbank.thirdpartypayments.util.CommonTestObjectUtil;
import com.airtelbank.thirdpartypayments.util.EncryptionDencryptionUtils;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mockStatic;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Slf4j
public class RedBusPaymentRefundServiceImplTest extends CommonTestObjectUtil {

    @InjectMocks
    RedBusPaymentRefundServiceImpl redBusPaymentRefundService;

    @Mock
    OrderDetailsRepo orderDetailsRepo;

    @Mock
    RefundDetailsRepo refundDetailsRepo;

    @Mock
    PHPaymentRequestService phPaymentRequestService;

    @Mock
    PHRefundRequestServiceImpl pHRefundRequestServiceImpl;

    @Mock
    HttpUtil httpUtil;

    @Mock
    ObjectMapper mapper;

    @Mock
    ValidationServiceImpl validationService;
    @Mock
    MessageSource messageSource;

    private static MockedStatic<EncryptionDencryptionUtils> mockedSettings;

    @BeforeClass
    public static void init() {

        mockedSettings = mockStatic(EncryptionDencryptionUtils.class);
    }

    @AfterClass
    public static void close() {
        mockedSettings.close();

    }

    @Before
    public void setUp() {

        log.info("Loading RedBusPaymentServiceImplTest......");

        ReflectionTestUtils.setField(redBusPaymentRefundService, "refundUpdateUrl", "http://localhost");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "useCase", "redbus");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "useCaseName", "redbus");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "partnerId", "redbus");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "billerId", "redbus");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "encKey", "redbus");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "decKey", "redbus");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "refundStatus", "redbus");
        ReflectionTestUtils.setField(redBusPaymentRefundService, "merchantId", "redbus");


    }


    @Test
    public void initiateRefundSuccessTest() throws JsonProcessingException {

        log.info("Entering into initiateRefundSuccessTest() method....");

        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
        Mockito.when(refundDetailsRepo.findByRefundReqId(Mockito.any())).thenReturn(transactionRefundEntity);
        // MockedStatic<EncryptionDencryptionUtils> mockedStatic2 = mockStatic(EncryptionDencryptionUtils.class);
        mockedSettings.when(() -> EncryptionDencryptionUtils.dataDecryptByPrivateKey(Mockito.any(), Mockito.any())).thenReturn(paymentRefundRequest().toString());
        Mockito.when(mapper.readValue(anyString(), eq(PaymentRefundRequest.class))).thenReturn(paymentRefundRequest());
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(anyString())).thenReturn(order);
        Mockito.lenient().when(pHRefundRequestServiceImpl.refundRequest(anyString(), Mockito.any())).thenReturn(CommonTestObjectUtil.refundTransactionResponse());
        Mockito.when(refundDetailsRepo.save(Mockito.any())).thenReturn(CommonTestObjectUtil.getTransactionRefundEntity());
        RedBusRefundResponse redBusRefundResponse = redBusPaymentRefundService.initiateRefund(getPaymentInitRefundRequest());
        System.out.println("redBusRefundResponse:" + redBusRefundResponse);
        Assert.assertEquals("test", redBusRefundResponse.getPurposeRefNo());
        log.info("Execution completed initiateRefundSuccessTest() method......");
    }

    @Test
    public void initiateRefundPurposeRefNoSameSumOfAmount() throws JsonProcessingException {

        log.info("Entering into initiateRefundSuccessTest() method....");

        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
        CustomResult customResult = new CustomResult();
        customResult.setAmount(BigDecimal.TEN);
        customResult.setPurposeRefNo("test");
        List<CustomResult> customResults = new ArrayList<>();
        customResults.add(customResult);
        Mockito.when(refundDetailsRepo.getTotalAmountFromPurposeRefNo(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(customResults);
        Mockito.when(refundDetailsRepo.findByRefundReqId(Mockito.any())).thenReturn(transactionRefundEntity);
        // MockedStatic<EncryptionDencryptionUtils> mockedStatic2 = mockStatic(EncryptionDencryptionUtils.class);
        mockedSettings.when(() -> EncryptionDencryptionUtils.dataDecryptByPrivateKey(Mockito.any(), Mockito.any())).thenReturn(paymentRefundRequestwithsomeamount().toString());
        Mockito.when(mapper.readValue(anyString(), eq(PaymentRefundRequest.class))).thenReturn(paymentRefundRequest());
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(anyString())).thenReturn(order);
        Mockito.lenient().when(pHRefundRequestServiceImpl.refundRequest(anyString(), Mockito.any())).thenReturn(CommonTestObjectUtil.refundTransactionResponse());
        Mockito.when(refundDetailsRepo.save(Mockito.any())).thenReturn(CommonTestObjectUtil.getTransactionRefundEntity());
        RedBusRefundResponse redBusRefundResponse = redBusPaymentRefundService.initiateRefund(getPaymentInitRefundRequest());
        System.out.println("redBusRefundResponse::" + redBusRefundResponse);
        Assert.assertEquals("test", redBusRefundResponse.getPurposeRefNo());


        log.info("Execution completed initiateRefundSuccessTest() method......");
    }

    @Test
    public void initiateRefundExceptionTest() {
        try {
            log.info("Entering into initiateRefundSuccessTest() method....");

            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            Mockito.when(refundDetailsRepo.existsByRefundReqId(Mockito.any())).thenReturn(true);
            TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
            Mockito.lenient().when(refundDetailsRepo.findByRefundReqId(Mockito.any())).thenReturn(transactionRefundEntity);
            // MockedStatic<EncryptionDencryptionUtils> mockedStatic2 = mockStatic(EncryptionDencryptionUtils.class);
            mockedSettings.when(() -> EncryptionDencryptionUtils.dataDecryptByPrivateKey(Mockito.any(), Mockito.any())).thenReturn(paymentRefundRequest().toString());
            Mockito.when(mapper.readValue(anyString(), eq(PaymentRefundRequest.class))).thenReturn(paymentRefundRequest());
            Mockito.lenient().when(orderDetailsRepo.findByPurposeRefNo(anyString())).thenReturn(order);
            Mockito.lenient().when(pHRefundRequestServiceImpl.refundRequest(anyString(), Mockito.any())).thenReturn(CommonTestObjectUtil.refundTransactionResponse());
            Mockito.lenient().when(refundDetailsRepo.save(Mockito.any())).thenReturn(CommonTestObjectUtil.getTransactionRefundEntity());
            RedBusRefundResponse redBusRefundResponse = redBusPaymentRefundService.initiateRefund(getPaymentInitRefundRequest());
            Assert.assertEquals("test", redBusRefundResponse.getPurposeRefNo());
            System.out.println("redBusRefundResponse::" + redBusRefundResponse);
            log.info("Execution completed initiateRefundSuccessTest() method......");
        } catch (GenericException | JsonProcessingException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void initiateRefundFulfilmentStatusResponseIsNull() throws JsonProcessingException {
        try {
            log.info("Entering into initiateRefundSuccessTest() method....");

            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
            Mockito.lenient().when(refundDetailsRepo.findByRefundReqId(Mockito.any())).thenReturn(transactionRefundEntity);
            // MockedStatic<EncryptionDencryptionUtils> mockedStatic2 = mockStatic(EncryptionDencryptionUtils.class);
            mockedSettings.when(() -> EncryptionDencryptionUtils.dataDecryptByPrivateKey(Mockito.any(), Mockito.any())).thenReturn(paymentRefundRequest().toString());
            Mockito.when(mapper.readValue(anyString(), eq(PaymentRefundRequest.class))).thenReturn(paymentRefundRequest());
            Mockito.lenient().when(orderDetailsRepo.findByPurposeRefNo(anyString())).thenReturn(null);
            Mockito.lenient().when(pHRefundRequestServiceImpl.refundRequest(anyString(), Mockito.any())).thenReturn(CommonTestObjectUtil.refundTransactionResponse());
            Mockito.lenient().when(refundDetailsRepo.save(Mockito.any())).thenReturn(CommonTestObjectUtil.getTransactionRefundEntity());
            RedBusRefundResponse redBusRefundResponse = redBusPaymentRefundService.initiateRefund(getPaymentInitRefundRequest());
            //Assert.assertEquals("test", redBusRefundResponse.getPurposeRefNo());
            log.info("Execution completed initiateRefundSuccessTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void initiateRefundSuccessTestwhentransactionResponseisnull() throws JsonProcessingException {
        try {
            log.info("Entering into initiateRefundSuccessTest() method....");

            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            orderDetailsTxn.setOrderDetailsTxnId("test");
            orderDetailsTxn.setKey("test");
            orderDetailsTxn.setType("test");
            orderDetailsTxn.setDisplayText("test");
            orderDetailsTxn.setValue("test");
            OrderDetailsEntity order = new OrderDetailsEntity();
            order.setMerchantTxnId("test");
            order.setPurposeRefNo("test");
            order.setAmount(BigDecimal.ONE);
            order.setPrID(null);
            List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
            orderDetailsTxnLIST.add(orderDetailsTxn);
            order.setMerchantId("test");
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdationDate(new Date());
            order.setCreationDate(new Date());
            order.setErrorMessage("test");
            order.setErrorCode("1234");
            order.setCustomerId("test");
            order.setOrderDetailsTxn(orderDetailsTxnLIST);
            TransactionRefundEntity transactionRefundEntity = CommonTestObjectUtil.getRefundDetails();
            Mockito.lenient().when(refundDetailsRepo.findByRefundReqId(Mockito.any())).thenReturn(transactionRefundEntity);
            mockedSettings.when(() -> EncryptionDencryptionUtils.dataDecryptByPrivateKey(Mockito.any(), Mockito.any())).thenReturn(paymentRefundRequest().toString());
            Mockito.when(mapper.readValue(anyString(), eq(PaymentRefundRequest.class))).thenReturn(paymentRefundRequest());
            Mockito.lenient().when(orderDetailsRepo.findByPurposeRefNo(anyString())).thenReturn(order);
            Mockito.lenient().when(pHRefundRequestServiceImpl.refundRequest(anyString(), Mockito.any())).thenReturn(CommonTestObjectUtil.refundTransactionResponse());
            Mockito.lenient().when(refundDetailsRepo.save(Mockito.any())).thenReturn(CommonTestObjectUtil.getTransactionRefundEntity());
            CustomResult customResult = new CustomResult();
            customResult.setAmount(BigDecimal.TEN);
            customResult.setPurposeRefNo("APB-12345");
            List<CustomResult> customResults = new ArrayList<>();
            customResults.add(customResult);
            Mockito.when(refundDetailsRepo.getTotalAmountFromPurposeRefNo(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(customResults);
            Mockito.when(pHRefundRequestServiceImpl.refundRequest(Mockito.any(), Mockito.any())).thenReturn(null);
            RedBusRefundResponse redBusRefundResponse = redBusPaymentRefundService.initiateRefund(getPaymentInitRefundRequest());
            //Assert.assertEquals("APB-12345", redBusRefundResponse.getPurposeRefNo());


            log.info("Execution completed initiateRefundSuccessTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void getRefundStatusTest() {

        log.info("Entering into getRefundStatusTest() method....");

        Mockito.lenient().when(refundDetailsRepo.findByRefundReqId(anyString())).thenReturn(getRefundDetails());
        RedBusRefundStatusResponse redBusRefundStatusResponse = redBusPaymentRefundService.getRefundStatusEnquiry("345");
        assertEquals("345", redBusRefundStatusResponse.getRefundRefNo());

        log.info("Execution completed getRefundStatusTest() method......");
    }

    @Test
    public void getRefundStatusSuccessTest() {

        log.info("Entering into getRefundStatusSuccessTest() method....");

        Mockito.when(refundDetailsRepo.findByRefundReqId(anyString())).thenReturn(getRefundDetails());
        RedBusRefundStatusResponse redBusRefundStatusResponse = redBusPaymentRefundService.getRefundStatusEnquiry("123");
        assertEquals("Initiated", redBusRefundStatusResponse.getRefundStatus());

        log.info("Execution completed getRefundStatusSuccessTest() method......");
    }

    @Test
    public void getRefundStatusWhereRefundReStatusResponseIsNull() {
        try {
            log.info("Entering into getRefundStatusSuccessTest() method....");

            Mockito.when(refundDetailsRepo.findByRefundReqId(anyString())).thenReturn(null);
            RedBusRefundStatusResponse redBusRefundStatusResponse = redBusPaymentRefundService.getRefundStatusEnquiry("123");
            assertNotNull(redBusRefundStatusResponse);
            log.info("Execution completed getRefundStatusSuccessTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }


    @Test
    public void getFulfilmentStatusFromPrIdSuccessTest() {

        log.info("Entering into getFulfilmentStatusFromPrIdSuccessTest() method....");

        Map<String, String> headers = new HashMap<>();
        headers.put("contentid", "1234");
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID(null);
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        Mockito.lenient().when(orderDetailsRepo.findByPrID(anyString())).thenReturn(getOrderDetailsEntityDetails());
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.any())).thenReturn(order);
        OrderDetailsEntity fulfilmentStatusFromPrIdResponse = redBusPaymentRefundService.getFulfilmentStatus("1");
        assertEquals("test", fulfilmentStatusFromPrIdResponse.getCustomerId());

        log.info("Execution completed getFulfilmentStatusFromPrIdSuccessTest() method......");
    }


    @Test
    public void saveRefundStatus() {
        OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
        orderDetailsTxn.setOrderDetailsTxnId("test");
        orderDetailsTxn.setKey("test");
        orderDetailsTxn.setType("test");
        orderDetailsTxn.setDisplayText("test");
        orderDetailsTxn.setValue("test");
        OrderDetailsEntity order = new OrderDetailsEntity();
        order.setMerchantTxnId("test");
        order.setPurposeRefNo("test");
        order.setAmount(BigDecimal.ONE);
        order.setPrID("test");
        List<OrderDetailsTxn> orderDetailsTxnLIST = new ArrayList<>();
        orderDetailsTxnLIST.add(orderDetailsTxn);
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        order.setMerchantId("test");
        order.setStatus(OrderStatus.COMPLETED);
        order.setUpdationDate(new Date());
        order.setCreationDate(new Date());
        order.setErrorMessage("test");
        order.setErrorCode("1234");
        order.setCustomerId("test");
        order.setOrderDetailsTxn(orderDetailsTxnLIST);
        PaymentRefundRequest paymentRefundRequest = new PaymentRefundRequest();
        paymentRefundRequest.setRefundRefNo("test");
        paymentRefundRequest.setTotalRefundAmount("100");
        paymentRefundRequest.setSecretKey("test");
        redBusPaymentRefundService.saveRefundStatus(order, paymentRefundRequest);
        Mockito.verify(refundDetailsRepo, Mockito.times(1)).save(Mockito.any());
    }

    @Test
    public void updateRefundStatusTest() throws JsonProcessingException {

        log.info("Entering into updateRefundStatusTest() method....");
        KafkaRefundResponse refundResponse = new KafkaRefundResponse();
        refundResponse.setRefundRefNo("test");
        refundResponse.setStatus("test");
        refundResponse.setPurposeRefNo("test");
        refundResponse.setTotalRefundAmount("100");
        refundResponse.setBankRefNo("test");
        refundResponse.setSecretKey("redbus");
        //   MockedStatic<EncryptionDencryptionUtils> mockedStatic = Mockito.mockStatic(EncryptionDencryptionUtils.class);
        String encData = "1111111";
        PaymentData paymentUpdate = new PaymentData(encData);
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        String kafkapaymentResponseinString = "{\"purposeRefNo\":\"11234455\",\"refundRefNo\":\"567\",\"status\":\"SUCCESS\",\"totalRefundAmount\":\"1\",\"bankRefNo\":9090,\"secretKey\":\"123\"}";

        //Mockito.when(mapper.writeValueAsString(anyString())).thenReturn(kafkapaymentResponseinString);
        mockedSettings.when(() -> EncryptionDencryptionUtils.dataEncryptByPublicKey(Mockito.any(), Mockito.any())).thenReturn(encData);
        Mockito.lenient().when(httpUtil.hitRequest(CommonAppConsent.PAYMENT_UPDATE_URL, paymentUpdate, String.class, headers, HttpMethod.POST, true)).thenReturn("ok");
        ResponseEntity<String> responseEntityResponse = redBusPaymentRefundService.updateRefundStatus(refundResponse);
        assertEquals(200, responseEntityResponse.getStatusCodeValue());

        log.info("Execution completed updateRefundStatusTest() method......");

    }


    @Test
    public void updateRefundStatusSecretKeyNotMatchedTest() throws JsonProcessingException {
        try {
            log.info("Entering into updateRefundStatusTest() method....");
            KafkaRefundResponse refundResponse = new KafkaRefundResponse();
            refundResponse.setRefundRefNo("test");
            refundResponse.setStatus("test");
            refundResponse.setPurposeRefNo("test");
            refundResponse.setTotalRefundAmount("100");
            refundResponse.setBankRefNo("test");
            refundResponse.setSecretKey("test");
            //   MockedStatic<EncryptionDencryptionUtils> mockedStatic = Mockito.mockStatic(EncryptionDencryptionUtils.class);
            String encData = "1111111";
            PaymentData paymentUpdate = new PaymentData(encData);
            Map<String, String> headers = new HashMap<>();
            headers.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
            String kafkapaymentResponseinString = "{\"purposeRefNo\":\"11234455\",\"refundRefNo\":\"567\",\"status\":\"SUCCESS\",\"totalRefundAmount\":\"1\",\"bankRefNo\":9090,\"secretKey\":\"123\"}";

            Mockito.lenient().when(mapper.writeValueAsString(anyString())).thenReturn(kafkapaymentResponseinString);
            mockedSettings.when(() -> EncryptionDencryptionUtils.dataEncryptByPublicKey(Mockito.any(), Mockito.any())).thenReturn(encData);
            Mockito.lenient().when(httpUtil.hitRequest(CommonAppConsent.PAYMENT_UPDATE_URL, paymentUpdate, String.class, headers, HttpMethod.POST, true)).thenReturn("ok");
            ResponseEntity<String> responseEntityResponse = redBusPaymentRefundService.updateRefundStatus(refundResponse);
            assertEquals(200, responseEntityResponse.getStatusCodeValue());

            log.info("Execution completed updateRefundStatusTest() method......");
        } catch (GenericException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void getFulfilmentStatusSuccessTest() {

        log.info("Entering into getFulfilmentStatusSuccessTest() method ....");

        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.anyString())).thenReturn(getFulfilmentStatus());
        OrderDetailsEntity fulfilmentStatus = redBusPaymentRefundService.getFulfilmentStatus("123");
        assertEquals("123", fulfilmentStatus.getPrID());

        log.info("Execution completed getFulfilmentStatusSuccessTest() method......");
    }

    @Test(expected = GenericException.class)
    public void getFulfilmentStatusFailTest() {

        log.info("Entering into getFulfilmentStatusFailTest() method ....");
        Mockito.when(orderDetailsRepo.findByPurposeRefNo(Mockito.anyString())).thenReturn(null);
        redBusPaymentRefundService.getFulfilmentStatus("123");
        log.info("Execution completed getFulfilmentStatusFailTest() method......");
    }


}

