package com.airtelbank.thirdpartypayments.model;

import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionEnquiryPaymentResponse implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private List<PaymentDetails> data;
    private Meta meta;
}

