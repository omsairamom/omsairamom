package com.airtelbank.thirdpartypayments.exception;

import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import lombok.Getter;

@Getter
public class RedBusPaymentException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final ResponseErrorCode errorCode;

    private final String code;

    private String message;

    public RedBusPaymentException(ResponseErrorCode errorCode) {
        super();
        this.errorCode = errorCode;
        this.code = String.valueOf(errorCode.getCode());
    }

    public RedBusPaymentException(ResponseErrorCode errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.message = errorMessage;
        this.code = String.valueOf(errorCode.getCode());
    }

    public RedBusPaymentException(ResponseErrorCode errorCode, String errorMessage, Throwable t) {
        super(errorMessage, t);
        this.errorCode = errorCode;
        this.message = errorMessage;
        this.code = String.valueOf(errorCode.getCode());
    }

    public RedBusPaymentException(ResponseErrorCode errorCode, Throwable cause) {
        super(cause);
        this.errorCode = errorCode;
        this.code = String.valueOf(errorCode.getCode());
    }

}
