package com.airtelbank.thirdpartypayments.model;

import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionRefundPaymentResponse implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private PaymentDetails data;
    private Meta meta;

}
