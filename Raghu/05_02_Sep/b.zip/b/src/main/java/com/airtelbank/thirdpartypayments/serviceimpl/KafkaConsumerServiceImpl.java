package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.model.PaymentDetails;
import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.service.KafkaConsumerService;
import com.airtelbank.thirdpartypayments.service.PostPaymentProcessingService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * @author b0206596
 */
@Slf4j
@Service
public class KafkaConsumerServiceImpl implements KafkaConsumerService {

    @Autowired
    private PostPaymentProcessingService postPaymentProcessingService;

    @Override
    @KafkaListener(topics = "${kafka.payments.topic.name}", groupId = "${kafka.payments.group.id}", containerFactory = "kafkaListenerContainerFactory")
    public void thirdPartyPaymentListener(PaymentDetails payment) {
        log.info("Payment Object {}", payment);
        log.info("Received Payment 2.0 purpose ref no " + payment.getPurposeRefNo() + "and PR_ID " + payment.getPrId());
        MDC.put(AppConstants.PURPOSE_CODE, payment.getPuporseCode());
        try {
            postPaymentProcessingService.processPayment(payment);
        } catch (Exception e) {
            log.error("Error while processing the payment " + e.getMessage(), e);

        }
    }

}
