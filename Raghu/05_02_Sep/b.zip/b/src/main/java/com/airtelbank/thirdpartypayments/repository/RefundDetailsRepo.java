package com.airtelbank.thirdpartypayments.repository;

import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.model.entityresult.CustomResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface RefundDetailsRepo extends JpaRepository<TransactionRefundEntity, String> {

    List<TransactionRefundEntity> findByRefundTxnId(String refundTxnId);

    List<TransactionRefundEntity> findByMerchantTxnId(String merchantTxnId);

    List<TransactionRefundEntity> findByPurposeRefNo(String purposeRefNo);

    TransactionRefundEntity findByRefundReqId(String refundRefNo);

    TransactionRefundEntity findByPrId(String prId);

    @Query("SELECT new com.airtelbank.thirdpartypayments.model.entityresult.CustomResult(t.purposeRefNo, SUM(t.amount) as amount) FROM TransactionRefundEntity t where t.purposeRefNo=?1 AND refundStatus NOT IN (?2,?3) GROUP BY t.purposeRefNo")
    List<CustomResult> getTotalAmountFromPurposeRefNo(String purposeRefNo, String status1, String status2);

    Boolean existsByRefundReqId(String refundReqId);

}
