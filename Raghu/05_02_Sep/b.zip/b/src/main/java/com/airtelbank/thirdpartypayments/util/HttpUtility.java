package com.airtelbank.thirdpartypayments.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

/**
 * @author Samita Mahajan
 */

public class HttpUtility {


    public static <T> HttpEntity<T> getHttpEntityForPostRequest(final T request, HttpHeaders httpHeader) {

        HttpEntity<T> httpEntity = new HttpEntity<>(request, httpHeader);
        return httpEntity;
    }


//    public static <T> HttpEntity<T> getHttpEntityForPostRequestSms(final String username, final String password,
//                                                                final T request, final org.springframework.http.MediaType contentType) {
//
//        HttpHeaders httpHeader = new HttpHeaders() {
//            private static final long serialVersionUID = 1L;
//            {
////                String encodedAuth = Base64.getEncoder()
////                        .encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
////                String authHeader = "Basic " + new String(encodedAuth);
////                set("Authorization", authHeader);
//                setContentType(contentType);
//            }
//        };
//        HttpEntity<T> httpEntity = new HttpEntity<T>(request, httpHeader);
//        return httpEntity;
//    }


    public static HttpEntity<String> getHttpEntity(final String contentId, final String channel) {

        HttpHeaders httpHeader = new HttpHeaders() {

            /** The Constant serialVersionUID. */
            private static final long serialVersionUID = 1L;

            {
                set("Content-Type", "application/json");
                set("Accept", "application/json");
                set("contentId", "contentId");
                set("channel", channel);
            }
        };
        HttpEntity<String> httpEntity = new HttpEntity<>(httpHeader);
        return httpEntity;
    }
}
