package com.airtelbank.thirdpartypayments.repository;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MerchantTransactionDetailsRepo extends JpaRepository<MerchantTransactionDetailsEntity, String> {

    MerchantTransactionDetailsEntity findByMerchantId(String merchantId);
}
