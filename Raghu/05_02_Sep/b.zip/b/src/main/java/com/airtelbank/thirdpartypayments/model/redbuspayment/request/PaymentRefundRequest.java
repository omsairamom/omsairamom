package com.airtelbank.thirdpartypayments.model.redbuspayment.request;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Setter
@Getter
public class PaymentRefundRequest {

    @NotBlank(message = AppConstants.SECRET_KEY_NO_NOT_BLANK_MSG)
    private String secretKey;
    @NotBlank(message = AppConstants.PURPOSE_REF_NO_BLANK_EMPTY_MSG)
    private String purposeRefNo;
    @NotBlank(message = AppConstants.REFUND_REF_NO_NOT_BLANK_MSG)
    private String refundRefNo;
    @NotBlank(message = AppConstants.AMOUNT_NOT_BLANK_MSG)
    private String totalRefundAmount;

}
