package com.airtelbank.thirdpartypayments.serviceimpl.order;

import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationService;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationServiceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class OrderConfirmationServiceFactoryImpl implements OrderConfirmationServiceFactory {

    @Autowired
    private DefaultOrderConfirmationService defaultOrderConfirmationService;

    private final Map<String, OrderConfirmationService> reqBuilderMap;

    public OrderConfirmationServiceFactoryImpl() {
        reqBuilderMap = new HashMap<>();
        reqBuilderMap.put("DEFAULT", null);
    }

    @Override
    public OrderConfirmationService getOrderConfirmationService(String name) {
        if (name.equals("DEFAULT")) {
            return defaultOrderConfirmationService;
        } else {
            return reqBuilderMap.get(name);
        }
    }

}
