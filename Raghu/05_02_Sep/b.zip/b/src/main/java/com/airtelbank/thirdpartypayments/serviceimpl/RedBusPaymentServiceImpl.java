package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.hub.client.dto.request.PaymentRequest;
import com.airtelbank.payments.hub.client.dto.response.PaymentResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.model.OrderDetails;
import com.airtelbank.payments.hub.client.model.OrderItems;
import com.airtelbank.payments.hub.client.service.PHPaymentRequestService;
import com.airtelbank.payments.hub.client.service.impl.PHRefundRequestServiceImpl;
import com.airtelbank.payments.hub.dto.paymentrequest.AccountDetail;
import com.airtelbank.payments.hub.dto.paymentrequest.CustomerDetail;
import com.airtelbank.thirdpartypayments.config.CustomLocalDateConverter;
import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.dto.response.common.Constants;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.CustomerDetailsPaymentRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.HeaderRequestDTO;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.RedBusPaymentRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusBookingResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusFulFilmentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentEnquiry;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaPaymentResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsTxnRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentService;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import com.airtelbank.thirdpartypayments.util.EncryptionDencryptionUtils;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;


@Slf4j
@Service
public class RedBusPaymentServiceImpl implements RedBusPaymentService {

    @Value("${config.redbus.payment.hub.usecase}")
    private String useCase;

    @Value("${config.redbus.payment.hub.useCaseName}")
    private String useCaseName;

    @Value("${config.redbus.server.ip}")
    private String serverIp;

    @Value("${config.redbus.payment.hub.partnerId}")
    private String partnerId;

    @Value("${config.redbus.payment.hub.billerId}")
    private String billerId;

    @Value("${config.redbus.payment.encKey}")
    private String encKey;

    @Value("${config.redbus.payment.decKey}")
    private String decKey;

    @Value("${config.redbus.payment.paymentStatus}")
    private String paymentStatus;

    @Value("${config.redbus.payment.merchantId}")
    private String merchantId;

    @Value("${config.redbus.payment.param1}")
    private String param1;

    @Value("${config.redbus.payment.param2}")
    private String param2;

    @Value("${config.redbus.payment.param3}")
    private String param3;

    @Value("${config.redbus.deeplink.android}")
    private String androidDeepLink;

    @Value("${config.redbus.deeplink.ios}")
    private String iosDeepLink;

    @Value("${config.redbus.segment}")
    private String customerSegment;

    @Value("${config.redbus.offersUseCase}")
    private String offersUseCase;

    @Value("${config.redbus.payment.update.url}")
    private String paymentUpdateUrl;

    @Value("${config.redbus.payment.hub.expirytime}")
    private Integer second;

    @Value("${config.redbus.payment.hub.bufferTime}")
    private Integer bufferTime;

    @Autowired
    private PHPaymentRequestService phPaymentRequestService;

    @Autowired
    private PHRefundRequestServiceImpl pHRefundRequestServiceImpl;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private HttpUtil httpUtil;

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    @Autowired
    private OrderDetailsTxnRepo orderDetailsTxnRepo;

    @Autowired
    private RefundDetailsRepo refundDetailsRepo;

    @Autowired
    MessageSource messageSource;

    @Autowired
    ValidationService validateService;

    private static final String MASK = "****";

    /**
     * Initiate payment request and call payments-hub-client-library for payment If
     * payment initiate success then update the payment status is initiated
     *
     * @param redBusPaymentRequest
     * @param headerRequestDTO
     * @return RedBusPaymentResponse
     */
    @Override
    public RedBusPaymentResponse postDataToPaymentHub(CustomerDetailsPaymentRequest redBusPaymentRequest,
                                                      HeaderRequestDTO headerRequestDTO) {

        log.info("Entering into postDataToPaymentHub() method :: {}", redBusPaymentRequest);
        validateService.validateRequestParam(headerRequestDTO);
        String redirectUrl;
        String enquiryUrl;
        String initiatePaymentDeepLinkURL;
        OrderDetailsEntity orderPaymentDetails = null;
        String channel = headerRequestDTO.getChannel();
        try {
            orderPaymentDetails = orderDetailsRepo.findByPurposeRefNo(redBusPaymentRequest.getPurposeRefNo());
            log.info("Get response from orderDetailsRepo.findByPurposeRefNo() for  postDataToPaymentHub() method");
            if (null == orderPaymentDetails) {
                log.error("Error into findByPurposeRefNo() in  postDataToPaymentHub()  method :{}", orderPaymentDetails);
                throw new GenericException(ResponseErrorCode.NOT_FOUND,
                        messageSource.getMessage(AppConstants.Key.DB_FAILED_MSG, null, Locale.getDefault()),
                        messageSource.getMessage(AppConstants.Key.DB_FAILED_CODE, null, Locale.getDefault()));
            }
        } catch (Exception e) {
            log.error(
                    "Exception :: {} occurs in orderDetailsRepo.findByPurposeRefNo() in  postDataToPaymentHub() method for PurposeNo ::: {}",
                    e.getMessage(), redBusPaymentRequest.getPurposeRefNo());
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }

        initiatePaymentDeepLinkURL = prepareInitiatePaymentDeepLink(channel, orderPaymentDetails.getPurposeRefNo());
        log.info(
                "prepareInitiatePaymentDeepLink method response :: {} from postDataToPaymentHub() method for PurposeRefNo::{}",
                initiatePaymentDeepLinkURL, orderPaymentDetails.getPurposeRefNo());
        BigDecimal orderId = orderDetailsTxnRepo.getNextSeriesId();
        log.info("OrderIdTxn sequence in  postDataToPaymentHub() method ::{}", orderId);
        List<OrderItems> orderItemsList = new ArrayList<>();
        CustomerDetail customerDetail = CustomerDetail.builder().custMsisdn(redBusPaymentRequest.getMobileNo())
                .custName(redBusPaymentRequest.getCustomerName()).segment(customerSegment).build();
        AccountDetail accountDetail = AccountDetail.builder().billerId(billerId).billerCode(param1).build();
        OrderItems orderItems = OrderItems.builder().amount(orderPaymentDetails.getAmount().doubleValue())
                .orderItemId(String.valueOf(orderId)).billerDetails(accountDetail).offersUsecase(offersUseCase).build();
        orderItemsList.add(orderItems);
        OrderDetails orderDetailsRequest = OrderDetails.builder().orderItems(orderItemsList).build();
        Map<String, Object> additionalDetails = new HashMap<>();
        additionalDetails.put(AppConstants.MASKED_NAT_ID,
                MASK + redBusPaymentRequest.getMobileNo().substring(redBusPaymentRequest.getMobileNo().length() - 4
                ));
        additionalDetails.put(AppConstants.MOBILE_NUMBER, redBusPaymentRequest.getMobileNo());

        PaymentRequest paymentRequest = PaymentRequest.builder().useCase(useCase).accessChannel(channel)
                .totalAmount(BigDecimal.valueOf(orderPaymentDetails.getAmount().doubleValue()))
                .orderId(String.valueOf(orderId)).partnerId(partnerId).orderDetails(orderDetailsRequest)
                .customerDetail(customerDetail).additionalDetails(additionalDetails)
                .usecaseHomeLink(initiatePaymentDeepLinkURL)
                .paymentExpiry(CustomLocalDateConverter.getPaymentDateTime(second - bufferTime)).build();
        log.info("PaymentRequest details in  postDataToPaymentHub() method ::{}", paymentRequest);

        ResponseDTO<PaymentResponse> transactionResponse = phPaymentRequestService.paymentRequest(useCase,
                paymentRequest, headerRequestDTO.getContentId());
        log.info("PaymentHub TransactionResponse  in  postDataToPaymentHub() method ::{}", transactionResponse);

        if (transactionResponse == null || null == transactionResponse.getData()) {
            log.error("Exception occurs in details from postDataToPaymentHub() method :: {}", transactionResponse);
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.PAYMENT_ERROR_DESC, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.PAYMENT_ERROR_CODE, null, Locale.getDefault()));
        }
        savePaymentResponse(orderPaymentDetails, transactionResponse, redBusPaymentRequest, orderId);
        redirectUrl = transactionResponse.getData().getRedirectionUrl();
        enquiryUrl = new StringBuilder(serverIp).append(AppConstants.RED_BUS_BASE_URL)
                .append(AppConstants.FULFILMENT_URL).toString();
        return RedBusPaymentResponse.builder().paymentId(transactionResponse.getData().getPaymentId())
                .redirectionUrl(redirectUrl).enquiryUrl(enquiryUrl).build();
    }

    /**
     * Save booking details information
     *
     * @param redBusPaymentRequest
     */
    public OrderDetailsEntity saveRedBusBookingDetailsRequest(RedBusPaymentRequest redBusPaymentRequest) {

        log.info("Entering into saveRedBusBookingDetailsRequest() method :: {}", redBusPaymentRequest);
        OrderDetailsEntity orderDetailsEntitySaveData = null;
        OrderDetailsEntity orderDetailsEntity = OrderDetailsEntity.builder()
                .purposeRefNo(redBusPaymentRequest.getPurposeRefNo())
                .amount(BigDecimal.valueOf(redBusPaymentRequest.getTotalAmount())).merchantId(merchantId)
                .build();
        try {
            orderDetailsEntitySaveData = orderDetailsRepo.saveAndFlush(orderDetailsEntity);
            log.info("saved the Booking details in DB::{}", orderDetailsEntitySaveData);
        } catch (Exception e) {
            log.info("Exception :: {} while inserting data for booking ", e.getMessage());
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
        log.info("Response return saveRedBusBookingDetailsRequest() method :: {}", orderDetailsEntitySaveData);
        return orderDetailsEntitySaveData;
    }

    /**
     * fetch the payment status
     *
     * @param purposeRefNo
     * @return RedBusPaymentResponse
     */
    @Override
    public RedBusPaymentStatusResponse getPaymentStatusEnquiry(String purposeRefNo) {

        log.info("Entering into getPaymentStatus() method :: {}", purposeRefNo);
        OrderDetailsEntity paymentStatusResponse = null;
        try {
            paymentStatusResponse = orderDetailsRepo.findByPurposeRefNo(purposeRefNo);
            log.info("Get paymentStatus details from orderDetailsRepo.findByPurposeRefNo() method ::");
        } catch (Exception e) {
            log.error("Exception :: {} occurs in orderDetailsRepo.findByPurposeRefNo() for PurposeNo :: {}",
                    e.getMessage(), purposeRefNo);
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
        if (null == paymentStatusResponse) {
            log.error("Error into findByPurposeRefNo() method because response is :: {}", paymentStatusResponse);
            throw new GenericException(ResponseErrorCode.NOT_FOUND,
                    messageSource.getMessage(AppConstants.Key.DB_FAILED_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_FAILED_CODE, null, Locale.getDefault()));
        }
        log.info("PaymentStatus details from ::{}", paymentStatusResponse.getStatus().getValue());

        return RedBusPaymentStatusResponse.builder().paymentStatus(paymentStatusResponse.getStatus().getValue())
                .paymentId(paymentStatusResponse.getPrID()).purposeRefNo(paymentStatusResponse.getPurposeRefNo())
                .paymentRefId(paymentStatusResponse.getMerchantTxnId()).errorCode(generateCustomPaymentErrorData(paymentStatusResponse.getStatus().getValue(), "C"))
                .errorMessage(generateCustomPaymentErrorData(paymentStatusResponse.getStatus().getValue(), "M"))
                .build();
    }

    private String generateCustomPaymentErrorData(String status, String type) {
        String errorMessage = null;
        if (OrderStatus.INITIATED.getValue().equalsIgnoreCase(status)) {
            errorMessage = messageSource.getMessage(AppConstants.Key.PAYMENT_STATUS_ERROR_INITIATED_MSG, null, Locale.getDefault());
        } else if (OrderStatus.FAILED.getValue().equalsIgnoreCase(status)) {
            errorMessage = messageSource.getMessage(AppConstants.Key.PAYMENT_STATUS_ERROR_FAILED_MSG, null, Locale.getDefault());
        }

        if (Objects.nonNull(errorMessage) && "C".equals(type)) {
            return messageSource.getMessage(AppConstants.Key.PAYMENT_STATUS_ENQUIRY_ERROR_CODE, null, Locale.getDefault());
        } else if (Objects.nonNull(errorMessage) && "M".equals(type)) {
            return errorMessage;
        }

        return null;
    }

    /**
     * save the customer booking details
     *
     * @param redBusPaymentRequest
     * @param headerRequestDTO
     * @return RedBusPaymentResponse
     */
    @Override
    public RedBusBookingResponse saveRedBusBookingDetails(PaymentData redBusPaymentRequest,
                                                          HeaderRequestDTO headerRequestDTO) {

        log.info("Entering into saveRedBusBookingDetails() method :: {}", redBusPaymentRequest);

        String decData = StringUtils.EMPTY;
        RedBusPaymentRequest redBusPaymentRequestValue = null;
        try {
            decData = EncryptionDencryptionUtils.dataDecryptByPrivateKey(decKey, redBusPaymentRequest.getData());
            redBusPaymentRequestValue = objectMapper.readValue(decData, RedBusPaymentRequest.class);
        } catch (Exception e) {
            log.error("Error :: {} into red bus booking details request data decryption", e.getMessage());
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.DENC_FAILED_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DENC_FAILED_CODE, null, Locale.getDefault()));
        }
        validateService.validateRequestParam(redBusPaymentRequestValue);
        validateService.validateForSecretKey(redBusPaymentRequestValue.getSecretKey());
        if (Boolean.TRUE.equals(orderDetailsRepo.existsByPurposeRefNo(redBusPaymentRequestValue.getPurposeRefNo()))) {
            log.error("Record is already available for the purposeRefNo :: {}",
                    redBusPaymentRequestValue.getPurposeRefNo());
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.DB_CONSTRAINT_ERROR_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_CONSTRAINT_ERROR_CODE, null, Locale.getDefault()));
        }
        OrderDetailsEntity orderDetailsEntity = saveRedBusBookingDetailsRequest(redBusPaymentRequestValue);
        log.info("Merchant Txn Id in Response return saveRedBusBookingDetailsRequest() method :: {}", orderDetailsEntity.getMerchantTxnId());
        return RedBusBookingResponse.builder().purposeRefNo(orderDetailsEntity.getPurposeRefNo())
                .paymentRefId(orderDetailsEntity.getMerchantTxnId()).build();
    }

    /**
     * update payment status to Redbus
     *
     * @param kafkapaymentResponse
     * @return ResponseEntity<String>
     */
    @Override
    public ResponseEntity<String> updatePaymentStatus(KafkaPaymentResponse kafkapaymentResponse) {

        log.info("Entering into updatePaymentStatus() method :: {}", kafkapaymentResponse);
        String encData = StringUtils.EMPTY;
        String data = StringUtils.EMPTY;
        try {
            data = objectMapper.writeValueAsString(kafkapaymentResponse);
            log.info("Converted object to json string ::: {}", data);
            encData = EncryptionDencryptionUtils.dataEncryptByPublicKey(encKey, data);
            log.info("Get Encrypted request  for  updatePaymentStatus() method ::: {}", encData);
        } catch (Exception e) {
            log.error("Exception occurs ::: {} in encryption of data ::: {}", e.getMessage(), data);
            throw new GenericException(ResponseErrorCode.EXCEPTION);
        }
        PaymentData paymentData = PaymentData.builder().data(encData).build();
        Map<String, String> headers = new HashMap<>();
        headers.put(AppConstants.HeaderKey.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        log.info(" calling RedBus update Payment Status API with PaymentData  :: {} ", paymentData);
        String hitRequestResponse = httpUtil.hitRequest(paymentUpdateUrl, paymentData, String.class, headers,
                HttpMethod.POST, true);
        log.info("Response return from  Redbus Payment Update API  :: {}", hitRequestResponse);
        return new ResponseEntity<>(hitRequestResponse, HttpStatus.OK);
    }


    /**
     * @param prID
     * @return OrderDetailsEntity
     */
    @Override
    public RedBusPaymentEnquiry getFulfilmentStatusEnquiryFromPrId(String prID, HeaderRequestDTO headerRequestDTO) {

        log.info("Entering into getFulfilmentStatusFromPrId() method :: {}", prID);
        String fulfilmentPaymentStatus = OrderStatus.FAILED.getValue();
        validateService.validateRequestParam(headerRequestDTO);
        Map<String, String> statusMap = null;
        OrderDetailsEntity fulfilmentStatusResponse = null;
        try {
            fulfilmentStatusResponse = orderDetailsRepo.findByPrID(prID);
            log.info("Get fulfilmentStatus using prId from getFulfilmentStatusFromPrId() method ::");

        } catch (Exception e) {
            log.error("Exception :: {} occurs in orderDetailsRepo.findByPrID() for PrId :: {}", e.getMessage(), prID);
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
        if (null == fulfilmentStatusResponse) {
            log.error("Getting FulfilmentStatusResponse is findByPrID() method because response is :: {}", fulfilmentStatusResponse);
            throw new GenericException(ResponseErrorCode.NOT_FOUND,
                    messageSource.getMessage(AppConstants.Key.DB_FAILED_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_FAILED_CODE, null, Locale.getDefault()));
        } else {
            statusMap = CommonUtil.prepareFulfilmentStatus(fulfilmentStatusResponse);
            log.info(
                    "Get statusMap details using prepareFulfilmentStatus method in  getFulfilmentStatusFromPrId() method ::{}", statusMap);
        }
        if ((OrderStatus.SUCCESS.getValue()
                .equalsIgnoreCase(fulfilmentStatusResponse.getStatus().getValue()))) {
            fulfilmentPaymentStatus = fulfilmentStatusResponse.getStatus().getValue();
        }
        String fulfilmentDeepLinkURL = prepareFulfilmentEnquiryDeepLink(headerRequestDTO.getChannel(),
                fulfilmentPaymentStatus, fulfilmentStatusResponse.getPurposeRefNo());

        log.info("Response :: {} from prepareFulfilmentEnquiryDeepLink() method :: ", fulfilmentDeepLinkURL);

        RedBusFulFilmentResponse redBusFulFilamentResponse = RedBusFulFilmentResponse.builder()
                .paymentRefId(fulfilmentStatusResponse.getPrID())
                .paymentStatus(fulfilmentStatusResponse.getStatus().getValue())
                .purposeRefNo(fulfilmentStatusResponse.getPurposeRefNo()).fulfilmentDeepLinkUrl(fulfilmentDeepLinkURL)
                .source(fulfilmentStatusResponse.getSource()).destination(fulfilmentStatusResponse.getDestination())
                .busType(fulfilmentStatusResponse.getBusType()).doj(fulfilmentStatusResponse.getDoj())
                .busType(fulfilmentStatusResponse.getBusType()).travelsName(fulfilmentStatusResponse.getTravelsName())
                .build();
        log.info("Response return from  getFulfilmentStatusFromPrId() method :: {}", redBusFulFilamentResponse);
        return RedBusPaymentEnquiry.builder().map(statusMap).redBusFulFilmentResponse(redBusFulFilamentResponse).build();
    }

    private String prepareInitiatePaymentDeepLink(String channel, String purposeRefNo) {
        log.info("Entering into prepareInitiatePaymentDeepLink() method :: {},{}", channel, purposeRefNo);

        if (AppConstants.ANDROID.equals(channel)) {
            return new StringBuilder(androidDeepLink).append(Constants.ORDER_ID).append(purposeRefNo).append(Constants.STATUS).append(paymentStatus).toString();
        } else if (AppConstants.IOS.equals(channel)) {
            return new StringBuilder(iosDeepLink).append(Constants.ORDER_ID).append(purposeRefNo).append(Constants.STATUS).append(paymentStatus).toString();
        } else {
            log.error(" Exception in prepareInitiatePaymentDeepLink because channel is :: {}", channel);
            throw new GenericException(ResponseErrorCode.INVALID_REQUEST_BODY,
                    messageSource.getMessage(AppConstants.Key.INVALID_CHANNEL_ERROR_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.INVALID_CHANNEL_ERROR_CODE, null, Locale.getDefault()));
        }
    }

    private String prepareFulfilmentEnquiryDeepLink(String channel, String paymentStatus, String purposeRefNo) {
        log.info("Entering into prepareFulfilmentEnquiryDeepLink() method :: {},{},{}", channel, paymentStatus,
                purposeRefNo);
        if (AppConstants.ANDROID.equals(channel)) {
            return new StringBuilder(androidDeepLink).append(Constants.ORDER_ID).append(purposeRefNo).append(Constants.STATUS).append(paymentStatus).toString();
        } else if (AppConstants.IOS.equals(channel)) {
            return new StringBuilder(iosDeepLink).append(Constants.ORDER_ID).append(purposeRefNo).append(Constants.STATUS).append(paymentStatus).toString();
        } else {
            log.error(" Exception in prepareFulfilmentEnquiryDeepLink because channel is :: {}", channel);
            throw new GenericException(ResponseErrorCode.INVALID_REQUEST_BODY,
                    messageSource.getMessage(AppConstants.Key.INVALID_CHANNEL_ERROR_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.INVALID_CHANNEL_ERROR_CODE, null, Locale.getDefault()));
        }
    }

    private void savePaymentResponse(OrderDetailsEntity orderPaymentDetails, ResponseDTO<PaymentResponse> transactionResponse,
                                     CustomerDetailsPaymentRequest redBusPaymentRequest, BigDecimal orderId) {
        try {
            List<OrderDetailsTxn> orderDetailsTxnList = new ArrayList<>();
            OrderDetailsTxn orderDetailsTxn = OrderDetailsTxn.builder().orderDetailsEntity(orderPaymentDetails)
                    .orderDetailsTxnId(String.valueOf(orderId)).build();
            orderDetailsTxnList.add(orderDetailsTxn);
            orderPaymentDetails.setPrID(transactionResponse.getData().getPaymentId());
            orderPaymentDetails.setCustomerId(redBusPaymentRequest.getMobileNo());
            orderPaymentDetails.setStatus(OrderStatus.INITIATED);
            orderPaymentDetails.setOrderDetailsTxn(orderDetailsTxnList);
            orderPaymentDetails.setSource(redBusPaymentRequest.getSource());
            orderPaymentDetails.setDestination(redBusPaymentRequest.getDestination());
            orderPaymentDetails.setDoj(redBusPaymentRequest.getDoj());
            orderPaymentDetails.setTravelsName(redBusPaymentRequest.getTravelsName());
            orderPaymentDetails.setBusType(redBusPaymentRequest.getBusType());
            orderDetailsRepo.save(orderPaymentDetails);
            log.info("saved details  to the database in orderDetailsEntity for purposeRefNo::{}", redBusPaymentRequest.getPurposeRefNo());

        } catch (Exception e) {
            log.error("Exception :: {} in saving detail in orderDetailsRepo.save() method", e.getMessage());
            throw new GenericException(ResponseErrorCode.EXCEPTION,
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()),
                    messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
    }
}
