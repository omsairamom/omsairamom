package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.ActorResponse;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author b0206596
 */

@Slf4j
@RestController
@RequestMapping(value = "thirdPartyPayments/api/v1/purpose")
public class ActorDetailsController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    LoggerModel loggerModel;

    /**
     * @param purposeCode-      Purpose code to identify the purpose of the code
     * @param purposeRefNumber- Unique parameter to identify unique payments each
     *                          time
     * @throws ThirdPartyPaymentsException
     */

    @CrossOrigin
    @GetMapping(path = "/{purposeCode}/{purposeRefNumber}")
    public ResponseEntity<RestApiResponse> getPurposeDetails(@Valid @PathVariable String purposeCode,
                                                             @Valid @PathVariable String purposeRefNumber) throws ThirdPartyPaymentsException {

        ResponseEntity<RestApiResponse> response = null;
        log.info("Initiate with Post Request {},{}", purposeCode, purposeRefNumber);
        MDC.put(AppConstants.PURPOSE_CODE, purposeCode);

        ActorResponse actorResponse = paymentService.sendPurposeDetails(purposeCode, purposeRefNumber);

        response = ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse("SUCCESS", actorResponse);

        return response;
    }
}
