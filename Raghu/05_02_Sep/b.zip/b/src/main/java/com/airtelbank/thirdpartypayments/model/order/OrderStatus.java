package com.airtelbank.thirdpartypayments.model.order;

public enum OrderStatus {

    INITIATED("INITIATED"), PAYMENT_COMPLETED("PAYMENT_COMPLETED"), COMPLETED("COMPLETED"),
    INITIALIZATION_FAILED("INITIALIZATION_FAILED"), PAYMENT_FAILED("PAYMENT_FAILED"),
    PAYMENT_PENDING("PAYMENT_PENDING"), CONFIRMATION_FAILED("CONFIRMATION_FAILED"),
    CONFIRMATION_PENDING("CONFIRMATION_PENDING"), REFUND_INITIATED("REFUND_INITIATED"), REFUNDED("REFUNDED"),
    REFUND_FAILED("REFUND_FAILED"), SUCCESS("SUCCESS"), FAILED("FAILED");

    OrderStatus(String value) {
        this.value = value;
    }

    private final String value;

    public String getValue() {
        return value;
    }

    int frontEndStatus = 2;

    public int parseToFrontEndStatus() {
        switch (this) {
            case COMPLETED:
                frontEndStatus = 0;
                break;
            case PAYMENT_COMPLETED:
                frontEndStatus = 2;
                break;
            case PAYMENT_PENDING:
                frontEndStatus = 2;
                break;
            default:
                frontEndStatus = 2;
        }
        return frontEndStatus;
    }

    public String parseToTxnEnquiryStatus() {
        String status = "PENDING";
        switch (this) {
            case COMPLETED:
                status = "SUCCESS";
                break;
            case CONFIRMATION_PENDING:
            case CONFIRMATION_FAILED:
            case PAYMENT_COMPLETED:
                status = "SUCCESS";
                break;
            case INITIATED:
                status = "INITIATED";
                break;
            case PAYMENT_FAILED:
                status = "FAILURE";
                break;
            default:
                status = "FAILURE";
                break;
        }

        return status;

    }

}
