package com.airtelbank.thirdpartypayments.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class LogMasker {

    @Autowired
    private LogMaskingConfiguration logMaskingConfiguration;

    private final String MASK = "****";
    private String REGEX = null;
    private Pattern PATTERN = null;
    private String MASK_PATTERN = null;

    @PostConstruct
    public void setPatterns() throws IOException {
        MASK_PATTERN = logMaskingConfiguration.getPattern();
        REGEX = logMaskingConfiguration.getRegex();
        PATTERN = Pattern.compile(REGEX);
    }

    private String patternReplace(final String MASK, final Pattern PATTERN, String message) {
        try {
            // setPatterns();
            message = message.replaceAll("\\s?:\\s?", ":");
            Matcher matcher = PATTERN.matcher(message);
            StringBuffer result = new StringBuffer();
            while (matcher.find()) {
                String replacement = "";
                String group = matcher.group(0);
                if (group != null) {
                    if (group.contains("<") && group.contains("</") && group.contains(">")) {
                        replacement = group.substring(0, group.indexOf(">") + 1) + MASK
                                + group.substring(group.lastIndexOf("</"));
                    } else {
                        String[] patternsToBeMasked = MASK_PATTERN.split("\\|");
                        for (String pattern : patternsToBeMasked) {
                            if (group.contains(pattern)) {
                                char lastChar = group.charAt(group.length() - 1);
                                group = group.subSequence(pattern.length(), group.length() - 1).toString();
                                replacement = MASK;
                                replacement = pattern + replacement + lastChar;
                            }
                        }
                    }
                } else {
                    replacement = MASK;
                }
                matcher.appendReplacement(result, replacement);
            }
            matcher.appendTail(result);
            return result.toString();
        } catch (Exception e) {
            return message;
        }
    }

    public String patternReplace(String message) {
        try {
            // setPatterns();
            message = message.replaceAll("\\s?:\\s?", ":");
            Matcher matcher = PATTERN.matcher(message);
            StringBuffer result = new StringBuffer();
            while (matcher.find()) {
                String replacement = "";
                String group = matcher.group(0);
                if (group != null) {
                    if (group.contains("<") && group.contains("</") && group.contains(">")) {
                        replacement = group.substring(0, group.indexOf(">") + 1) + MASK
                                + group.substring(group.lastIndexOf("</"));
                    } else {
                        String[] patternsToBeMasked = MASK_PATTERN.split("\\|");
                        for (String pattern : patternsToBeMasked) {
                            if (group.contains(pattern)) {
                                char lastChar = group.charAt(group.length() - 1);
                                group = group.subSequence(pattern.length(), group.length() - 1).toString();
                                replacement = MASK;
                                replacement = pattern + replacement + lastChar;
                            }
                        }
                    }
                } else {
                    replacement = MASK;
                }
                matcher.appendReplacement(result, replacement);
            }
            matcher.appendTail(result);
            return result.toString();
        } catch (Exception e) {
            return message;
        }
    }

}
