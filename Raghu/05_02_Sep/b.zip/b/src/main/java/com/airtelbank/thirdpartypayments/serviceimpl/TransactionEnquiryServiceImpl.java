package com.airtelbank.thirdpartypayments.serviceimpl;


import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryRequest;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponse;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponseDetail;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.TransactionEnquiryService;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author b0206596
 */
@Slf4j
@Service
public class TransactionEnquiryServiceImpl implements TransactionEnquiryService {

    @Autowired
    OrderDetailsRepo orderDetailsRepo;

    @Autowired
    RefundDetailsRepo refundDetailsRepo;

    @Autowired
    HttpUtil httpUtil;

    @Autowired
    private ValidationService validationService;

    @Autowired
    private Environment environment;

    @Override
    public TransactionEnquiryResponse enquiryInit(TransactionEnquiryRequest transactionEnquiryRequest, String appToken)
            throws ThirdPartyPaymentsException {
        TransactionEnquiryResponse enquiryResponse = null;

        OrderDetailsEntity orderDetailsEntity = orderDetailsRepo
                .findByMerchantTxnId(transactionEnquiryRequest.getMerchantTxnId());
        log.info("Data from the Database {}", orderDetailsEntity);

        if (orderDetailsEntity == null) {
            log.info("No data found for that MerchantTxnID {}", transactionEnquiryRequest.getMerchantTxnId());
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_TRANSACTIONID);
        }

        if (appToken != null) {
            log.info("Entering into Validation Service");
            validationService.validateAppToken(appToken, orderDetailsEntity.getMerchantId());
        }

        String clientSecret = validationService.getClientSecret(orderDetailsEntity.getMerchantId());


        if (Boolean.TRUE.equals(isForwardTxnEnquiry(transactionEnquiryRequest))) {
            enquiryResponse = parse(orderDetailsEntity, appToken, clientSecret);

        } else if (transactionEnquiryRequest.getType().equals("REFUND")) {
            log.info("Entering into Refund Enquiry");
            enquiryResponse = refundEnquiry(transactionEnquiryRequest, appToken, clientSecret);
        }
        return enquiryResponse;
    }

    private Boolean isForwardTxnEnquiry(TransactionEnquiryRequest request) {
        return Objects.isNull(request.getType()) || "FORWARD".equals(request.getType());
    }

    private TransactionEnquiryResponse parse(OrderDetailsEntity orderEntity, String appToken, String clientSecret) {
        TransactionEnquiryResponse response = new TransactionEnquiryResponse();
        List<TransactionEnquiryResponseDetail> details = new ArrayList<>();
        TransactionEnquiryResponseDetail transactionEnquiryResponseDetails = new TransactionEnquiryResponseDetail();

        transactionEnquiryResponseDetails.setAmount(orderEntity.getAmount());

        transactionEnquiryResponseDetails.setStatus(orderEntity.getStatus().parseToTxnEnquiryStatus());

        String formattedDate = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss z").format(orderEntity.getUpdationDate());

        transactionEnquiryResponseDetails.setTxnDate(formattedDate);
        transactionEnquiryResponseDetails.setTxnId(orderEntity.getMerchantTxnId());
        transactionEnquiryResponseDetails.setType("FORWARD");
        transactionEnquiryResponseDetails.setHash(
                DigestUtils.sha512Hex(appToken + '#' + 0 + '#' + orderEntity.getMerchantTxnId() + '#' + clientSecret));
        details.add(transactionEnquiryResponseDetails);
        response.setTransactionDetails(details);
        return response;
    }

    private TransactionEnquiryResponse refundEnquiry(TransactionEnquiryRequest request, String appToken,
                                                     String clientSecret) throws ThirdPartyPaymentsException {

        TransactionEnquiryResponse transactionEnquiryResponse = new TransactionEnquiryResponse();
        TransactionEnquiryResponseDetail transactionEnquiryResponseDetails = null;
        List<TransactionEnquiryResponseDetail> details = new ArrayList<>();

        TransactionRefundEntity transactionRefundEntity = null;
        List<TransactionRefundEntity> transactionRefundEntityList = null;

        if (request.getRefundTxnId() == null) {

            transactionRefundEntityList = refundDetailsRepo.findByMerchantTxnId(request.getMerchantTxnId());

            for (TransactionRefundEntity entity : transactionRefundEntityList) {
                transactionEnquiryResponseDetails = TransactionEnquiryResponseDetail.builder()
                        .amount(entity.getAmount()).txnDate(entity.getTxnDate())
                        .merchantTxnId(entity.getMerchantTxnId()).status(entity.getRefundStatus())
                        .type(request.getType()).txnId(entity.getPrId()).hash(DigestUtils.sha512Hex(appToken + '#'
                                + entity.getRefundStatus() + '#' + entity.getPrId() + '#' + clientSecret))
                        .build();
            }
            details.add(transactionEnquiryResponseDetails);
            transactionEnquiryResponse.setTransactionDetails(details);

        } else {
            transactionRefundEntityList = refundDetailsRepo.findByRefundTxnId(request.getRefundTxnId());
            if (transactionRefundEntityList.isEmpty()) {
                log.info("No data found in database for RefundTxnId {}", request.getRefundTxnId());
                throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_TRANSACTIONID);
            } else if (transactionRefundEntityList.get(0).getRefundTxnId().equals(request.getRefundTxnId())) {

                transactionRefundEntity = transactionRefundEntityList.get(0);
                transactionEnquiryResponseDetails = TransactionEnquiryResponseDetail.builder()
                        .amount(transactionRefundEntity.getAmount()).txnDate(transactionRefundEntity.getTxnDate())
                        .merchantTxnId(transactionRefundEntity.getMerchantTxnId())
                        .status(transactionRefundEntity.getRefundStatus()).type(request.getType())
                        .txnId(transactionRefundEntity.getPrId())
                        .hash(DigestUtils.sha512Hex(appToken + '#' + transactionRefundEntity.getRefundStatus() + '#'
                                + transactionRefundEntity.getPrId() + '#' + clientSecret))
                        .build();
            }
            details.add(transactionEnquiryResponseDetails);
            transactionEnquiryResponse.setTransactionDetails(details);
        }
        return transactionEnquiryResponse;
    }

}
