package com.airtelbank.thirdpartypayments.dto.response.common;

public class Constants {


    private Constants() {
    }

    public static final int STATUS_SUCCESS = 0;
    public static final int STATUS_FAILURE = 1;
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAILURE";
    public static final String UNEXPECTED_ERRMSG = "Something went wrong please try later";
    public static final String CODE_FAILURE = "1";
    public static final String CODE_SUCCCESS = "000";
    public static final String CHANNEL = "channel";
    public static final String CONTENT_ID = "contentId";
    public static final String REQUEST_ID = "requestId";
    public static final String CUSTOMER_ID = "customerId";
    public static final String USER_AGENT = "User-Agent";
    public static final String IP_ADDRESS = "ipAddress";
    public static final String SMS = "SMS";
    public static final String TRANSACTION = "transaction";
    public static final String IMMEDIATE = "I";
    public static final String AUTOREFUND = "AUTOREFUND";
    public static final String APB_CODE = "APB_1001";
    public static final String EXCEPTION_MSG = "Exception exception : {}";
    public static final String PURPOSEREFNO = "?purposeRefNo=";
    public static final String ORDER_ID = "?orderId=";
    public static final String STATUS = "?status=";
    public static final String ERROR_CODE = "APB-REQ-101";
    public static final String GENERIC_ERROR_MSG = "We are facing some technical issue";
    public static final String MOBILE_NO="?mobileNo=";
}
