package com.airtelbank.thirdpartypayments.serviceimpl.order;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationRequest;
import com.airtelbank.thirdpartypayments.model.order.OrderRequest;
import com.airtelbank.thirdpartypayments.service.order.RequestBuilder;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class DefaultRequestBuilder implements RequestBuilder<DefaultOrderConfirmationRequest> {

    @Override
    public OrderRequest<DefaultOrderConfirmationRequest> buildRequest(
            OrderDetailsEntity orderDetails, MerchantTransactionDetailsEntity merchantTransactionDetails) {

        // hash : sha512(merchantId + "#" + merchantTxnId + "#" + amount + "#" + status
        // + "#" + client_secret)

        StringBuilder hash = new StringBuilder(merchantTransactionDetails.getMerchantId());
        hash.append("#" + orderDetails.getMerchantTxnId());
        hash.append("#" + orderDetails.getAmount());
        hash.append("#" + orderDetails.getStatus());

        DefaultOrderConfirmationRequest defaultOrderRequest = DefaultOrderConfirmationRequest.builder()
                .amount(orderDetails.getAmount()).merchantId(merchantTransactionDetails.getMerchantId())
                .merchantTxnId(orderDetails.getMerchantTxnId()).status(orderDetails.getStatus().getValue())
                .txnId(orderDetails.getPrID()).txnDate(new Date()).hash(DigestUtils.sha512Hex(hash.toString())).build();

        OrderRequest<DefaultOrderConfirmationRequest> orderRequest = new OrderRequest<>();
        orderRequest.setData(defaultOrderRequest);

        return orderRequest;
    }

}
