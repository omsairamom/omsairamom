package com.airtelbank.thirdpartypayments.repository;

import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderDetailsRepo extends JpaRepository<OrderDetailsEntity, String> {

    OrderDetailsEntity findByPurposeRefNo(String purposeRefNo);

    OrderDetailsEntity findByMerchantTxnId(String merchantTxnId);

    OrderDetailsEntity findByPrID(String prID);

    Boolean existsByPurposeRefNo(String purposeRefNo);

}
