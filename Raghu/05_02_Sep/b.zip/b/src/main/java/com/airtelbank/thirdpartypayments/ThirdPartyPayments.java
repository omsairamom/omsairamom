package com.airtelbank.thirdpartypayments;


import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableAspectJAutoProxy(proxyTargetClass = true)
@EnableRetry
@SpringBootApplication
@EnableTransactionManagement
@ComponentScan(basePackages = {"com.airtelbank"})
@EnableDiscoveryClient
@EnableEncryptableProperties
public class ThirdPartyPayments extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(ThirdPartyPayments.class, args);
        System.out.println("Application Start....!!");
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ThirdPartyPayments.class);
    }

    @Bean
    MeterRegistryCustomizer<MeterRegistry> metricsCommonTags() {
        return registry -> registry.config().commonTags("application", "Reverse Integration Payments", "vertical", "Consumer Use Cases");
    }
}
