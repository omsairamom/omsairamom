package com.airtelbank.thirdpartypayments.repository;

import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface OrderDetailsTxnRepo extends JpaRepository<OrderDetailsTxn, String> {

    @Transactional
    @Query(value = "select * from ORDER_DETAILS_TXN ob where ob.MERCHANT_TXN_ID = ?1", nativeQuery = true)
    List<OrderDetailsTxn> findbyMerchantTxnId(String merchantTxnId);

    @Query(value = "SELECT ORDER_DETAILS_TXN_ID.nextval FROM dual", nativeQuery = true)
    BigDecimal getNextSeriesId();
}
