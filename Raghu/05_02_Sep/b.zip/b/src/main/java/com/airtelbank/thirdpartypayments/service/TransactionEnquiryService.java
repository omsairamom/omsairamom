package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryRequest;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponse;

public interface TransactionEnquiryService {
    TransactionEnquiryResponse enquiryInit(TransactionEnquiryRequest transactionEnquiryRequest, String appToken) throws ThirdPartyPaymentsException;


}
