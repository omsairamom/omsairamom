package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.OrderResponse;

public interface OrderService {

    boolean confirmOrder(OrderDetailsEntity order, MerchantTransactionDetailsEntity merchant) throws ThirdPartyPaymentsException;

    // change response to order detail object
    OrderResponse getOrderDetail(String purposeRefNo) throws ThirdPartyPaymentsException;

}
