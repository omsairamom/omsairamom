package com.airtelbank.thirdpartypayments.dto.response.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * @author Samita Mahajan
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class Metrics {
    private int size;
    private List<Link> links;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Getter
    @Setter
    @ToString
    public static class Link {
        private String rel;
        private String href;
        private int offset;
        private int limit;
    }
}
