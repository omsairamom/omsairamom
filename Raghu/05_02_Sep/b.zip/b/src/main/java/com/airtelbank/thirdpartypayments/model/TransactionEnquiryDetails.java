package com.airtelbank.thirdpartypayments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionEnquiryDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;


}
