package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.model.PaymentDetails;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.service.OrderService;
import com.airtelbank.thirdpartypayments.service.PostPaymentProcessingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class PostPaymentProcessingServiceImpl implements PostPaymentProcessingService {

    @Autowired
    private OrderService orderService;

    @Autowired
    private MerchantTransactionDetailsRepo merchantTransactionDetailsRepo;

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    protected static final Map<Integer, OrderStatus> statusMap = new HashMap<>();

    static {
        statusMap.put(0, OrderStatus.PAYMENT_COMPLETED);
        statusMap.put(1, OrderStatus.PAYMENT_FAILED);
        statusMap.put(2, OrderStatus.PAYMENT_PENDING);
    }


    @Override
    public void processPayment(PaymentDetails payment) throws ThirdPartyPaymentsException {

        MerchantTransactionDetailsEntity merchant = merchantTransactionDetailsRepo.getOne(payment.getPuporseCode());
        // save payment status in order detail table.
        log.info("fetched MerchantTransactionDetailsEntity from db  merchant:{}", merchant);
        OrderDetailsEntity orderDetails = orderDetailsRepo.findByPurposeRefNo(payment.getPurposeRefNo());
        orderDetails.setStatus(statusMap.get(payment.getStatus()));
        if (orderDetails.getPrID() == null) {
            orderDetails.setPrID(payment.getPrId());
        }
        orderDetailsRepo.save(orderDetails);
        log.info("saving order detail to db  orderDetails:{}", orderDetails);
        try {
            orderService.confirmOrder(orderDetails, merchant);
        } catch (ThirdPartyPaymentsException e) {

            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
        }

    }

}
