package com.airtelbank.thirdpartypayments.exception;

import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;

public class ConnectionException extends ThirdPartyPaymentsException {

    private static final long serialVersionUID = 1L;

    public ConnectionException(ResponseErrorCode errorCode) {
        super(errorCode);
    }

    public ConnectionException(ResponseErrorCode errorCode, String message) {
        super(errorCode);
    }

    public ConnectionException(ResponseErrorCode errorCode, String message, Throwable cause) {
        super(errorCode, cause);
    }

    public ConnectionException(ResponseErrorCode errorCode, Throwable cause) {
        super(errorCode, cause);
    }

    protected ConnectionException(ResponseErrorCode errorCode, String message, Throwable cause,
                                  boolean enableSuppression, boolean writableStackTrace) {
        super(errorCode);
    }

}
