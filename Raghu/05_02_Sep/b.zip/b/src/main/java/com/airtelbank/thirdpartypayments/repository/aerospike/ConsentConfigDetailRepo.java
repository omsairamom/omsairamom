package com.airtelbank.thirdpartypayments.repository.aerospike;

import com.airtelbank.thirdpartypayments.entity.aeroskipe.ConsentConfigDetails;
import org.springframework.data.aerospike.repository.AerospikeRepository;
import org.springframework.data.keyvalue.repository.KeyValueRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConsentConfigDetailRepo extends AerospikeRepository<ConsentConfigDetails, String>, KeyValueRepository<ConsentConfigDetails, String> {
}
