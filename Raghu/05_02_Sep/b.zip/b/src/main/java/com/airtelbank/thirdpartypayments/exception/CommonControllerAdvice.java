package com.airtelbank.thirdpartypayments.exception;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.Constants;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.model.consent.Meta;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.InvalidMediaTypeException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@ControllerAdvice
public class CommonControllerAdvice {

    @Autowired
    private MessageSource messageSource;

    @ExceptionHandler(InvalidMediaTypeException.class)
    public ResponseEntity<RestApiResponse> handleInvalidMediaTypeException(InvalidMediaTypeException exception) {
        return ResponseEntityBuilder.getBuilder(HttpStatus.UNSUPPORTED_MEDIA_TYPE).errorResponse(Constants.APB_CODE,
                exception.getMessage());
    }

    @ExceptionHandler(ThirdPartyPaymentsException.class)
    public ResponseEntity<RestApiResponse> handleInvalidThorException(ThirdPartyPaymentsException exception) {
        log.error("Payments exception : {}",
                messageSource.getMessage(exception.getErrorCode().getDescription(), null, null));
        log.debug("Payments exception : {}", exception);
        return ResponseEntityBuilder.getBuilder(exception.getErrorCode().getHttpStatus()).errorResponse(
                (messageSource.getMessage(exception.getErrorCode().getCode(), null, null)),
                getMessage(exception.getErrorCode().getDescription(), exception.getMessage()));
    }


    private String getMessage(String description, String message) {
        return StringUtils.isNotEmpty(message) ? message : messageSource.getMessage(description, null, null);

    }

    @ExceptionHandler(ConnectionException.class)
    public ResponseEntity<RestApiResponse> handleConnectionException(ConnectionException exception) {
        log.error("ConnectionException exception : {}", exception);
        return ResponseEntityBuilder.getBuilder(exception.getErrorCode().getHttpStatus())
                .errorResponse(exception.getErrorCode().getCode(), exception.getErrorCode().getDescription());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<RestApiResponse> handleException(Exception exception) {
        log.error(Constants.EXCEPTION_MSG, exception);
        return ResponseEntityBuilder.getBuilder(HttpStatus.INTERNAL_SERVER_ERROR).errorResponse(Constants.APB_CODE,
                Constants.GENERIC_ERROR_MSG);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<RestApiResponse> handleMethodArgumentNotValidException(
            MethodArgumentNotValidException exception) {
        log.error("MethodArgumentNotValidException is :: {}", exception);
        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getFieldErrors()
                .forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));
        log.error("Exception Response in handleMethodArgumentNotValidException :{} ", errors.toString());
        return ResponseEntityBuilder.getBuilder(HttpStatus.BAD_REQUEST).errorResponse(messageSource.getMessage(AppConstants.Key.VALIDATION_FAILED_CODE, null, Locale.getDefault()), errors.toString());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<RestApiResponse> handleConstraintViolation(ConstraintViolationException ex) {
        log.error("ConstraintViolationException is :: {}", ex);
        List<String> details = ex.getConstraintViolations()
                .parallelStream()
                .map(e -> e.getMessage())
                .collect(Collectors.toList());
        log.error("Exception Response in handleConstraintViolation :{} ", details.toString());
        return ResponseEntityBuilder.getBuilder(HttpStatus.BAD_REQUEST).errorResponse(messageSource.getMessage(AppConstants.Key.VALIDATION_FAILED_CODE, null, Locale.getDefault()),
                details.toString());
    }

    @ExceptionHandler(value = {GenericException.class})
    public ResponseEntity<Object> handleGenericException(GenericException ex) {
        log.error("GenericException is : {}", ex);

        ExceptionResponse exceptionResponse = new ExceptionResponse();
        Meta meta = new Meta();
        if (ex.getMeta() != null) {
            meta = ex.getMeta();
        } else if (ex.getErrorCode() != null && ex.getErrorMessage() != null) {
            meta.setCode(ex.getErrorCode());
            meta.setDescription(ex.getErrorMessage());
        } else {
            meta.setCode(messageSource.getMessage(AppConstants.Key.DEFAULT_CODE, null, null));
            meta.setDescription(messageSource.getMessage(AppConstants.Key.DEFAULT_MSG, null, null));
        }
        meta.setStatus(AppConstants.Status.STATUS_FAILURE);
        exceptionResponse.setMeta(meta);
        log.error("Exception Response in GenericException ::{} ", exceptionResponse);
        return ResponseEntity.status(ex.getHttpStatus()).body(exceptionResponse);

    }

}
