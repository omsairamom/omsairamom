package com.airtelbank.thirdpartypayments.dto.response.common;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

/**
 * @author b0206596
 */
public final class ResponseEntityBuilder {
    private ResponseEntityBuilder(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    private final HttpStatus httpStatus;

    public static ResponseEntityBuilder getBuilder(HttpStatus status) {
        return new ResponseEntityBuilder(status);
    }

    public ResponseEntity<RestApiResponse> successResponse(String message, Object result) {
        return successResponse("000", message, result);
    }

    public ResponseEntity<RestApiResponse> successResponse(String code, String message, Object result) {
        RestApiResponse response = RestApiResponse.buildSuccessResponse(code, message, result);
        return new ResponseEntity<>(response, httpStatus);
    }

    public ResponseEntity<RestApiResponse> successResponse(String code, String message, Object result,
                                                           Map<String, String> statusMap) {
        RestApiResponse response = RestApiResponse.buildResponse(code, message, AppConstants.Status.STATUS_SUCCESS, result, statusMap);
        return new ResponseEntity<>(response, httpStatus);
    }

    public ResponseEntity<RestApiResponse> errorResponse(String code, String message) {
        RestApiResponse response = RestApiResponse.buildFailureResponse(code, message);
        return new ResponseEntity<>(response, httpStatus);
    }

}
