package com.airtelbank.thirdpartypayments.model.redbuspayment.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RedBusFulFilmentResponse {
    private String paymentRefId;
    private String purposeRefNo;
    private String paymentStatus;
    private String fulfilmentDeepLinkUrl;
    private String source;
    private String destination;
    private String doj;
    private String travelsName;
    private String busType;
    //Map<String, String> statusMap;


}
