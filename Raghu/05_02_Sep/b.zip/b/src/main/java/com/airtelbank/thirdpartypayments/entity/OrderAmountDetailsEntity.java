package com.airtelbank.thirdpartypayments.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@Table(name = "ORDER_AMOUNT_DETAILS")
@Entity
public class OrderAmountDetailsEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ORDER_AMOUNT_ID")
    private String orderAmountId;

    @Column(name = "MERCHANT_TXN_ID")
    private String merchantTxnId;

    @Column(name = "AMOUNT_KEY")
    private String amountKey;

    @Column(name = "AMOUNT_VALUE")
    private BigDecimal amountValue;

//	@ManyToOne
//    @JoinColumn(name = "order_details_Id")
//    private OrderDetailsEntity orderDetailsEntity;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE", nullable = false, updatable = false)
    public Date createDate;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATE_DATE", nullable = false, updatable = true)
    public Date updateDate;

}
