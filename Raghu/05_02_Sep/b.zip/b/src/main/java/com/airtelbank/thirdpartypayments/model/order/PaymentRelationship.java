package com.airtelbank.thirdpartypayments.model.order;

public enum PaymentRelationship {
    PREPAYMENT("PRE_PAYMENT"), POSTPAYMENT("POST_PAYMENT");

    private final String value;

    PaymentRelationship(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
