package com.airtelbank.thirdpartypayments.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@Table(name = "ORDER_DETAILS_TXN")
@Entity
@AllArgsConstructor
public class OrderDetailsTxn {
    @ManyToOne
    @JoinColumn(name = "MERCHANT_TXN_ID", referencedColumnName = "MERCHANT_TXN_ID", nullable = false, updatable = true, insertable = true)
    private OrderDetailsEntity orderDetailsEntity;

    @Id
    @Column(name = "ORDER_DETAILS_TXN_ID")
    private String orderDetailsTxnId;

    @Column(name = "TYPE")
    private String type;

    @Column(name = "PAYMENT_RELATIONSHIP")
    private String paymentRelationship;

    @Column(name = "KEY")
    private String key;

    @Column(name = "DISPLAY_TEXT")
    private String displayText;

    @Column(name = "VALUE")
    private String value;

//	@Column(name="MERCHANT_TXN_ID")
//	private String merchantTxnId;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATION_DATE", nullable = false, updatable = false)
    public Date creationDate;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED", nullable = false, updatable = true)
    public Date updationDate;
}
