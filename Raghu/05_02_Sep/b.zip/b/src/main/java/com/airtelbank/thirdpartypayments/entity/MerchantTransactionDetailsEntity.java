package com.airtelbank.thirdpartypayments.entity;

import com.airtelbank.thirdpartypayments.model.order.OrderConfirmationRequestType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
@Table(name = "MERCHANT_TRANSACTION_DETAILS")
@Entity
public class MerchantTransactionDetailsEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "PURPOSE_CODE")
    private String purposeCode;

    @Column(name = "MERCHANT_ID")
    private String merchantId;
    // todo check for unique

    @Column(name = "LOB_ID")
    private String lobID;

    @Column(name = "CIRCLE_ID")
    private String circleID;

    @Column(name = "TRANS_TYPE")
    private String transType;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "purposeIconURL")
    private String pusposeIconURL;

    @Column(name = "ORDER_CONFIRMATION_URL")
    private String orderConfirmationURL;

    @Column(name = "diffParameter1")
    private String diffParameter1;

    @Column(name = "diffParameter2")
    private String diffParameter2;

    @Column(name = "FROM_NARRATION")
    private String fromNarration;

    @Column(name = "TO_NARRATION")
    private String toNarration;

    @Column(name = "FROM_SMS")
    private String fromSms;

    @Column(name = "TO_SMS")
    private String toSms;

    @Column(name = "msisdn")
    private String msisdn;

    @Column(name = "Merchant_Accont_Number")
    private String accNumber;

    @Column(name = "Merchant_Name")
    private String name;

    @Column(name = "Segment")
    private String segment;

    @Column(name = "product_code")
    private String productCode;

    @Column(name = "cust_type")
    private String custType;

    @Column(name = "successTitle")
    private String successTitle;

    @Column(name = "failureTitle")
    private String failureTitle;

    @Column(name = "orderPendingTitle")
    private String orderPendingTitle;

    @Column(name = "successDesc")
    private String successDesc;

    @Column(name = "failureDesc")
    private String failureDesc;

    @Column(name = "orderPendingDesc")
    private String orderPendingDesc;

    @Column(name = "successBenefit")
    private String successBenefit;

    @Column(name = "failureBenefit")
    private String failureBenefit;

    @Column(name = "orderPendingBenefit")
    private String orderPendingBenefit;

    /**
     * this is the comma saparated list of all error codes for which the order will
     * be in PENDING_CONFIRMATION state
     */
    @Column(name = "PENDING_CONFIRMATION_CODES")
    private String pendingCodes;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATION_DATE", nullable = false, updatable = false)
    public Date creationDate;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED", nullable = false, updatable = true)
    public Date updationDate;

    @Column(name = "confirmation_url")
    private String confirmationUrl;

    @Column(name = "request_type")
    private OrderConfirmationRequestType requestType;

}
