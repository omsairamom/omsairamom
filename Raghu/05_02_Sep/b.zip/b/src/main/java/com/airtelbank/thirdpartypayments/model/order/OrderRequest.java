package com.airtelbank.thirdpartypayments.model.order;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
public class OrderRequest<T> {

    Map<String, String> headers;

    T data;
}
