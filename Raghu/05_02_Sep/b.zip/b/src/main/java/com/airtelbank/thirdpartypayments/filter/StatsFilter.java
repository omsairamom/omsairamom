package com.airtelbank.thirdpartypayments.filter;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseDTO;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.util.LogMasker;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.core.config.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@Order(1)
public class StatsFilter extends OncePerRequestFilter {

    private final Logger logger = LoggerFactory.getLogger(StatsFilter.class);

    @Value("${config.service.id:reverseintegrationpayment}")
    private String serviceId;

    @Value("${kibana.separator:~#~}")
    private String logSeparator;

    @Autowired
    private LoggerModel loggerModel;

    @Autowired
    private LogMasker logMasker;

    @Autowired
    private Gson gson;

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain filterChain)
            throws ServletException, IOException {

        StopWatch watch = new StopWatch();
        watch.start();

        MultipleReadHttpServletRequest multipleReadHttpServletRequest = new MultipleReadHttpServletRequest(req);


        if (res.getCharacterEncoding() == null) {
            res.setCharacterEncoding("UTF-8"); // Or whatever default. UTF-8 is good for World Domination.
        }

        HttpServletResponseCopier responseCopier = new HttpServletResponseCopier(res);
        filterChain.doFilter(multipleReadHttpServletRequest, responseCopier);

        loggerModel.init();

        String userAgent = req.getHeader(AppConstants.USER_AGENT);
        String channel = req.getHeader(AppConstants.CHANNEL);
        try {
            if (null == channel) {
                String userAgentArr[] = userAgent.split("/");
                channel = userAgentArr[1].split(",")[1];
            }
        } catch (Exception e) {
            channel = "ANDROID";
        }
        List<String> listOfIds = new ArrayList<String>();
        listOfIds.add(channel);
        loggerModel.setIds(listOfIds);


        byte[] copy = responseCopier.getCopy();
        try {
            responseCopier.flushBuffer();
        } finally {

        }

        StringBuilder builder = new StringBuilder();

        // append basic info
        // Service id
        builder.append(serviceId).append(logSeparator);

        // api id
        if (StringUtils.isBlank(MDC.get(AppConstants.API_ID))) {
            MDC.put(AppConstants.API_ID, getApiId(multipleReadHttpServletRequest.getRequestURI().toString()));
        }
        builder.append(MDC.get(AppConstants.API_ID)).append(logSeparator);

        String customerMobileNo = loggerModel.getMsisdn();
        if (!StringUtils.isBlank(customerMobileNo)) {
            MDC.put(AppConstants.CUSTOMER_ID, customerMobileNo);
        }
        builder.append(MDC.get(AppConstants.CUSTOMER_ID)).append(logSeparator);

        if (StringUtils.isBlank(MDC.get(AppConstants.CONTENT_ID))) {
            MDC.put(AppConstants.CONTENT_ID, req.getHeader(AppConstants.CONTENT_ID));
        }
        builder.append(MDC.get(AppConstants.CONTENT_ID)).append(logSeparator);
        builder.append(MDC.get(AppConstants.MERCHANT_TXN_ID)).append(logSeparator);

        // tranId
        // builder.append(loggerModel.getTranId()).append(logSeparator);

        // amount
        builder.append(loggerModel.getAmount()).append(logSeparator);
        builder.append(MDC.get(AppConstants.CHANNEL)).append(logSeparator);
        builder.append(MDC.get(AppConstants.MERCHANT_ID)).append(logSeparator);
        builder.append(AppConstants.PURPOSE_CODE).append(logSeparator);
        builder.append(AppConstants.PAYMENT_STATUS).append(logSeparator);
        builder.append(AppConstants.ORDER_STATUS).append(logSeparator);
        builder.append(AppConstants.REFUND_STATUS).append(logSeparator);
        // for consent
        builder.append(MDC.get(AppConstants.APP_ID)).append(logSeparator);
        builder.append(MDC.get(AppConstants.CONTENT_ID)).append(logSeparator);
        // for red bus
        // builder.append(MDC.get(AppConstants.CUSTOMER_ID)).append(logSeparator);
        builder.append(MDC.get(AppConstants.CUSTOMER_NAME)).append(logSeparator);
        builder.append(MDC.get(AppConstants.PURPOSE_REF_NO)).append(logSeparator);
        builder.append(MDC.get(AppConstants.REFUND_REF_NO)).append(logSeparator);
        builder.append(MDC.get(AppConstants.TOTAL_REFUND_AMOUNT)).append(logSeparator);
        builder.append(MDC.get(AppConstants.PR_ID)).append(logSeparator);

        for (int i = 1; i <= 2; i++) {
            builder.append("").append(logSeparator);
        }

        // append request
        builder.append(multipleReadHttpServletRequest.getRequestBody()).append(logSeparator);

        // append response
        // Response handling
        try {
            String responseString = new String(copy, res.getCharacterEncoding());
            ResponseDTO<?> responseDto = gson.fromJson(responseString, ResponseDTO.class);

            if (responseDto != null && responseDto.getMeta() != null) {
                MDC.put(AppConstants.CODE, responseDto.getMeta().getCode());
                MDC.put(AppConstants.DESCRIPTION, responseDto.getMeta().getDescription());
                MDC.put(AppConstants.STATUS, StringUtils.EMPTY + responseDto.getMeta().getStatus());
            }
            MDC.put(AppConstants.RESPONSE, logMasker.patternReplace(responseString));
        } catch (Exception e) {
            log.error("Exception occurred in handling api reponse", e);
        }
        builder.append(MDC.get(AppConstants.RESPONSE)).append(logSeparator);
        builder.append(MDC.get(AppConstants.STATUS)).append(logSeparator);
        builder.append(MDC.get(AppConstants.CODE)).append(logSeparator);
        builder.append(MDC.get(AppConstants.DESCRIPTION)).append(logSeparator);

        watch.stop();
        // append time
        builder.append(watch.getTotalTimeMillis());
        String result = builder.toString();
        logger.info(result);
        MDC.clear();
    }

    private String getApiId(String requestURL) {
        return requestURL.substring(requestURL.lastIndexOf('/') + 1);
    }

}
