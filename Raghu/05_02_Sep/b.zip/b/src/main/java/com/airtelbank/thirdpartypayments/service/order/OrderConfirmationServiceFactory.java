package com.airtelbank.thirdpartypayments.service.order;

public interface OrderConfirmationServiceFactory {

    OrderConfirmationService getOrderConfirmationService(String name);
}
