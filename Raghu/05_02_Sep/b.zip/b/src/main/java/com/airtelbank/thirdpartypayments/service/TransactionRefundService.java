package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundResponse;

public interface TransactionRefundService {
    TransactionRefundResponse refundInit(TransactionRefundRequest transactionRefundRequest, String authToken) throws ThirdPartyPaymentsException;

}
