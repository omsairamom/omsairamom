package com.airtelbank.thirdpartypayments.util;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author SAPAN NAGPAL
 */

@Configuration
@ConfigurationProperties(prefix = "mask")
@PropertySource("file:${spring.config.location}/thirdPartyPayments_masking.properties")
public class LogMaskingConfiguration {

    private String pattern;
    private String regex;

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

}
