package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.model.Merchant;
import com.airtelbank.thirdpartypayments.service.MerchantDetailService;
import org.springframework.stereotype.Service;


@Service
public class MerchantDetailServiceImpl implements MerchantDetailService {

    @Override
    public Merchant getMerchantByPuporseCode(String puporseCode) {
        return null;
    }

}
