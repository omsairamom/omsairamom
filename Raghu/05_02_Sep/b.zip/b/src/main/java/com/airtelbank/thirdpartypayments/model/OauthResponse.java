package com.airtelbank.thirdpartypayments.model;

import com.airtelbank.thirdpartypayments.dto.response.common.ResponseDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OauthResponse extends ResponseDTO<OauthResponseAPB> {
    /**
     *
     */
    private static final long serialVersionUID = 1L;


}
