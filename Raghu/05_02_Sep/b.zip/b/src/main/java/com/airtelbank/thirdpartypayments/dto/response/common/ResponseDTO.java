package com.airtelbank.thirdpartypayments.dto.response.common;

import java.io.Serializable;
import java.util.List;

/**
 * @author Samita Mahajan
 */
public class ResponseDTO<T> implements Serializable {

    private static final long serialVersionUID = 1L;
    private Meta meta;
    private T data;
    private List<CustomError> errors;

    public Meta getMeta() {
        return meta;
    }

    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public List<CustomError> getErrors() {
        return errors;
    }

    public void setErrors(List<CustomError> errors) {
        this.errors = errors;
    }
}
