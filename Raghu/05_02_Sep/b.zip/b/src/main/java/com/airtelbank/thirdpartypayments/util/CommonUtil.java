package com.airtelbank.thirdpartypayments.util;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.consent.ConsentHeaderDTO;
import com.airtelbank.thirdpartypayments.model.consent.request.Consent;
import com.airtelbank.thirdpartypayments.model.consent.request.CreateConsentRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.Data;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.HeaderRequestDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * @author b0206596
 */
@Slf4j
public class CommonUtil {

    private static final DateFormat sdf = new SimpleDateFormat("DDDMMyyyyHHmmssSSS");

    public static String getChannel(String userAgent) {
        //String channel = "WEB";
        String channel = AppConstants.CHANNEL;
        try {
            if (null == channel) {
                String[] userAgentArr = userAgent.split("/");
                channel = userAgentArr[1].split(",")[1];
            }
            //String[] userAgentArr = userAgent.split("/");
            //channel = userAgentArr[1].split(",")[1];
        } catch (Exception e) {
            channel = AppConstants.ANDROID;
            e.printStackTrace();

        }
		/*try {
			String[] userAgentArr = userAgent.split("/");
			channel = userAgentArr[1].split(",")[1];
		} catch (Exception e) {
			e.printStackTrace();

		}*/
        return channel;
    }

    public static String purifyCustomerMobileNumber(String mobileNum) {
        if (mobileNum != null && mobileNum.length() > 10) {
            mobileNum = mobileNum.substring(2);
        }
        return mobileNum;
    }

    public static LoggerModel.LoggerError setLoggerError(Meta meta) {
        LoggerModel.LoggerError logError = new LoggerModel.LoggerError();
        logError.setErrorCode(meta.getCode());
        logError.setErrorDescription(meta.getDescription());
        return logError;
    }

    public static String logKibana(String customerId, String channel) {
        String logMsg = "|" + customerId + "|" + channel;

        return channel;
    }

    public static String logKibana(int pincode, String channel) {
        String logMsg = "|" + pincode + "|" + channel;

        return channel;
    }

    public static String getPurposeReference() {
        return new StringBuffer().append(sdf.format(new Date(System.currentTimeMillis())))
                .append(new Random().nextInt(4)).toString();
    }

    /**
     * Create create consent request data
     *
     * @param request
     * @return
     */
    public static CreateConsentRequest createConsentRequest(CustomerConsentRequest request, String appId) {
        CreateConsentRequest createConsentRequest = new CreateConsentRequest();
        Data data = new Data();
        List<Consent> listConsent = new ArrayList<>();
        Consent consent = new Consent();
        consent.setConsent(request.getConsent());
        consent.setMobileNumber(request.getMobileNumber());
        consent.setConsentType(request.getConsentType());
        consent.setConsentPurpose(request.getConsentPurpose());
        consent.setConsentMode(request.getConsentMode());
        consent.setConsentToken(appId);
        consent.setConsentDescription(request.getConsentDescription());
        consent.setValidityTill(request.getValidTill());
        listConsent.add(consent);
        data.setConsents(listConsent);
        createConsentRequest.setData(data);
        com.airtelbank.thirdpartypayments.model.consent.request.Meta meta = new com.airtelbank.thirdpartypayments.model.consent.request.Meta();
        meta.setAppId(appId);
        meta.setAppType(request.getConsentType());
        createConsentRequest.setMeta(meta);
        return createConsentRequest;
    }

    public static HeaderRequestDTO convertMaptoObject(Map<String, String> headers) {
        ObjectMapper mapper = new ObjectMapper();
        HeaderRequestDTO headerRequestDTONew = mapper.convertValue(headers, HeaderRequestDTO.class);
        return headerRequestDTONew;
    }

    public static ConsentHeaderDTO convertMapHeader(Map<String, String> headers) {
        log.info("Requested Headers for consent :: {}", headers);
        ObjectMapper mapper = new ObjectMapper();
        ConsentHeaderDTO headerRequestDTONew = mapper.convertValue(headers, ConsentHeaderDTO.class);
        log.info("Converted  Headers for consent :: {}", headerRequestDTONew.toString());
        return headerRequestDTONew;
    }

    public static String generateUniqueKey() {
        return new StringBuffer()
                .append(new SimpleDateFormat("DDDMMyyyyHHmmssSSS").format(new Date(System.currentTimeMillis())))
                .append(new Random().nextInt(10)).toString();
    }

    public static String getMerchantTxnId() {
        return new StringBuffer().append("RB-").append(sdf.format(new Date(System.currentTimeMillis())))
                .append(new Random().nextInt(4)).toString();
    }

    public static String getRefundRequestId() {
        return new StringBuffer().append("RBR-").append(sdf.format(new Date(System.currentTimeMillis())))
                .append(new Random().nextInt(4)).toString();
    }

    public static String getFessionId() {
        return new StringBuffer().append("RBR-").append(sdf.format(new Date(System.currentTimeMillis())))
                .append(new Random().nextInt(4)).toString();
    }


    public static Map<String, String> prepareFulfilmentStatus(OrderDetailsEntity response) {
        log.info("Inside prepareFulfilmentStatus() method with Status :: {}", response.getStatus().getValue());
        Map<String, String> statusMap = new HashMap<>();
        int statusCode = AppConstants.Status.STATUS_RETRY;
        String statusDesc = AppConstants.TIMEOUT;
        if (null != response) {
            OrderStatus status = response.getStatus();
            if (status == null) {
                statusCode = AppConstants.Status.STATUS_AWAITED;
                statusDesc = AppConstants.AWAITED;
            } else if (OrderStatus.SUCCESS.getValue().equalsIgnoreCase(status.getValue())) {
                statusCode = AppConstants.Status.STATUS_SUCCESS;
                statusDesc = AppConstants.SUCCESS;
            } else if (OrderStatus.FAILED.getValue().equalsIgnoreCase(status.getValue())) {
                statusCode = AppConstants.Status.STATUS_FAILURE;
                statusDesc = AppConstants.FAILED;
            }
        }

        statusMap.put(AppConstants.STATUS_CODE, String.valueOf(statusCode));
        statusMap.put(AppConstants.STATUS_DESC, statusDesc);
        log.info("Fulfilment  statusCode :: {}", statusCode);
        log.info("Fulfilment statusDesc :: {}", statusDesc);
        return statusMap;
    }

    public static String getCurrentTime() {
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        return dateFormat.format(date);
    }

    public static String getRefundId() {
        return new StringBuffer().append("RI-").append(sdf.format(new Date(System.currentTimeMillis())))
                .append(new Random().nextInt(4)).toString();
    }


}
