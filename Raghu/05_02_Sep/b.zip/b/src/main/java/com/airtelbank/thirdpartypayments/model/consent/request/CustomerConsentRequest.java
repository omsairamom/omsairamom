package com.airtelbank.thirdpartypayments.model.consent.request;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@JsonInclude(JsonInclude.Include.NON_NULL)
@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class CustomerConsentRequest {

    private Boolean consent;
    @Pattern(regexp = "[6-9][0-9]{9}$", message = AppConstants.MOBILE_NOT_VALID_MSG)
    @NotBlank(message = AppConstants.MOBILE_NOT_VALID_MSG)
    private String mobileNumber;
    @NotBlank(message = AppConstants.TYPE_NOT_BLANK_MSG)
    private String consentType;
    private String consentPurpose;
    @NotBlank(message = AppConstants.MODE_NOT_BLANK_MSG)
    private String consentMode;
    private String consentDescription;
    private String validTill;
}

