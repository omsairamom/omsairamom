package com.airtelbank.thirdpartypayments.service;


import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaRefundResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import org.springframework.http.ResponseEntity;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public interface RedBusPaymentRefundService {

    RedBusRefundResponse initiateRefund(PaymentData redBusInitiatePaymentRefund);

    RedBusRefundStatusResponse getRefundStatusEnquiry(String refundRefNo);

    OrderDetailsEntity getFulfilmentStatus(String prId);

    ResponseEntity<String> updateRefundStatus(KafkaRefundResponse refundResponse) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, InvalidKeySpecException;

}

