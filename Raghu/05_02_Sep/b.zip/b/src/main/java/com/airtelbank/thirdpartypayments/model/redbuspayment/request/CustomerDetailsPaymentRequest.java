package com.airtelbank.thirdpartypayments.model.redbuspayment.request;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDetailsPaymentRequest {

    @NotBlank(message = AppConstants.MOBILE_NOT_VALID_MSG)
    @Pattern(regexp = "[6-9][0-9]{9}$", message = AppConstants.MOBILE_NOT_VALID_MSG)
    public String mobileNo;
    @NotBlank(message = AppConstants.NAME_NOT_BLANK_MSG)
    public String customerName;
    @NotBlank(message = AppConstants.PURPOSE_REF_NO_BLANK_EMPTY_MSG)
    public String purposeRefNo;
    //@NotBlank(message = AppConstants.SECRET_KEY_NO_NOT_BLANK_MSG)
    //public String secretKey;
    //@NotBlank(message = AppConstants.PAYMENT_REF_NO_NOT_BLANK_MSG)
    //private String paymentRefId;

    @NotBlank(message = AppConstants.SOURCE_NOT_BLANK_MSG)
    private String source;

    @NotBlank(message = AppConstants.DESTINATION_NOT_BLANK_MSG)
    private String destination;

    @NotBlank(message = AppConstants.DOJ_NOT_BLANK_MSG)
    private String doj;

    @NotBlank(message = AppConstants.TRAVELNAME_NOT_BLANK_MSG)
    private String travelsName;

    @NotBlank(message = AppConstants.BUSTTYPE_NOT_BLANK_MSG)
    private String busType;


}
