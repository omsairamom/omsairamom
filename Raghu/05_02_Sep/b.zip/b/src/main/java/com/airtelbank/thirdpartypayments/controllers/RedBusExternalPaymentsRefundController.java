package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.HeaderRequestDTO;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentRefundService;
import com.airtelbank.thirdpartypayments.serviceimpl.PaymentStatusConsumerServiceImpl;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Locale;
import java.util.Map;

/**
 * Payment and booking details related end points
 *
 * @author Ranjeet Singh 14-June-2021
 */

@Slf4j
@RestController
@RequestMapping(value = "api/v1/redbus")
@Validated
public class RedBusExternalPaymentsRefundController {

    @Autowired
    private RedBusPaymentRefundService redBusPaymentRefundService;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    PaymentStatusConsumerServiceImpl paymentStatusConsumerService;


    /**
     * Initiate refund
     *
     * @param redBusInitiatePaymentRefund
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     */

    @PostMapping(path = "/payment/initiate/refund", produces = "application/json")
    public ResponseEntity<RestApiResponse> initiateRefund(@Valid @RequestBody PaymentData redBusInitiatePaymentRefund,
                                                          @RequestHeader Map<String, String> headers) {

        log.info("Entering into initiateRefund() method with Encrypted Payload :: {}", redBusInitiatePaymentRefund);

        HeaderRequestDTO headerRequestDTO = CommonUtil.convertMaptoObject(headers);
        log.info("Header values received  from initiateRefund() method:: {}", headerRequestDTO);
        RedBusRefundResponse initiateRefundResponse = redBusPaymentRefundService.initiateRefund(redBusInitiatePaymentRefund);
        log.info("Response return redBusPaymentRefundService.initiateRefund() method :: {}", initiateRefundResponse);
        if (initiateRefundResponse != null) {
            return ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse(AppConstants.STATUS_SUCCESS_CODE, AppConstants.INITIATE_REFUND_SUCCESSFULLY,
                    initiateRefundResponse);
        } else {
            return ResponseEntityBuilder.getBuilder(HttpStatus.INTERNAL_SERVER_ERROR).errorResponse(getMessage(AppConstants.Key.PAYMENT_ERROR_CODE),
                    getMessage(AppConstants.Key.PAYMENT_ERROR_DESC));
        }
    }

    /**
     * Fetch refund status
     *
     * @param refundRefNo
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     */

    @GetMapping(path = "/refundStatus/enquiry/{refundRefNo}")
    public ResponseEntity<RestApiResponse> getRefundStatusEnquiry(
            @Valid @PathVariable(value = "refundRefNo") String refundRefNo, @RequestHeader Map<String, String> headers) {

        log.info("Entering into getRefundStatus() method for refundRefNo :: {}", refundRefNo);
        MDC.put(AppConstants.REFUND_REF_NO, refundRefNo);
        HeaderRequestDTO headerRequestDTO = CommonUtil.convertMaptoObject(headers);
        log.info("Header values received  from initiateRefund() method:: {}", headerRequestDTO);
        RedBusRefundStatusResponse refundStatusResponse = redBusPaymentRefundService.getRefundStatusEnquiry(refundRefNo);
        log.info("Response  :: {} return redBusPaymentRefundService.getRefundStatus() method for refundRefNo :: {}", refundStatusResponse, refundRefNo);
        if (refundStatusResponse != null) {
            return ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse(AppConstants.STATUS_SUCCESS_CODE, AppConstants.REFUND_STATUS_ENQUIRY,
                    refundStatusResponse);
        } else {
            return ResponseEntityBuilder.getBuilder(HttpStatus.INTERNAL_SERVER_ERROR).errorResponse(getMessage(AppConstants.Key.PAYMENT_ERROR_CODE), getMessage(AppConstants.Key.PAYMENT_ERROR_DESC));
        }
    }

    private String getMessage(String key) {

        return messageSource.getMessage(key, null, Locale.getDefault());
    }
}
