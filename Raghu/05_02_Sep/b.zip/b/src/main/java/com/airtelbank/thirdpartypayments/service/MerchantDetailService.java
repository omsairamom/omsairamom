package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.model.Merchant;

public interface MerchantDetailService {

    Merchant getMerchantByPuporseCode(String puporseCode);
}
