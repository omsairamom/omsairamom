package com.airtelbank.thirdpartypayments.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Component
public class LoggerModel implements Serializable {
    private static final long serialVersionUID = 1L;
    private String serviceId;
    private String contentId;
    private String msisdn;
    private String tranId;
    private BigDecimal amount;
    private List<LoggerError> errors;
    private List<MethodStats> methods;
    private List<String> ids;
    private List<BigDecimal> numbers;
    private List<Date> dates;
    private String code;
    private String description;
    private String requestJson;
    private String responseJson;
    private String status;


    public void init() {
        errors = new ArrayList<>();
        methods = new ArrayList<>();
        ids = new ArrayList<>();
        numbers = new ArrayList<>();
        dates = new ArrayList<>();
    }

    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LoggerError implements Serializable {
        private static final long serialVersionUID = 1L;
        private int status;
        private String responseCode;
        private String errorCode;
        private String errorDescription;
    }

    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MethodStats implements Serializable {
        private static final long serialVersionUID = 1L;
        private String methodName;
        private long methodTime;
    }
}
