package com.airtelbank.thirdpartypayments.exception;

import com.airtelbank.thirdpartypayments.dto.response.common.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

/**
 * This exception wraps up the exceptions occurring at the Service layer. This
 * exception logs itself using the logger used in the application. Hence we
 * don't need to log this exception anywhere in the code.
 *
 * @author Atul Dwivedi
 */
public class ServiceException extends RuntimeException {

    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 8095179179694212963L;

    /**
     * The Constant logger.
     */
    private static final Logger logger = LoggerFactory.getLogger(ServiceException.class);

    /**
     * This property carries the detailed user message which is meant for the end
     * user.
     */
    private final String userMessgage;

    /**
     * This is the status code used to specify the scenario in case of occurrence of
     * exception.
     */
    private HttpStatus httpStatus;

    /**
     * The code.
     */
    private String code;

    /**
     * Instantiates a new service exception.
     *
     * @param innerException the inner exception
     * @param userMessage    the user message
     * @param code           the code
     */
    public ServiceException(Exception innerException, String userMessage, String code) {
        super(innerException);
        String exceptionMessage = innerException.getMessage();

        if (userMessage != null && !userMessage.isEmpty()) {
            this.userMessgage = userMessage;
        } else {
            this.userMessgage = Constants.UNEXPECTED_ERRMSG;
        }
        if (code != null && !code.isEmpty()) {
            this.code = code;
        } else {
            this.code = Constants.CODE_FAILURE;
        }
        logger.error(exceptionMessage, innerException);
    }

    /**
     * Instantiates a new service exception.
     *
     * @param innerException the inner exception
     */
    public ServiceException(Exception innerException) {
        super(innerException);
        String exceptionMessage = innerException.getMessage();
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        this.userMessgage = Constants.UNEXPECTED_ERRMSG;
        this.code = Constants.CODE_FAILURE;
        logger.error(exceptionMessage, innerException);
    }

    /**
     * Instantiates a new service exception.
     *
     * @param code        the code
     * @param userMessage the user message
     * @param httpStatus  the http status
     */
    public ServiceException(String code, String userMessage, HttpStatus httpStatus) {

        if (userMessage != null && !userMessage.isEmpty()) {
            this.userMessgage = userMessage;
        } else {
            this.userMessgage = Constants.UNEXPECTED_ERRMSG;
        }
        if (code != null && !code.isEmpty()) {
            this.code = code;
        } else {
            this.code = Constants.CODE_FAILURE;
        }
        if (httpStatus != null) {
            this.httpStatus = httpStatus;
        } else {
            this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        logger.debug(String.format("Exception Occured : %s", userMessage));
    }

    /**
     * Instantiates a new service exception.
     *
     * @param error      the error
     * @param httpStatus the http status
     */
    public ServiceException(Errors error, HttpStatus httpStatus) {
        String exceptionMessage = error.getErrorMessage();
        if (error.getErrorMessage() != null && !error.getErrorCode().isEmpty()) {
            this.userMessgage = error.getErrorMessage();
        } else {
            this.userMessgage = Constants.UNEXPECTED_ERRMSG;
        }
        if (error.getErrorCode() != null && !error.getErrorCode().isEmpty()) {
            this.code = error.getErrorCode();
        } else {
            this.code = Constants.CODE_FAILURE;
        }
        if (httpStatus != null) {
            this.httpStatus = httpStatus;
        } else {
            this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        logger.error(String.format("Exception Occured : %s", exceptionMessage));
    }

    /**
     * Instantiates a new service exception.
     *
     * @param innerException the inner exception
     * @param error          the error
     */
    public ServiceException(Exception innerException, Errors error) {
        super(innerException);
        String exceptionMessage = innerException.getMessage();

        if (error.getErrorMessage() != null && !error.getErrorMessage().isEmpty()) {
            this.userMessgage = error.getErrorMessage();
        } else {
            this.userMessgage = Constants.UNEXPECTED_ERRMSG;
        }
        if (error.getErrorCode() != null && !error.getErrorCode().isEmpty()) {
            this.code = error.getErrorCode();
        } else {
            this.code = Constants.CODE_FAILURE;
        }
        logger.error(exceptionMessage, innerException);
    }

    /**
     * Gets the user messgage.
     *
     * @return the user messgage
     */
    public String getUserMessgage() {
        return userMessgage;
    }

    /**
     * Gets the http status.
     *
     * @return the httpStatus
     */
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    /**
     * Sets the http status.
     *
     * @param httpStatus the httpStatus to set
     */
    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

}
