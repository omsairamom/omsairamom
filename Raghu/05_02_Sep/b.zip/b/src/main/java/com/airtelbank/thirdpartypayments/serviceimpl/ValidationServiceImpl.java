package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.dto.response.common.Constants;
import com.airtelbank.thirdpartypayments.entity.MerchantOAuthDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.OauthResponse;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;
import com.airtelbank.thirdpartypayments.repository.MerchantOAuthDetailsRepository;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Slf4j
@Service
public class ValidationServiceImpl implements ValidationService {

    @Autowired
    MerchantOAuthDetailsRepository merchantOAuthDetailsRepository;

    @Autowired
    OrderDetailsRepo orderDetailsRepo;

    @Autowired
    private Environment environment;

    @Autowired
    RefundDetailsRepo refundDetailsRepo;

    @Autowired
    HttpUtil httpUtil;

    @Autowired
    MessageSource messageSource;

    @Autowired
    private MerchantTransactionDetailsRepo merchantTransactionDetailsRepo;

    @Value("${config.redbus.secretKey}")
    private String secretKey;

    @Override
    public MerchantTransactionDetailsEntity validateMerchant(PaymentRequest paymentRequest, String customerId)
            throws ThirdPartyPaymentsException {
        checkRequestInDB(paymentRequest);
        validateAccessToken(paymentRequest, customerId);
        return checkMerchantDetails(paymentRequest);

    }

    @Override
    public String validateRefund(TransactionRefundRequest transactionRefundRequest, String appToken, String merchantId)
            throws ThirdPartyPaymentsException {
        checkRefundRequestInDB(transactionRefundRequest);
        String clientSecret = getClientSecret(merchantId);
        if (!(appToken.equals(Constants.AUTOREFUND))) {
            checkRefundHash(transactionRefundRequest, appToken, clientSecret);
        }
        return clientSecret;
    }


    @Override
    public void validateAppToken(String appToken, String merchantId) throws ThirdPartyPaymentsException {
        MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = merchantOAuthDetailsRepository
                .findByMerchantId(merchantId);
        if (!merchantOAuthDetailsEntity.getXAppToken().equals(appToken)) {
            log.error("X-App-Token not Matched {}", appToken);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_MERCHANT);
        }
    }

    @Override
    public String getClientSecret(String merchantId) throws ThirdPartyPaymentsException {
        MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = merchantOAuthDetailsRepository
                .findByMerchantId(merchantId);
        if (merchantOAuthDetailsEntity == null) {
            log.error("No Merchant Fopund for MerchantId {}", merchantId);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_MERCHANT);
        }
        return merchantOAuthDetailsEntity.getClientSecret();
    }

    private void validateAccessToken(PaymentRequest paymentRequest, String customerId)
            throws ThirdPartyPaymentsException {
        OauthResponse oauthResponse = new OauthResponse();
        String oauthEnquiryUrl = environment.getProperty(AppConstants.URL.OAUTH_ENQUIRY);
        Map<String, String> headers = new HashMap<>();
        headers.put("customerId", customerId);
        headers.put("merchantId", paymentRequest.getMerchantId());
        try {
            oauthResponse = httpUtil.hitRequest(oauthEnquiryUrl, null, OauthResponse.class, headers, HttpMethod.GET);
        } catch (Exception e) {
            log.error("Getting error while calling Payment Initialize OauthResponse. ", e);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
        }
        if (oauthResponse.getMeta().getStatus() == 1) {
            log.error("No access token found for customer{}. ", customerId);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.AUTHORIZATION_FAILED);
        }

        checkHash(paymentRequest, oauthResponse.getData().getAccessToken());
    }

    private void checkHash(PaymentRequest paymentRequest, String accessToken) throws ThirdPartyPaymentsException {
        try {
            MerchantOAuthDetailsEntity merchantOAuthDetailsEntity = merchantOAuthDetailsRepository
                    .findByMerchantId(paymentRequest.getMerchantId());
        } catch (Exception e) {
            log.error("No merchant Found for that MerchantId in the OAUTH Table{}", paymentRequest.getMerchantId());
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_MERCHANT);
        }
        String clientSecret = getClientSecret(paymentRequest.getMerchantId());
        String hash = paymentRequest.getMerchantId() + '#'
                + paymentRequest.getTransactionDetailsRequest().getMerchantTxnId() + '#' + paymentRequest.getAmount()
                + '#' + accessToken + '#' + clientSecret;
        String sha512hex = null;
        try {
            sha512hex = DigestUtils.sha512Hex(hash);
        } catch (Exception e) {
            log.error("Digest Util Failure for SHA-512");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
        }

        log.info("Comparing Hash");
        if (!sha512hex.equalsIgnoreCase(paymentRequest.getHash())) {
            log.error("Hash not Matched");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.AUTHORIZATION_FAILED);
        }

    }

    private void checkRefundHash(TransactionRefundRequest transactionRefundRequest, String appToken,
                                 String clientSecret) throws ThirdPartyPaymentsException {

        String hash = appToken + '#' + transactionRefundRequest.getMerchantTxnId() + '#'
                + transactionRefundRequest.getAmount() + '#' + clientSecret;
        String sha512hex = null;
        try {
            sha512hex = DigestUtils.sha512Hex(hash);
        } catch (Exception e) {
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
        }
        log.info("Comparing Hash");
        if (!sha512hex.equalsIgnoreCase(transactionRefundRequest.getHash())) {
            log.error("Hash not Matched");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.AUTHORIZATION_FAILED);
        }
    }

    private MerchantTransactionDetailsEntity checkMerchantDetails(PaymentRequest paymentRequest)
            throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity merchantTransactionDetailsEntity = merchantTransactionDetailsRepo
                .findByMerchantId(paymentRequest.getMerchantId());
        if (merchantTransactionDetailsEntity == null) {
            log.info("Inavlid Merchant {}", paymentRequest.getMerchantId());
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_MERCHANT);
        }
        if (paymentRequest.getAmount().equals(new BigDecimal(0).abs())) {
            log.info("Amount cannot zero ");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_AMOUNT);
        }
        if (paymentRequest.getAmount().compareTo(BigDecimal.ZERO) < 0) {
            log.info("Amount cannot be less than Zero ");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_AMOUNT);
        }
        return merchantTransactionDetailsEntity;
    }

    private void checkRequestInDB(PaymentRequest paymentRequest) throws ThirdPartyPaymentsException {
        OrderDetailsEntity orderDetailsEntity = orderDetailsRepo
                .getOne(paymentRequest.transactionDetailsRequest.getMerchantTxnId());
        if (orderDetailsEntity != null) {
            log.info("Payment Already Processed,{}", paymentRequest);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.DUPLICATE_MERCHANTTXNID);
        }
    }

    private void checkRefundRequestInDB(TransactionRefundRequest transactionRefundRequest)
            throws ThirdPartyPaymentsException {
        if (transactionRefundRequest == null) {
            throw new ThirdPartyPaymentsException(ResponseErrorCode.EXCEPTION);
        }
        TransactionRefundEntity transactionRefundEntity = refundDetailsRepo
                .getOne(transactionRefundRequest.getFeSessionId());
        if (transactionRefundEntity != null) {
            log.info("Duplicate Fsession Id: {}", transactionRefundEntity.getFeSessionId());
            throw new ThirdPartyPaymentsException(ResponseErrorCode.REFUND_ALREADY_PROCESSED);
        }

    }

    public int sum(int first, int second) {
        return (first + second);
    }

    /**
     * Validate customer consent appId
     *
     * @param appId
     * @throws ConsentException
     */
    @Override
    public void validateCustomerConsent(String appId) throws ConsentException {
        if (appId.isEmpty()) {
            log.info("Check customer AppId should not empty {}", appId);
            throw new ConsentException(ResponseErrorCode.CONSENT_APP_ID_NOT_EMPTY, AppConstants.CUSTOMER_APP_ID_NOT_EMPTY);
        }
    }

    /**
     * validate the request parameter
     *
     * @param request
     * @throws ConsentException
     */
    @Override
    public void validateCustomerDetailsConsent(CustomerConsentRequest request) throws ConsentException {
        if (request.getMobileNumber().isEmpty() || request.getConsentMode().isEmpty()) {
            throw new ConsentException(ResponseErrorCode.INVALID_REQUEST, AppConstants.SOME_THINGS_WENT_WRONG);
        }
    }

    @Override
    public void validateRequestParam(Object requestObject) {
        log.info("validation checking for requested param :: {}",requestObject);
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        StringBuilder stringBuilder = new StringBuilder();
        Set<ConstraintViolation<Object>> violations = validator.validate(requestObject);
        if (!(violations.isEmpty())) {
            for (ConstraintViolation<Object> violation : violations) {
                stringBuilder.append(violation.getMessage() + " , ");
            }
            log.error("Validation failed in requested param :: {}",stringBuilder);
            throw new GenericException(ResponseErrorCode.INVALID_REQUEST_BODY, stringBuilder.substring(0, stringBuilder.length() - 2), messageSource.getMessage(AppConstants.Key.VALIDATION_FAILED_CODE, null, Locale.getDefault()));
        }
    }

    /**
     * Check the authentication
     *
     * @param requestSecretKey
     */
    public void validateForSecretKey(String requestSecretKey) {
        log.info("Entering into validateForSecretKey() method :: {}", requestSecretKey);
        if (!(requestSecretKey.equals(secretKey))) {
            log.error("Error into validateForSecretKey() method");
            throw new GenericException(ResponseErrorCode.INVALID_REQUEST_BODY, messageSource.getMessage(AppConstants.Key.SECRET_FAILED_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.SECRET_FAILED_CODE, null, Locale.getDefault()));

        }
    }


}
