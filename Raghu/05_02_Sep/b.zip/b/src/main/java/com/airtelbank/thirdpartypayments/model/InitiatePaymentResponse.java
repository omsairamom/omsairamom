package com.airtelbank.thirdpartypayments.model;

import com.airtelbank.thirdpartypayments.model.order.OrderDetails;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InitiatePaymentResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    @JsonProperty("purposeRefNo")
    private String purposeRefNo;
    @JsonProperty("purposeCode")
    private String purposeCode;
    private String lobID;
    private String circleID;
    private String transType;
    private String enquiryURL;
    private String remarks;
    private String messageText;
    private String status;
    private BigDecimal totalAmount;
    private String purposeIconUrl;
    private OrderDetails orderDetails;

}
