package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.payments.model.PaymentDetails;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;

public interface PostPaymentProcessingService {

    void processPayment(PaymentDetails payment) throws ThirdPartyPaymentsException;

}
