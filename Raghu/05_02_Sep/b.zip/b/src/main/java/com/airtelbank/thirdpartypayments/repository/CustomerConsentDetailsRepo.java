package com.airtelbank.thirdpartypayments.repository;

import com.airtelbank.thirdpartypayments.entity.CustomerConsentDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerConsentDetailsRepo extends JpaRepository<CustomerConsentDetailsEntity, Long> {
    /**
     * Fetch user consent details by appId
     *
     * @param appId
     * @return CustomerConsentDetailsEntity
     */
    CustomerConsentDetailsEntity findByAppId(String appId);
}
