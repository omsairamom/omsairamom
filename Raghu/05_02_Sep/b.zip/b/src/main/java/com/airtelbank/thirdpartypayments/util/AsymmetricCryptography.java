package com.airtelbank.thirdpartypayments.util;

import org.apache.tomcat.util.codec.binary.Base64;

import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class AsymmetricCryptography {
    private static final String RSA = "RSA";

    /**
     * Generating public & private keys using RSA algorithm.
     *
     * @return
     * @throws Exception
     */

    public static KeyPair generateRSAKkeyPair() throws Exception {
        SecureRandom secureRandom = new SecureRandom();
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(RSA);

        keyPairGenerator.initialize(2048, secureRandom);

        return keyPairGenerator.generateKeyPair();
    }

    /**
     * Encryption function which converts the plainText into a cipherText using
     * private Key.
     *
     * @param plainText
     * @param publicKey
     * @return
     * @throws Exception
     */

    public static byte[] do_RSAEncryption(String plainText, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance(RSA);

        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        return cipher.doFinal(plainText.getBytes());
    }

    /**
     * Decryption function which converts the ciphertext back to the orginal
     * plaintext.
     *
     * @param cipherText
     * @param privateKey
     * @return
     * @throws Exception
     */
    public static String do_RSADecryption(byte[] cipherText, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance(RSA);

        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] result = cipher.doFinal(cipherText);

        return new String(result);
    }

    /**
     * convert key is PrivateKey
     *
     * @param privateKey
     * @return
     * @throws Exception
     */
    public static PrivateKey getprivate(String privateKey) throws Exception {

        Base64 base64 = new Base64();
        byte[] keyBytes = base64.decode(privateKey);

        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");

        return kf.generatePrivate(spec);
    }

    /**
     * Convert key into PublicKey
     *
     * @param publicKey
     * @return
     * @throws Exception
     */
    public static PublicKey getpublic(String publicKey) throws Exception {
        Base64 base64 = new Base64();
        byte[] keyBytes = base64.decode(publicKey);

        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }

    /**
     * Encrypt the text
     *
     * @param plainText
     * @param publicKey
     * @return
     * @throws Exception
     */
    public static byte[] RSAEncryption(String plainText, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance(RSA);

        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        return cipher.doFinal(plainText.getBytes());
    }

    /**
     * decrypt the text
     *
     * @param cipherText
     * @param privateKey
     * @return
     * @throws Exception
     */
    public static String RSADecryption(byte[] cipherText, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance(RSA);

        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] result = cipher.doFinal(cipherText);

        return new String(result);
    }
}
