package com.airtelbank.thirdpartypayments.entity;

public class APBOAuthEnum {
    public enum ExpiryUnit {
        SEC, HOUR, DAYS
    }

    public enum OAuthScope {
        DEFAULT, TYPE1, TYPE2
    }

    public enum ExpiryStatus {
        ACTIVE, INACTIVE
    }
}
