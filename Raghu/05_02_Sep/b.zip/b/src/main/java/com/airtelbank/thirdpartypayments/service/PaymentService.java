package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.ActorResponse;

public interface PaymentService {
    ActorResponse sendPurposeDetails(String purposeCode, String purposeRefNumber) throws ThirdPartyPaymentsException;
}