package com.airtelbank.thirdpartypayments.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

@Slf4j
public class CustomLocalDateConverter {


    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");
    private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final String PAYMENT_DATE_FORMAT="yyyy-MM-dd HH:mm:ss.SSSZ";

    @WritingConverter
    public enum Java8LocalDateToStringConverter implements Converter<java.time.LocalDate, String> {
        INSTANCE;

        @Override
        public String convert(java.time.LocalDate source) {
            return source == null ? null : dateTimeFormatter.format(source);
        }
    }

    @ReadingConverter
    public enum StringToJava8LocalDateConverter implements Converter<String, java.time.LocalDate> {
        INSTANCE;

        @Override
        public java.time.LocalDate convert(String source) {
            if (source == null) {
                return null;
            }

            return LocalDate.parse(source, dateTimeFormatter);
        }
    }

    @WritingConverter
    public enum ZonedDateTimeToStringConverter implements Converter<java.time.ZonedDateTime, String> {
        INSTANCE;

        @Override
        public String convert(java.time.ZonedDateTime source) {
            return source == null ? null : source.format(DateTimeFormatter.ISO_ZONED_DATE_TIME);
        }
    }

    @ReadingConverter
    public enum StringToZonedDateTimeConverter implements Converter<String, java.time.ZonedDateTime> {
        INSTANCE;

        @Override
        public java.time.ZonedDateTime convert(String source) {

            if (source == null) {
                return null;
            }

            return ZonedDateTime.parse(source, DateTimeFormatter.ISO_ZONED_DATE_TIME);
        }
    }

    public static String getCurrentUTC() {
        final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    public static String getPaymentDateTime(Integer second) {
        Calendar instance = Calendar.getInstance();
        instance.add(Calendar.SECOND, second);
        SimpleDateFormat dateFormat = new SimpleDateFormat(PAYMENT_DATE_FORMAT);
        Date extendTime = instance.getTime();
        return dateFormat.format(extendTime);
    }
}