package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.service.LogErrorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LogErrorServiceImpl implements LogErrorService {

    @Autowired
    private OrderDetailsRepo orderRepo;

    @Override
    public void logOrderError(OrderDetailsEntity order, String code, String message, OrderStatus status) {

        order.setErrorCode(code);
        order.setErrorMessage(message);
        order.setStatus(status);

        orderRepo.save(order);
    }

}
