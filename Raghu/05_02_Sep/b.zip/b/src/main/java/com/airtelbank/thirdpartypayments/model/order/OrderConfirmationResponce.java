package com.airtelbank.thirdpartypayments.model.order;

import com.airtelbank.thirdpartypayments.model.CustomActions;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor

public class OrderConfirmationResponce implements Serializable {

    private static final long serialVersionUID = 1L;
    private String merchantTxnId;
    private List<CustomEntry> details;
    private List<CustomActions> actions;
}
