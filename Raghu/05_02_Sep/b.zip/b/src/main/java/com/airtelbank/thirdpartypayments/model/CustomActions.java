package com.airtelbank.thirdpartypayments.model;

public class CustomActions extends CustomEntry {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

}
