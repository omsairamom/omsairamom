package com.airtelbank.thirdpartypayments.config;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.introspect.AnnotatedField;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;

public class MyNameStrategy extends PropertyNamingStrategy {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Override
    public String nameForField(MapperConfig config, AnnotatedField field, String defaultName) {
        return convert(defaultName);

    }

    @Override
    public String nameForGetterMethod(MapperConfig config, AnnotatedMethod method, String defaultName) {
        return convert(defaultName);
    }

    @Override
    public String nameForSetterMethod(MapperConfig config, AnnotatedMethod method, String defaultName) {

        return convert(defaultName);
    }

    public String convert(String defaultName) {
        final char[] arr = defaultName.toCharArray();
        if (arr.length != 0 && Character.isLowerCase(arr[0])) {
            final char upper = Character.toUpperCase(arr[0]);
            arr[0] = upper;
        }
        return new StringBuilder().append(arr).toString();
    }

}
