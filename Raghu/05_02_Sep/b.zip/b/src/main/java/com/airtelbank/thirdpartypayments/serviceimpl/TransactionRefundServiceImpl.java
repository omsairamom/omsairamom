package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.dto.response.common.Constants;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.PaymentDetails;
import com.airtelbank.thirdpartypayments.model.TransactionRefundPaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundPaymentResponse;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundResponse;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.TransactionRefundService;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class TransactionRefundServiceImpl implements TransactionRefundService {

    @Autowired
    private RefundDetailsRepo refundDetailsRepo;

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    @Autowired
    HttpUtil httpUtil;

    @Autowired
    private Environment environment;

    @Autowired
    private ValidationService validationService;

    @Override
    public TransactionRefundResponse refundInit(TransactionRefundRequest transactionRefundRequest, String appToken)
            throws ThirdPartyPaymentsException {
        if (transactionRefundRequest == null) {
            throw new ThirdPartyPaymentsException(ResponseErrorCode.EXCEPTION);
        }
        OrderDetailsEntity orderDetailsEntity = orderDetailsRepo.getOne(transactionRefundRequest.getMerchantTxnId());
        validationService.validateAppToken(appToken, orderDetailsEntity.getMerchantId());
        String clientSecret = validationService.validateRefund(transactionRefundRequest, appToken,
                orderDetailsEntity.getMerchantId());

        if (transactionRefundRequest.getAmount().compareTo(orderDetailsEntity.getAmount()) > 0) {
            log.info("Refund Amount is greater than Actual Amount");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.EXCEEDS_AMOUNT);
        }

        TransactionRefundPaymentResponse transactionRefundPaymentResponse = paymentRefund(transactionRefundRequest,
                orderDetailsEntity.getPrID());
        log.info("Refund Payment2.0 Response {}", transactionRefundPaymentResponse);

        TransactionRefundResponse transactionRefundResponse = null;
        TransactionRefundEntity transactionRefundEntity = new TransactionRefundEntity();

        if (transactionRefundPaymentResponse.getData().getPaymentsStatus() == 1) {
            log.info("Refund Processing Failure from Payments2.0 API");
            transactionRefundEntity.setRefundStatus(OrderStatus.REFUND_FAILED.toString());
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR);
        }

        PaymentDetails paymentDetails = transactionRefundPaymentResponse.getData();
        transactionRefundEntity.setFeSessionId(transactionRefundRequest.getFeSessionId());
        transactionRefundEntity.setRefundTxnId(transactionRefundRequest.getRefundTxnId());
        transactionRefundEntity.setMerchantTxnId(transactionRefundRequest.getMerchantTxnId());
        transactionRefundEntity.setAmount(transactionRefundRequest.getAmount());
        transactionRefundEntity.setPrId(paymentDetails.getPrId());
        transactionRefundEntity.setFtTxnId(paymentDetails.getTransactionStatusDetails().get(0).getFtTxnId());
        transactionRefundEntity.setMerchantId(orderDetailsEntity.getMerchantId());
        transactionRefundEntity.setPurposeRefNo(orderDetailsEntity.getPurposeRefNo());
        transactionRefundEntity.setRefundStatus(OrderStatus.REFUNDED.toString());

        String dateValue = paymentDetails.getTransactionStatusDetails().get(0).getTransactionDateTime().toString();
        DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
        String formattedDate = null;
        try {
            Date date = formatter.parse(dateValue);
            formattedDate = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss z").format(date);
            transactionRefundEntity.setTxnDate(formattedDate);
        } catch (ParseException e) {
            log.info("Date Parsing Exception", e);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
        }
        refundDetailsRepo.save(transactionRefundEntity);

        transactionRefundResponse = TransactionRefundResponse.builder().reversalTxnDate(formattedDate)
                .status(Constants.SUCCESS).refundTxnId(transactionRefundRequest.getRefundTxnId())
                .amount(transactionRefundRequest.getAmount()).reversalTxnId(paymentDetails.getPrId())
                .hash(DigestUtils.sha512Hex(appToken + '#' + transactionRefundPaymentResponse.getMeta().getStatus()
                        + '#' + paymentDetails.getPrId() + '#' + clientSecret))
                .build();

        return transactionRefundResponse;
    }

    private TransactionRefundPaymentResponse paymentRefund(TransactionRefundRequest transactionRefundRequest,
                                                           String prId) throws ThirdPartyPaymentsException {

        TransactionRefundPaymentRequest transactionRefundPaymentRequest = new TransactionRefundPaymentRequest();
        String refundPurposeUrl = environment.getProperty(AppConstants.URL.PURPOSE_REFUND);
        TransactionRefundPaymentResponse transactionRefundPaymentResponse = null;

        String url = refundPurposeUrl;
        Map<String, String> headers = new HashMap<>();
        headers.put("channel", "Android");
        headers.put("Content-Type", "application/json");

        transactionRefundPaymentRequest.setAmount(transactionRefundRequest.getAmount());
        transactionRefundPaymentRequest.setPrid(prId);
        transactionRefundPaymentRequest.setRequestTimestamp(LocalDateTime.now().toString());
        transactionRefundPaymentRequest.setToNarrative("");
        transactionRefundPaymentRequest.setToSmsData("");
        transactionRefundPaymentRequest.setPartnerOrgTxnId("");
        transactionRefundPaymentRequest.setPartnerRefundId("");

        try {
            transactionRefundPaymentResponse = httpUtil.hitRequest(url, transactionRefundPaymentRequest,
                    TransactionRefundPaymentResponse.class, headers, HttpMethod.POST);
        } catch (Exception ex) {
            log.error("Getting error while calling Payment2.0 Refund ", ex);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, ex);
        }
        if (transactionRefundPaymentResponse.getMeta().getStatus() == 1) {
            log.info("Refund failed at Payments2.0 end {}", transactionRefundPaymentResponse);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR);
        }
        return transactionRefundPaymentResponse;
    }
}