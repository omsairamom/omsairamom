package com.airtelbank.thirdpartypayments.exception;

import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.model.consent.Meta;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

@Getter
public class GenericException extends RuntimeException {
    private static final long serialVersionUID = -3201228269077444961L;
    private final Meta meta;
    private final String errorCode;
    private final String errorMessage;
    private HttpStatus httpStatus;

    public GenericException(ResponseErrorCode errorConstants) {
        super(errorConstants.getDescription());
        this.errorCode = errorConstants.getCode();
        this.errorMessage = errorConstants.getDescription();
        this.meta = null;
    }

    public GenericException(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.meta = null;
    }

    public GenericException(ResponseErrorCode errorConstants, String errorMessage) {
        if (!StringUtils.isEmpty(errorMessage)) {
            this.errorMessage = errorMessage;
        } else {
            this.errorMessage = errorConstants.getDescription();
        }
        this.errorCode = errorConstants.getCode();
        this.meta = null;
    }

    public GenericException(ResponseErrorCode errorConstants, String errorMessage, String errorCode) {
        if (!StringUtils.isEmpty(errorMessage)) {
            this.errorMessage = errorMessage;
        } else {
            this.errorMessage = errorConstants.getDescription();
        }
        this.errorCode = errorCode;
        this.meta = null;
        this.httpStatus = errorConstants.getHttpStatus();
    }

    public GenericException(String errorMessage) {
        super(errorMessage);
        this.errorMessage = errorMessage;
        this.errorCode = null;
        this.meta = null;
    }

    public GenericException(Meta meta) {
        this.meta = meta;
        this.errorCode = null;
        this.errorMessage = null;
    }
}
