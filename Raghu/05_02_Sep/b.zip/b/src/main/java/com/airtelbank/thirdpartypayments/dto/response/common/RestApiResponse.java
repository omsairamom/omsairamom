package com.airtelbank.thirdpartypayments.dto.response.common;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class RestApiResponse {

    private RestApiResponse() {
    }

    private Meta meta;
    private Object data;
    private List<CustomError> errors;

    public static RestApiResponse buildSuccessResponse(String code, String message, Object result) {
        RestApiResponse response = new RestApiResponse();
        Meta meta = new Meta();
        meta.setCode(code);
        meta.setDescription(message);
        meta.setStatus(AppConstants.Status.STATUS_SUCCESS);
        response.setMeta(meta);
        response.setData(result);
        return response;
    }

    public static RestApiResponse buildFailureResponse(String code, String message) {
        RestApiResponse restApiResopnse = new RestApiResponse();
        Meta meta = new Meta();
        meta.setCode(code);
        meta.setDescription(message);
        meta.setStatus(AppConstants.Status.STATUS_FAILURE);
        restApiResopnse.setMeta(meta);
        return restApiResopnse;
    }

    public static RestApiResponse buildResponse(String code, String message, int status, Object result,
                                                Map<String, String> statusMap) {
        RestApiResponse response = new RestApiResponse();
        Meta meta = new Meta();
        meta.setCode(code);
        meta.setStatus(AppConstants.Status.STATUS_SUCCESS);
        meta.setDescription(message);

        if (!CollectionUtils.isEmpty(statusMap)) {
            meta.setCode(statusMap.get(AppConstants.STATUS_CODE));
            meta.setStatus(AppConstants.Status.STATUS_SUCCESS);
            meta.setDescription(statusMap.get(AppConstants.STATUS_DESC));
        }

        response.setMeta(meta);
        response.setData(result);
        return response;
    }

}
