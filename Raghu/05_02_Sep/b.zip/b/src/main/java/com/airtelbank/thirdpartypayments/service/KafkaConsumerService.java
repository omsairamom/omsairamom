package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.payments.model.PaymentDetails;

public interface KafkaConsumerService {

    public void thirdPartyPaymentListener(PaymentDetails payment);

}
 