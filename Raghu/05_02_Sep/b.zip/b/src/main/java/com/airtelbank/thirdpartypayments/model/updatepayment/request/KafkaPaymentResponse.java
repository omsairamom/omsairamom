package com.airtelbank.thirdpartypayments.model.updatepayment.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
public class KafkaPaymentResponse {
    private String secretKey;
    private String purposeRefNo;
    private String paymentRefId;
    private String status;
    private String totalAmount;
    private String errorCode;
    private String errorMessage;
    private String timestamp;
}
