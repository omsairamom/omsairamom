package com.airtelbank.thirdpartypayments.util;

import com.airtelbank.thirdpartypayments.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.util.Map;
import java.util.Set;

@Slf4j
@Component
public class HttpUtil {

    private HttpUtil() {

    }

    private static final Logger logger = LoggerFactory.getLogger(HttpUtil.class);

    /**
     * The rest template.
     */
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier("proxyRestTemplate")
    private RestTemplate proxyTemplate;

    private RestTemplate selectedTemplate;

    public static boolean hasTextBody(HttpHeaders headers) {
        MediaType contentType = headers.getContentType();
        if (contentType != null) {
            String subtype = contentType.getSubtype();
            return "text".equals(contentType.getType()) || "xml".equals(subtype) || "json".equals(subtype);
        }
        return false;
    }

    public static Charset determineCharset(HttpHeaders headers) {
        MediaType contentType = headers.getContentType();
        if (contentType != null) {
            try {
                Charset charSet = contentType.getCharset();
                if (charSet != null) {
                    return charSet;
                }
            } catch (UnsupportedCharsetException e) {
                // ignore
            }
        }
        return StandardCharsets.UTF_8;
    }

    // TODO: refactor below two methods to remove code duplication

    public <Req, Res> Res hitRequest(String url, Req requestObj, Class<Res> classObj, Map<String, String> headers,
                                     HttpMethod method, Boolean useProxy) {

        Object resultObj = null;
        HttpEntity<?> entity = null;
        MultiValueMap<String, String> headersMap = null;

        if (headers != null && !headers.isEmpty()) {
            Set<String> headerKeySet = headers.keySet();

            headersMap = new LinkedMultiValueMap<>();

            for (String key : headerKeySet) {
                headersMap.add(key, headers.get(key));
            }
        }

        if (requestObj != null)
            entity = new HttpEntity<>(requestObj, headersMap);
        else
            entity = new HttpEntity<>(headersMap);

        try {
            // Send request with GET method, and Headers.
            StopWatch stopWatch = new StopWatch();
            logger.info("Going to hit Third Party API");
            stopWatch.start();
            HttpsURLConnection.setDefaultHostnameVerifier((host, session) -> true);
            ResponseEntity<?> response = proxyTemplate.exchange(url, method, entity, classObj);
            log.info("Response from API {}", response);
            stopWatch.stop();
            logger.info("After hitting Third Party API Time Taken: {} ms.", stopWatch.getTotalTimeMillis());
            resultObj = response.getBody();
            logger.info("Response :{}", resultObj);
        } catch (RestClientException ex) {
            logger.error("failed to call Third party API {}", ex.getMessage());
            throw new ServiceException(ex, "Error while calling third party API", "008");

        }
        return (Res) resultObj;

    }

    public <Req, Res> Res hitRequest(String url, Req requestObj, Class<Res> classObj, Map<String, String> headers,
                                     HttpMethod method) {
        Object resultObj = null;
        HttpEntity<?> entity = null;
        MultiValueMap<String, String> headersMap = null;

        if (headers != null && !headers.isEmpty()) {
            Set<String> headerKeySet = headers.keySet();

            headersMap = new LinkedMultiValueMap<String, String>();

            for (String key : headerKeySet) {
                headersMap.add(key, headers.get(key));
            }
        }

        if (requestObj != null)
            entity = new HttpEntity<>(requestObj, headersMap);
        else
            entity = new HttpEntity<>(headersMap);

        try {
            // Send request with GET method, and Headers.
            StopWatch stopWatch = new StopWatch();
            logger.info("Going to hit Third Party API");
            stopWatch.start();
            HttpsURLConnection.setDefaultHostnameVerifier((host, session) -> true);
            ResponseEntity<?> response = restTemplate.exchange(url, method, entity, classObj);
            log.info("Response from API {}", response);
            stopWatch.stop();
            logger.info("After hitting Third Party API Time Taken: {} ms.", stopWatch.getTotalTimeMillis());
            resultObj = response.getBody();
            logger.info("Response :{}", resultObj);
        } catch (RestClientException ex) {
            logger.error("failed to call Third party API {}", ex.getMessage());
            throw new ServiceException(ex, "Error while calling third party API", "008");

        }
        return (Res) resultObj;
    }

}
