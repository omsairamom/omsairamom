package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.model.consent.Consent;
import com.airtelbank.thirdpartypayments.model.consent.ConsentDetailsResponse;
import com.airtelbank.thirdpartypayments.model.consent.ConsentHeaderDTO;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;
import com.airtelbank.thirdpartypayments.service.ConsentService;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import java.util.Locale;
import java.util.Map;

/**
 * @author Ranjeet singh 04/06/2021 The com.airtel.thirdPartyPayments.Consent
 * conrtroller contains the two end points: Fetch customer consent
 * details Create the customer consent
 */

@Slf4j
@RestController
@RequestMapping(value = "api/v1/consent")
@Validated
public class ConsentController {

    @Autowired
    private ConsentService consentService;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private ValidationService validationService;


    /**
     * API end points for fetch customer consent details
     *
     * @param mobileNo
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     * @throws ConsentException
     */

    @GetMapping(path = "/{mobileNo}")
    public ResponseEntity<RestApiResponse> getConsentDetails(@PathVariable(value = "mobileNo")
                                                             @Pattern(regexp = "[6-9][0-9]{9}$", message = AppConstants.MOBILE_NOT_VALID_MSG) String mobileNo,
                                                             @RequestHeader Map<String, String> headers)
            throws ConsentException {

        log.info("Entering into getConsentDetails() method for mobile :: {} , headers :: {}",mobileNo,headers);
        ConsentHeaderDTO headerRequestDTO = CommonUtil.convertMapHeader(headers);
        validationService.validateRequestParam(headerRequestDTO);
        MDC.put(AppConstants.APP_ID, mobileNo);
        MDC.put(AppConstants.CHANNEL, headerRequestDTO.getChannel());
        MDC.put(AppConstants.CONTENT_ID, headerRequestDTO.getContentId());
        Consent consentDetailsResponse = consentService.getCustomerConsent(mobileNo, headerRequestDTO.getContentId(), headerRequestDTO.getChannel(), headerRequestDTO.getUserAgent());
        log.info("Response return consentService.getConsentDetails() method :: {}", consentDetailsResponse);
        if (null != consentDetailsResponse)
            return ResponseEntityBuilder.getBuilder(HttpStatus.OK)
                    .successResponse(AppConstants.SUCCESS, consentDetailsResponse);
        else
            return ResponseEntityBuilder.getBuilder(HttpStatus.OK).errorResponse(messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_CODE, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_MSG, null, Locale.getDefault()));
    }

    /**
     * API end points for save consent details
     *
     * @param request
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     * @throws ConsentException
     */

    /**
     * @Valid annotation for checking the validation in request and through //in
     * case any data is missing.
     **/
    @PostMapping(path = "/saveConsent")
    public ResponseEntity<RestApiResponse> saveConsent(@RequestBody @Valid CustomerConsentRequest request,
                                                       @RequestHeader Map<String, String> headers) throws ConsentException {

        log.info("Entering into saveConsent() method for request :: {} and headers", request,headers);
        ConsentHeaderDTO headerRequestDTO = CommonUtil.convertMapHeader(headers);
        validationService.validateRequestParam(headerRequestDTO);
        MDC.put(AppConstants.CUSTOMER_ID, request.getMobileNumber());
        MDC.put(AppConstants.CHANNEL, headerRequestDTO.getChannel());
        MDC.put(AppConstants.CONTENT_ID, headerRequestDTO.getContentId());

        ConsentDetailsResponse consentDetailsResponse = consentService.createCustomerConsent(request, headerRequestDTO.getChannel(),
                headerRequestDTO.getContentId(), headerRequestDTO.getUserAgent());

        log.info("Response return consentService.saveConsent() method :: {}", consentDetailsResponse);

        return ResponseEntityBuilder.getBuilder(HttpStatus.OK)
                .successResponse(AppConstants.SUCCESS, consentDetailsResponse.getData());
    }

}
