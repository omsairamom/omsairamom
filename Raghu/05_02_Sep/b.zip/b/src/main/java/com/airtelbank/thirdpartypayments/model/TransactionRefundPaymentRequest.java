package com.airtelbank.thirdpartypayments.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionRefundPaymentRequest implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private BigDecimal amount;
    private String prid;
    private String partnerOrgTxnId;
    private String partnerRefundId;
    private String requestTimestamp;
    private String toSmsData;
    private String toNarrative;

}
