package com.airtelbank.thirdpartypayments.serviceimpl.order;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.model.order.OrderRequest;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.service.LogErrorService;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationService;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class DefaultOrderConfirmationService implements OrderConfirmationService {

    @Autowired
    private DefaultRequestBuilder defaultRequestBuilder;

    @Autowired
    HttpUtil httpUtil;

    @Autowired
    LogErrorService errorService;

    @Retryable(
            //value = {.class},
            maxAttempts = 2, backoff = @Backoff(5000))
    @Override
    public DefaultOrderConfirmationResponce doConfirm(OrderDetailsEntity order,
                                                      MerchantTransactionDetailsEntity merchant) throws ThirdPartyPaymentsException {

        OrderRequest<?> orderRequest = defaultRequestBuilder.buildRequest(order, merchant);

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

// Checking user eligibility
        String url = merchant.getOrderConfirmationURL();

        DefaultOrderConfirmationResponce confirmationResponse;

        try {
            confirmationResponse = httpUtil.hitRequest(url, orderRequest.getData(),
                    DefaultOrderConfirmationResponce.class, header, HttpMethod.POST, true);
            log.info("Confirmation Response from Third Party Partner Id:{},Response:{}", merchant.getMerchantId(), confirmationResponse);

        } catch (Exception e) {
            log.error("Error while calling third party for order confirmation for merchant txn id: "
                    + order.getMerchantTxnId());
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR);
        }
        return confirmationResponse;
    }


    @Recover
    public DefaultOrderConfirmationResponce recover(OrderDetailsEntity order,
                                                    MerchantTransactionDetailsEntity merchant) throws ThirdPartyPaymentsException {
        DefaultOrderConfirmationResponce confirmationResponse;
        OrderRequest<?> orderRequest = defaultRequestBuilder.buildRequest(order, merchant);
        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");
        confirmationResponse = httpUtil.hitRequest(merchant.getOrderConfirmationURL(), orderRequest.getData(),
                DefaultOrderConfirmationResponce.class, header, HttpMethod.POST, true);
        if (confirmationResponse == null || confirmationResponse.getMeta() == null) {
            log.error("Error while calling third party for order confirmation for merchant txn id:{} "
                    + order.getMerchantTxnId());
            errorService.logOrderError(order, null,
                    "Error while calling third party for order confirmation for merchant txn id:{},{}"
                            + order.getMerchantTxnId(),
                    OrderStatus.CONFIRMATION_FAILED);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR);
        } else if (confirmationResponse.getMeta().getStatus() > 0) {
            log.error(
                    "Error while calling third party for order confirmation for merchant txn id: %s "
                            + "with code and status as {},{} ",
                    order.getMerchantTxnId(), confirmationResponse.getMeta().getCode(),
                    confirmationResponse.getMeta().getDescription());
            errorService.logOrderError(order, confirmationResponse.getMeta().getCode(),
                    confirmationResponse.getMeta().getDescription(), OrderStatus.CONFIRMATION_FAILED);
            MDC.put(AppConstants.ORDER_STATUS, OrderStatus.CONFIRMATION_FAILED.toString());
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR);
        }
        return confirmationResponse;
    }

}
