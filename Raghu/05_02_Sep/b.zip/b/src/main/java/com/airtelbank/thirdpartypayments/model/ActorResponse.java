package com.airtelbank.thirdpartypayments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class ActorResponse implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String requestTimestamp;
    private String txnAmount;
    private Customer customer;
    private String diffParameter1;
    private String diffParameter2;
    private String fromNarration;
    private String toNarration;
    private String fromSms;
    private String toSms;

}
