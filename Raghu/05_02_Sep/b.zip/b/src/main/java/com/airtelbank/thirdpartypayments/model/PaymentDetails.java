package com.airtelbank.thirdpartypayments.model;

import com.airtelbank.payments.model.TransactionStatusDetails;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String prId;

    private String refPrid;

    private String type;

    private String puporseCode;

    private String purposeRefNo;

    private BigDecimal totalAmount;

    private String txnMessage;

    @JsonProperty("status")
    private Integer paymentsStatus;

    private String addParam1;

    private String narration;

    private String addParam2;

    private List<TransactionStatusDetails> transactionStatusDetails;

    private Map<String, String> paramaters;

    private String customerNumber;

}
