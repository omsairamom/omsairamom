package com.airtelbank.thirdpartypayments.model.consent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class Consent {

    private Boolean consent;
    private String mobileNumber;
    private String consentPurpose;
    private String consentType;
    private String consentMode;
    private String consentToken;
    private String consentDescription;
    private String createdDate;
    private String updatedDate;
    private String validityTill;
    private String pwaLink;
}

