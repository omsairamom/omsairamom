package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.model.redbuspayment.request.FulfilmentRequest;

public interface RedBusProducerService {

    void sendFulfilmentRequest(FulfilmentRequest fulfilmentRequest);

}
