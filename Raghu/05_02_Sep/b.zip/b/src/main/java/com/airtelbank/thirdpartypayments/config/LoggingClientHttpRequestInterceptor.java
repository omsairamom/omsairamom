package com.airtelbank.thirdpartypayments.config;

import com.airtelbank.thirdpartypayments.util.HttpUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import java.io.IOException;

@Component
public class LoggingClientHttpRequestInterceptor implements ClientHttpRequestInterceptor {

    protected Logger logger = LoggerFactory.getLogger(getClass());

    protected Logger requestLogger = LoggerFactory.getLogger("spring.web.client.MessageTracing.sent");
    protected Logger responseLogger = LoggerFactory.getLogger("spring.web.client.MessageTracing.received");

    private volatile boolean loggedMissingBuffering;

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        logRequest(request, body);
        ClientHttpResponse response = execution.execute(request, body);
        logResponse(request, response);
        return response;
    }

    protected void logRequest(HttpRequest request, byte[] body) {
        if (logger.isDebugEnabled()) {
            logger.debug("=============request begin============");
            logger.debug("Request uri :{}", request.getMethod());
            logger.debug("Request uri :{}", request.getURI());
            logger.debug("Request headers :{}", request.getHeaders());
            if (body.length > 0 && HttpUtil.hasTextBody(request.getHeaders())) {
                String bodyText = new String(body, HttpUtil.determineCharset(request.getHeaders()));
                // logger.debug(LogMasker.patternReplace(bodyText), "utf-8");
                logger.debug(bodyText, "utf-8");
            }
            logger.debug("-------------request end--------------");
        }
    }

    protected void logResponse(HttpRequest request, ClientHttpResponse response) {
        if (logger.isDebugEnabled()) {
            try {
                String bodyText = null;
                StringBuilder inputStringBuilder = new StringBuilder();
                logger.debug("==========response begin===========");
                logger.debug("Status code  : {}", response.getStatusCode());
                logger.debug("Status text  : {}", response.getStatusText());
                logger.debug("Headers      : {}", response.getHeaders());
                HttpHeaders responseHeaders = response.getHeaders();
                long contentLength = responseHeaders.getContentLength();
                if (contentLength != 0) {
                    if (HttpUtil.hasTextBody(responseHeaders) && isBuffered(response)) {
                        bodyText = StreamUtils.copyToString(response.getBody(),
                                HttpUtil.determineCharset(responseHeaders));
                        inputStringBuilder.append(bodyText);
                    } else {
                        if (contentLength == -1) {
                            inputStringBuilder.append(" with content of unknown length");
                        } else {
                            inputStringBuilder.append(" with content of length ").append(contentLength);
                        }
                        MediaType contentType = responseHeaders.getContentType();
                        if (contentType != null) {
                            inputStringBuilder.append(" and content type ").append(contentType);
                        } else {
                            inputStringBuilder.append(" and unknown context type");
                        }
                    }
                }

                // logger.debug("Response body: {}",
                // LogMasker.patternReplace(inputStringBuilder.toString()), "utf-8");
                logger.debug(inputStringBuilder.toString(), "Response body: {}", "utf-8");
                logger.debug("----------response end-----------");
            } catch (IOException e) {
                logger.warn("Failed to log response for {} request to {}", request.getMethod(), request.getURI(), e);
            }
        }
    }

    protected boolean isBuffered(ClientHttpResponse response) {
        // class is non-public, so we check by name
        boolean buffered = "org.springframework.http.client.BufferingClientHttpResponseWrapper"
                .equals(response.getClass().getName());
        if (!buffered && !loggedMissingBuffering) {
            logger.warn(
                    "Can't log HTTP response bodies, as you haven't configured the RestTemplate with a BufferingClientHttpRequestFactory");
            loggedMissingBuffering = true;
        }
        return buffered;
    }

}
