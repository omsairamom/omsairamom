package com.airtelbank.thirdpartypayments.util;

import com.airtelbank.thirdpartypayments.model.LoggerModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class LoggerUtility {

    @Autowired
    private KibanaUtility kibanaUtility;

    public void setRequestJson(String requestJson) {
        kibanaUtility.getLoggerModel().setRequestJson(requestJson);
    }

    /**
     * Gets the KibanaLogParams.
     *
     * @return the object of KibanaLogParams
     */
    public static LoggerModel getKibanaLogger() {
        return new LoggerModel();
    }

    /**
     * Method to Print Kibana Logs
     */
    @Async
    public static void printLog(String applicationServiceId, String apiID, String purposeId, String prID, String id4,
                                String id5, LoggerModel kibanaLogger, String response, long start) {
        StringBuilder builder = new StringBuilder();
        builder.append(applicationServiceId);
        builder.append("~#~");
        builder.append(apiID);
        builder.append("~#~");
        builder.append(kibanaLogger.getMsisdn());
        builder.append("~#~");
        builder.append("~#~~#~~#~~#~");
        builder.append(purposeId);
        builder.append("~#~");
        builder.append(prID);
        builder.append("~#~");
        builder.append(id4);
        builder.append("~#~");
        builder.append(id5);
        builder.append("~#~");
        builder.append("~#~~#~~#~~#~~#~~#~~#~~#~~#~~#~#~");
        builder.append(kibanaLogger.getRequestJson());
        builder.append("~#~");
        builder.append(response);
        builder.append("~#~");
        builder.append(kibanaLogger.getStatus());
        builder.append("~#~");
        builder.append(kibanaLogger.getCode());
        builder.append("~#~");
        builder.append(kibanaLogger.getDescription());
        builder.append("~#~");
        long end = System.currentTimeMillis();
        end = end - start;
        builder.append(end);
        log.info(builder.toString());
    }

    /**
     * Method to set KibanaLogParams for FAILURE
     */
    /*
     * public static void setFailureParams(LoggerModel kibanaLogger,ErrorConstants
     * errorConstants) { kibanaLogger.setCode(errorConstants.getCode());
     * kibanaLogger.setStatus(Constants.Code.FAILURE);
     * kibanaLogger.setDescription(errorConstants.getMessage()); }
     */

}
