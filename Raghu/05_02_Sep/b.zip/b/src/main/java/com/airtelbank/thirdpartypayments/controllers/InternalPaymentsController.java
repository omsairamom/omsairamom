package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.payments.model.PaymentDetails;
import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.InitiatePaymentResponse;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.service.PaymentInitializationService;
import com.airtelbank.thirdpartypayments.service.PostPaymentProcessingService;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author b0206596
 */
@Slf4j
@RestController
@RequestMapping(value = "thirdPartyPayments/api/v1/payment")
public class InternalPaymentsController {

    @Autowired
    PaymentInitializationService paymentInitializationService;

    @Autowired
    LoggerModel loggerModel;

    /**
     * @param request     - Payment Request body
     * @param userAgent-  UserAgent at App End
     * @param customerId- unique customerId of the person
     * @param result-     For binding the above values
     * @return
     * @throws ThirdPartyPaymentsException
     */
    @CrossOrigin
    @PostMapping(path = "/initialize", consumes = "application/json", produces = "application/json")
    public ResponseEntity<RestApiResponse> executePayment(@Valid @RequestBody PaymentRequest request,
                                                          @RequestHeader(value = "User-Agent") String userAgent,
                                                          @RequestHeader(value = "customerId") String customerId, BindingResult result)
            throws ThirdPartyPaymentsException {
        ResponseEntity<RestApiResponse> response = null;

        log.info("Initiate with Post Request {},{}", customerId, request);
        MDC.put(AppConstants.MERCHANT_TXN_ID, request.getTransactionDetailsRequest().getMerchantTxnId());
        MDC.put(AppConstants.AMOUNT, request.getAmount());
        MDC.put(AppConstants.MERCHANT_ID, request.getMerchantId());
        MDC.put(AppConstants.CHANNEL, CommonUtil.getChannel(userAgent));
        InitiatePaymentResponse reversePaymentResponse;
        if (result.hasErrors()) {
            log.info("Invalid Request");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_REQUEST);
        } else {
            reversePaymentResponse = paymentInitializationService.paymentInitialize(request, customerId);
        }
        response = ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse("SUCCESS", reversePaymentResponse);

        return response;

    }


    // confirmation API.
    @Autowired
    private PostPaymentProcessingService postPaymentProcessingService;

    @CrossOrigin
    @PostMapping(path = "/testKafka", consumes = "application/json", produces = "application/json")
    public ResponseEntity<RestApiResponse> simulateKafka(@Valid @RequestBody PaymentDetails payment,
                                                         @RequestHeader(value = "User-Agent") String userAgent) throws ThirdPartyPaymentsException {
        ResponseEntity<RestApiResponse> response = null;
        try {
            postPaymentProcessingService.processPayment(payment);
        } catch (Exception e) {
            log.error("Error while processing the payment " + e.getMessage(), e);

        }
        response = ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse("SUCCESS", null);

        return response;
    }
}
