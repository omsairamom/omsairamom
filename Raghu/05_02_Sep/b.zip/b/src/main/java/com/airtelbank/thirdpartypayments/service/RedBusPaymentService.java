package com.airtelbank.thirdpartypayments.service;


import com.airtelbank.thirdpartypayments.model.redbuspayment.request.CustomerDetailsPaymentRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.HeaderRequestDTO;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusBookingResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentEnquiry;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaPaymentResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import org.springframework.http.ResponseEntity;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public interface RedBusPaymentService {
    RedBusPaymentResponse postDataToPaymentHub(CustomerDetailsPaymentRequest redBusPaymentRequest, HeaderRequestDTO headerRequestDTO);

    RedBusPaymentStatusResponse getPaymentStatusEnquiry(String purposeRefNo);

    RedBusBookingResponse saveRedBusBookingDetails(PaymentData redBusPaymentRequest, HeaderRequestDTO headerRequestDTO);

    ResponseEntity<String> updatePaymentStatus(KafkaPaymentResponse paymentRequest) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, InvalidKeySpecException;

    RedBusPaymentEnquiry getFulfilmentStatusEnquiryFromPrId(String prID, HeaderRequestDTO headerRequestDTO);

}

