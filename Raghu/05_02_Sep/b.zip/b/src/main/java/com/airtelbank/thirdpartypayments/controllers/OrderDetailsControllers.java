package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.OrderResponse;
import com.airtelbank.thirdpartypayments.service.OrderService;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author b0206596
 */
@Slf4j
@RestController
@RequestMapping(value = "thirdPartyPayments/api/v1/payment")
public class OrderDetailsControllers {

    @Autowired
    OrderService orderService;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    LoggerModel loggerModel;

    /**
     * @param purposeCode-      unique parameter for the Purpose
     * @param purposeRefNumber- Unique parameter to identify uniqueness of Payment
     * @param paymentRequestID- PaymentRequestID after the successful transaction at
     *                          PAyments2.0 field
     * @param customerId-       CustomerId of the customer to identify the unique
     *                          Customer
     * @param userAgent
     * @return Returns the response required at App End
     * @throws ThirdPartyPaymentsException
     */

    @CrossOrigin
    @GetMapping(path = "/bookingDetails/{PurposeCode}/{PurposerefNumber}/{PaymentRequestID}")
    public ResponseEntity<RestApiResponse> getOrderDetail(@Valid @PathVariable("PurposeCode") String purposeCode,
                                                          @Valid @PathVariable("PurposerefNumber") String purposeRefNumber,
                                                          @Valid @PathVariable("PaymentRequestID") String paymentRequestID,
                                                          @RequestHeader("customerId") String customerId, @RequestHeader(value = "User-Agent") String userAgent)
            throws ThirdPartyPaymentsException {
        ResponseEntity<RestApiResponse> response = null;
        log.info("Initiate with GET Request {},{},{}", purposeCode, purposeRefNumber, paymentRequestID);
        MDC.put(AppConstants.PURPOSE_CODE, purposeCode);
        MDC.put(AppConstants.CHANNEL, CommonUtil.getChannel(userAgent));
        OrderResponse orderResponse = null;

        orderResponse = orderService.getOrderDetail(purposeRefNumber);
        response = ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse("PAYMENT SUCCESS", orderResponse);
        return response;
    }

}
