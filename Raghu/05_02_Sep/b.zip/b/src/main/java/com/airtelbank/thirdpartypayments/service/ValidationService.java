package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;

public interface ValidationService {
    MerchantTransactionDetailsEntity validateMerchant(PaymentRequest paymentRequest, String customerId)
            throws ThirdPartyPaymentsException;

    void validateAppToken(String appToken, String merchantId) throws ThirdPartyPaymentsException;

    String getClientSecret(String merchantId) throws ThirdPartyPaymentsException;

    String validateRefund(TransactionRefundRequest transactionRefundRequest, String appToken, String merchantId)
            throws ThirdPartyPaymentsException;

    /**
     * Use for consent validation
     *
     * @param appId
     * @throws ConsentException
     */
    void validateCustomerConsent(String appId) throws ConsentException;

    /**
     * validate the create customer consent request
     *
     * @param request
     * @throws ConsentException
     */
    void validateCustomerDetailsConsent(CustomerConsentRequest request) throws ConsentException;

    /**
     * validate the request
     *
     * @param requestObject
     */
    void validateRequestParam(Object requestObject);

    /**
     * to check secret key
     *
     * @param requestSecretKey
     */
    void validateForSecretKey(String requestSecretKey);
}
