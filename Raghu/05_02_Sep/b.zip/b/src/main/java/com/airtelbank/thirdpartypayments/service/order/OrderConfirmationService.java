package com.airtelbank.thirdpartypayments.service.order;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationResponce;

public interface OrderConfirmationService {

    DefaultOrderConfirmationResponce doConfirm(OrderDetailsEntity order, MerchantTransactionDetailsEntity merchant) throws ThirdPartyPaymentsException;

}
