package com.airtelbank.thirdpartypayments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class TransactionEnquiryResponseDetail implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private BigDecimal amount;
    private String txnDate;
    private String txnId;
    private String merchantTxnId;
    private String status;
    private String type;
    private String hash;
}
