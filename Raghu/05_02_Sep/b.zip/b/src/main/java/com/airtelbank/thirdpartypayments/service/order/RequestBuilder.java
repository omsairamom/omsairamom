package com.airtelbank.thirdpartypayments.service.order;

import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.model.order.OrderRequest;

public interface RequestBuilder<T> {

    OrderRequest<T> buildRequest(OrderDetailsEntity orderDetails,
                                 MerchantTransactionDetailsEntity merchantTransactionDetails);

}
