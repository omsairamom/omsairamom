package com.airtelbank.thirdpartypayments.dto.response.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author Samita Mahajan
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class CustomError implements Serializable {

    private static final long serialVersionUID = 1L;
    private String field;
    private String description;
    private String code;
}
