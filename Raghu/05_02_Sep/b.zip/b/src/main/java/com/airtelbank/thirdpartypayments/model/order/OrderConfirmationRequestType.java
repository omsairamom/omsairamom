package com.airtelbank.thirdpartypayments.model.order;

public enum OrderConfirmationRequestType {


    DEFAULT("DEFAULT"),
    INTERNAL("INTERNAL"),
    CUSTOM("CUSTOM");

    OrderConfirmationRequestType(String value) {
        this.value = value;
    }

    private final String value;

    public String getValue() {
        return value;
    }


}
