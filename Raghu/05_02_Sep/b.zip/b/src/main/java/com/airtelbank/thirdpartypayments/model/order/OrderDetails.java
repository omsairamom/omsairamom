package com.airtelbank.thirdpartypayments.model.order;

import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    private String merchantTxnId;
    @JsonProperty("details")
    private List<CustomEntry> details;

}
