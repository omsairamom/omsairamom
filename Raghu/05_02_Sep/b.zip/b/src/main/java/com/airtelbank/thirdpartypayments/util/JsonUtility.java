package com.airtelbank.thirdpartypayments.util;

import com.google.gson.Gson;

/**
 * @author b0206596
 */
public class JsonUtility {

    public static <T> T jsonStringToClass(String str, Class<T> JsonClass) {
        Gson gson = new Gson();
        T obj = gson.fromJson(str, JsonClass);
        return obj;
    }
}
