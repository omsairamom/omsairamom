package com.airtelbank.thirdpartypayments.dto.response.common;

import java.io.IOException;

public class ResponseBuilder {

    public static ResponseBuilder getBuilder() {
        return new ResponseBuilder();
    }

    public RestApiResponse setResponse(String code, String message) throws IOException {
        return RestApiResponse.buildFailureResponse(code, message);
    }

}
