package com.airtelbank.thirdpartypayments.entity;

import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Builder
@Data
@NoArgsConstructor
@Table(name = "ORDER_DETAILS")
@Entity
@AllArgsConstructor
public class OrderDetailsEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @OneToMany(mappedBy = "orderDetailsEntity", cascade = CascadeType.ALL)
    private List<OrderDetailsTxn> orderDetailsTxn;

    @Id
    @Column(name = "MERCHANT_TXN_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MERCHANT_TXN_ID")
    @GenericGenerator(name = "MERCHANT_TXN_ID", strategy = "com.airtelbank.thirdpartypayments.sequence.MerchantTxnIdGenerator",
            parameters = {@Parameter(name = "sequence_prefix", value = "RB-"), @Parameter(name = "sequence_name", value = "MERCHANT_TXN_ID")})
    private String merchantTxnId;

    @Column(name = "CUSTOMER_ID")
    private String customerId;

    @Column(name = "MERCHANT_ID")
    private String merchantId;//todo check for unique

    @Column(name = "Amount")
    private BigDecimal amount;

    @Column(name = "PURPOSE_REF_NO", unique = true)
    private String purposeRefNo;

    @Column(name = "PRID")
    private String prID;

    @Column(name = "ERROR_CODE")
    private String errorCode;

    @Column(name = "ERROR_MESSAGE")
    private String errorMessage;

    @Column(name = "STATUS")
    private OrderStatus status;

    @Column(name = "CUSTOM_COL_1")
    private String source;

    @Column(name = "CUSTOM_COL_2")
    private String destination;

    @Column(name = "CUSTOM_COL_3")
    private String travelsName;

    @Column(name = "CUSTOM_COL_4")
    private String busType;

    @Column(name = "CUSTOM_COL_5")
    private String doj;

    @Column(name = "CUSTOM_COL_6")
    private String transactionId;
//
//	@OneToMany(mappedBy = "orderDetailsEntity", cascade = CascadeType.ALL)
//    private Set <OrderAmountDetailsEntity> getOrderAmountDetailsEntity;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATION_DATE", nullable = false, updatable = false)
    public Date creationDate;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED", nullable = false, updatable = true)
    public Date updationDate;


}
