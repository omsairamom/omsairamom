package com.airtelbank.thirdpartypayments.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@Table(name = "REFUND_REVERSE_PAYMENT")
@Entity
@AllArgsConstructor
@Builder
public class TransactionRefundEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "FE_SESSION_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FE_SESSION_ID")
    @GenericGenerator(name = "FE_SESSION_ID", strategy = "com.airtelbank.thirdpartypayments.sequence.MerchantTxnIdGenerator",
            parameters = {@Parameter(name = "sequence_prefix", value = "RBR-"), @Parameter(name = "sequence_name", value = "FE_SESSION_ID")})
    private String feSessionId;

    @Column(name = "MERCHANT_TXN_ID")
    private String merchantTxnId;

    @Column(name = "TXN_DATE")
    private String txnDate;

    @Column(name = "MERCHANT_ID")
    private String merchantId;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Column(name = "PURPOSE_REF_NO")
    private String purposeRefNo;

    @Column(name = "FT_TXN_ID")
    private String ftTxnId;

    @Column(name = "PR_ID")
    private String prId;

    @Column(name = "REFUND_STATUS")
    private String refundStatus;

    @Column(name = "REFUND_TXN_ID", unique = true)
    private String refundTxnId;

    @Column(name = "REFUND_REQ_ID", unique = true)
    private String refundReqId;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATION_DATE", nullable = false, updatable = false)
    public Date creationDate;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED", nullable = false, updatable = true)
    public Date updationDate;

}
