package com.airtelbank.thirdpartypayments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("merchantId")
    public String merchantId;

    @JsonProperty("transactionDetails")
    public TransactionDetailsRequest transactionDetailsRequest;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("amountDetails")
    private Map<String, BigDecimal> amountDetails;


    private String hash;

}
