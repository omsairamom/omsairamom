package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.dto.response.common.Constants;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomActions;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.OrderKeyValueTemplate;
import com.airtelbank.thirdpartypayments.model.OrderKeyValueTemplateAction;
import com.airtelbank.thirdpartypayments.model.OrderResponse;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.order.DefaultOrderConfirmationResponce;
import com.airtelbank.thirdpartypayments.model.order.OrderRelationship;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.order.PaymentRelationship;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsTxnRepo;
import com.airtelbank.thirdpartypayments.service.OrderService;
import com.airtelbank.thirdpartypayments.service.TransactionRefundService;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationService;
import com.airtelbank.thirdpartypayments.service.order.OrderConfirmationServiceFactory;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author b0206596
 */
@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderConfirmationServiceFactory orderConfirmationServiceFactory;

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    @Autowired
    private TransactionRefundService refundService;

    @Autowired
    private OrderDetailsTxnRepo orderDetailsTxnRepo;

    @Autowired
    private MerchantTransactionDetailsRepo merchantRepo;


    @Override
    public boolean confirmOrder(OrderDetailsEntity orderDetailsEntity, MerchantTransactionDetailsEntity merchant)
            throws ThirdPartyPaymentsException {

        log.info("order value {},{}", orderDetailsEntity, merchant);
        OrderConfirmationService orderConfirmationService = orderConfirmationServiceFactory
                .getOrderConfirmationService("DEFAULT");

        DefaultOrderConfirmationResponce confirmationResponce = orderConfirmationService.doConfirm(orderDetailsEntity, merchant);

        if (confirmationResponce.getMeta().getStatus() == 0) {

            List<OrderDetailsTxn> orderDetailsTxnList = new ArrayList<>();
            String merchantTxnId = confirmationResponce.getData().getMerchantTxnId();


            orderDetailsTxnList = setOrderDetails(confirmationResponce, merchantTxnId, orderDetailsTxnList);

            orderDetailsEntity.setOrderDetailsTxn(orderDetailsTxnList);

            orderDetailsTxnList = setOrderActions(confirmationResponce, merchantTxnId, orderDetailsTxnList);

            orderDetailsEntity.setStatus(OrderStatus.COMPLETED);

            orderDetailsEntity.setOrderDetailsTxn(orderDetailsTxnList);

            MDC.put(AppConstants.ORDER_STATUS, OrderStatus.COMPLETED.toString());
            MDC.put(AppConstants.PAYMENT_STATUS, OrderStatus.COMPLETED.toString());

            try {
                orderDetailsRepo.save(updateOrder(orderDetailsEntity));
                log.info("Updating Data into Database {}", orderDetailsEntity);
            } catch (Exception e) {
                log.error("Exception while updating data in the databases {}", orderDetailsEntity);
                throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
            }

        } else {
            List<String> pendingStatuses = Arrays
                    .asList(StringUtils.tokenizeToStringArray(merchant.getPendingCodes(), ",", true, true));

            if (pendingStatuses.contains(confirmationResponce.getMeta().getCode())) {
                orderDetailsEntity.setStatus(OrderStatus.CONFIRMATION_PENDING);
                MDC.put(AppConstants.PAYMENT_STATUS, OrderStatus.CONFIRMATION_PENDING.toString());
                orderDetailsRepo.save(orderDetailsEntity);
            } else {
                initiateRefund(orderDetailsEntity);

                TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
                transactionRefundRequest.setAmount(orderDetailsEntity.getAmount());
                transactionRefundRequest.setFeSessionId(CommonUtil.getPurposeReference());
                transactionRefundRequest.setMerchantTxnId(orderDetailsEntity.getMerchantTxnId());
                try {
                    refundService.refundInit(transactionRefundRequest, Constants.AUTOREFUND);
                    MDC.put(AppConstants.REFUND_STATUS, Constants.AUTOREFUND);
                } catch (ThirdPartyPaymentsException e) {
                    log.info("Exception Occured While trying AutoRefund {}", e);
                    throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
                }

            }
        }
        return true;
    }

    private void initiateRefund(OrderDetailsEntity orderDetailsEntity) throws ThirdPartyPaymentsException {
        TransactionRefundRequest transactionRefundRequest = new TransactionRefundRequest();
        transactionRefundRequest.setAmount(orderDetailsEntity.getAmount());
        transactionRefundRequest.setFeSessionId(CommonUtil.getPurposeReference());
        transactionRefundRequest.setMerchantTxnId(orderDetailsEntity.getMerchantTxnId());
        try {
            refundService.refundInit(transactionRefundRequest, Constants.AUTOREFUND);
            MDC.put(AppConstants.REFUND_STATUS, Constants.AUTOREFUND);
        } catch (ThirdPartyPaymentsException e) {
            log.info("Exception %s", e);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e.getMessage());
        }
    }

    private List<OrderDetailsTxn> setOrderDetails(DefaultOrderConfirmationResponce confirmationResponce, String merchantTxnId,
                                                  List<OrderDetailsTxn> orderDetailsTxnList) {
        String ordertxnId = null;
        for (CustomEntry customEntry : confirmationResponce.getData().getDetails()) {
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            ordertxnId = merchantTxnId + '_' + customEntry.getKey();
            orderDetailsTxn.setKey(customEntry.getKey());
            orderDetailsTxn.setValue(customEntry.getValue());
            orderDetailsTxn.setDisplayText(customEntry.getDisplayText());
            orderDetailsTxn.setOrderDetailsTxnId(ordertxnId);
            orderDetailsTxn.setPaymentRelationship(PaymentRelationship.POSTPAYMENT.toString());
            orderDetailsTxn.setType(OrderRelationship.DETAILS.toString());
            orderDetailsTxnList.add(orderDetailsTxn);
        }
        return orderDetailsTxnList;
    }

    private List<OrderDetailsTxn> setOrderActions(DefaultOrderConfirmationResponce confirmationResponce, String merchantTxnId,
                                                  List<OrderDetailsTxn> orderDetailsTxnList) {
        String ordertxnId = null;
        for (CustomActions customActions : confirmationResponce.getData().getActions()) {
            OrderDetailsTxn orderDetailsTxn = new OrderDetailsTxn();
            ordertxnId = merchantTxnId + '_' + customActions.getKey();
            orderDetailsTxn.setKey(customActions.getKey());
            orderDetailsTxn.setValue(customActions.getValue());
            orderDetailsTxn.setDisplayText(customActions.getDisplayText());
            orderDetailsTxn.setOrderDetailsTxnId(ordertxnId);
            orderDetailsTxn.setPaymentRelationship(PaymentRelationship.POSTPAYMENT.toString());
            orderDetailsTxn.setType(OrderRelationship.ACTIONS.toString());
            orderDetailsTxnList.add(orderDetailsTxn);
        }
        return orderDetailsTxnList;
    }

    public OrderDetailsEntity updateOrder(OrderDetailsEntity orderDetailsEntity) {
        List<OrderDetailsTxn> orderDetailsTxnList = orderDetailsEntity.getOrderDetailsTxn();
        for (OrderDetailsTxn orderDetailsTxn : orderDetailsTxnList) {
            orderDetailsTxn.setOrderDetailsEntity(orderDetailsEntity);
        }
        return orderDetailsEntity;
    }

    @Override
    public OrderResponse getOrderDetail(String purposeRefNo) throws ThirdPartyPaymentsException {

        OrderResponse orderResponse = new OrderResponse();
        OrderDetailsEntity orderDetailsEntity = orderDetailsRepo.findByPurposeRefNo(purposeRefNo);
        MerchantTransactionDetailsEntity merchantEntity = merchantRepo.findByMerchantId(orderDetailsEntity.getMerchantId());

        MDC.put(AppConstants.MERCHANT_ID, orderDetailsEntity.getMerchantId());
        MDC.put(AppConstants.MERCHANT_TXN_ID, orderDetailsEntity.getMerchantTxnId());
        MDC.put(AppConstants.MERCHANT_NAME, merchantEntity.getName());
        MDC.put(AppConstants.PAYMENT_STATUS, orderDetailsEntity.getStatus().toString());
        MDC.put(AppConstants.ORDER_STATUS, orderDetailsEntity.getStatus().toString());

        List<OrderDetailsTxn> orderDetailsTxnList = orderDetailsTxnRepo.findbyMerchantTxnId(orderDetailsEntity.getMerchantTxnId());
        log.info("Details fetched from Database {}", orderDetailsTxnList.get(0));
        createContentAndActions(orderResponse, orderDetailsTxnList);
        orderResponse.setPurpose(null);
        orderResponse.setTxnStatus(orderDetailsEntity.getStatus().parseToFrontEndStatus());
        createAllTitles(orderResponse, orderDetailsEntity.getStatus(), merchantEntity);
        return orderResponse;
    }

    private void createAllTitles(OrderResponse orderResponse, OrderStatus status,
                                 MerchantTransactionDetailsEntity merchantEntity) {

        switch (status) {
            case COMPLETED:
                orderResponse.setTitle(merchantEntity.getSuccessTitle());
                orderResponse.setBenefit(merchantEntity.getSuccessBenefit());
                orderResponse.setDescription(merchantEntity.getSuccessDesc());
                break;
            case CONFIRMATION_FAILED:
                orderResponse.setTitle(merchantEntity.getFailureTitle());
                orderResponse.setBenefit(merchantEntity.getFailureBenefit());
                orderResponse.setDescription(merchantEntity.getFailureDesc());
                break;
            case CONFIRMATION_PENDING:
                orderResponse.setTitle(merchantEntity.getOrderPendingTitle());
                orderResponse.setBenefit(merchantEntity.getOrderPendingBenefit());
                orderResponse.setDescription(merchantEntity.getOrderPendingDesc());
                break;
            default:
                orderResponse.setTitle(merchantEntity.getOrderPendingTitle());
                orderResponse.setBenefit(merchantEntity.getOrderPendingBenefit());
                orderResponse.setDescription(merchantEntity.getOrderPendingDesc());
                break;
        }
    }

    private void createContentAndActions(OrderResponse orderResponse, List<OrderDetailsTxn> orderDetailsTxnList) {
        List<OrderKeyValueTemplate> contentList = new ArrayList<>();
        List<OrderKeyValueTemplateAction> actionList = new ArrayList<>();

        for (OrderDetailsTxn orderDetailsTxn : orderDetailsTxnList) {
            if (orderDetailsTxn.getType().equals(OrderRelationship.DETAILS.toString()) && orderDetailsTxn.getPaymentRelationship().equals(PaymentRelationship.POSTPAYMENT.toString())) {
                if (!orderDetailsTxn.getKey().equals("Amount")) {
                    OrderKeyValueTemplate contentEntry = new OrderKeyValueTemplate();
                    contentEntry.setField(orderDetailsTxn.getDisplayText());
                    contentEntry.setValue(orderDetailsTxn.getValue());
                    contentList.add(contentEntry);
                }
            } else if (orderDetailsTxn.getType().equals(OrderRelationship.ACTIONS.toString())) {
                OrderKeyValueTemplateAction actionEntry = new OrderKeyValueTemplateAction();
                actionEntry.setField(orderDetailsTxn.getKey());
                actionEntry.setValue(orderDetailsTxn.getValue());
                actionEntry.setDisplayText(orderDetailsTxn.getDisplayText());
                actionList.add(actionEntry);
            }
        }
        orderResponse.setAction(actionList);
        orderResponse.setContent(contentList);
    }

}
