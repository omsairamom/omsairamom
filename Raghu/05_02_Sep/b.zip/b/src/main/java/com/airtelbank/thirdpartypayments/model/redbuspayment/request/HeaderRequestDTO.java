package com.airtelbank.thirdpartypayments.model.redbuspayment.request;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class HeaderRequestDTO {
    @JsonProperty("contentId")
    private String contentId;
    @JsonProperty("feSessionId")
    private String feSessionId;
    @JsonProperty("content-type")
    private String contentType;
    @JsonProperty("Authorization")
    private String authorization;
    @NotBlank(message = AppConstants.CHANNEL_NOT_BLANK_MSG)
    @JsonProperty("channel")
    private String channel;

}