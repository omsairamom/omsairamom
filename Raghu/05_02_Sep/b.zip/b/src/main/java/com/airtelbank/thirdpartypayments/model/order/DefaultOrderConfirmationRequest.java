package com.airtelbank.thirdpartypayments.model.order;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor

public class DefaultOrderConfirmationRequest implements Serializable {

    private static final long serialVersionUID = 1L;
    public String merchantId;
    public String merchantTxnId;
    public BigDecimal amount;
    public String status;
    public String txnId;
    public Date txnDate;
    public String hash;

}
