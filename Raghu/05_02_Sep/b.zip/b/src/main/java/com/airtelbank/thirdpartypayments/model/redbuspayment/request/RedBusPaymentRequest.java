package com.airtelbank.thirdpartypayments.model.redbuspayment.request;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@ToString
public class RedBusPaymentRequest {

    @NotBlank(message = AppConstants.SECRET_KEY_NO_NOT_BLANK_MSG)
    private String secretKey;
    @NotBlank(message = AppConstants.PURPOSE_REF_NO_BLANK_EMPTY_MSG)
    private String purposeRefNo;
    @DecimalMin(value = "0.0", message = AppConstants.AMOUNT_SMALLER_MSG)
    private Double totalAmount;
    private String currency;
    @NotBlank(message = AppConstants.REDIRECTLINK_NOT_BLANK_MSG)
    private String redirectionURL;


    /*@NotBlank(message = AppConstants.SOURCE_NOT_BLANK_MSG)
    @JsonProperty("Source")
    private String Source;
    @NotBlank(message = AppConstants.DESTINATION_NOT_BLANK_MSG)
    @JsonProperty("Destination")
    private String Destination;
    @NotBlank(message = AppConstants.DOJ_NOT_BLANK_MSG)
    @JsonProperty("DOJ")
    private String DOJ;
    @NotBlank(message = AppConstants.TRAVELNAME_NOT_BLANK_MSG)
    @JsonProperty("Travels_Name")
    private String Travels_Name;
    @NotBlank(message = AppConstants.BUSTTYPE_NOT_BLANK_MSG)
    @JsonProperty("Bus_Type")
    private String Bus_Type;*/

}
