package com.airtelbank.thirdpartypayments.model.redbuspayment.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(includeFieldNames = true)
public class FulfilmentRequest {

    private Integer quantity;

    private Integer amount;

    private String customerMobileNumber;

    private String customerName;

    private String customerEmail;

    private String retailerMobileNumber;

    private String retailerName;

    private String retailerEmail;

    private String transactionId;

    private String prId;

}
