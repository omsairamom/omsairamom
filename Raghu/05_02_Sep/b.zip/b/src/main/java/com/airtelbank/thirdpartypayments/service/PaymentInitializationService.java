package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.InitiatePaymentResponse;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;

public interface PaymentInitializationService {
    InitiatePaymentResponse paymentInitialize(PaymentRequest paymentRequest, String customerId) throws ThirdPartyPaymentsException;

}
