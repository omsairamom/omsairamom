package com.airtelbank.thirdpartypayments.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@Table(name = "MER_OAUTH_DETAILS")
@Entity
public class MerchantOAuthDetailsEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "MERCHANT_ID")
    private String merchantId;

    @Column(name = "X_APP_TOKEN", unique = true)
    private String xAppToken;

    @Column(name = "CLIENT_SECRET", unique = true)
    private String clientSecret;

    @Column(name = "REDIRECT_URI")
    private String redirectURI;

    @Column(name = "SCOPE")
    @Enumerated(EnumType.STRING)
    private APBOAuthEnum.OAuthScope scope;

    @Column(name = "ACCESS_TOKEN_EXPIRY_VALUE")
    private int accessTokenExpiryValue;

    @Column(name = "ACCESS_TOKEN_EXPIRY_UNIT")
    @Enumerated(EnumType.STRING)
    private APBOAuthEnum.ExpiryUnit accessTokenExpiryUnit;

    @Column(name = "AUTH_CODE_EXPIRY_IN_SEC")
    private int authCodeExpiryInSec;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATIOn_DATE", nullable = false, updatable = false)
    private Date creationDate;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATION_DATE", nullable = false, updatable = true)
    private Date updationDate;

}