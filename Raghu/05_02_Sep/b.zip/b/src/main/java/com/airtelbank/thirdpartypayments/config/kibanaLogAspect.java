package com.airtelbank.thirdpartypayments.config;

//AOP
//Configuration
//@Aspect
//@Configuration
public class kibanaLogAspect {

//	@Autowired
//	LoggerModel loggerModel;
//
//	private Logger logger = LoggerFactory.getLogger(this.getClass());
//
//	@AfterReturning(value = "execution(* com.airtel.thirdPartyPayments.controllers.*.*(..))", returning = "result")
//	public void afterReturning(JoinPoint joinPoint, ResponseEntity<RestApiResponse> result) {
//		logger.info("{} doing kibana logging {}", joinPoint, result);
//		MDC.put(AppConstants.STATUS, result.getBody().getMeta().getStatus());
//		loggerModel.getErrors().add(CommonUtil.setLoggerError(result.getBody().getMeta()));
//	}
//
//	@AfterReturning(value = "execution(* com.airtel.thirdPartyPayments.exception.CommonControllerAdvice.*(..))", returning = "result")
//	public void afterReturningException(JoinPoint joinPoint, ResponseEntity<RestApiResponse> result) {
//		logger.info("{} doing kibana logging {}", joinPoint, result);
//		MDC.put(AppConstants.STATUS, result.getBody().getMeta().getStatus());
//		loggerModel.getErrors().add(CommonUtil.setLoggerError(result.getBody().getMeta()));
//	}

}