package com.airtelbank.thirdpartypayments.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class PaymentResponsetoClient implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String paymentStatus;
    private String refId;

}
