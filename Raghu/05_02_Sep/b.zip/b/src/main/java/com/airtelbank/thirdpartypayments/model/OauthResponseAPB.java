package com.airtelbank.thirdpartypayments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
public class OauthResponseAPB implements Serializable {
    private static final long serialVersionUID = 1L;
    @JsonProperty("accessToken")
    private String accessToken;
    @JsonProperty("msisdn")
    private String msisdn;
    @JsonProperty("expiryDate")
    private long expiryDate;
    @JsonProperty("merchantId")
    private String merchantId;
    @JsonProperty("expiryStatus")
    private String expiryStatus;
    @JsonProperty("scope")
    private String scope;
    @JsonProperty("creationDate")
    private long creationDate;
    @JsonProperty("updationDate")
    private long updationDate;
    @JsonProperty("xappToken")
    private String xappToken;
}
