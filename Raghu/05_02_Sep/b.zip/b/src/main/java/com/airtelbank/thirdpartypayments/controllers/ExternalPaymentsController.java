package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryRequest;
import com.airtelbank.thirdpartypayments.model.TransactionEnquiryResponse;
import com.airtelbank.thirdpartypayments.model.TransactionRefundRequest;
import com.airtelbank.thirdpartypayments.model.TransactionRefundResponse;
import com.airtelbank.thirdpartypayments.service.TransactionEnquiryService;
import com.airtelbank.thirdpartypayments.service.TransactionRefundService;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author b0206596
 */

@Slf4j
@RestController
@RequestMapping(value = "thirdPartyPayments/api/v1/payment")
public class ExternalPaymentsController {

    @Autowired
    TransactionEnquiryService transactionEnquiryService;

    @Autowired
    TransactionRefundService transactionRefundService;

    @Autowired
    LoggerModel loggerModel;

    /**
     * @param request-Body of Transaction Inquiry Request
     * @param appToken-    AppToken issued to particular merchant(Third Party)
     * @param result
     * @return processes the information and returns the data accordingly
     * @throws Exception
     */
    @CrossOrigin
    @PostMapping(path = "/transactionEnquiry", consumes = "application/json", produces = "application/json")
    public ResponseEntity<RestApiResponse> transactionEnquiry(@RequestBody TransactionEnquiryRequest request,
                                                              @RequestHeader("X-APP-TOKEN") String appToken, BindingResult result) throws ThirdPartyPaymentsException {

        ResponseEntity<RestApiResponse> response = null;
        MDC.put(AppConstants.MERCHANT_TXN_ID, request.getMerchantTxnId());
        MDC.put(AppConstants.AMOUNT, request.getAmount());
        TransactionEnquiryResponse transactionEnquiryResponseToMerchant = null;
        log.info("Transaction Enquiry Request {},appToken {}", request, appToken);

        if (result.hasErrors()) {
            log.info("Invalid Request ");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_REQUEST);

        } else {
            transactionEnquiryResponseToMerchant = transactionEnquiryService.enquiryInit(request, appToken);
        }
        response = ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse("SUCCESS",
                transactionEnquiryResponseToMerchant);

        return response;
    }

    @CrossOrigin
    @PostMapping(path = "/transactionRefund", consumes = "application/json", produces = "application/json")
    public ResponseEntity<RestApiResponse> transactionRefund(
            @Valid @RequestBody TransactionRefundRequest transactionRefundRequest,
            @RequestHeader("X-APP-TOKEN") String appToken, BindingResult result) throws ThirdPartyPaymentsException {

        ResponseEntity<RestApiResponse> response = null;
        MDC.put(AppConstants.MERCHANT_TXN_ID, transactionRefundRequest.getMerchantTxnId());
        MDC.put(AppConstants.AMOUNT, transactionRefundRequest.getAmount());

        log.info("Transaction Refund Request {},appToken{}", transactionRefundRequest, appToken);
        TransactionRefundResponse transactionRefundResponse = null;

        if (result.hasErrors()) {
            log.info("Invalid Request");
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_REQUEST);
        } else {
            transactionRefundResponse = transactionRefundService.refundInit(transactionRefundRequest, appToken);
        }
        response = ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse("REFUND SUCCESSFUL",
                transactionRefundResponse);

        return response;
    }

}
