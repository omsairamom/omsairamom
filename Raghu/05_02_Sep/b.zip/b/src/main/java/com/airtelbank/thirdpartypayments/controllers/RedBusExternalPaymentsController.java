package com.airtelbank.thirdpartypayments.controllers;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.dto.response.common.ResponseEntityBuilder;
import com.airtelbank.thirdpartypayments.dto.response.common.RestApiResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.CustomerDetailsPaymentRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.HeaderRequestDTO;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusBookingResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusFulFilmentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentEnquiry;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusPaymentStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentService;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Locale;
import java.util.Map;

/**
 * Payment and booking details related end points
 *
 * @author Ranjeet Singh 14-June-2021
 */

@Slf4j
@RestController
@RequestMapping(value = "api/v1/redbus")
@Validated
public class RedBusExternalPaymentsController {

    @Autowired
    private RedBusPaymentService redBusPaymentService;

    @Autowired
    private MessageSource messageSource;

    /**
     * Initiate payment request
     *
     * @param redBusPaymentRequest
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     * @throws Exception
     */

    @PostMapping(path = "/payment/initiate", consumes = "application/json", produces = "application/json")
    public ResponseEntity<RestApiResponse> postPaymentDetails(
            @RequestBody @Valid CustomerDetailsPaymentRequest redBusPaymentRequest, @RequestHeader Map<String, String> headers) {
        log.info("Entering into postPaymentDetails() method  for request :: {} and headers :: {}", redBusPaymentRequest, headers);

        MDC.put(AppConstants.CUSTOMER_ID, redBusPaymentRequest.getMobileNo());
        MDC.put(AppConstants.CUSTOMER_NAME, redBusPaymentRequest.getCustomerName());
        MDC.put(AppConstants.PURPOSE_REF_NO, redBusPaymentRequest.getPurposeRefNo());

        HeaderRequestDTO headerRequestDTO = CommonUtil.convertMaptoObject(headers);
        log.info("Header values received from postPaymentDetails() method  :: {}", headerRequestDTO);
        RedBusPaymentResponse paymentDetailsResponse = redBusPaymentService.postDataToPaymentHub(redBusPaymentRequest,
                headerRequestDTO);
        log.info("Response return redBusPaymentService.postPaymentDetails() method :: {}", paymentDetailsResponse);
        if (paymentDetailsResponse != null) {
            return ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse(AppConstants.STATUS_SUCCESS_CODE, AppConstants.PAYMENT_INITIATE_SUCCESSFULLY,
                    paymentDetailsResponse);
        } else {
            return ResponseEntityBuilder.getBuilder(HttpStatus.INTERNAL_SERVER_ERROR).errorResponse(getMessage(AppConstants.Key.PAYMENT_ERROR_CODE), getMessage(AppConstants.Key.PAYMENT_ERROR_DESC));
        }
    }

    /**
     * Fetch payment status
     *
     * @param purposeRefNo
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     */
    @GetMapping(path = "/paymentStatus/enquiry/{purposeRefNo}")
    public ResponseEntity<RestApiResponse> getPaymentStatusEnquiry(@Valid @PathVariable(value = "purposeRefNo") String purposeRefNo, @RequestHeader Map<String, String> headers) {

        log.info("Entering into getPaymentStatus() method for purposeRefNo :: {}", purposeRefNo);

        MDC.put(AppConstants.PURPOSE_REF_NO, purposeRefNo);

        HeaderRequestDTO headerRequestDTO = CommonUtil.convertMaptoObject(headers);
        log.info("Header values received from getPaymentStatusEnquiry() method  :: {}", headerRequestDTO);
        RedBusPaymentStatusResponse paymentStatusResponse = redBusPaymentService.getPaymentStatusEnquiry(purposeRefNo);
        log.info("Response :: {} return redBusPaymentService.getPaymentStatusEnquiry() method for purposeRefNo :: {}", paymentStatusResponse, purposeRefNo);
        if (paymentStatusResponse != null) {
            return ResponseEntityBuilder.getBuilder(HttpStatus.OK).successResponse(AppConstants.STATUS_SUCCESS_CODE, AppConstants.PAYMENT_STATUS_ENQUIRY,
                    paymentStatusResponse);
        } else {
            return ResponseEntityBuilder.getBuilder(HttpStatus.INTERNAL_SERVER_ERROR).errorResponse(getMessage(AppConstants.Key.PAYMENT_ERROR_CODE),
                    getMessage(AppConstants.Key.PAYMENT_ERROR_DESC));
        }
    }

    /**
     * Save seat booking details
     *
     * @param redBusPaymentRequest
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     * @throws Exception
     */
    @PostMapping(path = "/initiate/booking", produces = "application/json")
    public ResponseEntity<RestApiResponse> saveRedBusBookingDetails(@Valid @RequestBody(required = true) PaymentData redBusPaymentRequest, @RequestHeader Map<String, String> headers) {

        log.info("Entering into saveRedBusBookingDetails() method with Encrypted Payload :: {}", redBusPaymentRequest);

        HeaderRequestDTO headerRequestDTO = CommonUtil.convertMaptoObject(headers);
        log.info("Header values received  from saveRedBusBookingDetails() method:: {}", headerRequestDTO);
        RedBusBookingResponse paymentDetailsResponse = redBusPaymentService
                .saveRedBusBookingDetails(redBusPaymentRequest, headerRequestDTO);
        log.info("Response return redBusPaymentService.saveRedBusBookingDetails :: {}", paymentDetailsResponse);
        if (paymentDetailsResponse != null) {
            return ResponseEntityBuilder.getBuilder(HttpStatus.CREATED).successResponse(AppConstants.STATUS_SUCCESS_CODE, AppConstants.BOOKING_DETAILS_SAVE_SUCCESSFULLY,
                    paymentDetailsResponse);
        } else {
            return ResponseEntityBuilder.getBuilder(HttpStatus.BAD_REQUEST).errorResponse(getMessage(AppConstants.Key.PAYMENT_ERROR_CODE), getMessage(AppConstants.Key.PAYMENT_ERROR_DESC));
        }
    }

    /**
     * fetch payment status
     * this Api will use payment hub
     *
     * @param prId
     * @param headers
     * @return ResponseEntity<RestApiResponse>
     */
    @GetMapping(path = "/fulfilment/enquiry/{prId}")
    public ResponseEntity<RestApiResponse> getFulfilmentStatusEnquiry(@Valid @PathVariable(value = "prId") String prId, @RequestHeader Map<String, String> headers) {

        log.info("Entering into getFulfilmentStatus() method :: {}", prId);

        HeaderRequestDTO headerRequestDTO = CommonUtil.convertMaptoObject(headers);
        log.info("Header values received  from getFulfilmentStatus() method:: {}", headerRequestDTO);
        MDC.put(AppConstants.PR_ID, prId);
        RedBusPaymentEnquiry redBusPaymentEnquiry = redBusPaymentService.getFulfilmentStatusEnquiryFromPrId(prId, headerRequestDTO);
        log.info("Response return getFulfilmentStatus() method :: {}", redBusPaymentEnquiry);
        RedBusFulFilmentResponse fulfilmentStatusResponse = redBusPaymentEnquiry.getRedBusFulFilmentResponse();
        log.info("Respone return from redBusPaymentService.getFulfilmentStatusEnquiryFromPrId() :: {}", redBusPaymentEnquiry);
        if (fulfilmentStatusResponse != null) {
            return ResponseEntityBuilder.getBuilder(HttpStatus.OK)
                    .successResponse(AppConstants.STATUS_SUCCESS_CODE, AppConstants.FULLFILLMENT_STATUS_SUCCESSFULLY, fulfilmentStatusResponse
                            , redBusPaymentEnquiry.getMap());
        } else {
            return ResponseEntityBuilder.getBuilder(HttpStatus.INTERNAL_SERVER_ERROR).errorResponse(getMessage(AppConstants.Key.PAYMENT_ERROR_CODE), getMessage(AppConstants.Key.PAYMENT_ERROR_DESC));
        }
    }


    private String getMessage(String key) {
        return messageSource.getMessage(key, null, Locale.getDefault());
    }


}
