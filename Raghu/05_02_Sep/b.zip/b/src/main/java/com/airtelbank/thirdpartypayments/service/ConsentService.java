package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.model.consent.Consent;
import com.airtelbank.thirdpartypayments.model.consent.ConsentDetailsResponse;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;

/**
 * this interface create two methods
 * createCustomerConsent()- when customer allow consent then save the customer consent.
 * getCustomerConsent()- fetch the customer detail on the basis of the appId.
 */
public interface ConsentService {

    ConsentDetailsResponse createCustomerConsent(CustomerConsentRequest request, String channel, String contentId, String userAgent) throws ConsentException;

    Consent getCustomerConsent(String appId, String contentId, String channel, String userAgent) throws ConsentException;
}
