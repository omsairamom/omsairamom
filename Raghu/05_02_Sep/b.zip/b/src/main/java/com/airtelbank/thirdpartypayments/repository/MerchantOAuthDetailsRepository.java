package com.airtelbank.thirdpartypayments.repository;

import com.airtelbank.thirdpartypayments.entity.MerchantOAuthDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

public interface MerchantOAuthDetailsRepository extends JpaRepository<MerchantOAuthDetailsEntity, String> {

    @Transactional
    @Query(value = "select * from MER_OAUTH_DETAILS md WHERE md.X_APP_TOKEN = ?1 AND ROWNUM=1 ", nativeQuery = true)
    MerchantOAuthDetailsEntity getMerchant(String xAppToken);

    MerchantOAuthDetailsEntity findByMerchantId(String merchantId);
}
