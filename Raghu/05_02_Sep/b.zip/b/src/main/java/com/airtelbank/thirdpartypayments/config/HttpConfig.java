package com.airtelbank.thirdpartypayments.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.util.Arrays;

/**
 * @author SAPAN NAGPAL
 */

@Configuration
public class HttpConfig {

    @Value("${checktxn.connect.timeout.millis:30000}")
    private int checkTxnTimeout;

    @Value("${checktxn.read.timeout.millis:5000}")
    private int readTimeout;

    @Value("${config.http.proxy.ip:airtelproxy.airtel.com}")
    private String proxyIP;

    @Value("${config.http.proxy.isEnabled:true}")
    private boolean isProxy;

    @Value("${config.http.proxy.port:4145}")
    private int proxyPort;

    @Value("${config.http.proxy.username}")
    private String proxyUsername;

    @Value("${config.http.proxy.password}")
    private String proxyPassword;

    @Autowired
    private LoggingClientHttpRequestInterceptor loggingClientHttpRequestInterceptor;

    @Autowired
    private CorrelationIdInterceptor correlationIdInterceptor;

    public ObjectMapper jacksonObjectMapper() {
        return new ObjectMapper().setPropertyNamingStrategy(propertyNamingStrategy());
    }

    @Bean
    public PropertyNamingStrategy propertyNamingStrategy() {
        return new MyNameStrategy();
    }

    @Bean(name = "proxyRestTemplate")
    RestTemplate restTemplateProxy() {
        RestTemplate restTemplate = new RestTemplateBuilder()
                .additionalInterceptors(Arrays.asList(correlationIdInterceptor, loggingClientHttpRequestInterceptor))
                .setConnectTimeout(Duration.ofMillis(checkTxnTimeout)).setReadTimeout(Duration.ofMillis(readTimeout))
                .build();

//		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
//				HttpClients.createDefault());
        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
                HttpClients.custom()
                        .setDefaultRequestConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build())
                        .build());
        httpComponentsClientHttpRequestFactory.setConnectTimeout(checkTxnTimeout);
        httpComponentsClientHttpRequestFactory.setConnectionRequestTimeout(checkTxnTimeout);
        httpComponentsClientHttpRequestFactory.setReadTimeout(readTimeout);

        if (isProxy) {

            HttpHost myProxy = new HttpHost(proxyIP, proxyPort);
            // HttpClientBuilder clientBuilder = HttpClientBuilder.create();
            HttpClientBuilder clientBuilder = HttpClients.custom()
                    .setDefaultRequestConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build());
            clientBuilder.setProxy(myProxy);
            if (StringUtils.isNotBlank(proxyUsername)) {
                CredentialsProvider credsProvider = new BasicCredentialsProvider();
                credsProvider.setCredentials(new AuthScope(proxyIP, proxyPort),
                        new UsernamePasswordCredentials(proxyUsername, proxyPassword));
                // clientBuilder.setDefaultCredentialsProvider(credsProvider).disableCookieManagement();
                clientBuilder.setDefaultCredentialsProvider(credsProvider);
            }

            HttpClient httpClient = clientBuilder.build();

            httpComponentsClientHttpRequestFactory.setHttpClient(httpClient);
        }

        restTemplate.setRequestFactory(httpComponentsClientHttpRequestFactory);

        return restTemplate;
    }

    @Bean
    @Primary
    RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplateBuilder()
                .additionalInterceptors(Arrays.asList(correlationIdInterceptor, loggingClientHttpRequestInterceptor))
                .setConnectTimeout(Duration.ofMillis(checkTxnTimeout)).setReadTimeout(Duration.ofMillis(readTimeout))
                .build();

        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
                HttpClients.createDefault());
        httpComponentsClientHttpRequestFactory.setConnectTimeout(checkTxnTimeout);
        httpComponentsClientHttpRequestFactory.setConnectionRequestTimeout(checkTxnTimeout);
        restTemplate.setRequestFactory(httpComponentsClientHttpRequestFactory);

        return restTemplate;
    }

}
