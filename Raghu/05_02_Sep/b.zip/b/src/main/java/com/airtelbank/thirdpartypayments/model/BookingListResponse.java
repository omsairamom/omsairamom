package com.airtelbank.thirdpartypayments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class BookingListResponse implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @JsonProperty("merchantTxnId")
    private String merchantTxnId;
    private Double amount;
    @JsonProperty("merchantId")
    private String merchantId;
    @JsonProperty("purposeRefNo")
    private String purposeRefNo;
    @JsonProperty("purposeCode")
    private String purposeCode;

}
