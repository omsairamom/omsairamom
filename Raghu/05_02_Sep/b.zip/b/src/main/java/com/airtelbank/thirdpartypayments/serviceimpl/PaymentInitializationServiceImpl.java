package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderAmountDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsTxn;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.CustomEntry;
import com.airtelbank.thirdpartypayments.model.InitiatePaymentResponse;
import com.airtelbank.thirdpartypayments.model.PaymentRequest;
import com.airtelbank.thirdpartypayments.model.order.OrderDetails;
import com.airtelbank.thirdpartypayments.model.order.OrderRelationship;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.order.PaymentRelationship;
import com.airtelbank.thirdpartypayments.repository.OrderAmountDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.service.PaymentInitializationService;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author b0206596
 */

@Slf4j
@Service
public class PaymentInitializationServiceImpl implements PaymentInitializationService {

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    @Autowired
    private OrderAmountDetailsRepo orderAmountDetailsRepo;

    @Autowired
    private ValidationService validationService;

    @Value("${config.url.oyo.orderConfirmation.appUrl}")
    private String orderConfirmationURLForApp;

    @Override
    public InitiatePaymentResponse paymentInitialize(PaymentRequest paymentRequest, String customerId)
            throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity merchantTransactionDetailsEntity = validationService
                .validateMerchant(paymentRequest, customerId);
        MDC.put(AppConstants.MERCHANT_NAME, merchantTransactionDetailsEntity.getName());
        InitiatePaymentResponse initiatePaymentReaponse = paymentInitailization(paymentRequest, customerId,
                merchantTransactionDetailsEntity);
        log.info("Initiate Payment Response:{}", initiatePaymentReaponse);
        return initiatePaymentReaponse;

    }

    private InitiatePaymentResponse paymentInitailization(PaymentRequest paymentRequest, String customerId,
                                                          MerchantTransactionDetailsEntity merchantTransactionDetailsEntity) throws ThirdPartyPaymentsException {
        OrderDetailsEntity orderDetailsEntity = new OrderDetailsEntity();
        OrderAmountDetailsEntity orderAmountDetailsEntity = new OrderAmountDetailsEntity();
        OrderDetailsTxn orderDetailsTxn = null;

        String purposeRefNo = CommonUtil.getPurposeReference();
        orderDetailsEntity.setMerchantTxnId(paymentRequest.transactionDetailsRequest.getMerchantTxnId());
        orderDetailsEntity.setMerchantId(paymentRequest.getMerchantId());
        orderDetailsEntity.setCustomerId(customerId);
        orderDetailsEntity.setAmount(paymentRequest.getAmount());
        orderDetailsEntity.setPurposeRefNo(purposeRefNo);
        orderDetailsEntity.setStatus(OrderStatus.INITIATED);
        MDC.put(AppConstants.ORDER_STATUS, OrderStatus.INITIATED.toString());
        List<CustomEntry> customEntryList = paymentRequest.getTransactionDetailsRequest().getDetails();
        List<OrderDetailsTxn> orderDetailsTxnList = new ArrayList<>();
        String merchantTxnId = paymentRequest.getTransactionDetailsRequest().getMerchantTxnId();
        String ordertxnId = null;
        for (CustomEntry customEntry : customEntryList) {
            orderDetailsTxn = new OrderDetailsTxn();
            ordertxnId = merchantTxnId + '_' + customEntry.getKey();
            orderDetailsTxn.setKey(customEntry.getKey());
            orderDetailsTxn.setValue(customEntry.getValue());
            orderDetailsTxn.setDisplayText(customEntry.getDisplayText());
            orderDetailsTxn.setOrderDetailsTxnId(ordertxnId);
            orderDetailsTxn.setPaymentRelationship(PaymentRelationship.PREPAYMENT.toString());
            orderDetailsTxn.setType(OrderRelationship.DETAILS.toString());
            orderDetailsTxnList.add(orderDetailsTxn);
        }

        orderDetailsEntity.setOrderDetailsTxn(orderDetailsTxnList);

        try {
            log.info("Saving to Database {}", orderDetailsEntity);
            orderDetailsRepo.save(updateOrder(orderDetailsEntity));
        } catch (Exception e) {
            log.info("Exception while Saving to Database {}", orderDetailsEntity);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
        }

        for (Map.Entry<String, BigDecimal> entry : paymentRequest.getAmountDetails().entrySet()) {
            merchantTxnId = paymentRequest.transactionDetailsRequest.getMerchantTxnId();
            orderAmountDetailsEntity.setMerchantTxnId(merchantTxnId);
            orderAmountDetailsEntity.setAmountKey(entry.getKey());
            orderAmountDetailsEntity.setAmountValue(entry.getValue());
            String orderAmountId = merchantTxnId + '_' + entry.getKey();
            orderAmountDetailsEntity.setOrderAmountId(orderAmountId);
            try {
                log.info("Saving to Database {}", orderAmountDetailsEntity);
                orderAmountDetailsRepo.save(orderAmountDetailsEntity);
            } catch (Exception e) {
                log.info("Exception while Saving to Database {}", orderAmountDetailsEntity);
                throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
            }
        }

        OrderDetails orderDetails = OrderDetails.builder()
                .merchantTxnId(paymentRequest.getTransactionDetailsRequest().getMerchantTxnId())
                .details(paymentRequest.getTransactionDetailsRequest().getDetails()).build();

        InitiatePaymentResponse initiatePaymentReaponse = InitiatePaymentResponse.builder()
                .purposeCode(merchantTransactionDetailsEntity.getPurposeCode()).purposeRefNo(purposeRefNo)
                .lobID(merchantTransactionDetailsEntity.getLobID())
                .circleID(merchantTransactionDetailsEntity.getCircleID()).enquiryURL(orderConfirmationURLForApp)
                .remarks(merchantTransactionDetailsEntity.getRemarks())
                .transType(merchantTransactionDetailsEntity.getTransType()).totalAmount(paymentRequest.getAmount())
                .purposeIconUrl(merchantTransactionDetailsEntity.getPusposeIconURL()).orderDetails(orderDetails)
                .build();

        MDC.put(AppConstants.PAYMENT_STATUS, OrderStatus.INITIATED.toString());
        return initiatePaymentReaponse;
    }

    public OrderDetailsEntity updateOrder(OrderDetailsEntity orderDetailsEntity) {
        List<OrderDetailsTxn> orderDetailsTxnList = orderDetailsEntity.getOrderDetailsTxn();
        for (OrderDetailsTxn orderDetailsTxn : orderDetailsTxnList) {
            orderDetailsTxn.setOrderDetailsEntity(orderDetailsEntity);
        }
        return orderDetailsEntity;
    }

}
