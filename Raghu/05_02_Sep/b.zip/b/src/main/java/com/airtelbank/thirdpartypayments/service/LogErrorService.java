package com.airtelbank.thirdpartypayments.service;

import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;

public interface LogErrorService {

    void logOrderError(OrderDetailsEntity order, String code, String message, OrderStatus status);

}
