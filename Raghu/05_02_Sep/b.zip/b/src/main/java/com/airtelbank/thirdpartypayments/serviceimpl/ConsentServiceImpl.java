package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.dto.response.common.Constants;
import com.airtelbank.thirdpartypayments.entity.CustomerConsentDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.aeroskipe.ConsentConfigDetails;
import com.airtelbank.thirdpartypayments.exception.ConsentException;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.model.consent.ConsentDetailsResponse;
import com.airtelbank.thirdpartypayments.model.consent.request.Consent;
import com.airtelbank.thirdpartypayments.model.consent.request.CreateConsentRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.CustomerConsentRequest;
import com.airtelbank.thirdpartypayments.model.consent.request.Data;
import com.airtelbank.thirdpartypayments.repository.CustomerConsentDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.aerospike.ConsentConfigDetailRepo;
import com.airtelbank.thirdpartypayments.service.ConsentService;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.CipherUtil;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * This class contains the business logic of the create customer consent
 * and get customer consent details.
 */
@Slf4j
@Service
public class ConsentServiceImpl implements ConsentService {

    @Autowired
    private HttpUtil httpUtil;

    @Autowired
    private CipherUtil cipherUtil;

    @Autowired
    private ValidationService validationService;

    @Autowired
    MessageSource messageSource;

    @Autowired
    ConsentConfigDetailRepo consentAppIdRepo;

    @Autowired
    private CustomerConsentDetailsRepo customerConsentDetailsRepo;

    @Value("${config.redbus.pwa.link}")
    private String pwaLink;

    @Value("${config.redbus.request.encKey}")
    private String encryptionKey;

    @Value("${config.url.get.consent.url}")
    private String getConsentUrl;

    @Value("${config.url.save.consent.url}")
    private String saveConsentUrl;


    /**
     * the createCustomerConsent method, we are consume the consent MS API for create customer consent.
     *
     * @return ConsentDetailsResponse
     */
    @Override
    public ConsentDetailsResponse createCustomerConsent(CustomerConsentRequest request, String channel, String contentId, String userAgent) throws ConsentException {

        log.info("Entering into createCustomerConsent() method :: {}", request);
        String pwaLinkWithMobile;
        String encryptedMobileNo;
        String appId;
        com.airtelbank.thirdpartypayments.model.consent.Data data = null;
        appId = saveAppIdToAerospike(request.getMobileNumber());
        CustomerConsentDetailsEntity findCustomerConsentDetails = customerConsentDetailsRepo.findByAppId(appId);
        log.info("Response :: {} from customerConsentDetailsRepo.findByAppId() for App Id :: {}", findCustomerConsentDetails, appId);
        CustomerConsentDetailsEntity customerConsentDetailsEntity = null;
        if (findCustomerConsentDetails == null) {
            customerConsentDetailsEntity = getCustomerConsentDetailsEntity(request, appId);
            customerConsentDetailsRepo.save(customerConsentDetailsEntity);
        } else {
            if (Boolean.TRUE.equals(request.getConsent())) {
                findCustomerConsentDetails.setConsentAllow("Y");
                customerConsentDetailsRepo.save(findCustomerConsentDetails);
            }
        }
        ConsentDetailsResponse consentDetailsResponse = new ConsentDetailsResponse();
        if (Boolean.TRUE.equals(request.getConsent())) {
            Map<String, String> headers = createConsentHeaders(channel, contentId, MediaType.APPLICATION_JSON_VALUE, userAgent);
            CreateConsentRequest createConsentRequest = createConsentRequest(request, appId);
            log.info(" Calling Save consent Microservice with Param :: {} and Headers :: {}", createConsentRequest, headers);
            consentDetailsResponse = httpUtil.hitRequest(saveConsentUrl, createConsentRequest, ConsentDetailsResponse.class, headers, HttpMethod.POST);
            log.info("Response from Save consent Microservice :: {} ", consentDetailsResponse);
            validateCustomerDetailsConsentResponse(consentDetailsResponse);
            if (consentDetailsResponse.getMeta().getStatus().equals(AppConstants.Status.STATUS_SUCCESS)) {
                try {
                    encryptedMobileNo = cipherUtil.encryptData(request.getMobileNumber());
                    log.info("encrypted MobileNo details in createCustomerConsent() method :: {}", encryptedMobileNo);
                } catch (Exception e) {
                    log.error("Exception :: {} in Mobile Number encryption ", e.getMessage());
                    throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_CODE, null, Locale.getDefault()));
                }
                pwaLinkWithMobile = pwaLink + Constants.MOBILE_NO + encryptedMobileNo;
                data = new com.airtelbank.thirdpartypayments.model.consent.Data();
                data.setPwaLink(pwaLinkWithMobile);
                data.setDescription(consentDetailsResponse.getMeta().getDescription());
                consentDetailsResponse.setData(data);
            }
        } else {
            data = new com.airtelbank.thirdpartypayments.model.consent.Data();
            data.setPwaLink(pwaLink);
            data.setDescription(AppConstants.CONSENT.CONSENT_SAVE_MSG);
            consentDetailsResponse.setData(data);
        }
        log.info("Response return createCustomerConsent() method :: {}", consentDetailsResponse);
        return consentDetailsResponse;
    }

    /**
     * the getCustomerConsent method, we are consume the consent MS API for get customer consent details.
     *
     * @param mobileNo
     * @param contentId
     * @param channel
     * @return ConsentDetailsResponse
     */
    @Override
    public com.airtelbank.thirdpartypayments.model.consent.Consent getCustomerConsent(String mobileNo, String contentId, String channel, String userAgent)
            throws ConsentException {
        log.info("Entering into getCustomerConsent() method :: {},{},{}", mobileNo, contentId, channel);
        String pwaLinkWithMobile;
        String appId;
        com.airtelbank.thirdpartypayments.model.consent.Consent consent = null;
        String encryptedMobileNo;
        appId = getAppIdFromAerospike(mobileNo);
        String url = getURLFromUri(getConsentUrl, appId);
        Map<String, String> headers = createHeaders(contentId, channel);
        log.info(" Calling Get consent Microservice with App Id :: {} and Headers :: {} and URL :: {}", appId, headers, url);
        ConsentDetailsResponse consentDetailsResponse = httpUtil.hitRequest(url, null, ConsentDetailsResponse.class, headers, HttpMethod.GET);
        log.info("Response return from Get Consent Microservice  :: {}", consentDetailsResponse);
        validateCustomerDetailsConsentResponse(consentDetailsResponse);
        if (AppConstants.Status.STATUS_SUCCESS == consentDetailsResponse.getMeta().getStatus()) {
            consent = getConsentFromList(consentDetailsResponse.getData().getConsents());
            try {
                encryptedMobileNo = cipherUtil.encryptData(consent.getMobileNumber());
                log.info("EncryptMobileNo in  getCustomerConsent  :: {}", encryptedMobileNo);
            } catch (Exception e) {
                log.error("Exception :: {} in Mobile Number encryption ", e.getMessage());
                throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_CODE, null, Locale.getDefault()));
            }
            pwaLinkWithMobile = pwaLink + Constants.MOBILE_NO + encryptedMobileNo;
            log.info("pwaLinkWithMobile from getCustomerConsent  :: {}", pwaLinkWithMobile);
            consent.setPwaLink(pwaLinkWithMobile);

        }
        log.info("Response return getCustomerConsent() method :: {}", consentDetailsResponse);
        return consent;

    }

    /**
     * prepare the customer consent data for save in the DB tbl
     *
     * @return CustomerConsentDetailsEntity
     */
    CustomerConsentDetailsEntity getCustomerConsentDetailsEntity(CustomerConsentRequest request, String appId) {

        log.info("Entering into getCustomerConsentDetailsEntity() method :: {}", request);

        CustomerConsentDetailsEntity customerConsentDetailsEntity = new CustomerConsentDetailsEntity();
        customerConsentDetailsEntity.setAppId(appId);
        customerConsentDetailsEntity.setAppType(request.getConsentType());
        if (Boolean.TRUE.equals(request.getConsent())) {
            customerConsentDetailsEntity.setConsentAllow("Y");
        } else {
            customerConsentDetailsEntity.setConsentAllow("N");
        }
        customerConsentDetailsEntity.setCustomerMobileNumber(request.getMobileNumber());
        customerConsentDetailsEntity.setConsentMode(request.getConsentMode());
        customerConsentDetailsEntity.setConsentPurpose(request.getConsentPurpose());
        customerConsentDetailsEntity.setConsentDescription(request.getConsentDescription());
        customerConsentDetailsEntity.setExpiryDate(null);
        log.info("Response return getCustomerConsentDetailsEntity() method :: {}", customerConsentDetailsEntity);

        return customerConsentDetailsEntity;

    }

    /**
     * check the customer consent response
     */
    public void validateCustomerDetailsConsentResponse(ConsentDetailsResponse consentDetailsResponse) throws ConsentException {

        log.info("Entering validateCustomerDetailsConsentResponse() method :: {}", consentDetailsResponse);

        if (consentDetailsResponse == null) {
            log.error("Exception in validateCustomerDetailsConsentResponse method because response is  :: {}", consentDetailsResponse);
            throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.CONSENT_ERROR_CODE, null, Locale.getDefault()));
        }
    }

    public static Map<String, String> createConsentHeaders(String channel, String contentId, String contentType, String userAgent) {
        log.info("Entering into createConsentHeaders() method ::{},{}, {},{}", channel, contentId, contentType, userAgent);
        Map<String, String> headers = new HashMap<>();
        headers.put(AppConstants.CHANNEL_KEY, channel);
        headers.put(AppConstants.CONTENT_ID_KEY, contentId);
        headers.put(AppConstants.CONTENT_TYPE, contentType);
        headers.put(AppConstants.USER_AGENT, userAgent);
        log.info("header response createConsentHeaders() method :: {}", headers);
        return headers;

    }

    /**
     * Create create consent request data
     *
     * @param request
     * @return
     */
    public static CreateConsentRequest createConsentRequest(CustomerConsentRequest request, String appId) {
        log.info("Entering into createConsentRequest() method ::{}", request);
        CreateConsentRequest createConsentRequest = new CreateConsentRequest();
        Data data = new Data();
        List<Consent> listConsent = new ArrayList<>();
        Consent consent = Consent.builder().consent(request.getConsent()).mobileNumber(request.getMobileNumber()).consentType(request.getConsentType())
                .consentPurpose(request.getConsentPurpose()).consentMode(request.getConsentMode()).consentToken(appId)
                .consentDescription(request.getConsentDescription()).validityTill(request.getValidTill()).build();

        listConsent.add(consent);
        data.setConsents(listConsent);
        createConsentRequest.setData(data);
        com.airtelbank.thirdpartypayments.model.consent.request.Meta meta = new com.airtelbank.thirdpartypayments.model.consent.request.Meta();
        meta.setAppId(appId);
        meta.setAppType(request.getConsentType());
        createConsentRequest.setMeta(meta);
        log.info("create Consent request  :: {}", createConsentRequest);
        return createConsentRequest;
    }

    public static Map<String, String> createHeaders(String contentId, String channel) {
        log.info("Entering into createHeaders() method ::{},{}", channel, contentId);
        Map<String, String> headers = new HashMap<>();
        headers.put(AppConstants.CONTENT_ID_KEY, contentId);
        headers.put(AppConstants.CHANNEL_KEY, channel);
        log.info("header response createHeaders() method :: {}", headers);
        return headers;
    }

    public static String getURLFromUri(String uriTemplate, Object... params) {
        log.info("Entering into getURLFromUri() method ::{},{}", uriTemplate, params);
        if (params == null || params.length == 0) {
            log.info("uriTemplate response  from getURLFromUri() method :: {}", uriTemplate);
            return uriTemplate;
        } else {
            UriComponents uriComponents = UriComponentsBuilder.fromUriString(uriTemplate).build();
            uriComponents = uriComponents.expand(params);
            log.info("uriComponents response  from getURLFromUri() method :: {}", uriComponents.toUriString());
            return uriComponents.toUriString();
        }
    }

    public com.airtelbank.thirdpartypayments.model.consent.Consent getConsentFromList(List<com.airtelbank.thirdpartypayments.model.consent.Consent> consentList) {
        log.info("Request :: {} for the getConsentFromList()", consentList);
        com.airtelbank.thirdpartypayments.model.consent.Consent consent = null;
        com.airtelbank.thirdpartypayments.model.consent.Consent filteredConsent = null;
        ListIterator<com.airtelbank.thirdpartypayments.model.consent.Consent> iterate = consentList.listIterator();
        while (iterate.hasNext()) {
            consent = iterate.next();
            if (consent != null && AppConstants.CONSENT.CONSENT_TYPE.equalsIgnoreCase(consent.getConsentType())) {
                filteredConsent = consent;
                break;
            }
        }
        if (null == filteredConsent) {
            log.error("No Consent found for Redbus in response");
            throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.CONSENT_NOT_FOUND_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.CONSENT_NOT_FOUND_CODE, null, Locale.getDefault()));
        }
        log.info("Response return from getConsentFromList  () :: {}", filteredConsent);
        return filteredConsent;
    }

    private String getAppIdFromAerospike(String mobileNo) {
        Optional<ConsentConfigDetails> consentAppId = consentAppIdRepo.findById(mobileNo);
        log.info("Response :: {} from  consentAppIdRepo.findById() for Mobile :: {}", consentAppId, mobileNo);
        if (!(consentAppId.isPresent())) {
            log.error("No App Id present for Mobile :: {} in DB", mobileNo);
            throw new GenericException(ResponseErrorCode.AEROSPIKE_EXCEPTION, messageSource.getMessage(AppConstants.Key.CONSENT_NOT_FOUND_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.CONSENT_NOT_FOUND_CODE, null, Locale.getDefault()));
        }
        return consentAppId.get().getAppId();
    }

    private String saveAppIdToAerospike(String mobileNo) {
        Optional<ConsentConfigDetails> consentAppId = consentAppIdRepo.findById(mobileNo);
        log.info("Response :: {} from  consentAppIdRepo.findById() for Mobile :: {}", consentAppId, mobileNo);
        ConsentConfigDetails newAppId = null;
        String uuid;
        if (!(consentAppId.isPresent())) {
            log.info("No AppId is available for  for Data:: {}", mobileNo);
            uuid = UUID.randomUUID().toString();
            newAppId = new ConsentConfigDetails();
            newAppId.setAppId(uuid);
            newAppId.setMobileNo(mobileNo);
            consentAppIdRepo.save(newAppId);
            log.info("Saved New App Id to Database for Data:: {}", newAppId);
            return uuid;
        } else {
            log.info("AppId is already present for given Mobile No :: {}", mobileNo);
            return consentAppId.get().getAppId();
        }
    }
}
