package com.airtelbank.thirdpartypayments.constant;

public interface AppConstants {

    String UCID = "ucId";

    String SMS = "SMS";
    String TRANSACTION = "transaction";
    String IMMEDIATE = "I";

    String CONTENT_ID = "contentId";
    String REQUEST_ID = "requestId";
    String CUSTOMER_ID = "customerId";
    String USER_AGENT = "User-Agent";
    String IP_ADDRESS = "ipAddress";
    String MERCHANT_TXN_ID = "merchantTxnId";
    String MERCHANT_ID = "merchantId";
    String AMOUNT = "amount";
    String API_ID = "apiId";
    String ANDROID = "ANDROID";
    String IOS = "IOS";
    String RESPONSE = "response_json";
    String CODE = "code";
    String DESCRIPTION = "description";

    /**
     * The Constant CHANNEL.
     */
    String CHANNEL = "channel";

    String SYMBOLS = "symbol";

    String STATUS = "status";

    String ERROR_DESCRIPTION = "errorDesc";
    String STACK_TRACE = "stackTrace";

    String PURPOSE_CODE = "purposeCode";
    String MERCHANT_NAME = "merchantName";
    String PAYMENT_STATUS = "paymentStatus";
    String ORDER_STATUS = "orderStatus";
    String REFUND_STATUS = "refundStatus";
    String RETRY = "RETRY";
    String TIMEOUT = "TIMEOUT";
    String AWAITED = "AWAITED";
    String FAILED = "FAILED";
    String STATUS_DESC = "STATUS_DESC";
    String STATUS_CODE = "STATUS_CODE";
    /* Some commonly used words */
    String MASKED_NAT_ID = "maskedNatlId";
    String MOBILE_NUMBER = "mobileNumber";
    String CHANNEL_KEY = "channel";
    String CONTENT_ID_KEY = "contentId";
    String CONTENT_HANDLE_TYPE = "customerHandleType";
    String CONTENT_TYPE = "Content-Type";
    String CUSTOMER_HANDLE_NUMBER = "customerHandleNumber";
    String APP_ID = "customerHandleNumber";
    String SUCCESS = "SUCCESS";
    String CUSTOMER_APP_ID_NOT_EMPTY = "Customer AppId should not blank.";
    String SOME_THINGS_WENT_WRONG = "Some things wrong.";
    String THIRD_PARTY_EXCEP_CODE="4";
    String THIRD_PARTY_EXCEP_DESC="Third party error";
    String EXCEPTION_CODE="1";
    String INVALID_BODY_EXCEP_DESC="Invalid Request";
    String DB_EXCEP_DESC="Error occurred while getting data";
    String EXCEP_DESC="Exception occurs";
    String NOT_FOUND_EXCEP_DESC="Data not found";
    String AERO_BODY_EXCEP_DESC="No data available";

    //Common Error Messages for the Model class
    String MOBILE_NULL_MSG = "MOBILE NUMBER SHOULD NOT BE NULL";
    String MOBILE_NOT_VALID_MSG = "Mobile Number should be in proper format";
    String MOBILE_NOT_EMPTY_MSG = "Mobile Number is not Valid ";
    String MOBILE_NOT_BLANK_MSG = "Mobile Number should not be blank";
    String TOKEN_NULL_MSG = "TOKEN SHOULD NOT BE NULL";
    String TOKEN_NOT_EMPTY_MSG = "TOKEN SHOULD NOT EMPTY ";
    String TOKEN_NOT_BLANK_MSG = "Consent Token shold not blank";
    String MODE_NULL_MSG = "MODE SHOULD NOT BE NULL";
    String MODE_NOT_EMPTY_MSG = "MODE SHOULD NOT EMPTY ";
    String MODE_NOT_BLANK_MSG = "Consent Mode should not blank";
    String TYPE_NULL_MSG = "TYPE SHOULD NOT BE NULL";
    String TYPE_NOT_BLANK_MSG = "Consent Type Should not be blank";
    String TYPE_NOT_EMPTY_MSG = "TYPE SHOULD NOT EMPTY ";
    String NAME_NULL_MSG = "NAME SHOULD NOT BE NULL";
    String NAME_NOT_EMPTY_MSG = "NAME SHOULD NOT EMPTY ";
    String PURPOSE_REF_NO_NULL_MSG = "PURPOSE_REF_NO SHOULD NOT BE NULL";
    String PURPOSE_REF_NO_NOT_EMPTY_MSG = "PURPOSE_REF_NO SHOULD NOT EMPTY ";
    String PURPOSE_REF_NO_BLANK_EMPTY_MSG = "Purpose Ref No should not blank";
    String SECRET_KEY_NULL_MSG = "SECRET KEY SHOULD NOT BE NULL";
    String SECRET_KEY_NO_NOT_EMPTY_MSG = "SECRET KEY SHOULD NOT EMPTY ";
    String SECRET_KEY_NO_NOT_BLANK_MSG = "Secret Key should not blank";
    String PAYMENT_REF_NO_NOT_BLANK_MSG = "Payment Ref Id should not blank";
    String REFUND_REF_NO_NOT_NULL_MSG = "REFUND REF NO. SHOULD NOT NULL";
    String REFUND_REF_NO_NOT_EMPTY_MSG = "REFUND REF NO. SHOULD NOT EMPTY";
    String REFUND_REF_NO_NOT_BLANK_MSG = "Refund Ref No. should not blank";
    String AMOUNT_NOT_EMPTY_MSG = "AMOUNT SHOULD NOT EMPTY";
    String AMOUNT_NOT_NULL_MSG = "AMOUNT SHOULD NOT NULL";
    String AMOUNT_NOT_BLANK_MSG = "Amount should not blank";
    String FE_SESSION_NOT_BLANK_MSG = "FeSession Id should not blank";
    String DATA_NOT_NULL_MSG = "DATA SHOULD NOT NULL";
    String DATA_NOT_EMPTY = "DATA SHOULD NOT EMPTY";
    String REFUND_TRANSACTION_FAILED = "Refund transaction failed";
    String INVALID_REQUEST = "Invalid Request";
    String TRANSACTION_WITH_SAME_PARAMETER = "Transaction with same parameters already in progress";
    String PAYMENT_REFUND_FAILED = "Payment/Refund transaction failed";
    String STATUS_SUCCESS_CODE = "0";
    String STATUS_FAILED_CODE = "APB102";
    String REFUND_STATUS_ENQUIRY = "Refund status enquiry";
    String REFUND_STATUS_FAILED_CODE = "APB104";
    String PAYMENT_STATUS_ENQUIRY = "Payment status enquiry";
    String INITIATE_REFUND_SUCCESSFULLY = "Refund initiated successfully.";
    String BOOKING_DETAILS_SAVE_SUCCESSFULLY = "Booking details saved successfully.";
    String PAYMENT_INITIATE_SUCCESSFULLY = "Payment initiated successfully.";
    String FULLFILLMENT_STATUS_SUCCESSFULLY = "Fulfillment enquiry";
    String INVALID_STATUS_CODE = "APB101";
    String CUSTOMER_NAME = "Customer Name";
    String PURPOSE_REF_NO = "PurposeRefNo";
    String REFUND_REF_NO = "RefundRefNo";
    String TOTAL_REFUND_AMOUNT = "TotalRefundAmount";
    String BOOKING_DETAILS_REQUEST = "BookingDetails Request";
    String PR_ID = "PrId";
    String AMOUNT_GREATER_MSG = "Amount should not be Greater than 1000";
    String AMOUNT_SMALLER_MSG = "Amount should not be less than 0.0";
    String CURRENCY_NOT_NULL = "Currency should not be null";
    String CURRENCY_NOT_EMPTY = "Currency should not be empty";
    String REDIRECT_URL_NOT_NULL = "RedirectUrl should not be null";
    String REDIRECT_URL_NOT_EMPTY = "RedirectUrl should not be empty";
    String CHANNEL_NOT_EMPTY_MSG = "Channel should not empty";
    String CHANNEL_NOT_BLANK_MSG = "Channel should not blank";
    String CONTENT_ID_NOT_BLANK_MSG = "contentid should not blank";
    String USER_AGENT_NOT_BLANK_MSG = "user agent should not blank";
    String CONTENT_NOT_BLANK_MSG = "ContentId should not blank";
    String SOURCE_NOT_BLANK_MSG = "Source should not blank";
    String DESTINATION_NOT_BLANK_MSG = "Destination should not blank";
    String DOJ_NOT_BLANK_MSG = "Date Of Journey should not blank";
    String TRAVELNAME_NOT_BLANK_MSG = "Travel Name should not blank";
    String BUSTTYPE_NOT_BLANK_MSG = "Bus Type should not blank";
    String CURRENCY_NOT_BLANK_MSG = "Currency should not blank";
    String REDIRECTLINK_NOT_BLANK_MSG = "Redirect Link should not blank";
    String NAME_NOT_BLANK_MSG = "Name should not blank";
    String DATA_NOT_BLANK_MSG = "Data should not blank";


    //Payment Msg
    String PAYMENT_FAILED_STATUS = "FAILED";

    //
    String ERRORS = "errors";
    String ACCESS_CHANNEL = "RETP";
    String REQUEST_SUCCESS_CODE = "000";
    String REQUEST_SUCCESS_DESCRIPTION = "SUCCESS";
    String REQUEST_FAILURE_DESCRIPTION = "FAILED";
    String RED_BUS_BASE_URL = "/apb/utilities/redbus";
    String FULFILMENT_URL = "/fulfilment/enquiry/";
    String USECASE = "customer.utilities.redbus";

    interface ErrorCodes {
        String GENERIC_ERROR_CODE = "config.generic.errorCode";
        String GENERIC_ERROR_MESSAGE = "config.generic.errorMessage";

        String TIMEOUT_ERROR_CODE = "config.timeout.errorCode";
        String TIMEOUT_ERROR_MESSAGE = "config.timeout.errorMessage";

        String INVALID_REQUEST_CODE = "config.invalid.request.errorCode";
        String INVALID_REQUEST_MESSAGE = "config.invalid.request.errorMessage";

    }

    interface ReverseIntegrationPayments2 {
        String SUCCESS = "config.success.message";

        String DUPLICATE_MERCHANTTXNID_CODE = "config.property.payment.duplicate.merchanttxnid.code";
        String DUPLICATE_MERCHANTTXNID_MESSAGE = "config.property.payment.duplicate.merchanttxnid.message";

        String REQUEST_AUTHORIZATION_CODE = "config.property.payment.request.authorization.failed.code";
        String REQUEST_AUTHORIZATION_MESSAGE = "config.property.payment.request.authorization.failed.message";

        String INVALID_MERCHANTDETAILS_CODE = "config.property.invalid.merchant.details.code";
        String INVALID_MERCHANTDETAILS_MESSAGE = "config.property.invalid.merchant.details.message";

        String INVALID_AMOUNT_CODE = "config.property.invalid.amount.code";
        String INVALID_AMOUNT_MESSAGE = "config.property.invalid.amount.message";

        String INVALID_TRANSACTIONID_CODE = "config.property.invalid.transactionid.code";
        String INVALID_TRANSACTIONID_MESSAGE = "config.property.invalid.transactionid.message";

        String REFUND_ALREADY_PROCESSED_CODE = "config.property.refund.already.processed.code";
        String REFUND_ALREADY_PROCESSED_MESSAGE = "config.property.refund.already.processed.message";

        String REFUND_NOT_PROCESSED_CODE = "config.property.refund.notprocessed.code";
        String REFUND_NOT_PROCESSED_MESSAGE = "config.property.refund.notprocessed.message";

        String REFUND_EXCEED_ORIGINAL_CODE = "config.property.exceed.original.amount.code";
        String REFUND_EXCEED_ORIGINAL_MESSAGE = "config.property.exceed.original.amount.message";

        String REFUND_NOT_INITIATED_CODE = "config.property.refund.notinitiated.code";
        String REFUND_NOT_INITIATED_MESSAGE = "config.property.refund.notinitiated.message";


    }

    interface Status {
        int STATUS_SUCCESS = 0;
        int STATUS_FAILURE = 1;
        int STATUS_RETRY = 2;
        int STATUS_AWAITED = 3;
    }

    interface URL {

        String PURPOSE_ENQUIRY = "config.url.payment.enquiry";
        String PURPOSE_REFUND = "config.url.payment.refund";
        String OAUTH_ENQUIRY = "config.url.oauth.query";

        // for consent
        String CREATE_CUSTOMER_CONSENT = "http://10.56.110.189:3109/v3/consents";
        String FETCH_CUSTOMER_CONSENT = "http://10.56.110.189:3109/v3/consents?appId={appId}";
        //for redbus payment
        String PAYMENT_UPDATE_URL = "https://paaspreprod.redbus.com/PGResponse/AirtelInAppResponse";
        String UPDATE_REFUND_URL = "https://irispublic.redbus.com/stream/Airtelrefundcallback";

    }

    interface CONSENT {
        String CUSTOMER_CONSENT_APP_ID_ERROR_CODE = "config.property.consent.empty.code";
        String CUSTOMER_CONSENT_APP_ID_ERROR_MESSAGE = "config.property.consent.empty.code.message";
        String CONSENT_SAVE_MSG = "Data Saved Successfully";
        String CONSENT_TYPE = "REDBUS";
    }

    interface HeaderKey {
        String CONTENT_TYPE = "Content-Type";
    }

    interface PaymentStatus {
        String SUCCESS = "SUCCESS";
        String PENDING = "PENDING";
        String FAILED = "FAILED";
        String TIMEOUT = "TIMEOUT";
        String REQUESTED = "REQUESTED";
        String INITIATED = "INITIATED";
        String RETRY = "RETRY";
        String AWAITED = "AWAITED";
        String TAT_EXPIRED_CODE = "APB-TAT-101";
        String TAT_EXPIRED_MSG = "TAT EXPIRED";
        String PROCESSED = "PROCESSED";
        String GENERIC_ERROR_MSG = "We are facing some technical issue";
    }

    interface Key {
        String FAILED = "FAILED";
        String CODE = "CODE";
        String VALUE = "VALUE";
        String DEFAULT_CODE = "config.generic.errorCode";
        String DEFAULT_MSG = "config.generic.errorMessage";
        String BOOKING_SAVE_SUCCESS_CODE = "config.property.booking.save.code";
        String BOOKING_SAVE_SUCCESS_MSG = "config.property.booking.save.message";
        String BOOKING_SAVE_ERROR_CODE = "config.property.booking.failed.code";
        String BOOKING_SAVE_ERROR_MSG = "config.property.booking.failed.message";
        String REFUND_INIT_SAVE_CODE = "config.property.refund.init.success.code";
        String REFUND_INIT_SAVE_MSG = "config.property.refund.init.success.message";
        String REFUND_INIT_ERROR_CODE = "config.property.refund.init.failed.code";
        String REFUND_INIT_ERROR_MSG = "config.property.refund.init.failed.message";
        String PAYMENT_STATUS_SAVE_CODE = "config.property.payment.status.success.code";
        String PAYMENT_STATUS_SAVE_MSG = "config.property.payment.status.success.message";
        String PAYMENT_STATUS_ERROR_CODE = "config.property.payment.status.failed.code";
        String PAYMENT_STATUS_ERROR_MSG = "config.property.payment.status.failed.message";
        String REFUND_STATUS_SAVE_CODE = "config.property.refund.status.success.code";
        String REFUND_STATUS_SAVE_MSG = "config.property.refund.status.success.message";
        String REFUND_STATUS_ERROR_CODE = "config.property.refund.status.failed.code";
        String REFUND_STATUS_ERROR_MSG = "config.property.refund.status.failed.message";
        String FULFILMENT_STATUS_SAVE_CODE = "config.property.fulfilment.success.code";
        String FULFILMENT_STATUS_SAVE_MSG = "config.property.fulfilment.success.message";
        String FULFILMENT_STATUS_ERROR_CODE = "config.property.fulfilment.failed.code";
        String FULFILMENT_STATUS_ERROR_MSG = "config.property.fulfilment.failed.message";
        String PAYMENT_SAVE_SUCCESS_CODE = "config.property.payment.save.code";
        String PAYMENT_SAVE_SUCCESS_MSG = "config.property.payment.save.message";
        String PAYMENT_SAVE_ERROR_CODE = "config.property.payment.failed.code";
        String PAYMENT_SAVE_ERROR_MSG = "config.property.payment.failed.message";
        String VALIDATION_FAILED_CODE = "config.property.validation.failed.code";
        String ENC_FAILED_CODE = "config.property.enc.failed.code";
        String ENC_FAILED_MSG = "config.property.enc.failed.msg";
        String DENC_FAILED_CODE = "config.property.denc.failed.code";
        String DENC_FAILED_MSG = "config.property.denc.failed.msg";
        String SECRET_FAILED_CODE = "config.property.sceret.key.failed.code";
        String SECRET_FAILED_MSG = "config.property.sceret.key.failed.msg";
        String DB_FAILED_CODE = "config.property.db.fetch.failed.code";
        String DB_FAILED_MSG = "config.property.db.fetch.failed.msg";
        String FE_CHANNEL_CODE = "config.property.fulfilment.req.failed.code";
        String FE_CHANNEL_MSG = "config.property.fulfilment.req.failed.msg";
        String DB_EXCEPTION_CODE = "config.property.db.fetch.exception.code";
        String DB_EXCEPTION_MSG = "config.property.db.fetch.exception.msg";
        String AMOUNT_EXCEED_MSG = "config.property.refund.amount.exception.message";
        String AMOUNT_EXCEED_CODE = "config.property.refund.amount.exception.code";
        String DB_CONSTRAINT_ERROR_MSG = "config.property.db.constraint.msg";
        String DB_CONSTRAINT_ERROR_CODE = "config.property.db.constraint.code";
        String INVALID_CHANNEL_ERROR_MSG = "config.property.channel.msg";
        String INVALID_CHANNEL_ERROR_CODE = "config.property.channel.code";
        String INITIATE_PAYMENT_ERROR_MSG = "config.property.init.payment.exception.msg";
        String INITIATE_PAYMENT_ERROR_CODE = "config.property.init.payment.exception.code";
        String INITIATE_REFUND_ERROR_MSG = "config.property.init.refund.exception.msg";
        String INITIATE_REFUND_ERROR_CODE = "config.property.init.refund.exception.code";
        String CONSENT_ERROR_MSG = "config.property.consent.exception.msg";
        String CONSENT_ERROR_CODE = "config.property.consent.exception.code";
        String CONSENT_NOT_FOUND_MSG = "config.property.consent.db.exception.msg";
        String CONSENT_NOT_FOUND_CODE = "config.property.consent.db.exception.code";
        String PAYMENT_ERROR_CODE = "config.property.generic.payment.exception.code";
        String PAYMENT_ERROR_DESC = "config.property.generic.payment.exception.msg";
        String PAYMENT_STATUS_ENQUIRY_ERROR_CODE = "config.property.payment.status.enquiry.error.code";
        String PAYMENT_STATUS_ERROR_INITIATED_MSG = "config.property.payment.status.error.initiated.msg";
        String PAYMENT_STATUS_ERROR_FAILED_MSG = "config.property.payment.status.error.failed.msg";


    }

}
