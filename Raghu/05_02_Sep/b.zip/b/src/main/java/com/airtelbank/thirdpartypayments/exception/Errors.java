package com.airtelbank.thirdpartypayments.exception;

public interface Errors {

    /**
     * Gets the error code.
     *
     * @return the error code
     */
    String getErrorCode();

    /**
     * Gets the error message.
     *
     * @return the error message
     */
    String getErrorMessage();

}
