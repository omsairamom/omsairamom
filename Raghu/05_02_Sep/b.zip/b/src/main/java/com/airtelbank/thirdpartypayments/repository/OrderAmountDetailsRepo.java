package com.airtelbank.thirdpartypayments.repository;

import com.airtelbank.thirdpartypayments.entity.OrderAmountDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderAmountDetailsRepo extends JpaRepository<OrderAmountDetailsEntity, String> {

}
