package com.airtelbank.thirdpartypayments.entity.aeroskipe;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.annotation.Id;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "CONSENT_CONFIG_DETAILS")
public class ConsentConfigDetails {
    private static final long serialVersionUID = 1L;
    @Id
    private String mobileNo;
    private String appId;
}
