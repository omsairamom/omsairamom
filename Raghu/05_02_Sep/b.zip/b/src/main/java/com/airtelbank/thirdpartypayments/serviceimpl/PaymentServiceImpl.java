package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.entity.MerchantTransactionDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.exception.ThirdPartyPaymentsException;
import com.airtelbank.thirdpartypayments.model.ActorResponse;
import com.airtelbank.thirdpartypayments.model.Customer;
import com.airtelbank.thirdpartypayments.model.LoggerModel;
import com.airtelbank.thirdpartypayments.repository.MerchantTransactionDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * @author b0206596
 */

@Slf4j
@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private MerchantTransactionDetailsRepo merchantTransactionDetailsRepo;

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    @Autowired
    LoggerModel loggerModel;


    @Override
    public ActorResponse sendPurposeDetails(String purposeCode, String purposeRefNumber)
            throws ThirdPartyPaymentsException {
        MerchantTransactionDetailsEntity merchantTransactionDetailsEntity;
        OrderDetailsEntity orderDetailsEntity;
        if (purposeCode == null) {
            throw new ThirdPartyPaymentsException(ResponseErrorCode.EXCEPTION);
        }
        try {

            merchantTransactionDetailsEntity = merchantTransactionDetailsRepo.getOne(purposeCode);
            log.info("Data from Database MerchantTransactionDetails {}", merchantTransactionDetailsEntity);
            orderDetailsEntity = orderDetailsRepo.findByPurposeRefNo(purposeRefNumber);
            log.info("Data from Database OrderDatils {}", orderDetailsEntity);
        } catch (Exception e) {
            log.info("Exception Occured while fetching data {}", purposeCode);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.GENERIC_ERROR, e);
        }
        if (orderDetailsEntity == null) {
            log.info("Invalid Purpose Code or Reference No {},{}", purposeCode, purposeRefNumber);
            throw new ThirdPartyPaymentsException(ResponseErrorCode.INVALID_REQUEST);
        }

        Customer customer = Customer.builder().accNumber(merchantTransactionDetailsEntity.getAccNumber())
                .custType(merchantTransactionDetailsEntity.getCustType())
                .msisdn(merchantTransactionDetailsEntity.getMsisdn()).name(merchantTransactionDetailsEntity.getName())
                .productCode(merchantTransactionDetailsEntity.getProductCode())
                .segment(merchantTransactionDetailsEntity.getSegment()).build();

        return ActorResponse.builder().txnAmount(orderDetailsEntity.getAmount().toString())
                .customer(customer).diffParameter1(merchantTransactionDetailsEntity.getDiffParameter1())
                .diffParameter2(merchantTransactionDetailsEntity.getDiffParameter2())
                .fromNarration(merchantTransactionDetailsEntity.getFromNarration())
                .fromSms(merchantTransactionDetailsEntity.getFromSms())
                .toNarration(merchantTransactionDetailsEntity.getToNarration())
                .toSms(merchantTransactionDetailsEntity.getToSms()).requestTimestamp(LocalDateTime.now().toString())
                .build();
    }

}
