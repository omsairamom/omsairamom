package com.airtelbank.thirdpartypayments.util;

import com.airtelbank.thirdpartypayments.model.LoggerModel;
import org.springframework.stereotype.Component;


@Component
public class KibanaUtility {

    private final ThreadLocal<LoggerModel> loggerModelThreadLocal = ThreadLocal.withInitial(LoggerModel::new);

    public LoggerModel getLoggerModel() {
        return loggerModelThreadLocal.get();
    }

    public void setLoggerModel(LoggerModel loggerModel) {
        loggerModelThreadLocal.set(loggerModel);
    }

    public void clear() {
        loggerModelThreadLocal.remove();
    }
}
