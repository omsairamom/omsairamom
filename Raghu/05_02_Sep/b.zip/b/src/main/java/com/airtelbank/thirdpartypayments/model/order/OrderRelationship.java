package com.airtelbank.thirdpartypayments.model.order;

public enum OrderRelationship {
    DETAILS("DETAILS"), ACTIONS("ACTIONS");

    private final String value;

    OrderRelationship(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
