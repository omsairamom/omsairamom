package com.airtelbank.thirdpartypayments.model.order;

import com.airtelbank.thirdpartypayments.dto.response.common.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DefaultOrderConfirmationResponce implements Serializable {

    private static final long serialVersionUID = 1L;
    private Meta meta;
    private OrderConfirmationResponce data;

}
