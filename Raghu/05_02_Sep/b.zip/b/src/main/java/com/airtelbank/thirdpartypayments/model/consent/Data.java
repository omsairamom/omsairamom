package com.airtelbank.thirdpartypayments.model.consent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class Data {

    private String appId;
    private String appType;
    private String createdDate;
    private String updatedDate;
    private String pwaLink;
    private String description;
    private List<Consent> consents = null;

}
