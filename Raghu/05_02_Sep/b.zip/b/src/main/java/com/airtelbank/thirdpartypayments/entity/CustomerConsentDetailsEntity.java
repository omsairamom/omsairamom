package com.airtelbank.thirdpartypayments.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@Table(name = "CUSTOMER_CONSENT_DETAILS")
@Entity
public class CustomerConsentDetailsEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "APP_ID")
    private String appId;

    @Column(name = "APP_TYPE")
    private String appType;

    @Column(name = "IS_CONSENT_ALLOW")
    private String consentAllow;

    @Column(name = "CUSTOMER_MOBILE_NO")
    private String customerMobileNumber;

    @Column(name = "CONSENT_MODE")
    private String consentMode;

    @Column(name = "CONSENT_PURPOSE")
    private String consentPurpose;

    @Column(name = "CONSENT_DESCRIPTION")
    private String consentDescription;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "EXPIRY_DATE", nullable = true, updatable = false)
    private Date expiryDate;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATIOn_DATE", nullable = false, updatable = false)
    private Date creationDate;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATION_DATE", nullable = false, updatable = true)
    private Date updationDate;

}