package com.airtelbank.thirdpartypayments.config;

import com.airtelbank.thirdpartypayments.constant.AppConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class LogInterceptor implements HandlerInterceptor {


    @Override
    public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3) {

    }

    @Override
    public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3) {
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse arg1, Object arg2) throws Exception {
        String contentId = request.getHeader(AppConstants.CONTENT_ID);
        MDC.put(AppConstants.CONTENT_ID, contentId);
        String requestId = request.getRequestedSessionId();
        MDC.put(AppConstants.REQUEST_ID, requestId);
        String userAgent = request.getHeader(AppConstants.USER_AGENT);
        String channel = request.getHeader(AppConstants.CHANNEL);
        try {
            if (null == channel) {
                String[] userAgentArr = userAgent.split("/");
                channel = userAgentArr[1].split(",")[1];
            }
        } catch (Exception e) {
            channel = AppConstants.ANDROID;
        }
        MDC.put(AppConstants.IP_ADDRESS, getIpAddress(request));
        MDC.put(AppConstants.CHANNEL, channel);
        return true;
    }

    public static String getIpAddress(HttpServletRequest req) {
        String clientIpAddress = req.getHeader("true-client-ip");
        String ipAddress = StringUtils.isNotBlank(clientIpAddress) ? clientIpAddress : req.getHeader("X-FORWARDED-FOR");
        ipAddress = StringUtils.isNotBlank(ipAddress) ? ipAddress : req.getRemoteAddr();
        return ipAddress;
    }
}