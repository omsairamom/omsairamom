package com.airtelbank.thirdpartypayments.constant;

import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

@Getter
@ToString
public enum ResponseErrorCode {

    GENERIC_ERROR(AppConstants.ErrorCodes.GENERIC_ERROR_CODE, AppConstants.ErrorCodes.GENERIC_ERROR_MESSAGE,
            HttpStatus.INTERNAL_SERVER_ERROR),
    TIMEOUT_ERROR(AppConstants.ErrorCodes.TIMEOUT_ERROR_CODE, AppConstants.ErrorCodes.TIMEOUT_ERROR_MESSAGE,
            HttpStatus.INTERNAL_SERVER_ERROR),
    INVALID_REQUEST(AppConstants.ErrorCodes.INVALID_REQUEST_CODE, AppConstants.ErrorCodes.INVALID_REQUEST_MESSAGE,
            HttpStatus.BAD_REQUEST),
    DUPLICATE_MERCHANTTXNID(AppConstants.ReverseIntegrationPayments2.DUPLICATE_MERCHANTTXNID_CODE,
            AppConstants.ReverseIntegrationPayments2.DUPLICATE_MERCHANTTXNID_MESSAGE, HttpStatus.OK),
    AUTHORIZATION_FAILED(AppConstants.ReverseIntegrationPayments2.REQUEST_AUTHORIZATION_CODE,
            AppConstants.ReverseIntegrationPayments2.REQUEST_AUTHORIZATION_MESSAGE, HttpStatus.OK),
    INVALID_MERCHANT(AppConstants.ReverseIntegrationPayments2.INVALID_MERCHANTDETAILS_CODE,
            AppConstants.ReverseIntegrationPayments2.INVALID_MERCHANTDETAILS_MESSAGE, HttpStatus.OK),
    INVALID_AMOUNT(AppConstants.ReverseIntegrationPayments2.INVALID_AMOUNT_CODE,
            AppConstants.ReverseIntegrationPayments2.INVALID_AMOUNT_MESSAGE, HttpStatus.OK),
    INVALID_TRANSACTIONID(AppConstants.ReverseIntegrationPayments2.INVALID_TRANSACTIONID_CODE,
            AppConstants.ReverseIntegrationPayments2.INVALID_TRANSACTIONID_MESSAGE, HttpStatus.OK),
    REFUND_ALREADY_PROCESSED(AppConstants.ReverseIntegrationPayments2.REFUND_ALREADY_PROCESSED_CODE,
            AppConstants.ReverseIntegrationPayments2.REFUND_ALREADY_PROCESSED_MESSAGE, HttpStatus.OK),
    REFUND_NOT_PROCESSED(AppConstants.ReverseIntegrationPayments2.REFUND_NOT_PROCESSED_CODE,
            AppConstants.ReverseIntegrationPayments2.REFUND_NOT_PROCESSED_MESSAGE, HttpStatus.OK),
    EXCEEDS_AMOUNT(AppConstants.ReverseIntegrationPayments2.REFUND_EXCEED_ORIGINAL_CODE,
            AppConstants.ReverseIntegrationPayments2.REFUND_EXCEED_ORIGINAL_MESSAGE, HttpStatus.OK),
    REFUND_NOT_INITIATED(AppConstants.ReverseIntegrationPayments2.REFUND_NOT_INITIATED_CODE,
            AppConstants.ReverseIntegrationPayments2.REFUND_NOT_INITIATED_MESSAGE, HttpStatus.OK),
    CONSENT_APP_ID_NOT_EMPTY(AppConstants.CONSENT.CUSTOMER_CONSENT_APP_ID_ERROR_CODE,
            AppConstants.CONSENT.CUSTOMER_CONSENT_APP_ID_ERROR_MESSAGE, HttpStatus.OK),
    THIRD_PARTY_EXCEPTION(AppConstants.THIRD_PARTY_EXCEP_CODE, AppConstants.THIRD_PARTY_EXCEP_DESC, HttpStatus.INTERNAL_SERVER_ERROR),
    DB_EXCEPTION(AppConstants.EXCEPTION_CODE, AppConstants.DB_EXCEP_DESC, HttpStatus.INTERNAL_SERVER_ERROR),
    EXCEPTION(AppConstants.EXCEPTION_CODE, AppConstants.EXCEP_DESC, HttpStatus.INTERNAL_SERVER_ERROR),
    INVALID_REQUEST_BODY(AppConstants.EXCEPTION_CODE, AppConstants.INVALID_BODY_EXCEP_DESC, HttpStatus.BAD_REQUEST),
    NOT_FOUND(AppConstants.EXCEPTION_CODE, AppConstants.NOT_FOUND_EXCEP_DESC, HttpStatus.NOT_FOUND),
    AEROSPIKE_EXCEPTION(AppConstants.EXCEPTION_CODE,AppConstants.AERO_BODY_EXCEP_DESC,HttpStatus.OK);

    ResponseErrorCode(String code, String description, HttpStatus httpStatus) {
        this.code = code;
        this.description = description;
        this.httpStatus = httpStatus;
    }

    private final String code;
    private final String description;
    private final HttpStatus httpStatus;

}
