package com.airtelbank.thirdpartypayments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderResponse implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private int txnStatus;
    private String title;
    private String description;
    private String benefit;
    private List<OrderKeyValueTemplate> content;
    private List<OrderKeyValueTemplateAction> action;
    private Object purpose; // TODO- This is empty as of now, might be used in future if purpose details are required.

}

