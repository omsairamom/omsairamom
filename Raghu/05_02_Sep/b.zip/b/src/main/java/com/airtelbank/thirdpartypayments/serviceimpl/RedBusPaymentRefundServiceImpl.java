package com.airtelbank.thirdpartypayments.serviceimpl;

import com.airtelbank.payments.hub.client.dto.request.RefundRequest;
import com.airtelbank.payments.hub.client.dto.response.RefundResponse;
import com.airtelbank.payments.hub.client.dto.response.ResponseDTO;
import com.airtelbank.payments.hub.client.service.impl.PHRefundRequestServiceImpl;
import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.constant.ResponseErrorCode;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.exception.GenericException;
import com.airtelbank.thirdpartypayments.model.entityresult.CustomResult;
import com.airtelbank.thirdpartypayments.model.redbuspayment.request.PaymentRefundRequest;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundResponse;
import com.airtelbank.thirdpartypayments.model.redbuspayment.response.RedBusRefundStatusResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaRefundResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.PaymentData;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentRefundService;
import com.airtelbank.thirdpartypayments.service.ValidationService;
import com.airtelbank.thirdpartypayments.util.CommonUtil;
import com.airtelbank.thirdpartypayments.util.EncryptionDencryptionUtils;
import com.airtelbank.thirdpartypayments.util.HttpUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Slf4j
@Service
public class RedBusPaymentRefundServiceImpl implements RedBusPaymentRefundService {


    @Value("${config.redbus.payment.hub.usecase}")
    private String useCase;

    @Value("${config.redbus.payment.hub.useCaseName}")
    private String useCaseName;

    @Value("${config.redbus.payment.hub.partnerId}")
    private String partnerId;

    @Value("${config.redbus.payment.hub.billerId}")
    private String billerId;

    @Value("${config.redbus.payment.encKey}")
    private String encKey;

    @Value("${config.redbus.payment.decKey}")
    private String decKey;

    @Value("${config.redbus.payment.refundStatus}")
    private String refundStatus;

    @Value("${config.redbus.payment.merchantId}")
    private String merchantId;

    @Value("${config.redbus.refund.update.url}")
    private String refundUpdateUrl;

    @Autowired
    private PHRefundRequestServiceImpl pHRefundRequestServiceImpl;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private HttpUtil httpUtil;

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    @Autowired
    private RefundDetailsRepo refundDetailsRepo;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private ValidationService validateService;


    /**
     * initiate refund and call payment hub
     * and update the status
     *
     * @param redBusInitiatePaymentRefund
     * @return RedBusPaymentResponse
     */
    @Override
    public RedBusRefundResponse initiateRefund(PaymentData redBusInitiatePaymentRefund) {

        log.info("Entering into initiateRefund() method :: {}", redBusInitiatePaymentRefund);
        String decData = null;
        PaymentRefundRequest paymentRefundRequest = null;
        try {
            decData = EncryptionDencryptionUtils.dataDecryptByPrivateKey(decKey, redBusInitiatePaymentRefund.getData());
            log.info("Decrypt Data details from initiateRefund() method ::{}", decData);
            paymentRefundRequest = objectMapper.readValue(decData, PaymentRefundRequest.class);
            log.info("paymentRefundRequest  details from initiateRefund() method ::{}", paymentRefundRequest);
        } catch (Exception e) {
            log.error("Exception :: {} into RedBus Initiate Refund request data decryption", e.getMessage());
            throw new GenericException(ResponseErrorCode.INVALID_REQUEST_BODY, messageSource.getMessage(AppConstants.Key.DENC_FAILED_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DENC_FAILED_CODE, null, Locale.getDefault()));
        }
        validateService.validateRequestParam(paymentRefundRequest);
        validateService.validateForSecretKey(paymentRefundRequest.getSecretKey());
        if (Boolean.TRUE.equals(refundDetailsRepo.existsByRefundReqId(paymentRefundRequest.getRefundRefNo()))) {
            log.error("Data is already exists in  DB for Given  Refund RefNo {}", paymentRefundRequest.getRefundRefNo());
            throw new GenericException(ResponseErrorCode.INVALID_REQUEST_BODY, messageSource.getMessage(AppConstants.Key.DB_CONSTRAINT_ERROR_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DB_CONSTRAINT_ERROR_CODE, null, Locale.getDefault()));
        }

        MDC.put(AppConstants.PURPOSE_REF_NO, paymentRefundRequest.getPurposeRefNo());
        MDC.put(AppConstants.REFUND_REF_NO, paymentRefundRequest.getRefundRefNo());
        MDC.put(AppConstants.TOTAL_REFUND_AMOUNT, paymentRefundRequest.getTotalRefundAmount());

        OrderDetailsEntity dbRequest = getFulfilmentStatus(paymentRefundRequest.getPurposeRefNo());
        log.info("OrderDetailsEntity  details from initiateRefund() method ::{}", dbRequest);
        checkRefundableAmount(dbRequest, paymentRefundRequest);
        saveRefundStatus(dbRequest, paymentRefundRequest);
        RefundRequest refundRequest = RefundRequest.builder().paymentReqId(dbRequest.getPrID()).amount(new BigDecimal(paymentRefundRequest.getTotalRefundAmount())).orderItemId(dbRequest.getOrderDetailsTxn().get(0).getOrderDetailsTxnId()).amt(paymentRefundRequest.getTotalRefundAmount()).orderRefundId(CommonUtil.generateUniqueKey()).partnerId(partnerId).accessChannel(AppConstants.ACCESS_CHANNEL).build();
        log.info("Refund Request of initiateRefund() :: {} ", refundRequest);

        ResponseDTO<RefundResponse> transactionResponse = pHRefundRequestServiceImpl.refundRequest(useCase, refundRequest);
        if (null == transactionResponse || null == transactionResponse.getMeta() || null == transactionResponse.getData() || transactionResponse.getMeta().getStatus() == AppConstants.Status.STATUS_FAILURE) {
            log.error("Error into  pHRefundRequestServiceImpl.refundRequest() method response :: {}", transactionResponse);
            throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.PAYMENT_ERROR_DESC, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.PAYMENT_ERROR_CODE, null, Locale.getDefault()));
        }
        log.info("Response from payment hub for initiating refund :: {}", transactionResponse);
        saveRefundResponse(transactionResponse, paymentRefundRequest);

        return RedBusRefundResponse.builder().refundRefId((null != transactionResponse.getData()) ? transactionResponse.getData().getRefundReqId() : StringUtils.EMPTY)
                .purposeRefNo(dbRequest.getPurposeRefNo()).refundRefNo(paymentRefundRequest.getRefundRefNo())
                .build();

    }

    /**
     * fetch the refund status
     *
     * @param refundRefNo
     * @return RedBusPaymentResponse
     */
    @Override
    public RedBusRefundStatusResponse getRefundStatusEnquiry(String refundRefNo) {

        log.info("Entering into RedBusPaymentRefundServiceImpl of getRefundStatus() method :: {}", refundRefNo);

        TransactionRefundEntity refundReStatusResponse = null;
        try {
            refundReStatusResponse = refundDetailsRepo.findByRefundReqId(refundRefNo);
            log.info("Get Response using refundRefNo from refundDetailsRepo.findByRefundReqId() method ::");
        } catch (Exception e) {
            log.error("Exception :: {} occurs in refundDetailsRepo.findByRefundReqId() for refundRefNo :: {}", e.getMessage(), refundRefNo);
            throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
        if (null == refundReStatusResponse) {
            log.error("Error into findByRefundReqId() method because response is :: {}", refundReStatusResponse);
            throw new GenericException(ResponseErrorCode.NOT_FOUND, messageSource.getMessage(AppConstants.Key.DB_FAILED_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DB_FAILED_CODE, null, Locale.getDefault()));
        }
        log.info("Response return findByRefundReqId() method :: {}", refundReStatusResponse);

        return RedBusRefundStatusResponse.builder().paymentId(refundReStatusResponse.getPrId()).purposeRefNo(refundReStatusResponse.getPurposeRefNo()).refundRefNo(refundReStatusResponse.getRefundReqId()).refundStatus(refundReStatusResponse.getRefundStatus()).build();
    }

    /**
     * Fetch the fulfilment status
     *
     * @param prId
     * @return OrderDetailsEntity
     */
    public OrderDetailsEntity getFulfilmentStatus(String prId) {

        log.info("Entering into RedBusPaymentRefundServiceImpl of  getFulfilmentStatus() method for prId :: {}", prId);
        OrderDetailsEntity dbRequest = null;
        try {
            dbRequest = orderDetailsRepo.findByPurposeRefNo(prId);

        } catch (Exception e) {
            log.error("Exception :: {} occurs in orderDetailsRepo.findByPurposeRefNo() for PurposeNo :: {}", e.getMessage(), prId);
            throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
        if (null == dbRequest) {
            log.error("Error into findByPurposeRefNo() method because response is :: {}", dbRequest);
            throw new GenericException(ResponseErrorCode.NOT_FOUND, messageSource.getMessage(AppConstants.Key.DB_FAILED_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DB_FAILED_CODE, null, Locale.getDefault()));
        }

        log.info("Response return RedBusPaymentRefundServiceImpl.getFulfilmentStatus() method :: {}", dbRequest);
        return dbRequest;
    }

    /**
     * save the refund status
     *
     * @param dbRequest
     * @param paymentRefundRequest
     */
    public void saveRefundStatus(OrderDetailsEntity dbRequest, PaymentRefundRequest paymentRefundRequest) {
        log.info("Entering into saveRefundStatus() method");
        TransactionRefundEntity redBusPaymentRefundEntity = TransactionRefundEntity.builder().merchantId(merchantId).merchantTxnId(dbRequest.getMerchantTxnId()).amount(new BigDecimal(paymentRefundRequest.getTotalRefundAmount()))
                .purposeRefNo(paymentRefundRequest.getPurposeRefNo()).prId(dbRequest.getPrID()).refundStatus(AppConstants.PaymentStatus.INITIATED)
                .refundReqId(paymentRefundRequest.getRefundRefNo()).build();

        refundDetailsRepo.save(redBusPaymentRefundEntity);
        log.info("Save data into repo of saveRefundStatus() method :: {}", redBusPaymentRefundEntity);
    }

    /**
     * save Refund Response
     *
     * @param transactionResponse
     * @param paymentRefundRequest
     */
    public void saveRefundResponse(ResponseDTO<RefundResponse> transactionResponse, PaymentRefundRequest paymentRefundRequest) {
        log.info("Entering into saveRefundResponse() method");
        TransactionRefundEntity transactionRefundEntity = null;
        try {
            transactionRefundEntity = refundDetailsRepo.findByRefundReqId(paymentRefundRequest.getRefundRefNo());
            log.info("Response :: {} of refundDetailsRepo.findByRefundReqId() for :: {}", transactionRefundEntity, paymentRefundRequest.getRefundRefNo());

        } catch (Exception e) {
            log.error("Exception :: {} in refundDetailsRepo.findByRefundReqId() for :: {}", e.getMessage(), paymentRefundRequest.getRefundRefNo());
            throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
        if (null == transactionRefundEntity) {
            log.error(" Null  in Response  refundDetailsRepo.findByRefundReqId() for :: {}", paymentRefundRequest.getRefundRefNo());
            throw new GenericException(ResponseErrorCode.EXCEPTION, messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.DB_EXCEPTION_CODE, null, Locale.getDefault()));
        }
        transactionRefundEntity.setRefundTxnId(transactionResponse.getData().getRefundReqId());
        transactionRefundEntity.setRefundStatus(AppConstants.PaymentStatus.PROCESSED);
        refundDetailsRepo.save(transactionRefundEntity);
        log.info("Save data into repo of saveRefundResponse() method :: {}", transactionRefundEntity);
    }


    /**
     * Update Refund status to Redbus
     *
     * @param paymentRequest
     * @return ResponseEntity<String>
     */
    @Override
    public ResponseEntity<String> updateRefundStatus(KafkaRefundResponse paymentRequest) {
        log.info("Entering into updateRefundStatus() method :: {}", paymentRequest);

        String encData = StringUtils.EMPTY;
        String data = StringUtils.EMPTY;
        try {
            data = objectMapper.writeValueAsString(paymentRequest);
            log.info("converted object to json string of updateRefundStatus() method :: {}", data);
            encData = EncryptionDencryptionUtils.dataEncryptByPublicKey(encKey, data);
            log.info(" Encrypt  request in  updateRefundStatus()  method ::{}", encData);
        } catch (Exception e) {
            log.error("Exception occurs :: {} in encryption of data  in  updateRefundStatus() method :: {}", e.getMessage(), data);
            throw new GenericException(ResponseErrorCode.EXCEPTION);
        }
        PaymentData paymentData = PaymentData.builder().data(encData).build();
        Map<String, String> headers = new HashMap<>();
        headers.put(AppConstants.HeaderKey.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        log.info(" calling redbus update refund status API with PaymentData  :: {} ", paymentData);
        String hitRequestResponse =
                httpUtil.hitRequest(refundUpdateUrl, paymentData, String.class, headers, HttpMethod.POST, true);
        log.info("Response return from Redbus Refund Update API  :: {}", hitRequestResponse);
        return new ResponseEntity<>(hitRequestResponse, HttpStatus.OK);
    }

    private void checkRefundableAmount(OrderDetailsEntity dbRequest, PaymentRefundRequest paymentRefundRequest) {
        BigDecimal sumAmount = BigDecimal.ZERO;
        CustomResult customResult = null;
        List<CustomResult> refundEntityList = refundDetailsRepo.getTotalAmountFromPurposeRefNo(paymentRefundRequest.getPurposeRefNo(), AppConstants.PaymentStatus.INITIATED, AppConstants.PaymentStatus.FAILED);
        log.info("Response :: {} from refundDetailsRepo.getTotalAmountFromPurposeRefNo() for :: {}", refundEntityList, paymentRefundRequest.getPurposeRefNo());
        if (null != refundEntityList && refundEntityList.size() > 0) {
            customResult = refundEntityList.get(0);
            if (customResult.getPurposeRefNo().equals(paymentRefundRequest.getPurposeRefNo())) {
                sumAmount = sumAmount.add(customResult.getAmount());
            }
        }
        sumAmount = sumAmount.add(new BigDecimal(paymentRefundRequest.getTotalRefundAmount()));
        log.info(" Total Sum Amount of Refund :: {} and Actual Amount in DB:: {}", sumAmount, dbRequest.getAmount());
        if (sumAmount.compareTo(dbRequest.getAmount()) > 0) {
            log.error("Error while initiating because enteredAmount is Greater than Actual Amount");
            throw new GenericException(ResponseErrorCode.INVALID_REQUEST_BODY, messageSource.getMessage(AppConstants.Key.AMOUNT_EXCEED_MSG, null, Locale.getDefault()), messageSource.getMessage(AppConstants.Key.AMOUNT_EXCEED_CODE, null, Locale.getDefault()));
        }
    }
}
