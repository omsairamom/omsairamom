package com.airtelbank.thirdpartypayments.config;

import com.airtelbank.payments.hub.client.model.PHEnvironment;
import com.airtelbank.payments.hub.client.utility.PHInitialiseEnvironment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
public class PHClientConfig {

    @Value("${config.redbus.payment.hub.usecase}")
    private String useCase;

    @Value("${config.redbus.payment.hub.salt}")
    private String salt;

    @Value("${config.redbus.payment.hub.partnerId}")
    private String partnerId;

    @Value("${config.redbus.payment.hub.baseUrl}")
    private String baseUrl;

    @Value("${config.redbus.payment.hub.fulfilmentTopic}")
    private String fulfilmentTopic;


    @PostConstruct
    public void init() {
        PHEnvironment phEnvironment = PHEnvironment.builder().baseUrl(baseUrl).salt(salt).partnerId(partnerId).serviceFulfilmentTopic(fulfilmentTopic).build();
        PHInitialiseEnvironment.init(phEnvironment, useCase);
    }

}
