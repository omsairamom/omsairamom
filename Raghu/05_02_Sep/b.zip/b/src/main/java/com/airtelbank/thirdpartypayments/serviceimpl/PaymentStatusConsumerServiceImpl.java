package com.airtelbank.thirdpartypayments.serviceimpl;


import com.airtelbank.payments.hub.client.dto.kafka.PaymentStatus;
import com.airtelbank.payments.hub.client.dto.kafka.RefundStatus;
import com.airtelbank.payments.hub.client.model.OrderItemStatus;
import com.airtelbank.payments.hub.client.model.TransactionDetails;
import com.airtelbank.payments.hub.client.service.PHRefundStatusConsumerService;
import com.airtelbank.payments.hub.client.service.PHTxnStatusConsumerService;
import com.airtelbank.thirdpartypayments.constant.AppConstants;
import com.airtelbank.thirdpartypayments.entity.OrderDetailsEntity;
import com.airtelbank.thirdpartypayments.entity.TransactionRefundEntity;
import com.airtelbank.thirdpartypayments.model.order.OrderStatus;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaPaymentResponse;
import com.airtelbank.thirdpartypayments.model.updatepayment.request.KafkaRefundResponse;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsRepo;
import com.airtelbank.thirdpartypayments.repository.OrderDetailsTxnRepo;
import com.airtelbank.thirdpartypayments.repository.RefundDetailsRepo;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentRefundService;
import com.airtelbank.thirdpartypayments.service.RedBusPaymentService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service(value = AppConstants.USECASE)
@Slf4j
public class PaymentStatusConsumerServiceImpl implements PHRefundStatusConsumerService, PHTxnStatusConsumerService {

    @Value("${config.redbus.secretKey}")
    private String secretKey;

    @Autowired
    private RedBusPaymentService redBusPaymentService;

    @Autowired
    private RedBusPaymentRefundService redBusPaymentRefundService;

    @Autowired
    private RefundDetailsRepo refundDetailsRepo;

    @Autowired
    private OrderDetailsRepo orderDetailsRepo;

    @Autowired
    private OrderDetailsTxnRepo orderDetailsTxnRepo;

    @Value("${config.redbus.payment.hub.expiryTime}")
    private Integer expiredTime;

    /**
     * override the Refund status of Payment hub and provide implementation
     */
    @Override
    public void refundStatus(RefundStatus refundStatus) {

        log.info("Entering into PaymentStatusConsumerServiceImpl.refundStatus() method :: {}", refundStatus);
        if (null != refundStatus.getRefundDetails() && !(refundStatus.getRefundDetails().isEmpty()) && null != refundStatus.getRefundDetails().get(0) && StringUtils.isNotEmpty(refundStatus.getRefundDetails().get(0).getTransactionTime())) {
            List<TransactionRefundEntity> transactionRefundEntity = refundDetailsRepo.findByRefundTxnId(refundStatus.getRefundDetails().get(0).getRefundReqId());
            if (null != transactionRefundEntity && !(transactionRefundEntity.isEmpty()) &&
                    !(transactionRefundEntity.get(0).getRefundStatus().equalsIgnoreCase(AppConstants.PaymentStatus.FAILED))
                    && !(transactionRefundEntity.get(0).getRefundStatus().equalsIgnoreCase(AppConstants.PaymentStatus.SUCCESS))) {
                log.info("Getting Response from findByRefundTxnId() for Id : {} is :: {}", refundStatus.getPaymentReqId(), transactionRefundEntity);
                TransactionRefundEntity refundEntity = transactionRefundEntity.get(0);
                refundEntity.setRefundStatus(refundStatus.getRefundDetails().get(0).getStatus());
                refundEntity.setFtTxnId(refundStatus.getRefundDetails().get(0).getTransactionId());
                refundEntity.setTxnDate(refundStatus.getRefundDetails().get(0).getTransactionTime());
                refundDetailsRepo.save(refundEntity);
                if (AppConstants.PaymentStatus.SUCCESS.equalsIgnoreCase(refundStatus.getRefundDetails().get(0).getStatus()) || AppConstants.PaymentStatus.FAILED.equalsIgnoreCase(refundStatus.getRefundDetails().get(0).getStatus())) {
                    KafkaRefundResponse kafkaRefundResponse = KafkaRefundResponse.builder().status(refundStatus.getRefundDetails().get(0).getStatus()).
                            secretKey(secretKey).bankRefNo(refundEntity.getRefundTxnId()).refundRefNo(refundEntity.getRefundReqId()).
                            purposeRefNo(refundEntity.getPurposeRefNo()).
                            totalRefundAmount(refundStatus.getRefundDetails().get(0).getAmount().toString()).build();
                    try {
                        log.info(" Starts calling the updateRefundStatus() of Redbus API with param :: {}", kafkaRefundResponse);
                        redBusPaymentRefundService.updateRefundStatus(kafkaRefundResponse);
                    } catch (Exception e) {
                        log.error("Exception occur :: {} while calling RedBus Update Refund API with param :: {}", e.getMessage(), kafkaRefundResponse);
                    }
                }
            }
        }
    }


    /**
     * override txn status of Payment hub and provide implementation
     *
     * @param paymentStatus
     */
    @Override
    public void txnStatus(PaymentStatus paymentStatus) {

        log.info("Entering into PaymentStatusConsumerServiceImpl.txnStatus() method :: {}", paymentStatus);
        Long timeDiff;
        KafkaPaymentResponse kafkapaymentResponse = null;
        List<TransactionDetails> transactionDetails = paymentStatus.getDebitDetails();
        List<OrderItemStatus> orderItems = paymentStatus.getOrderDetails().getOrderItems();
        OrderDetailsEntity orderDetailsEntity = orderDetailsRepo.findByPrID(paymentStatus.getPaymentReqId());
        if (null != transactionDetails && null != orderItems && null != orderDetailsEntity && !(orderDetailsEntity.getStatus().getValue().equals(OrderStatus.FAILED.getValue()))
                && !(orderDetailsEntity.getStatus().getValue().equals(OrderStatus.SUCCESS.getValue()))) {
            TransactionDetails transactionDetail = transactionDetails.get(0);
            OrderItemStatus orderItemStatus = orderItems.get(0);
            if (AppConstants.PaymentStatus.SUCCESS.equals(transactionDetail.getStatus()) &&
                    AppConstants.PaymentStatus.SUCCESS.equals(orderItemStatus.getCreditDetails().getStatus())) {
                timeDiff = getTimeDifference(orderDetailsEntity.getUpdationDate());
                log.info("Getting Payment Status Response from findByPrID() for prId : {} is :: {}", paymentStatus.getPaymentReqId(), orderDetailsEntity.getStatus().getValue());
                if (timeDiff > expiredTime) {
                    log.info("Time Difference is :: {} and setting the error code and error message in table", timeDiff);
                    orderDetailsEntity.setStatus(OrderStatus.FAILED);
                    orderDetailsEntity.setErrorCode(AppConstants.PaymentStatus.TAT_EXPIRED_CODE);
                    orderDetailsEntity.setErrorMessage(AppConstants.PaymentStatus.TAT_EXPIRED_MSG);
                    orderDetailsEntity.setTransactionId(transactionDetail.getTransactionId());
                    kafkapaymentResponse = KafkaPaymentResponse.builder()
                            .secretKey(secretKey).purposeRefNo(orderDetailsEntity.getPurposeRefNo())
                            .paymentRefId(orderDetailsEntity.getPrID()).status(AppConstants.PaymentStatus.FAILED)
                            .totalAmount(transactionDetail.getAmount()).errorCode(AppConstants.PaymentStatus.TAT_EXPIRED_CODE)
                            .errorMessage(AppConstants.PaymentStatus.TAT_EXPIRED_MSG).timestamp(transactionDetail.getTransactionTime())
                            .build();
                } else {
                    log.info("Time Difference is :: {} less than TAT expired time", timeDiff);
                    orderDetailsEntity.setStatus(OrderStatus.SUCCESS);
                    orderDetailsEntity.setTransactionId(transactionDetail.getTransactionId());
                    kafkapaymentResponse = KafkaPaymentResponse.builder()
                            .secretKey(secretKey).purposeRefNo(orderDetailsEntity.getPurposeRefNo())
                            .paymentRefId(orderDetailsEntity.getPrID()).status(AppConstants.PaymentStatus.SUCCESS)
                            .totalAmount(transactionDetail.getAmount()).errorCode(null)
                            .errorMessage(null).timestamp(transactionDetail.getTransactionTime())
                            .build();
                }

            } else {
                log.info("Payment Status in Kafka Response is not SUCCESS");
                orderDetailsEntity.setStatus(OrderStatus.FAILED);
                orderDetailsEntity.setErrorMessage(transactionDetail.getMessage());
                orderDetailsEntity.setErrorCode(transactionDetail.getErrorCode());
                kafkapaymentResponse = KafkaPaymentResponse.builder()
                        .secretKey(secretKey).purposeRefNo(orderDetailsEntity.getPurposeRefNo())
                        .paymentRefId(orderDetailsEntity.getPrID()).status(AppConstants.PaymentStatus.FAILED)
                        .totalAmount(transactionDetail.getAmount()).errorCode(transactionDetail.getErrorCode())
                        .errorMessage(AppConstants.PaymentStatus.GENERIC_ERROR_MSG).timestamp(transactionDetail.getTransactionTime())
                        .build();

            }
            orderDetailsRepo.save(orderDetailsEntity);
            try {
                log.info(" Starts calling the updatePaymentStatus() of Redbus API with param :: {}", kafkapaymentResponse);
                redBusPaymentService.updatePaymentStatus(kafkapaymentResponse);
            } catch (Exception e) {
                log.error("Exception :: {} occur while calling RedBus Update Payment API with param :: {}", e.getMessage(), kafkapaymentResponse);
            }
        }
    }


    private Long getTimeDifference(Date paymentInitTime) {
        long timeDiff;
        Date date = Calendar.getInstance().getTime();
        timeDiff = date.getTime() - paymentInitTime.getTime();
        TimeUnit time = TimeUnit.SECONDS;
        return time.convert(timeDiff, TimeUnit.MILLISECONDS);
    }
}
