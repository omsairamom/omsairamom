package com.airtelbank.admin.dao;

import com.airtelbank.admin.util.PropertyManager;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest
class PromoterDetailsReportDAOTest {
    @Autowired
    PromoterDetailsReportDAO promoterDetailsReportDAO;

    @MockBean
    JdbcTemplate jdbctemplate;

    @MockBean
    PropertyManager prop;

    @Test
    public void getPromoterDtls() throws Exception
    {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("CAT_ID", "1");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> row = promoterDetailsReportDAO.getPromoterDtls("7006980033");
        assertTrue(!row.equals(""));
    }
    @Test
    public void getOutletDtls() throws Exception
    {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("CAT_ID", "1");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> row = promoterDetailsReportDAO.getOutletDtls("7006980033");
        assertTrue(!row.equals(""));
    }

    @Test
    public void getOutletDtl() throws Exception
    {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("CAT_ID", "1");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> row = promoterDetailsReportDAO.getOutletDtl("7006980033");
        assertTrue(!row.equals(""));
    }

    @Test
    public void getMappedPromotersList() throws Exception
    {
        List<Map<String, Object>> rows = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("CAT_ID", "1");
        rows.add(map);

        String query = "";

        when(prop.getProperty(Mockito.anyString())).thenReturn(query);
        when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

        List<Map<String, Object>> row = promoterDetailsReportDAO.getMappedPromotersList("7006980033");
        assertTrue(!row.equals(""));
    }

}