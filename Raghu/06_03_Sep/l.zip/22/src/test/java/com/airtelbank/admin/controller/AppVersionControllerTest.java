package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.AppVersionService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AppVersionControllerTest {

    @InjectMocks
    AppVersionController appVersionController;

    @Mock
    AppVersionService appVersionService;

    @Autowired
    PropertyManager prop;

    @Mock
    PropertyManager propMock;

    @Mock
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @Test
    public void processOnLoadAppVersionRequest_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9000011462");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("APPVER_FETCH_DTLS_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(appVersionService.onLoadAppVersionDetails(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = appVersionController.processOnLoadAppVersionRequest(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void processOnLoadAppVersionRequest_Fail() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = appVersionController.processOnLoadAppVersionRequest(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    public void processOnLoadAppVersionRequest_throwException() throws Exception
    {
        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        ResponseEntity<Object> responseEntity = appVersionController.processOnLoadAppVersionRequest(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }
}