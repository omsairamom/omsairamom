package com.airtelbank.admin.dao;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.PropertyManager;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest
class KpiConfigurationDAOTest
{
	@Autowired
	KpiConfigurationDAO kpiConfigurationDAO;

	@MockBean
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	@Test
	public void saveKpiConfigDtlsSuccess() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setKpiName("Kpi");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("90");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setPromoterType("Retailer");

		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();

		rows.add(map);

		List<Map<String, Object>> rows1 = new ArrayList<>();
		Map<String, Object> map1 = new HashMap<>();
		rows1.add(map1);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows1);

		int totalWeightAge = kpiConfigurationDAO.saveKpiConfigDtls(snapWorkRequest, "10-01-2021", "20-01-2021");
		assertTrue(totalWeightAge == 0);
	}

	@Test
	public void saveKpiConfigDtlsSuccess_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName(null);
		snapWorkRequest.setKpiName(null);
		snapWorkRequest.setWeightAge(null);
		snapWorkRequest.setTarget(null);
		snapWorkRequest.setStatusEnable(null);
		snapWorkRequest.setPromoterType(null);

		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();

		rows.add(map);

		List<Map<String, Object>> rows1 = new ArrayList<>();
		Map<String, Object> map1 = new HashMap<>();
		rows1.add(map1);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows1);

		int totalWeightAge = kpiConfigurationDAO.saveKpiConfigDtls(snapWorkRequest, "10-01-2021", "20-01-2021");
		assertTrue(totalWeightAge == 0);
	}

	@Test
	public void fetchKpiConfigDtls() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = kpiConfigurationDAO.fetchKpiConfigDtls();
		assertTrue(row.size() == rows.size());
	}

	@Test
	public void fetchKpiConfigurationGetPromoterType() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = kpiConfigurationDAO.fetchKpiConfigurationGetPromoterType("1");
		assertTrue(row.size() == rows.size());
	}

	@Test
	public void getStartDateSuccess() throws Exception {

		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("START_DATE", "10-01-2021");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String startDate = kpiConfigurationDAO.getStartDate();
		assertTrue(startDate.equals(rows.get(0).get("START_DATE")));
	}

	@Test
	public void getStartDateFail() throws Exception {

		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("START_DATE", "");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String startDate1 = kpiConfigurationDAO.getStartDate();
		System.out.println("endDate" + startDate1);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String endDate = formatter.format(date);
		assertTrue(endDate.equals(startDate1));

	}

	@Test
	public void getEndDateSuccess() throws Exception {

		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("END_DATE", "10-01-2021");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String startDate = kpiConfigurationDAO.getEndDate();
		assertTrue(startDate.equals(rows.get(0).get("END_DATE")));
	}

	@Test
	public void getEndDateFail() throws Exception {

		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("END_DATE", "");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String endDate1 = kpiConfigurationDAO.getEndDate();
		System.out.println("endDate" + endDate1);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String endDate = formatter.format(date);
		assertTrue(endDate.equals(endDate1));
	}

	@Test
	public void getWeightageSumSuccess() throws Exception {

		List<Map<String, Object>> weightagerows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("WEIGHT_AGE_SUM", 1);
		weightagerows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(weightagerows);

		int totalWeightAge = kpiConfigurationDAO.getWeightageSum("ABM");
		assertTrue(totalWeightAge == 1);
	}

	@Test
	public void updateKpiConfigDtlsSuccess() throws Exception
	{

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setKpiName("Kpi");
		snapWorkRequest.setKpiId("Kpi123");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("90");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setPromoterType("Retailer");

		List<Map<String, Object>> rows1 = new ArrayList<>();
		Map<String, Object> map1 = new HashMap<>();
		map1.put("CAT_ID", "13");
		rows1.add(map1);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows1);

		List<Map<String, Object>> rows2 = new ArrayList<>();
		Map<String, Object> map2 = new HashMap<>();
		map2.put("KPI_ID", "13");
		rows2.add(map2);
		String query = "";
//		when(jdbctemplate.queryForList(query, Mockito.any(Object.class))).thenReturn(rows2);

		when(jdbctemplate.update(Mockito.any(), Mockito.any(Object.class))).thenReturn(1);
//		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		int count = kpiConfigurationDAO.updateKpiConfigDtls(snapWorkRequest);
		assertTrue(count == 0);
	}

	@Test
	public void getUpdatedWeightageSum() throws Exception {
		List<Map<String, Object>> rows1 = new ArrayList<>();
		Map<String, Object> map1 = new HashMap<>();
		map1.put("WEIGHT_AGE_SUM", "13");
		rows1.add(map1);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows1);

		int count = kpiConfigurationDAO.getUpdatedWeightageSum("kpi12", "ABP");
		assertTrue(count == 13);
	}

	@Test
	public void getUpdatedWeightageSum_1() throws Exception
	{
		List<Map<String, Object>> rows1 = new ArrayList<>();

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows1);

		int count = kpiConfigurationDAO.getUpdatedWeightageSum("kpi12", "ABP");
		assertTrue(count != 13);
	}

	@Test
	public void getKpiTargetDtlsFromDbSuccess() throws Exception
	{
		JdbcTemplate mockTemplate = Mockito.mock(JdbcTemplate.class);

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setCategoryId("APB");
		snapWorkRequest.setKpiId("Kpi123");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setStatusEnable("Y");
//		
		List<Map<String, Object>> rows1 = new ArrayList<>();
		Map<String, Object> map1 = new HashMap<>();
		map1.put("CAT_ID", "13");
		rows1.add(map1);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows1);

		List<Map<String, Object>> rows2 = new ArrayList<>();
		Map<String, Object> map2 = new HashMap<>();
		map2.put("TARGET", "113");
		rows2.add(map2);
		Mockito.when(mockTemplate.queryForList(Mockito.anyString(), ArgumentMatchers.<Object>any())).thenReturn(rows2);

		String Target = kpiConfigurationDAO.getKpiTargetDtlsFromDb(snapWorkRequest);
		System.out.println("==" + Target);
		assertTrue(Target.equals(""));
	}

	@Test
	public void getKpiTargetDtlsFromDbSuccess_NULL() throws Exception
	{
		JdbcTemplate mockTemplate = Mockito.mock(JdbcTemplate.class);

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName(null);
		snapWorkRequest.setCategoryId(null);
		snapWorkRequest.setKpiId(null);
		snapWorkRequest.setWeightAge(null);
		snapWorkRequest.setStatusEnable(null);

		List<Map<String, Object>> rows1 = new ArrayList<>();
		Map<String, Object> map1 = new HashMap<>();
		map1.put("CAT_ID", "13");
		rows1.add(map1);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows1);

		List<Map<String, Object>> rows2 = new ArrayList<>();
		Map<String, Object> map2 = new HashMap<>();
		map2.put("TARGET", "113");
		rows2.add(map2);
		Mockito.when(mockTemplate.queryForList(Mockito.anyString(), ArgumentMatchers.<Object>any())).thenReturn(rows2);

		String Target = kpiConfigurationDAO.getKpiTargetDtlsFromDb(snapWorkRequest);
		System.out.println("==" + Target);
		assertTrue(Target.equals(""));
	}

	@Test
	public void isExistKpiDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("KPI_TYPE", "Kpi");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		boolean res = kpiConfigurationDAO.isExistKpiDetails("Kpi", "13");
		assertTrue(res);
	}

	@Test
	public void getKpiId() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("KPI_ID", "kpi12");
		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String kpiID = kpiConfigurationDAO.getKpiId("kpi", "13");
		assertTrue(kpiID.equals(""));
	}

	@Test
	public void getCurrentQuarter() throws Exception
	{
		List<Map<String, Object>> weightagerows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CURRENT_QUARTER", 1);
		weightagerows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(weightagerows);

		String totalWeightAge = kpiConfigurationDAO.getCurrentQuarter();

		assertEquals("1" , totalWeightAge);
	}

	@Test
	public void updatekpiConfigDtls() throws Exception
	{

		try {

			List<Map<String, Object>> rows = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			map.put("CREATED_DT", "10-03-2016 22:22:12 PM");
			rows.add(map);

			List<Map<String, Object>> row1 = new ArrayList<>();
			Map<String, Object> map1 = new HashMap<>();
			map1.put("CURRENT_QUARTER", "2");
			row1.add(map1);

			when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(row1);

			when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

			when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

			int res = kpiConfigurationDAO.updateKpiConfigDtls();

			assertEquals(1, res);

		}
		catch (Exception e) {

		}

	}

	@Test
	public void updatekpiConfigDtls_1() throws Exception
	{

		try {

			List<Map<String, Object>> rows = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			map.put("CREATED_DT", "10-03-2016 22:22:12 PM");
			rows.add(map);

			List<Map<String, Object>> row1 = new ArrayList<>();
			Map<String, Object> map1 = new HashMap<>();
			map1.put("CURRENT_QUARTER", "1");
			row1.add(map1);

			when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(row1);

			when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

			when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

			int res = kpiConfigurationDAO.updateKpiConfigDtls();

			assertEquals(1, res);

		}
		catch (Exception e) {

		}

	}

}
