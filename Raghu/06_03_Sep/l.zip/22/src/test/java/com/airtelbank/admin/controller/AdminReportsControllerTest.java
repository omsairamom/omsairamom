package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.AdminReportService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AdminReportsControllerTest
{
    @InjectMocks
    AdminReportsController adminReportsController;

    @Mock
    AdminReportService adminReportService;

    @Autowired
    PropertyManager prop;

    @Mock
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @MockBean
    Base64 base64;

    @Test
    void fetchDashboardMarketVisitDetails_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("7042709702");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setCircleName("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setZoneName("All");
        snapWorkRequest.setRoleId("All");
        snapWorkRequest.setRoleName("All");
        snapWorkRequest.setCategoryId("All");
        snapWorkRequest.setCategoryName("All");
        snapWorkRequest.setStartDate("01-01-2021");
        snapWorkRequest.setEndDate("31-01-2021");
        snapWorkRequest.setVer("0");
        snapWorkRequest.setChannel("PWEB");
        snapWorkRequest.setFeSessionId("PWEBxPQOtmtmK97K9");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("ADMIN_LOGIN_USER_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(adminReportService.dashboardMarketVisitDetails(Mockito.any()))
             .thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                adminReportsController.fetchDashboardMarketVisitDetails(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    void fetchDashboardMarketVisitDetails_Fail() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("");
        snapWorkRequest.setCircleId("");
        snapWorkRequest.setCircleName("");
        snapWorkRequest.setZoneId("");
        snapWorkRequest.setZoneName("All");
        snapWorkRequest.setRoleId("All");
        snapWorkRequest.setRoleName("");
        snapWorkRequest.setCategoryId("");
        snapWorkRequest.setCategoryName("All");
        snapWorkRequest.setStartDate("");
        snapWorkRequest.setEndDate("");
        snapWorkRequest.setVer("0");
        snapWorkRequest.setChannel("PWEB");
        snapWorkRequest.setFeSessionId("PWEBxPQOtmtmK97K9");


        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                adminReportsController.fetchDashboardMarketVisitDetails(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    void fetchDashboardMarketVisitDetails_Fail_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName(null);
        snapWorkRequest.setCircleId(null);
        snapWorkRequest.setCircleName(null);
        snapWorkRequest.setZoneId(null);
        snapWorkRequest.setZoneName(null);
        snapWorkRequest.setRoleId(null);
        snapWorkRequest.setRoleName(null);
        snapWorkRequest.setCategoryId(null);
        snapWorkRequest.setCategoryName(null);
        snapWorkRequest.setStartDate(null);
        snapWorkRequest.setEndDate(null);
        snapWorkRequest.setVer(null);
        snapWorkRequest.setChannel(null);
        snapWorkRequest.setFeSessionId(null);


        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                adminReportsController.fetchDashboardMarketVisitDetails(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    void fetchDashboardMarketVisitDetails_throwException() throws Exception
    {
        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                adminReportsController.fetchDashboardMarketVisitDetails(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    void downloadMarketDetails_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setRoleName("All");
        snapWorkRequest.setCategoryId("All");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setStartDate("01-01-2021");
        snapWorkRequest.setEndDate("12-03-2021");

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn("");
        Mockito.when(response.getStatusCode()).thenReturn("");
        Mockito.when(response.getResponse()).thenReturn(null);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        JSONObject json = new JSONObject();
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage("Download market details fetched successfully");
        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setResponse(json);

        Mockito.when(adminReportService.downloadMarketVisit(
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyString())).thenReturn(response);

        ResponseEntity<Object> responseEntity =
                adminReportsController
                        .downloadMarketDetails(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);

    }

    @Test
    void downloadMarketDetails_Fail_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setRoleName("");
        snapWorkRequest.setCategoryId("");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setStartDate("01-01-2021");
        snapWorkRequest.setEndDate("12-03-2021");

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(new JSONObject());
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                adminReportsController
                        .downloadMarketDetails(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    void downloadMarketDetails_Exception() throws Exception
    {
        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(new JSONObject());
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                adminReportsController
                        .downloadMarketDetails(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }
}