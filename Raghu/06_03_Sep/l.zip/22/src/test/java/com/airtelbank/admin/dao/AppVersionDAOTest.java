package com.airtelbank.admin.dao;

import com.airtelbank.admin.bean.AppVersionBean;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.PropertyManager;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest
class AppVersionDAOTest {

	@Autowired
	AppVersionDAO appVersionDAO;
	
	@MockBean
	JdbcTemplate jdbctemplate;

	@MockBean
	PropertyManager prop;

	@Test
	public void saveAppVersionDtls() throws Exception
	{
		SnapWorkRequest request = new SnapWorkRequest();
		request.setAction("add");

		AppVersionBean obj = new AppVersionBean();
		obj.setUserAgent("abc");
		obj.setAppVersion("V2");
		obj.setUrl("/fddg");
		obj.setMandatoryFlag("Y");
		obj.setMessage("app  version saved");
		obj.setLoadFlag("Y");
		
		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);
		
		int row = appVersionDAO.saveAppVersionDtls(request, obj);
		assertTrue(row > 0);
		
	}
	
	@Test
	public void saveAppVersionDtls_1() throws Exception
	{
		SnapWorkRequest request = new SnapWorkRequest();
		request.setAction("update");

		AppVersionBean obj = new AppVersionBean();
		obj.setUserAgent("abc");
		obj.setAppVersion("V2");
		obj.setUrl("/fddg");
		obj.setMandatoryFlag("Y");
		obj.setMessage("app  version saved");
		obj.setLoadFlag("Y");
		
		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);
		
		int row = appVersionDAO.saveAppVersionDtls(request, obj);
		assertTrue(row > 0);
		
	}
	
	@Test
	public void isAppVersionDetailsExist() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("falg", "true");
		rows.add(map);

		AppVersionBean obj = new AppVersionBean();
		obj.setUserAgent("abc");
		
		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		boolean res = appVersionDAO.isAppVersionDetailsExist(obj);
		assertTrue(res);
	}
	
	@Test
	public void fetchAppVersionDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = appVersionDAO.fetchAppVersionDetails();
		assertTrue(!row.equals(""));
	}
}
