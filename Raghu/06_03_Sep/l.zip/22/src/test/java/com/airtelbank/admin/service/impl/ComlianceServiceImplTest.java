package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.ComplianceDAO;
import com.airtelbank.admin.dao.GeoFencingDAO;
import com.airtelbank.admin.service.ComplianceService;
import com.airtelbank.admin.util.PropertyManager;
import com.airtelbank.admin.util.SecureBuilderVer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class ComlianceServiceImplTest
{
	@Autowired
	ComplianceService complianceService;
	
	@Autowired
	PropertyManager prop;

	@MockBean
	ComplianceDAO complianceDao;
	
	@MockBean
	GeoFencingDAO geoFencingDao;

	@Mock
	SecureBuilderVer secureBuilderVer_1;

	SecureBuilderVer secureBuilderVer = mock(SecureBuilderVer.class);

	@Test
	public void viewComplianceDetails_Success() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("7006980034");
		snapWorkRequest.setCircleId("1");
		snapWorkRequest.setZoneId("1");
		snapWorkRequest.setStartDate("22-10-2021");
		snapWorkRequest.setEndDate("22-10-2020");

		Map<String, Object> circleRow = new HashMap<>();
		circleRow.put("LAPU_NO", "9889898989");
		circleRow.put("USER_NAME", "Test");

		List<Map<String, Object>> circleRows  = new ArrayList<>();
		circleRows.add(circleRow);

		Mockito.when(complianceDao.fetchComplRetailerDetails(Mockito.any())).thenReturn(circleRows);

		SnapWorkResponse snapWorkResponse = complianceService.viewComplianceDetails(snapWorkRequest);

		assertEquals(snapWorkResponse.getMessage(), prop.getProperty("COMPLIANCE_FETCH_DTLS_SUCC_MSG"));
	}

	@Test
	public void viewComplianceDetails_Success_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("7006980034");
		snapWorkRequest.setCircleId("1");
		snapWorkRequest.setZoneId("1");
		snapWorkRequest.setStartDate("22-10-2021");
		snapWorkRequest.setEndDate("22-10-2020");

		List<Map<String, Object>> circleRows  = new ArrayList<>();

		Mockito.when(complianceDao.fetchComplRetailerDetails(Mockito.any())).thenReturn(circleRows);

		SnapWorkResponse snapWorkResponse = complianceService.viewComplianceDetails(snapWorkRequest);

		assertEquals(snapWorkResponse.getMessage(), prop.getProperty("COMPLIANCE_FETCH_DTLS_FAIL_MSG"));
	}

	@Test
	public void viewComplianceDetails_Fail() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("");
		snapWorkRequest.setCircleId("");
		snapWorkRequest.setZoneId("");
		snapWorkRequest.setStartDate("");
		snapWorkRequest.setEndDate("");

		SnapWorkResponse snapWorkResponse = complianceService.viewComplianceDetails(snapWorkRequest);

		assertEquals(snapWorkResponse.getMessage(), prop.getProperty("FAILURE_INVALID_REQUEST"));
	}

	@Test
	public void viewComplianceDetails_Fail_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(null);
		snapWorkRequest.setCircleId(null);
		snapWorkRequest.setZoneId(null);
		snapWorkRequest.setStartDate(null);
		snapWorkRequest.setEndDate(null);

		SnapWorkResponse snapWorkResponse = complianceService.viewComplianceDetails(snapWorkRequest);

		assertEquals(snapWorkResponse.getMessage(), prop.getProperty("FAILURE_INVALID_REQUEST"));
	}

	@Test
	public void viewComplianceDetails_Exception() throws Exception
	{
		SnapWorkResponse snapWorkResponse = complianceService.viewComplianceDetails(null);

		assertEquals("Server Error, please try after sometime.", snapWorkResponse.getMessage());
	}

	@Test
	public void onloadDashboardDetails_Success() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("7006980034");
	
		Map<String, Object> circleRow = new HashMap<>();
		circleRow.put("CIRCLE_NAME", "Test");
		circleRow.put("CIRCLE_CODE", "Test");
		circleRow.put("CIRCLE_ID", "Test");
		
		List<Map<String, Object>> circleRows  = new ArrayList<>();
		circleRows.add(circleRow);
		
		Map<String, Object> catRow = new HashMap<>();
		catRow.put("CAT_ID", "Test");
		catRow.put("CAT_NAME", "Test");
		catRow.put("CAT_DESC", "Test");
	
		List<Map<String, Object>> catRows  = new ArrayList<>();
		catRows.add(catRow);
		
		Mockito.when(geoFencingDao.getCircleMasterDetails()).thenReturn(circleRows);
		
		Mockito.when(geoFencingDao.getCategoryMasterDetails()).thenReturn(catRows);

		Map<String, Object> zoneRow = new HashMap<>();
		zoneRow.put("ZONE_ID", "Test");
		zoneRow.put("ZONE_NAME", "Test");
		zoneRow.put("ZONE_DESC", "Test");
	
		List<Map<String, Object>> zoneRows  = new ArrayList<>();
		zoneRows.add(zoneRow);
		
		Map<String, Object> roleRow = new HashMap<>();
		roleRow.put("ROLE_ID", "Test");
		roleRow.put("ROLE_NAME", "Test");
		roleRow.put("ROLE_DESC", "Test");
	
		List<Map<String, Object>> roleRows  = new ArrayList<>();
		roleRows.add(roleRow);
				
		Mockito.when(geoFencingDao.getZoneMasterDetails()).thenReturn(zoneRows);
		
		Mockito.when(geoFencingDao.getRoleMasterDetails()).thenReturn(roleRows);
		
		SnapWorkResponse snapWorkResponse = complianceService.onloadDashboardDetails(snapWorkRequest);
		
		assertEquals(snapWorkResponse.getMessage(), prop.getProperty("DASHBOARD_ONLOAD_DATA_FETCH_SUCC_MSG"));
		
	}

	@Test
	public void onloadDashboardDetails_Success_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("7006980034");

		Map<String, Object> circleRow = new HashMap<>();
		circleRow.put("CIRCLE_NAME", "Test");
		circleRow.put("CIRCLE_CODE", "Test");
		circleRow.put("CIRCLE_ID", "Test");

		List<Map<String, Object>> circleRows  = new ArrayList<>();

		Map<String, Object> catRow = new HashMap<>();
		catRow.put("CAT_ID", "Test");
		catRow.put("CAT_NAME", "Test");
		catRow.put("CAT_DESC", "Test");

		List<Map<String, Object>> catRows  = new ArrayList<>();
		catRows.add(catRow);

		Mockito.when(geoFencingDao.getCircleMasterDetails()).thenReturn(circleRows);

		Mockito.when(geoFencingDao.getCategoryMasterDetails()).thenReturn(catRows);

		Map<String, Object> zoneRow = new HashMap<>();
		zoneRow.put("ZONE_ID", "Test");
		zoneRow.put("ZONE_NAME", "Test");
		zoneRow.put("ZONE_DESC", "Test");

		List<Map<String, Object>> zoneRows  = new ArrayList<>();
		zoneRows.add(zoneRow);

		Map<String, Object> roleRow = new HashMap<>();
		roleRow.put("ROLE_ID", "Test");
		roleRow.put("ROLE_NAME", "Test");
		roleRow.put("ROLE_DESC", "Test");

		List<Map<String, Object>> roleRows  = new ArrayList<>();
		roleRows.add(roleRow);

		Mockito.when(geoFencingDao.getZoneMasterDetails()).thenReturn(zoneRows);

		Mockito.when(geoFencingDao.getRoleMasterDetails()).thenReturn(roleRows);

		SnapWorkResponse snapWorkResponse = complianceService.onloadDashboardDetails(snapWorkRequest);

		assertEquals(snapWorkResponse.getMessage(), prop.getProperty("DASHBOARD_ONLOAD_DATA_FETCH_SUCC_MSG"));

	}

	@Test
    public void onloadDashboardDetailsFailTest() throws Exception
	{
		
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(" ");
		
		SnapWorkResponse response = complianceService.onloadDashboardDetails(snapWorkRequest);

		assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"),response.getMessage());
		
		System.out.print(" " + prop.getProperty("FAILURE_INVALID_REQUEST") + " " +response.getMessage());

	}

	@Test
	public void onloadDashboardDetailsFailTest_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(null);

		SnapWorkResponse response = complianceService.onloadDashboardDetails(snapWorkRequest);

		assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"),response.getMessage());

		System.out.print(" " + prop.getProperty("FAILURE_INVALID_REQUEST") + " " +response.getMessage());
	}
	
	@Test
	public void when_onloadDashboardDetails_Then_ThrowExceptionTest()
	{
		try
		{
			
				SnapWorkResponse response = complianceService.onloadDashboardDetails(null);
				
			    assertEquals(response.getMessage(), prop.getProperty("FAILURE_ERROR_MESSAGE"));
			    
			    System.out.print(" " + prop.getProperty("FAILURE_ERROR_MESSAGE") + " " +response.getMessage());
			    
		}
		catch (Exception e)
		{

		}
	}

	@Test
	void downloadComplianceDetails_Success() throws Exception
	{
		String param_1 = "ezaHxaB7XvbtMDeLPmmnrA==";
		String param_2 = "UThCYUZ0c2NsTHU5M0d2emlPWSt2T1FUbmY3QnV6bTB3blJXQzZ2elBqOEZSSUJNWFFlcEFtWnZBcStJZUZjUHJsak9jS1BvaGV6QUdPc1p2NXNpUGN4Y25Wakl3K2VKN1RJUFc5TVd2b0xMQ2laQmZOeHlibzU1Q0VOVXJFbGYyNTFSYlpxbUFPa09lUXU1dlpYaHFnPT0=";

		MockHttpServletResponse httpResponse = new MockHttpServletResponse();
		httpResponse.addHeader("parameterName", "someValue");

		int res = complianceService.downloadComplianceDetails(param_1,
				param_2, "WEB19", httpResponse, true);

		Assertions.assertEquals( 1, res);
	}

	@Test
	void downloadAttendance_Fail() throws Exception
	{
		String param_1 = "ezaHxaB7XvbtMDeLPmmnrA==";
		String param_2 = "UThCYUZ0c2NsTHU5M0d2emlPWSt2T1FUbmY3QnV6bTB3blJXQzZ2elBqOEZSSUJNWFFlcEFtWnZBcStJZUZjUHJsak9jS1BvaGV6QUdPc1p2NXNpUGN4Y25Wakl3K2VKN1RJUFc5TVd2b0xMQ2laQmZOeHlibzU1Q0VOVXJFbGYyNTFSYlpxbUFPa09lUXU1dlpYaHFnPT0=";

		String decryptedString = "Q8BaFtsclLu93GvziOY+vOQTnf7Buzm0wnRWC6vzPj8FRIBMXQepAmZvAq+IeFcPrljOcKPohezAGOsZv5siPcxcnVjIw+eJ7TIPW9MWvoLLCiZBfNxybo55CENUrElf251RbZqmAOkOeQu5vZXhqg==";

		MockHttpServletResponse httpResponse = new MockHttpServletResponse();
		httpResponse.addHeader("parameterName", "someValue");

		Mockito.when(secureBuilderVer.decrypt(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(decryptedString);

		int res = complianceService.downloadComplianceDetails(param_1,
				param_2, "WEB19", httpResponse, true);

		Assertions.assertEquals( 1, res);
	}

	@Test
	void downloadAttendance_Exception() throws Exception
	{
		String param_1 = "ezaHxaB7XvbtMDeLPmmnrA==";
		String param_2 = "UThCYUZ0c2NsTHU5M0d2emlPWSt2T1FUbmY3QnV6bTB3blJXQzZ2elBqOEZSSUJNWFFlcEFtWnZBcStJZUZjUHJsak9jS1BvaGV6QUdPc1p2NXNpUGN4Y25Wakl3K2VKN1RJUFc5TVd2b0xMQ2laQmZOeHlibzU1Q0VOVXJFbGYyNTFSYlpxbUFPa09lUXU1dlpYaHFnPT0=";

		String decryptedString = "Q8BaFtsclLu93GvziOY+vOQTnf7Buzm0wnRWC6vzPj8FRIBMXQepAmZvAq+IeFcPrljOcKPohezAGOsZv5siPcxcnVjIw+eJ7TIPW9MWvoLLCiZBfNxybo55CENUrElf251RbZqmAOkOeQu5vZXhqg==";

		MockHttpServletResponse httpResponse = new MockHttpServletResponse();
		httpResponse.addHeader("parameterName", "someValue");

		Mockito.when(secureBuilderVer_1.decrypt(param_1,
				param_2, "WEB19", "web"))
				.thenReturn(decryptedString);

		int res = complianceService.downloadComplianceDetails(param_1,
				param_2, "WEB19", httpResponse, true);

		Assertions.assertEquals( 1, res);
	}
}
