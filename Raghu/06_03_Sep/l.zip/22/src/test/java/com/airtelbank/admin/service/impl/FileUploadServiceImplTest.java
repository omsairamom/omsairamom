package com.airtelbank.admin.service.impl;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.enums.FileStatus;
import com.airtelbank.admin.repository.PromoterUploadFileAuditRepository;
import com.airtelbank.admin.util.Constants;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.FileUploadDAO;
import com.airtelbank.admin.service.FileUploadService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.PropertyManager;

@ExtendWith(SpringExtension.class)
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class FileUploadServiceImplTest {

	@Autowired
	PropertyManager prop;

	@Autowired
	SnapWorkResponse response;

	@Autowired
	FileUploadService fileUploadService;

	@Autowired
	SnapWorkRequest request;

	@MockBean
	FileUploadDAO fileUploadDAO;

	@MockBean
	CommonUtils commonUtil;

	@Mock
	private RestTemplate restTemplate;

	@MockBean
	private PromoterUploadFileAuditRepository promoterUploadFileAuditRepository;

	@Value("${promoter.whitelist.file.type}")
	private String promoterWhitelistFileType;

	@Value("${promoter.outlet.mapping.file.type}")
	private String promoterOutletMappingFileType;

	@Test
	public void retailerUploadDetailsSuccess() throws Exception {

		File file = new File("src/test/resources/promoter.csv");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));

		HashMap<String, String> circleMap = new HashMap<>();
		when(fileUploadDAO.populateCircleMaster()).thenReturn(circleMap);

		HashMap<String, String> zoneMap = new HashMap<>();
		when(fileUploadDAO.populateZoneMaster()).thenReturn(zoneMap);

		HashMap<String, String> categoryMap = new HashMap<>();
		categoryMap.put("ABM", "ABM");
		when(fileUploadDAO.getCategoryIdDtlsMap()).thenReturn(categoryMap);

		ArrayList<String> mobileNolist = new ArrayList<>();
		when(fileUploadDAO.populateAppUserDtls()).thenReturn(mobileNolist);

		ArrayList<String> otherMobilelist = new ArrayList<>();
		when(fileUploadDAO.populateOthersDtls()).thenReturn(otherMobilelist);

		when(fileUploadDAO.storeDtlsInAppUserForBatch(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyInt())).thenReturn(1);

		when(fileUploadDAO.updateDelUserDtls(Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenReturn(1);

		when(fileUploadDAO.getCircleIdDtls(Mockito.any())).thenReturn("1");
		when(fileUploadDAO.getZoneIdDtls(Mockito.any())).thenReturn("1");

		when(fileUploadDAO.updateDtlsInAppUserForBatch(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyInt())).thenReturn(1);

		when(fileUploadDAO.updateUserDtls(Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(1);

		ResponseEntity<String> result = new ResponseEntity<String>(HttpStatus.OK);

		SnapWorkRequest request = new SnapWorkRequest();
		request.setMobileNo("7607784211");
		final String baseUrl = prop.getProperty("API_MERCHANT_BLACKLISTING");
		URI uri = new URI(baseUrl);

		Mockito.when(restTemplate.postForEntity(uri, request, String.class))
				.thenReturn(new ResponseEntity(HttpStatus.OK));

		response = fileUploadService.retailerUploadDetails(multipartFile);

		assertEquals(prop.getProperty("UPLOAD_RETAIL_FILE_SUCC_MSG"), response.getMessage());

	}

	@Test
	public void retailerUploadDetailsCatIDEmpty() throws Exception {

		File file = new File("src/test/resources/promoter.csv");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));

		HashMap<String, String> circleMap = new HashMap<>();
		when(fileUploadDAO.populateCircleMaster()).thenReturn(circleMap);

		HashMap<String, String> zoneMap = new HashMap<>();
		when(fileUploadDAO.populateZoneMaster()).thenReturn(zoneMap);

		HashMap<String, String> categoryMap = new HashMap<>();
		when(fileUploadDAO.getCategoryIdDtlsMap()).thenReturn(categoryMap);

		ArrayList<String> mobileNolist = new ArrayList<>();
		when(fileUploadDAO.populateAppUserDtls()).thenReturn(mobileNolist);

		ArrayList<String> otherMobilelist = new ArrayList<>();
		when(fileUploadDAO.populateOthersDtls()).thenReturn(otherMobilelist);

		when(fileUploadDAO.storeDtlsInAppUserForBatch(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyInt())).thenReturn(1);

		when(fileUploadDAO.updateDelUserDtls(Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenReturn(1);

		when(fileUploadDAO.getCircleIdDtls(Mockito.any())).thenReturn("1");
		when(fileUploadDAO.getZoneIdDtls(Mockito.any())).thenReturn("1");

		doNothing().when(fileUploadDAO).saveErrorReocrdDtls(Mockito.anyString(), Mockito.anyString());

		when(fileUploadDAO.updateDtlsInAppUserForBatch(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyInt())).thenReturn(1);

		when(fileUploadDAO.updateUserDtls(Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(1);


		response = fileUploadService.retailerUploadDetails(multipartFile);

		assertEquals(prop.getProperty("UPLOAD_RETAIL_FILE_SUCC_MSG"), response.getMessage());

	}

	@Test
	public void retailerUploadDetailsFail() throws Exception
	{

		File file = new File("src/test/resources/promoter.php.csv");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
				IOUtils.toByteArray(input));

		HashMap<String, String> circleMap = new HashMap<>();
		when(fileUploadDAO.populateCircleMaster()).thenReturn(circleMap);

		HashMap<String, String> zoneMap = new HashMap<>();
		when(fileUploadDAO.populateZoneMaster()).thenReturn(zoneMap);

		HashMap<String, String> categoryMap = new HashMap<>();
		when(fileUploadDAO.getCategoryIdDtlsMap()).thenReturn(categoryMap);

		ArrayList<String> mobileNolist = new ArrayList<>();
		when(fileUploadDAO.populateAppUserDtls()).thenReturn(mobileNolist);

		ArrayList<String> otherMobilelist = new ArrayList<>();
		when(fileUploadDAO.populateOthersDtls()).thenReturn(otherMobilelist);

		response = fileUploadService.retailerUploadDetails(multipartFile);

		assertEquals(prop.getProperty("UPLOAD_RETAIL_INVALID_FILE_EXTN_MSG"), response.getMessage());

	}

	@Test
	public void retailerUploadDetailsThrowException() throws Exception
	{
		response = fileUploadService.retailerUploadDetails(null);
		assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
	}

	@Test
	public void enquirePromoterCSVDetailsInvalidFileNameTest() throws IOException {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.PENDING.name());
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName(nullable(String.class));
		assertNotNull(fileUploadService.enquirePromoterCSVDetails("file"));
	}

	@Test
	public void enquirePromoterCSVDetailsStatusPendingTest() throws IOException {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.PENDING.name());
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file.csv");
		Assertions.assertTrue(fileUploadService.enquirePromoterCSVDetails("file.csv").getMessage().equalsIgnoreCase("PENDING"));
	}

	@Test
	public void enquirePromoterCSVDetailsStatusProcessedTest() throws IOException {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.PROCESSED.name());
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file.csv");
		Assertions.assertTrue(fileUploadService.enquirePromoterCSVDetails("file.csv").getMessage().equalsIgnoreCase(Constants.DATA_WAS_UPLOADED_SUCCESSFULLY));
	}

	@Test
	public void enquirePromoterCSVDetailsStatusFailedTest() throws IOException {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.FAILED.name());
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file.csv");
		Assertions.assertTrue(fileUploadService.enquirePromoterCSVDetails("file.csv").getMessage().equalsIgnoreCase(Constants.PLEASE_TRY_AGAIN_WITH_A_DIFFERENT_FILE_NAME));
	}

	@Test
	public void enquirePromoterCSVDetailsStatusInProgressTest() throws IOException {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.IN_PROGRESS.name());
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file.csv");
		Assertions.assertTrue(fileUploadService.enquirePromoterCSVDetails("file.csv").getMessage().equalsIgnoreCase(Constants.THE_FILE_IS_UNDER_PROCESSING));
	}

	@Test
	public void enquirePromoterCSVDetailsStatusLastConditionTest() throws IOException {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus("default");
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file.csv");
		Assertions.assertTrue(fileUploadService.enquirePromoterCSVDetails("file.csv").getMessage().equalsIgnoreCase("default"));
	}

	@Test
	public void downloadPromoterCSVDetailsWhitelistFileException() throws Exception {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.PROCESSED.name());
		promoterUploadFileAuditEntity.setFileName("file.csv");
		promoterUploadFileAuditEntity.setType("Pr_whitelisting");
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file.csv");
		java.nio.file.NoSuchFileException thrown = assertThrows(
				java.nio.file.NoSuchFileException.class,
				() -> fileUploadService.downloadPromoterCSVDetails("file.csv"),
				"testing."
		);
		assertTrue(thrown.toString().contains("NoSuchFileException"));
	}

	@Test
	public void downloadPromoterCSVDetailsOutletFileException() throws Exception {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.PROCESSED.name());
		promoterUploadFileAuditEntity.setFileName("file.csv");
		promoterUploadFileAuditEntity.setType("Outlet_mapping");
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file.csv");
		java.nio.file.NoSuchFileException thrown = assertThrows(
				java.nio.file.NoSuchFileException.class,
				() -> fileUploadService.downloadPromoterCSVDetails("file.csv"),
				"testing."
		);
		assertTrue(thrown.toString().contains("NoSuchFileException"));
	}

	@Test
	public void downloadPromoterCSVDetailsInvalidFileException() throws Exception {
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setStatus(FileStatus.PROCESSED.name());
		promoterUploadFileAuditEntity.setType("Outlet_mapping");
		Mockito.doReturn(Optional.of(promoterUploadFileAuditEntity)).when(promoterUploadFileAuditRepository).findByFileName("file");
		Exception thrown = assertThrows(
				Exception.class,
				() -> fileUploadService.downloadPromoterCSVDetails("file.csv"),
				"testing."
		);
		assertTrue(thrown.toString().contains("Exception"));
	}

}
