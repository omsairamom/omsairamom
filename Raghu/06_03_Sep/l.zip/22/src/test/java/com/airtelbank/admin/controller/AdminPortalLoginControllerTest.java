package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.AdminPortalLoginService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.servlet.http.HttpServletRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AdminPortalLoginControllerTest
{
	@InjectMocks
	AdminPortalLoginController adminPortalLoginController;

	@Mock
	AdminPortalLoginService adminPortalLoginService;

	@Autowired
	PropertyManager prop;

	@Mock
	CommonUtils commonUtil;

	@Mock
	SnapWorkResponse response;

	@Mock
	HttpServletRequest httpServletRequest;

	@Test
	public void adminLoginDetailsSuccess() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("9000011462");
		snapWorkRequest.setPassword("Admin@123");

		JSONObject jsonObject = new JSONObject();

		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("ADMIN_LOGIN_USER_SUCC_MSG"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		Mockito.when(adminPortalLoginService.adminLoginDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.adminLoginDetails(snapWorkRequest);

		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void adminLoginDetailsInvalidRequest() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("9000011462");
		snapWorkRequest.setPassword("");

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.adminLoginDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( "500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void adminLoginDetailsInvalidRequest_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(null);
		snapWorkRequest.setPassword(null);

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.adminLoginDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( "500", snapWorkResponse.getStatusCode());


	}

	@Test
	public void adminLoginDetailsNullPointerException() throws Exception
	{
		SnapWorkRequest snapWorkRequest = null;

		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
		Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.adminLoginDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( "500", snapWorkResponse.getStatusCode());


	}

	@Test
	public void fetchCircleMasterDetailsSuccess() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("9000011462");

		JSONObject jsonObject = new JSONObject();
		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("ADMIN_FETCH_CIRCLE_MST_DTLS_SUCC_MSG"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		Mockito.when(adminPortalLoginService.fetchCircleDetails(Mockito.anyString(), Mockito.any()))
				.thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchCircleMasterDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());


	}
	
	@Test
	public void fetchCircleMasterDetailsInvalidRequest() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("");

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		Mockito.when(adminPortalLoginService.fetchCircleDetails(Mockito.anyString(), Mockito.any()))
				.thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchCircleMasterDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

	}

	@Test
	public void fetchCircleMasterDetailsInvalidRequest_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(null);

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		Mockito.when(adminPortalLoginService.fetchCircleDetails(Mockito.anyString(), Mockito.any()))
				.thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchCircleMasterDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());

	}

	@Test
	public void fetchCircleMasterDetailsThrowException() throws Exception
	{
		SnapWorkRequest snapWorkRequest = null;
		

		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
		Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		Mockito.when(adminPortalLoginService.fetchCircleDetails(Mockito.anyString(), Mockito.any()))
				.thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchCircleMasterDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());
	}
	
	@Test
	public void fetchDashboardAttendanceDetailsSuccess() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId("circleid");
		snapWorkRequest.setStartDate("01/02/2021");
		snapWorkRequest.setEndDate("10/02/2021");


		JSONObject jsonObject = new JSONObject();
		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("ADMIN_FETCH_ATTEND_DTLS_SUCC_MSG"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		Mockito.when(adminPortalLoginService.dashboardAttendanceDetails(Mockito.any()))
				.thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchDashboardAttendanceDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}
	
	@Test
	public void fetchDashboardAttendanceDetailsInvalidRequest() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId("");
		snapWorkRequest.setStartDate("");
		snapWorkRequest.setEndDate("");
		
		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");


		Mockito.when(adminPortalLoginService.dashboardAttendanceDetails(Mockito.any()))
				.thenReturn(response);


		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchDashboardAttendanceDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void fetchDashboardAttendanceDetailsInvalidRequest_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId(null);
		snapWorkRequest.setStartDate(null);
		snapWorkRequest.setEndDate(null);

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");


		Mockito.when(adminPortalLoginService.dashboardAttendanceDetails(Mockito.any()))
				.thenReturn(response);


		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchDashboardAttendanceDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void fetchDashboardAttendanceDetailsThrowException() throws Exception
	{
		SnapWorkRequest snapWorkRequest = null;
		
		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
		Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		Mockito.when(adminPortalLoginService.dashboardAttendanceDetails(Mockito.any()))
				.thenReturn(response);


		ResponseEntity<Object> responseEntity = adminPortalLoginController.fetchDashboardAttendanceDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

	}
	
	@Test
	public void resetPasswordDetailsSuccess() throws Exception{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("9000011462");
		snapWorkRequest.setPassword("Admin@123");


		JSONObject jsonObject = new JSONObject();
		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("ADMIN_RESET_PASSWD_SUCC_MSG"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		Mockito.when(adminPortalLoginService.resetPassword(Mockito.anyString(),Mockito.anyString(), Mockito.any()))
				.thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.resetPasswordDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}
	
	@Test
	public void resetPasswordDetailsInvalidRequest() throws Exception{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("");
		snapWorkRequest.setPassword("");


		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");


		Mockito.when(adminPortalLoginService.resetPassword(Mockito.anyString(),Mockito.anyString(), Mockito.any()))
				.thenReturn(response);


		ResponseEntity<Object> responseEntity = adminPortalLoginController.resetPasswordDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void resetPasswordDetailsInvalidRequest_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(null);
		snapWorkRequest.setPassword(null);

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");


		Mockito.when(adminPortalLoginService.resetPassword(Mockito.anyString(),Mockito.anyString(), Mockito.any()))
				.thenReturn(response);


		ResponseEntity<Object> responseEntity = adminPortalLoginController.resetPasswordDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void resetPasswordDetailsThrowException() throws Exception{
		SnapWorkRequest snapWorkRequest = null;
		
		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
		Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		Mockito.when(adminPortalLoginService.resetPassword(Mockito.anyString(),Mockito.anyString(), Mockito.any()))
		.thenReturn(response);


		ResponseEntity<Object> responseEntity = adminPortalLoginController.resetPasswordDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void sendOTPDetails_Success() throws Exception
	{

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("Sabreena");

		JSONObject jsonObject = new JSONObject();

		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("ADMIN_SEND_OTP_SUCC_MSG"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		Mockito.when(adminPortalLoginService.sendOTP(Mockito.anyString(), Mockito.any())).thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.sendOTPDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void sendOTPDetails_Fail() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("");

		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.sendOTPDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( "500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void sendOTPDetails_Fail_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(null);

		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.sendOTPDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( "500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void sendOTPDetails_throwException()
	{

		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
		Mockito.when(response.getStatusCode()).thenReturn("500");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.sendOTPDetails(null);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals("500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void verifyOTPDetails_Success() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("Sabreena");
		snapWorkRequest.setOtp("1112233");
		snapWorkRequest.setOtpVerificationCode("12345");

		JSONObject jsonObject = new JSONObject();

		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("ADMIN_VERIFY_OTP_SUCC_MSG"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		Mockito.when(adminPortalLoginService.verifyOTP(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.verifyOTPDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void verifyOTPDetails_Fail() throws Exception
	{

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("");
		snapWorkRequest.setOtp("");
		snapWorkRequest.setOtpVerificationCode("12345");

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.verifyOTPDetails(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( "500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void verifyOTPDetails_throwException()
	{
		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.verifyOTPDetails(null);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( "500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void downloadAttendanceDetails_Success() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId("All");
		snapWorkRequest.setStartDate("01-01-2021");
		snapWorkRequest.setEndDate("12-03-2021");

		MockHttpServletResponse httpResponse = new MockHttpServletResponse();
		httpResponse.addHeader("parameterName", "someValue");

		Mockito.when(response.getMessage()).thenReturn("");
		Mockito.when(response.getStatusCode()).thenReturn("");
		Mockito.when(response.getResponse()).thenReturn(null);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		JSONObject json = new JSONObject();
		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage("Attendance details fetched successfully");
		response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
		response.setResponse(json);

		Mockito.when(adminPortalLoginService.downloadAttendance(Mockito.anyString(),
				Mockito.anyString(),  Mockito.anyString())).thenReturn(response);

		ResponseEntity<Object> responseEntity =
				adminPortalLoginController.downloadAttendanceDetails(snapWorkRequest);

		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertNotNull(snapWorkResponse);
	}

	@Test
	public void downloadAttendanceDetails_Fail() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId("");
		snapWorkRequest.setStartDate("01-01-2021");
		snapWorkRequest.setEndDate("12-03-2021");

		MockHttpServletResponse httpResponse = new MockHttpServletResponse();
		httpResponse.addHeader("parameterName", "someValue");


		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
		Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
		Mockito.when(response.getResponse()).thenReturn(new JSONObject());

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		Mockito.when(adminPortalLoginService.downloadAttendance(Mockito.anyString(),
				Mockito.anyString(),  Mockito.anyString())).thenReturn(response);

		JSONObject json = new JSONObject();
		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
		response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
		response.setResponse(json);

		ResponseEntity<Object> responseEntity =
				adminPortalLoginController.downloadAttendanceDetails(snapWorkRequest);

		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());

	}

	@Test
	public void downloadAttendanceDetails_ThrowExeption() throws Exception
	{

		MockHttpServletResponse httpResponse = new MockHttpServletResponse();
		httpResponse.addHeader("parameterName", "someValue");


		Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
		Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
		Mockito.when(response.getResponse()).thenReturn(new JSONObject());

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
		Mockito.when(adminPortalLoginService.downloadAttendance(Mockito.anyString(),
				Mockito.anyString(),  Mockito.anyString())).thenReturn(response);

		ResponseEntity<Object> responseEntity = adminPortalLoginController.downloadAttendanceDetails(null);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

	}

	@Test
	public void logOut_Success() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName("7006980034");

		JSONObject jsonObject = new JSONObject();

		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("ADMIN_LOGOUT_SUCC_MSG"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		String payload ="{\"mobileno\":\"7006980036\"}";
		Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

		Mockito.when(adminPortalLoginService.processLogOutRequest(Mockito.anyString())).thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.logOut(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void logOut_Fail() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(" ");

		String payload ="{\"mobileno\":\"7006980036\"}";
		Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.logOut(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals("500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void logOut_Fail_1() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setUserName(null);

		String payload ="{\"mobileno\":\"7006980036\"}";
		Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.logOut(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals("500", snapWorkResponse.getStatusCode());
	}

	@Test
	public void logOut_throwException()
	{
		String payload ="{\"mobileno\":\"7006980036\"}";
		Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.logOut(null);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals("500", snapWorkResponse.getStatusCode());
	}
	
	@Test
	public void getTokenSuccess() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setMobileNo("7006980034");

		JSONObject jsonObject = new JSONObject();

		SnapWorkResponse response = new SnapWorkResponse();
		response.setMessage(prop.getProperty("JWT_GENERATED_SUCCESSFULLY"));
		response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
		response.setResponse(jsonObject);

		Mockito.when(adminPortalLoginService.isRefreshToKen(Mockito.any())).thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.getToken(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());
	}

	@Test
	public void getTokenInvalidRequest() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setMobileNo("");

		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		Mockito.when(adminPortalLoginService.isRefreshToKen(Mockito.any())).thenReturn(response);

		Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.getToken(snapWorkRequest);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());
	}
	
	@Test
	public void getTokenThrowException() throws Exception
	{
		Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
		Mockito.when(response.getStatusCode()).thenReturn("500");

		ResponseEntity<Object> responseEntity = adminPortalLoginController.getToken(null);
		SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

		assertEquals("500", snapWorkResponse.getStatusCode());
	}
}