package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.PromoterDetailsReport;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterDetailsReportControllerTest {

    @InjectMocks
    PromoterDetailsReportController promoterDetailsReportController;

    @Mock
    PromoterDetailsReport promoterDetailsReport;

    @Autowired
    PropertyManager prop;

    @Mock
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @Test
    void getPromoterDtlsSuccess() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7042709702");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("OUTLET_DETAILS_SUCC_MGS"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);


        Mockito.when(promoterDetailsReport.getPromoterDtls(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                promoterDetailsReportController.getPromoterDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    public void getPromoterDtlsFail_IsBlank() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = promoterDetailsReportController.getPromoterDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    void getPromoterDtls_throwException() throws Exception
    {
        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                promoterDetailsReportController.getPromoterDtls(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }
    @Test
    public void getOutletDtlsSuccess() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("9000011462");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("PROMOTERS_DETAILS_SUCC_MGS"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(promoterDetailsReport.getOutletDtls(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = promoterDetailsReportController.getOutletDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        Assertions.assertEquals(response.getMessage(), snapWorkResponse.getMessage());
    }
    @Test
    public void getOutletDtlsFail_IsBlank() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = promoterDetailsReportController.getOutletDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());
    }

    @Test
    void getOutletDtls_throwException() throws Exception
    {
        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                promoterDetailsReportController.getOutletDtls(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

    @Test
    void downloadOutletDtls_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980033");

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn("");
        Mockito.when(response.getStatusCode()).thenReturn("");
        Mockito.when(response.getResponse()).thenReturn(null);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        JSONObject json = new JSONObject();
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage("Download Outlet details fetched successfully");
        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setResponse(json);

        Mockito.when(promoterDetailsReport.downloadOutletDtls(
                Mockito.anyString())).thenReturn(response);

        ResponseEntity<Object> responseEntity = promoterDetailsReportController.downloadOutletDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);

    }

    @Test
    void downloadOutletDtls_Fail_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(new JSONObject());
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                promoterDetailsReportController
                        .downloadOutletDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }


    @Test
    void downloadPromoterDtls_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980033");

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn("");
        Mockito.when(response.getStatusCode()).thenReturn("");
        Mockito.when(response.getResponse()).thenReturn(null);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        JSONObject json = new JSONObject();
        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage("Download Promoter details fetched successfully");
        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setResponse(json);

        Mockito.when(promoterDetailsReport.downloadPromoterDtls(
                Mockito.anyString())).thenReturn(response);

        ResponseEntity<Object> responseEntity = promoterDetailsReportController.downloadPromoterDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);

    }

    @Test
    void downloadPromoterDtls_Fail_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(new JSONObject());
        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                promoterDetailsReportController
                        .downloadPromoterDtls(snapWorkRequest);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(snapWorkResponse.getStatusCode(), response.getStatusCode());

    }

}