package com.airtelbank.admin.dao;

import com.airtelbank.admin.util.PropertyManager;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest
class AdminReportDAOTest {
	
	@Autowired
	AdminReportDAO adminReportDAO;
	
	@MockBean
	JdbcTemplate jdbctemplate;

	@MockBean
	PropertyManager prop;
	
	@Test
	public void fetchMarketRoleDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("1","1","1","sabreena");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_1() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","All","All","All");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_2() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("1","All","All","All");
		assertTrue(!row.equals(""));
	}

	@Test
	public void fetchMarketRoleDetails_3() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","All","All","sabreena");
		assertTrue(!row.equals(""));
	}

	@Test
	public void fetchMarketRoleDetails_4() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","1","All","All");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_5() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","All","1","All");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_6() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","All","1","1");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_7() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","1","1","1");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_8() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CIRCLE_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","1","1","All");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_9() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("1","1","1","All");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_10() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("1","All","All","1");
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchMarketRoleDetails_11() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketRoleDetails("All","1","All","1");
		assertTrue(!row.equals(""));
	}

	@Test
	public void fetchMarketVisitedRetailerDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("USER_NAME", "Sabreena");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String retName= adminReportDAO.fetchMarketVisitedRetailerDetails("7006980034");
		assertTrue(!retName.equals(""));
	}

	@Test
	public void getRollDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("USER_TYPE", "PR");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String roleName = adminReportDAO.getRollDetails("7006980034");
		assertTrue(!roleName.equals(""));
	}

	@Test
	public void fetchMarketVisitedCheckInDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchMarketVisitedCheckInDetails("7006980035","7006980034","All","1");
		assertTrue(!row.equals(""));
	}

	@Test
	public void getOutletVisistedCount() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("count", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		int row = adminReportDAO.getOutletVisistedCount("PR","7006980034");
		assertTrue(row > 0);
	}

	@Test
	public void fetchCheckInDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchCheckInDetails("7006980035","7006980034","All","1");
		assertTrue(!row.equals(""));
	}

	@Test
	public void fetchCheckOutDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.fetchCheckOutDetails("7006980035","7006980034","All","1");
		assertTrue(!row.equals(""));
	}

	@Test
	public void getLatLongDtls() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = adminReportDAO.getLatLongDtls("18/02/2021", "7006980035","7006980034");
		assertTrue(!row.equals(""));
	}
}
