package com.airtelbank.admin.dao;

import com.airtelbank.admin.bean.AdminLoginInfoTrackerBean;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.collections.map.HashedMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest
class AdminPortalLoginDAOTest
{
	@Autowired
	AdminPortalLoginDAO AdminPortalLoginDAO;

	@MockBean
	JdbcTemplate jdbctemplate;

	@Mock
	PropertyManager prop;

	@BeforeEach
	private void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void saveAdminLoginInfoTrackerDetails() throws Exception
	{
		int row = 1;

		AdminLoginInfoTrackerBean obj = new AdminLoginInfoTrackerBean();
		obj.setUserName("7006980035");
		obj.setLoginType(1);
		obj.setField1("NA");
		obj.setField2("NA");
		obj.setField3("NA");
		obj.setField4("NA");
		obj.setField5("NA");

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int count = AdminPortalLoginDAO.saveAdminLoginInfoTrackerDetails(obj);

		assertEquals(count, row);
	}

	@Test
	public void validateAdminLoginDetailsSuccess() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Map<String, Object> map = new HashedMap();
		map.put("ADM_NAME", "9000011462");
		map.put("ADM_PWD", "Admin@123");
		map.put("ADM_TYPE", "admin");

		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);
		List<Map<String, Object>> Responserows = AdminPortalLoginDAO.validateAdminLoginDetails("9000011462",
				"Airtel@123");

		System.out.println(Responserows);

		assertEquals(Responserows.size(), rows.size());

	}

	@Test
	public void getCircleMasterDetailsSuccess() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Map<String, Object> map = new HashedMap();
		map.put("CIRCLE_NAME", "UP");
		map.put("CIRCLE_CODE", "UP123");
		map.put("CIRCLE_ID", "13");

		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString())).thenReturn(rows);
		List<Map<String, Object>> Responserows = AdminPortalLoginDAO.getCircleMasterDetails();

		System.out.println(Responserows);

		assertEquals(Responserows.size(), rows.size());

	}

	@Test
	public void fetchAttendanceDataDetailsSuccess() throws Exception
	{

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId("13");
		snapWorkRequest.setStartDate("10-01-2021");
		snapWorkRequest.setEndDate("20-01-2021");

		List<Map<String, Object>> rows = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Map<String, Object> map = new HashedMap();
		map.put("CIRCLE_NAME", "UP");
		map.put("CIRCLE_CODE", "UP123");
		map.put("CIRCLE_ID", "13");

		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);
		List<Map<String, Object>> Responserows = AdminPortalLoginDAO.fetchAttendanceDataDetails(snapWorkRequest);

		System.out.println(Responserows);

		assertEquals(Responserows.size(), rows.size());

	}

	@Test
	public void fetchAttendanceDataDetailsSuccess_NULL() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId(null);
		snapWorkRequest.setStartDate(null);
		snapWorkRequest.setEndDate(null);

		List<Map<String, Object>> rows = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Map<String, Object> map = new HashedMap();
		map.put("CIRCLE_NAME", "UP");
		map.put("CIRCLE_CODE", "UP123");
		map.put("CIRCLE_ID", "13");

		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);
		List<Map<String, Object>> Responserows = AdminPortalLoginDAO.fetchAttendanceDataDetails(snapWorkRequest);

		System.out.println(Responserows);

		assertEquals(Responserows.size(), rows.size());

	}

	@Test
	public void fetchAttendanceDataDetailsElse() throws Exception
	{

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCircleId("All");
		snapWorkRequest.setStartDate("10-01-2021");
		snapWorkRequest.setEndDate("20-01-2021");

		List<Map<String, Object>> rows = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Map<String, Object> map = new HashedMap();
		map.put("CIRCLE_NAME", "UP");
		map.put("CIRCLE_CODE", "UP123");
		map.put("CIRCLE_ID", "13");

		rows.add(map);

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);
		List<Map<String, Object>> Responserows = AdminPortalLoginDAO.fetchAttendanceDataDetails(snapWorkRequest);

		System.out.println(Responserows);

		assertEquals(Responserows.size(), rows.size());

	}

	@Test
	public void getOutletVisistedCountSuccess() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Map<String, Object> map = new HashedMap();
		map.put("count", "20");

		rows.add(map);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);
		int count = AdminPortalLoginDAO.getOutletVisistedCount("10-01-2021", "7607842101");
		assertEquals( 20, count);
	}

	@Test
	public void getOutletVisistedCountSuccessWithNull_2() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);
		int count = AdminPortalLoginDAO.getOutletVisistedCount("10-01-2021", "7607842101");
		assertEquals(0, count);
	}

	@Test
	public void updateAdminPasswordDetailsSuccess() throws Exception
	{

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);
		int count = AdminPortalLoginDAO.updateAdminPasswordDetails("Admin", "Airtel@123");
		assertEquals(1, count);
	}
	
	@Test
	public void getLatLongDtlsSuccess() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Map<String, Object> map2 = new HashedMap();
		map2.put("LATITUDE", "38.889510");
		map2.put("LONGITUDE", "-77.032000");
		rows.add(map2);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);
		List<Map<String, Object>> rows1 = AdminPortalLoginDAO.getLatLongDtls("10-01-2021", "7607842101");
		assertEquals(rows1.size(), rows.size());
	}
	
	@Test
	public void fetchAttendanceDataDetails() throws Exception 
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = AdminPortalLoginDAO.fetchAttendanceDataDetails("All","02/12/2020","03/12/2020");
		assertTrue(!row.equals(""));
	}

	@Test
	public void fetchAttendanceDataDetails_1() throws Exception 
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = AdminPortalLoginDAO.fetchAttendanceDataDetails("1","02/12/2020","03/12/2020");
		assertTrue(!row.equals(""));
	}

	@Test
	public void getOutletVisistedCount() throws Exception 
	{
		
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("count", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		int count = AdminPortalLoginDAO.getOutletVisistedCount("03/12/2020 11:00:00", "7006980034");
		
	    System.out.print(count);
		assertTrue(count > 0);
	}
	
	@Test
	public void updateJWT() throws Exception 
	{
		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int count = AdminPortalLoginDAO.updateJWT("jwtTokn123", "7006980034");
		
	    System.out.print(count);
		assertTrue(count > 0);
	}
	
	@Test
	public void getJWT() throws Exception 
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("JWT_TOKEN", "jwtkone123");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		String  jwtToken = AdminPortalLoginDAO.getJWT("7006980034");
		
	    System.out.print(jwtToken);
		assertTrue(!jwtToken.isEmpty());
	}

	@Test
	public void getJWT_NULL() throws Exception
	{
		String query = "";
		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(null);

		String  jwtToken = AdminPortalLoginDAO.getJWT("7006980034");

		assertNotNull(jwtToken);
	}
}