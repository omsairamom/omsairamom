package com.airtelbank.admin.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.web.client.RestTemplate;

import com.airtelbank.admin.bean.CircleMasterBean;
import com.airtelbank.admin.bean.OthersHierarchyBean;
import com.airtelbank.admin.bean.RetailerDetailsBean;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.PropertyManager;

@SpringBootTest
class FileUploadDAOTest {

	@Autowired
	FileUploadDAO fileUploadDAO;

	@MockBean
	JdbcTemplate jdbctemplate;

	@MockBean
	PropertyManager prop;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private KeyHolder keyHolderMock;

	@Mock
	private org.springframework.cglib.core.KeyFactory keyHolderFactoryMock;

	@Test
	public void getCategoryIdDtlsMap() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		map.put("CAT_NAME", "Test");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		HashMap<String, String> CATEGORY_MAP = fileUploadDAO.getCategoryIdDtlsMap();
		assertTrue(!CATEGORY_MAP.equals(""));
	}

	@Test
	public void populateCircleMaster() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CIRCLE_ID", "1");
		map.put("CIRCLE_NAME", "Test");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		HashMap<String, String> CIRCLE_MAP = fileUploadDAO.populateCircleMaster();
		assertTrue(!CIRCLE_MAP.equals(""));
	}

	@Test
	public void populateZoneMaster() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("ZONE__ID", "1");
		map.put("ZONE__NAME", "Test");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		HashMap<String, String> ZONE_MAP = fileUploadDAO.populateZoneMaster();
		assertTrue(!ZONE_MAP.equals(""));
	}

	@Test
	public void populateAppUserDtls() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("LAPU_NO", "7006980036");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		ArrayList<String> list = fileUploadDAO.populateAppUserDtls();
		assertTrue(!list.equals(""));
	}

	@Test
	public void populateOthersDtls() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("LAPU_NO", "7006980036");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		ArrayList<String> list = fileUploadDAO.populateOthersDtls();
		assertTrue(!list.equals(""));
	}

	@Test
	public void getCircleIdDtlsSuccess() throws Exception {
		CircleMasterBean circleMasterBean = new CircleMasterBean();
		circleMasterBean.setCircleCode("UK");
		circleMasterBean.setCircleName("Mock");
		String query = "INSERT INTO PAPP_CIRCLE_MST (CIRCLE_ID,CIRCLE_NAME,CIRCLE_CODE,UPDATED_DT,CREATED_DT)VALUES(circle_mst_seq.nextval,?,?,sysdate,sysdate)";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		Mockito.when(jdbctemplate.update(Mockito.any(PreparedStatementCreator.class), Mockito.any(KeyHolder.class)))
				.thenReturn(1);

		String circleID = fileUploadDAO.getCircleIdDtls(circleMasterBean);
		System.out.println("circleID" + circleID);
		assertTrue(circleID.equals("0"));
	}

	@Test
	public void getZoneIdDtlsSuccess() throws Exception {
		OthersHierarchyBean othersHierarchyBean = new OthersHierarchyBean();
		othersHierarchyBean.setZoneName("Mumbai");
		
		String query = "INSERT INTO PAPP_ZONE_MST(ZONE_ID,ZONE_NAME,ZONE_DESC,UPDATED_BY,CREATE_DT,UPDATE_DT) VALUES (zone_mst_seq.nextval,?,?,'Admin',SYSDATE,SYSDATE)";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		Mockito.when(jdbctemplate.update(Mockito.any(PreparedStatementCreator.class), Mockito.any(KeyHolder.class)))
				.thenReturn(1);

		String zoneID = fileUploadDAO.getZoneIdDtls(othersHierarchyBean);
		System.out.println("zoneID" + zoneID);
		assertTrue(zoneID.equals("0"));
	}

//	@Test
//	public void storeDtlsInAppUserForBatch() throws Exception {
//		RetailerDetailsBean retailerBean = new RetailerDetailsBean();
//		retailerBean.setRetailerName("Deeksha");
//		retailerBean.setRetailerNo("7607842101");
//		CircleMasterBean circleBean = new CircleMasterBean();
//		circleBean.setCircleName("UP");
//		circleBean.setCircleCode("c123");
//		OthersHierarchyBean othersBean = new OthersHierarchyBean();
//		othersBean.setPromoterLapuNo("7607842102");
//		othersBean.setPromoterType("Merchant");
//		othersBean.setPromoterName("Ayush");
//		othersBean.setPromoterAgency("ABC");
//		othersBean.setPromoterEmployeeID("");
//
//		othersBean.setPromoterDob("10-02-2021");
//		othersBean.setPromoterDoj("10-02-2021");
//		othersBean.setTlNo("7607842103");
//		othersBean.setTlName("Ayush");
//		othersBean.setTlAgency("Ayush");
//		othersBean.setTlEmployeeID("7607842103");
//		othersBean.setZoneName("ZM");
//		othersBean.setZmNo("7607842104");
//		othersBean.setZmName("Dee");
//		othersBean.setRmMsisdn("7607842105");
//		othersBean.setRmName("Deeksha1");
//		othersBean.setCphNo("7607842103");
//		othersBean.setCphName("Divya");
//		othersBean.setMmno("7607842105");
//		othersBean.setMmname("Divya12");
//		othersBean.setAction("A");
//
//		ArrayList<String> mobileNolist = new ArrayList<>();
//
//		when(prop.getProperty(Mockito.anyString())).thenReturn("");
//
//		ResponseEntity<String> result = new ResponseEntity<String>(HttpStatus.OK);
////		when(restTemplate.postForEntity(Mockito.any(), Mockito.any(), String.class)).thenReturn(result);
//
//		SnapWorkRequest request = new SnapWorkRequest();
//		request.setMobileNo(othersBean.getPromoterLapuNo());
//		request.setPromoterName(othersBean.getPromoterName());
//		request.setReference1("Y");
//
//		String baseUrl = "http://10.56.110.210:9000/merchantsignup-services/v1/users/merchantwhitelisting";
//		when(prop.getProperty(Mockito.anyString())).thenReturn(baseUrl);
////		final String baseUrl = prop.getProperty("API_MERCHANT_WHITELISTING");
//		URI uri = new URI(baseUrl);
//
//		Mockito.when(restTemplate.postForEntity(uri, request, String.class))
//				.thenReturn(new ResponseEntity(HttpStatus.OK));
//
//		int[] arr = { 1 };
//		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);
//
//		int count = fileUploadDAO.storeDtlsInAppUserForBatch(retailerBean, circleBean, othersBean, "c12", "z12", "cat1",
//				mobileNolist, 0);
//		System.out.println("count" + count);
//		assertTrue(count > 0);
//
//	}

	@Test
	public void storeDtlsInAppUserForBatchFail() throws Exception {
		RetailerDetailsBean retailerBean = new RetailerDetailsBean();
		retailerBean.setRetailerName("Deeksha");
		retailerBean.setRetailerNo("RetailerNo");
		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");
		OthersHierarchyBean othersBean = new OthersHierarchyBean();
		othersBean.setPromoterLapuNo("PromoterLapuNo");
		othersBean.setPromoterType("Retailer");
		othersBean.setPromoterName("Ayush");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("");

		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("TlNo");
		othersBean.setTlName("Ayush");
		othersBean.setTlAgency("Ayush");
		othersBean.setTlEmployeeID("TlEmployeeID");
		othersBean.setZoneName("ZM");
		othersBean.setZmNo("ZmNo");
		othersBean.setZmName("Dee");
		othersBean.setRmMsisdn("RmMsisdn");
		othersBean.setRmName("Deeksha1");
		othersBean.setCphNo("CphNo");
		othersBean.setCphName("Divya");
		othersBean.setMmno("MMNo");
		othersBean.setMmname("Divya12");
		othersBean.setAction("A");

		ArrayList<String> mobileNolist = new ArrayList<>();

		when(prop.getProperty(Mockito.anyString())).thenReturn(
				"INSERT INTO PAPP_ERROR_RETAILER_RECORDS (ER_ID,LAPU_NO,ERROR_MSG,CREATED_DT)VALUES(err_retailer_records_seq.nextval,?,?,SYSDATE)");

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int count = fileUploadDAO.storeDtlsInAppUserForBatch(retailerBean, circleBean, othersBean, "c12", "z12", "cat1",
				mobileNolist, 0);

		assertTrue(count == 0);

	}

	@Test
	public void saveErrorReocrdDtlsSuccess() throws Exception {
		int count = 0;
		when(prop.getProperty(Mockito.anyString())).thenReturn(
				"INSERT INTO PAPP_ERROR_RETAILER_RECORDS (ER_ID,LAPU_NO,ERROR_MSG,CREATED_DT)VALUES(err_retailer_records_seq.nextval,?,?,SYSDATE)");

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		fileUploadDAO.saveErrorReocrdDtls("errorMsg", "7607842110");
		assertTrue(count == 0);

	}

	@Test
	public void storeUserDtlsSuccess() throws Exception {
		RetailerDetailsBean retailerBean = new RetailerDetailsBean();

		retailerBean.setRetailerNo("7607842100");
		retailerBean.setRetailerName("retailerName");
		retailerBean.setOutletType("Promoter");
		retailerBean.setLongitude("0.0");
		retailerBean.setLatitude("0.0");
		retailerBean.setVillageName("AB");
		retailerBean.setVillagesType("T");
		retailerBean.setVillagePop("villagePop");
		retailerBean.setCity("city");
		retailerBean.setBlockTehsil("blockTehsil");
		retailerBean.setDistrict("district");
		retailerBean.setSiteId("siteId");
		retailerBean.setCategory("category");

		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");
		OthersHierarchyBean othersBean = new OthersHierarchyBean();

		othersBean.setPromoterLapuNo("7607842101");
		othersBean.setPromoterType("Retailer");
		othersBean.setPromoterName("Deeksah");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("7607842102");
		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("7607842102");
		othersBean.setTlName("Dee");
		othersBean.setTlAgency("AB");
		othersBean.setTlEmployeeID("7607842103");
		othersBean.setTlDob("10-02-2021");
		othersBean.setTlDoj("10-02-2021");
		othersBean.setZoneName("KAnpur");
		othersBean.setZmNo("7607842104");
		othersBean.setZmName("Zmnem");
		othersBean.setRmMsisdn("7607842105");
		othersBean.setRmName("rmName");
		othersBean.setCphNo("7607842106");
		othersBean.setCphName("cphName");
		othersBean.setMmno("7607842109");
		othersBean.setMmname("MMName");
		othersBean.setAction("A");

		ArrayList<String> otherMobilelist = new ArrayList<>();

		int[] arr = { 1 };
		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);

		int count = fileUploadDAO.storeUserDtls(1, retailerBean, circleBean, othersBean, otherMobilelist);
		assertTrue(count > 0);
	}

	@Test
	public void storeUserDtlsLATLONGNA() throws Exception {
		RetailerDetailsBean retailerBean = new RetailerDetailsBean();

		retailerBean.setRetailerNo("7607842100");
		retailerBean.setRetailerName("retailerName");
		retailerBean.setOutletType("Promoter");
		retailerBean.setLongitude("NA");
		retailerBean.setLatitude("NA");
		retailerBean.setVillageName("AB");
		retailerBean.setVillagesType("T");
		retailerBean.setVillagePop("villagePop");
		retailerBean.setCity("city");
		retailerBean.setBlockTehsil("blockTehsil");
		retailerBean.setDistrict("district");
		retailerBean.setSiteId("siteId");
		retailerBean.setCategory("category");

		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");
		OthersHierarchyBean othersBean = new OthersHierarchyBean();

		othersBean.setPromoterLapuNo("7607842101");
		othersBean.setPromoterType("Retailer");
		othersBean.setPromoterName("Deeksah");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("7607842102");
		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("7607842102");
		othersBean.setTlName("Dee");
		othersBean.setTlAgency("AB");
		othersBean.setTlEmployeeID("7607842103");
		othersBean.setTlDob("10-02-2021");
		othersBean.setTlDoj("10-02-2021");
		othersBean.setZoneName("KAnpur");
		othersBean.setZmNo("7607842104");
		othersBean.setZmName("Zmnem");
		othersBean.setRmMsisdn("7607842105");
		othersBean.setRmName("rmName");
		othersBean.setCphNo("7607842106");
		othersBean.setCphName("cphName");
		othersBean.setMmno("7607842109");
		othersBean.setMmname("MMName");
		othersBean.setAction("A");

		ArrayList<String> otherMobilelist = new ArrayList<>();

		int[] arr = { 1 };
		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);

		int count = fileUploadDAO.storeUserDtls(1, retailerBean, circleBean, othersBean, otherMobilelist);
		assertTrue(count > 0);
	}

	@Test
	public void updateDelUserDtlsSuccess() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("LAPU_NO", "7607842110");
		map.put("DEL_BLOCK_FLAG", "0");
		rows.add(map);
		RetailerDetailsBean retailerBean = new RetailerDetailsBean();
		OthersHierarchyBean othersBean = new OthersHierarchyBean();
		when(prop.getProperty(Mockito.anyString()))
				.thenReturn("UPDATE PAPP_APP_USERS SET DEL_BLOCK_FLAG=1,UPDATED_DT=sysdate WHERE LAPU_NO=?");

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);
		int count = fileUploadDAO.updateDelUserDtls("7607842110", "Deeksah", retailerBean, othersBean);
		assertTrue(count > 0);
	}

	@Test
	public void isExistDeactiveDtlsSuccess() throws Exception {
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("LAPU_NO", "7607842110");
		map.put("DEL_BLOCK_FLAG", "0");
		rows.add(map);
		when(prop.getProperty(Mockito.anyString()))
				.thenReturn("UPDATE PAPP_APP_USERS SET DEL_BLOCK_FLAG=1,UPDATED_DT=sysdate WHERE LAPU_NO=?");

		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		boolean isExist = fileUploadDAO.isExistDeactiveDtls("7607842110", "Deeksja");
		assertTrue(isExist == true);
	}

//	@Test
//	public void updateDtlsInAppUserForBatchSuccess() throws Exception {
//		RetailerDetailsBean retailerBean = new RetailerDetailsBean();
//
//		retailerBean.setRetailerNo("7607842100");
//		retailerBean.setRetailerName("retailerName");
//		retailerBean.setOutletType("Promoter");
//		retailerBean.setLongitude("NA");
//		retailerBean.setLatitude("NA");
//		retailerBean.setVillageName("AB");
//		retailerBean.setVillagesType("T");
//		retailerBean.setVillagePop("villagePop");
//		retailerBean.setCity("city");
//		retailerBean.setBlockTehsil("blockTehsil");
//		retailerBean.setDistrict("district");
//		retailerBean.setSiteId("siteId");
//		retailerBean.setCategory("category");
//
//		CircleMasterBean circleBean = new CircleMasterBean();
//		circleBean.setCircleName("UP");
//		circleBean.setCircleCode("c123");
//		OthersHierarchyBean othersBean = new OthersHierarchyBean();
//
//		othersBean.setPromoterLapuNo("7607842101");
//		othersBean.setPromoterType("Merchant");
//		othersBean.setPromoterName("Deeksah");
//		othersBean.setPromoterAgency("ABC");
//		othersBean.setPromoterEmployeeID("7607842102");
//		othersBean.setPromoterDob("10-02-2021");
//		othersBean.setPromoterDoj("10-02-2021");
//		othersBean.setTlNo("7607842201");
//		othersBean.setTlName("Dee");
//		othersBean.setTlAgency("AB");
//		othersBean.setTlEmployeeID("7607842103");
//		othersBean.setTlDob("10-02-2021");
//		othersBean.setTlDoj("10-02-2021");
//		othersBean.setZoneName("KAnpur");
//		othersBean.setZmNo("7607842104");
//		othersBean.setZmName("Zmnem");
//		othersBean.setRmMsisdn("7607842105");
//		othersBean.setRmName("rmName");
//		othersBean.setCphNo("7607842106");
//		othersBean.setCphName("cphName");
//		othersBean.setMmno("7607842109");
//		othersBean.setMmname("MMName");
//		othersBean.setAction("A");
//
//		ArrayList<String> mobileNolist = new ArrayList<>();
//		mobileNolist.add("7607842100");
//		mobileNolist.add("7607842101");
//		mobileNolist.add("7607842102");
//		mobileNolist.add("7607842201");
//		mobileNolist.add("7607842103");
//		mobileNolist.add("7607842104");
//		mobileNolist.add("7607842105");
//		mobileNolist.add("7607842106");
//		mobileNolist.add("7607842109");
//
//		when(prop.getProperty(Mockito.anyString())).thenReturn("");
//
//		SnapWorkRequest request = new SnapWorkRequest();
//		request.setMobileNo(othersBean.getPromoterLapuNo());
//		request.setPromoterName(othersBean.getPromoterName());
//
//		String baseUrl = "http://10.56.110.210:9000/merchantsignup-services/v1/users/merchantwhitelistingupdate";
//		when(prop.getProperty(Mockito.anyString())).thenReturn(baseUrl);
////		final String baseUrl = prop.getProperty("API_MERCHANT_WHITELISTING");
//		URI uri = new URI(baseUrl);
//
//		Mockito.when(restTemplate.postForEntity(uri, request, String.class))
//				.thenReturn(new ResponseEntity(HttpStatus.OK));
//
//		int[] arr = { 1 };
//		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);
//
//		int count = fileUploadDAO.updateDtlsInAppUserForBatch(retailerBean, circleBean, othersBean, "1", "z1", "cat1",
//				mobileNolist, 1);
//		assertTrue(count > 0);
//	}

	@Test
	public void updateDtlsInAppUserForBatchFail() throws Exception {
		RetailerDetailsBean retailerBean = new RetailerDetailsBean();

		retailerBean.setRetailerNo("760784210R");
		retailerBean.setRetailerName("retailerName");
		retailerBean.setOutletType("Promoter");
		retailerBean.setLongitude("NA");
		retailerBean.setLatitude("NA");
		retailerBean.setVillageName("AB");
		retailerBean.setVillagesType("T");
		retailerBean.setVillagePop("villagePop");
		retailerBean.setCity("city");
		retailerBean.setBlockTehsil("blockTehsil");
		retailerBean.setDistrict("district");
		retailerBean.setSiteId("siteId");
		retailerBean.setCategory("category");

		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");
		OthersHierarchyBean othersBean = new OthersHierarchyBean();

		othersBean.setPromoterLapuNo("760784210P");
		othersBean.setPromoterType("Retailer");
		othersBean.setPromoterName("Deeksah");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("760784210E");
		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("76078422T");
		othersBean.setTlName("Dee");
		othersBean.setTlAgency("AB");
		othersBean.setTlEmployeeID("760784210TL");
		othersBean.setTlDob("10-02-2021");
		othersBean.setTlDoj("10-02-2021");
		othersBean.setZoneName("KAnpur");
		othersBean.setZmNo("760784210ZM");
		othersBean.setZmName("Zmnem");
		othersBean.setRmMsisdn("760784210RM");
		othersBean.setRmName("rmName");
		othersBean.setCphNo("760784210CH");
		othersBean.setCphName("cphName");
		othersBean.setMmno("760784210MM");
		othersBean.setMmname("MMName");
		othersBean.setAction("A");

		ArrayList<String> mobileNolist = new ArrayList<>();
		mobileNolist.add("760784210R");
		mobileNolist.add("760784210P");
		mobileNolist.add("760784210E");
		mobileNolist.add("76078422T");
		mobileNolist.add("760784210TL");
		mobileNolist.add("760784210ZM");
		mobileNolist.add("760784210RM");
		mobileNolist.add("760784210CH");
		mobileNolist.add("760784210MM");

		when(prop.getProperty(Mockito.anyString())).thenReturn("");

		SnapWorkRequest request = new SnapWorkRequest();
		request.setMobileNo(othersBean.getPromoterLapuNo());
		request.setPromoterName(othersBean.getPromoterName());

		when(prop.getProperty(Mockito.anyString())).thenReturn(
				"INSERT INTO PAPP_ERROR_RETAILER_RECORDS (ER_ID,LAPU_NO,ERROR_MSG,CREATED_DT)VALUES(err_retailer_records_seq.nextval,?,?,SYSDATE)");

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int count = fileUploadDAO.updateDtlsInAppUserForBatch(retailerBean, circleBean, othersBean, "1", "z1", "cat1",
				mobileNolist, 1);
		assertTrue(count == 0);
	}

	@Test
	public void updateDtlsInAppUserForBatchFail1() throws Exception {
		RetailerDetailsBean retailerBean = new RetailerDetailsBean();

		retailerBean.setRetailerNo("7607842100");
		retailerBean.setRetailerName("retailerName");
		retailerBean.setOutletType("Promoter");
		retailerBean.setLongitude("NA");
		retailerBean.setLatitude("NA");
		retailerBean.setVillageName("AB");
		retailerBean.setVillagesType("T");
		retailerBean.setVillagePop("villagePop");
		retailerBean.setCity("city");
		retailerBean.setBlockTehsil("blockTehsil");
		retailerBean.setDistrict("district");
		retailerBean.setSiteId("siteId");
		retailerBean.setCategory("category");

		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");
		OthersHierarchyBean othersBean = new OthersHierarchyBean();

		othersBean.setPromoterLapuNo("7607842101");
		othersBean.setPromoterType("Merchant");
		othersBean.setPromoterName("Deeksah");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("7607842102");
		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("7607842201");
		othersBean.setTlName("Dee");
		othersBean.setTlAgency("AB");
		othersBean.setTlEmployeeID("7607842103");
		othersBean.setTlDob("10-02-2021");
		othersBean.setTlDoj("10-02-2021");
		othersBean.setZoneName("KAnpur");
		othersBean.setZmNo("7607842104");
		othersBean.setZmName("Zmnem");
		othersBean.setRmMsisdn("7607842105");
		othersBean.setRmName("rmName");
		othersBean.setCphNo("7607842106");
		othersBean.setCphName("cphName");
		othersBean.setMmno("7607842109");
		othersBean.setMmname("MMName");
		othersBean.setAction("A");

		ArrayList<String> mobileNolist = new ArrayList<>();

		when(prop.getProperty(Mockito.anyString())).thenReturn("");

		SnapWorkRequest request = new SnapWorkRequest();
		request.setMobileNo(othersBean.getPromoterLapuNo());
		request.setPromoterName(othersBean.getPromoterName());

		String baseUrl = "http://10.56.110.210:9000/merchantsignup-services/v1/users/merchantwhitelistingupdate";
		when(prop.getProperty(Mockito.anyString())).thenReturn(baseUrl);
//		final String baseUrl = prop.getProperty("API_MERCHANT_WHITELISTING");
		URI uri = new URI(baseUrl);

		Mockito.when(restTemplate.postForEntity(uri, request, String.class))
				.thenReturn(new ResponseEntity(HttpStatus.OK));

		int[] arr = { 1 };
		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);

		int count = fileUploadDAO.updateDtlsInAppUserForBatch(retailerBean, circleBean, othersBean, "1", "z1", "cat1",
				mobileNolist, 1);
		assertTrue(count == 0);
	}

	@Test
	public void updateUserDtlsSuccess() throws Exception {

		RetailerDetailsBean retailerBean = new RetailerDetailsBean();

		retailerBean.setRetailerNo("7607842100");
		retailerBean.setRetailerName("retailerName");
		retailerBean.setOutletType("Promoter");
		retailerBean.setLongitude("NA");
		retailerBean.setLatitude("NA");
		retailerBean.setVillageName("AB");
		retailerBean.setVillagesType("T");
		retailerBean.setVillagePop("villagePop");
		retailerBean.setCity("city");
		retailerBean.setBlockTehsil("blockTehsil");
		retailerBean.setDistrict("district");
		retailerBean.setSiteId("siteId");
		retailerBean.setCategory("category");

		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");
		OthersHierarchyBean othersBean = new OthersHierarchyBean();

		othersBean.setPromoterLapuNo("7607842101");
		othersBean.setPromoterType("Merchant");
		othersBean.setPromoterName("Deeksah");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("7607842102");
		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("7607842201");
		othersBean.setTlName("Dee");
		othersBean.setTlAgency("AB");
		othersBean.setTlEmployeeID("7607842103");
		othersBean.setTlDob("10-02-2021");
		othersBean.setTlDoj("10-02-2021");
		othersBean.setZoneName("KAnpur");
		othersBean.setZmNo("7607842104");
		othersBean.setZmName("Zmnem");
		othersBean.setRmMsisdn("7607842105");
		othersBean.setRmName("rmName");
		othersBean.setCphNo("7607842106");
		othersBean.setCphName("cphName");
		othersBean.setMmno("7607842109");
		othersBean.setMmname("MMName");
		othersBean.setAction("A");
		ArrayList<String> otherMobilelist = new ArrayList<>();
		otherMobilelist.add("7607842100");
		otherMobilelist.add("7607842101");
		otherMobilelist.add("7607842102");
		otherMobilelist.add("7607842201");
		otherMobilelist.add("7607842103");
		otherMobilelist.add("7607842104");
		otherMobilelist.add("7607842105");
		otherMobilelist.add("7607842106");
		otherMobilelist.add("7607842109");

		when(prop.getProperty(Mockito.anyString())).thenReturn("");

		int[] arr = { 1 };
		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int count = fileUploadDAO.updateUserDtls(1, retailerBean, circleBean, othersBean, otherMobilelist);
		System.out.println("count" + count);
		assertTrue(count > 0);

	}

	@Test
	public void updateUserDtlsLatLOngNASuccess() throws Exception {

		RetailerDetailsBean retailerBean = new RetailerDetailsBean();

		retailerBean.setRetailerNo("7607842100");
		retailerBean.setRetailerName("retailerName");
		retailerBean.setOutletType("Promoter");
		retailerBean.setLongitude("0.0");
		retailerBean.setLatitude("0.0");
		retailerBean.setVillageName("AB");
		retailerBean.setVillagesType("T");
		retailerBean.setVillagePop("villagePop");
		retailerBean.setCity("city");
		retailerBean.setBlockTehsil("blockTehsil");
		retailerBean.setDistrict("district");
		retailerBean.setSiteId("siteId");
		retailerBean.setCategory("category");

		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");
		OthersHierarchyBean othersBean = new OthersHierarchyBean();

		othersBean.setPromoterLapuNo("7607842101");
		othersBean.setPromoterType("Merchant");
		othersBean.setPromoterName("Deeksah");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("7607842102");
		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("7607842201");
		othersBean.setTlName("Dee");
		othersBean.setTlAgency("AB");
		othersBean.setTlEmployeeID("7607842103");
		othersBean.setTlDob("10-02-2021");
		othersBean.setTlDoj("10-02-2021");
		othersBean.setZoneName("KAnpur");
		othersBean.setZmNo("7607842104");
		othersBean.setZmName("Zmnem");
		othersBean.setRmMsisdn("7607842105");
		othersBean.setRmName("rmName");
		othersBean.setCphNo("7607842106");
		othersBean.setCphName("cphName");
		othersBean.setMmno("7607842109");
		othersBean.setMmname("MMName");
		othersBean.setAction("A");
		ArrayList<String> otherMobilelist = new ArrayList<>();
		otherMobilelist.add("7607842100");
		otherMobilelist.add("7607842101");
		otherMobilelist.add("7607842102");
		otherMobilelist.add("7607842201");
		otherMobilelist.add("7607842103");
		otherMobilelist.add("7607842104");
		otherMobilelist.add("7607842105");
		otherMobilelist.add("7607842106");
		otherMobilelist.add("7607842109");

		when(prop.getProperty(Mockito.anyString())).thenReturn("");

		int[] arr = { 1 };
		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int count = fileUploadDAO.updateUserDtls(1, retailerBean, circleBean, othersBean, otherMobilelist);
		System.out.println("count" + count);
		assertTrue(count > 0);

	}

	@Test
	public void updateUserDtlsFail() throws Exception {

		RetailerDetailsBean retailerBean = new RetailerDetailsBean();

		retailerBean.setRetailerNo("7607842100");
		retailerBean.setRetailerName("retailerName");
		retailerBean.setOutletType("Promoter");
		retailerBean.setLongitude("0.0");
		retailerBean.setLatitude("0.0");
		retailerBean.setVillageName("AB");
		retailerBean.setVillagesType("T");
		retailerBean.setVillagePop("villagePop");
		retailerBean.setCity("city");
		retailerBean.setBlockTehsil("blockTehsil");
		retailerBean.setDistrict("district");
		retailerBean.setSiteId("siteId");
		retailerBean.setCategory("category");

		CircleMasterBean circleBean = new CircleMasterBean();
		circleBean.setCircleName("UP");
		circleBean.setCircleCode("c123");

		OthersHierarchyBean othersBean = new OthersHierarchyBean();

		othersBean.setPromoterLapuNo("7607842101");
		othersBean.setPromoterType("Merchant");
		othersBean.setPromoterName("Deeksah");
		othersBean.setPromoterAgency("ABC");
		othersBean.setPromoterEmployeeID("7607842102");
		othersBean.setPromoterDob("10-02-2021");
		othersBean.setPromoterDoj("10-02-2021");
		othersBean.setTlNo("7607842201");
		othersBean.setTlName("Dee");
		othersBean.setTlAgency("AB");
		othersBean.setTlEmployeeID("7607842103");
		othersBean.setTlDob("10-02-2021");
		othersBean.setTlDoj("10-02-2021");
		othersBean.setZoneName("KAnpur");
		othersBean.setZmNo("7607842104");
		othersBean.setZmName("Zmnem");
		othersBean.setRmMsisdn("7607842105");
		othersBean.setRmName("rmName");
		othersBean.setCphNo("7607842106");
		othersBean.setCphName("cphName");
		othersBean.setMmno("7607842109");
		othersBean.setMmname("MMName");
		othersBean.setAction("A");
		ArrayList<String> otherMobilelist = new ArrayList<>();

		when(prop.getProperty(Mockito.anyString())).thenReturn("");

		int[] arr = { 1 };
		when(jdbctemplate.batchUpdate(Mockito.anyString(), Mockito.anyList())).thenReturn(arr);

		when(jdbctemplate.update(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(1);

		int count = fileUploadDAO.updateUserDtls(1, retailerBean, circleBean, othersBean, otherMobilelist);
		System.out.println("count" + count);
		assertTrue(count == 0);
	}
}
