package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dto.FileEnquiryRequest;
import com.airtelbank.admin.service.FileUploadService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class FileUploadControllerTest {
    @InjectMocks
    FileUploadController fileUploadController;


    @Mock
    FileUploadService fileUploadService;

    @Autowired
    PropertyManager prop;

    @Mock
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @Mock
    HttpServletRequest httpServletRequest;

    @Test
    public void uploadKPICSVDetails_v2_Success() throws Exception {
        File file = new File("src/test/resources/Promoter_KPI_MST.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "text/plain",
                IOUtils.toByteArray(input));

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("UPLOAD_RETAIL_FILE_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        Mockito.when(fileUploadService.kpiUploadDetailsv2(multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = fileUploadController.uploadKPICSVDetails_v2(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

    @Test
    public void uploadKPICSVDetails_v2_Fail() throws Exception {
        File file = new File("src/test/resources/Promoter_KPI_MST_EMPTY.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "text/plain",
                IOUtils.toByteArray(input));

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        Mockito.when(fileUploadService.kpiUploadDetailsv2(multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = fileUploadController.uploadKPICSVDetails_v2(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", response.getStatusCode());

    }

    @Test
    public void uploadKPICSVDetails_v2_Exception() throws Exception {
        File file = new File("src/test/resources/Promoter_KPI_MST_EMPTY.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "text/plain",
                IOUtils.toByteArray(input));

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        Mockito.when(fileUploadService.kpiUploadDetailsv2(multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = fileUploadController.uploadKPICSVDetails_v2(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", response.getStatusCode());

    }

    @Test
    public void uploadRetailerCSVDetails1Success() throws Exception {
        File file = new File("src/test/resources/promoter.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("UPLOAD_RETAIL_FILE_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        Mockito.when(fileUploadService.retailerUploadDetails(multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        String payload = "{\"mobileno\":\"7006980036\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        ResponseEntity<Object> responseEntity = fileUploadController.uploadRetailerCSVDetails1(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

    @Test
    public void uploadRetailerCSVDetails1InvalidRequest() throws Exception {
        JSONObject json = new JSONObject();
        File file = new File("src/test/resources/promoter.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(json);

        Mockito.when(fileUploadService.retailerUploadDetails(multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        String payload = "{\"mobileno\":\"7006980036\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        ResponseEntity<Object> responseEntity = fileUploadController.uploadRetailerCSVDetails1(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }


    @Test
    public void uploadRetailerCSVDetails1EmptyRequest() throws Exception {
        JSONObject json = new JSONObject();
        File file = new File("src/test/resources/promoter.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(json);

        Mockito.when(fileUploadService.retailerUploadDetails(multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        String payload = "{\"mobileno\":\"\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        ResponseEntity<Object> responseEntity = fileUploadController.uploadRetailerCSVDetails1(multipartFile);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    public void uploadRetailerCSVDetails1_Exception() throws Exception {
        JSONObject json = new JSONObject();
        File file = new File("src/test/resources/promoter.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(json);

        Mockito.when(fileUploadService.retailerUploadDetails(multipartFile)).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = fileUploadController.uploadRetailerCSVDetails1(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }


//    @Test
//    @Ignore
//    public void uploadPromoterCSVDetailsSuccess() throws Exception {
//        File file = new File("src/test/resources/promoter.csv");
//        FileInputStream input = new FileInputStream(file);
//        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
//                IOUtils.toByteArray(input));
//
//        SnapWorkResponse response = new SnapWorkResponse();
//        response.setMessage(prop.getProperty("SUCCESS"));
//        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
//        JSONObject json = new JSONObject();
//
//        response.setResponse(json);
//
//        Mockito.when(fileUploadService.uploadPromoterCSVDetails(multipartFile, "PR","7006980036")).thenReturn(response);
//
//        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
//
//        String payload = "{\"mobileno\":\"7006980036\"}";
//        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);
//
//        ResponseEntity<Object> responseEntity = fileUploadController.uploadPromoterCSVDetails(multipartFile, "PR");
//
//        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
//
//        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
//
//    }

    //@Test
    public void uploadPromoterCSVDetailsFail() throws Exception {
        File file = new File("src/test/resources/promoter.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
        response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
        JSONObject json = new JSONObject();

        response.setResponse(json);

        Mockito.when(fileUploadService.uploadPromoterCSVDetails(multipartFile, "PR","7006980036")).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        String payload = "{\"mobileno\":\"\"}";
        Mockito.when(httpServletRequest.getHeader("jwt_payload")).thenReturn(payload);

        ResponseEntity<Object> responseEntity = fileUploadController.uploadPromoterCSVDetails(multipartFile, "PR");

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());

    }

//    @Test
//    public void uploadPromoterCSVDetailsException() throws Exception {
//        JSONObject json = new JSONObject();
//        File file = new File("src/test/resources/promoter.csv");
//        FileInputStream input = new FileInputStream(file);
//        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
//                IOUtils.toByteArray(input));
//
//        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
//        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
//        Mockito.when(response.getResponse()).thenReturn(json);
//
//        Mockito.when(fileUploadService.uploadPromoterCSVDetails(multipartFile, "PR")).thenReturn(response);
//
//        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
//
//        ResponseEntity<Object> responseEntity = fileUploadController.uploadPromoterCSVDetails(null, "PR");
//
//        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();
//
//        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
//    }

    @Test
    public void enquirePromoterCSVDetails_Success() throws Exception {
        JSONObject json = new JSONObject();

        File file = new File("src/test/resources/promoter.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        FileEnquiryRequest request = new FileEnquiryRequest();
        request.setFileName(multipartFile.getName());

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("DATA_WAS_UPLOADED_SUCCESSFULLY"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("SUCCESS_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(json);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        Mockito.when(fileUploadService.enquirePromoterCSVDetails(
                Mockito.anyString())).thenReturn(response);

        ResponseEntity<Object> responseEntity =
                fileUploadController.enquirePromoterCSVDetails(request);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }
    @Test
    public void enquirePromoterCSVDetailsException() throws Exception {
        JSONObject json = new JSONObject();

        File file = new File("src/test/resources/promoter.csv");
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "multipart/form-data",
                IOUtils.toByteArray(input));

        FileEnquiryRequest request = new FileEnquiryRequest();
        request.setFileName(multipartFile.getName());

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(json);

        Mockito.when(fileUploadService.enquirePromoterCSVDetails(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = fileUploadController.enquirePromoterCSVDetails(null);

        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    public void downloadException() throws Exception {

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

            Mockito.doReturn(null).when(fileUploadService).downloadPromoterCSVDetails("file.csv");
   java.lang.NullPointerException thrown = assertThrows(
           java.lang.NullPointerException.class,
            () -> fileUploadController.download(null),
            "testing.");
    assertTrue(thrown.toString().contains("NullPointerException"));
    }

}
