package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.ComplianceService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class ComplianceControllerTest
{
    @InjectMocks
    ComplianceController complianceController;

    @Mock
    ComplianceService complianceService;

    @Autowired
    PropertyManager prop;

    @Mock
    PropertyManager propMock;

    @Mock
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @Test
    void fetchComplianceDetails_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9897108404");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setStartDate("01-01-2020");
        snapWorkRequest.setEndDate("16-02-2021");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("COMPLIANCE_FETCH_DTLS_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(complianceService.viewComplianceDetails(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                complianceController.fetchComplianceDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    void fetchComplianceDetails_Fail()
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("");
        snapWorkRequest.setCircleId("");
        snapWorkRequest.setZoneId("");
        snapWorkRequest.setStartDate("");
        snapWorkRequest.setEndDate("");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                complianceController.fetchComplianceDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    void fetchComplianceDetails_Fail_1()
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName(null);
        snapWorkRequest.setCircleId(null);
        snapWorkRequest.setZoneId(null);
        snapWorkRequest.setStartDate(null);
        snapWorkRequest.setEndDate(null);

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity =
                complianceController.fetchComplianceDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    void fetchComplianceDetails_throwException()
    {
        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_ERROR_MESSAGE"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));

        ResponseEntity<Object> responseEntity =
                complianceController.fetchComplianceDetails(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

   // @Test
    public void dashboardOnLoadDetails_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("7006980034");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("ADMIN_LOGOUT_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(complianceService.onloadDashboardDetails(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = complianceController.dashboardOnLoadDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    public void dashboardOnLoadDetails_Fail() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName(" ");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = complianceController.dashboardOnLoadDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void dashboardOnLoadDetails_Fail_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName(null);
        snapWorkRequest.setCircleId(null);
        snapWorkRequest.setZoneId(null);
        snapWorkRequest.setStartDate(null);
        snapWorkRequest.setEndDate(null);

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = complianceController.dashboardOnLoadDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals( "500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void public_throwException()
    {
        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = complianceController.dashboardOnLoadDetails(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void downloadComplianceDetails_Success() throws Exception
    {
        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn("");
        Mockito.when(response.getStatusCode()).thenReturn("");
        Mockito.when(response.getResponse()).thenReturn(null);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        Mockito.when(complianceService.downloadComplianceDetails(
                Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyBoolean())).thenReturn(1);

        ResponseEntity<Object> responseEntity =
                complianceController.downloadComplianceDetails("abc", "def", "ghi", httpResponse);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertNotNull(snapWorkResponse);
    }

    @Test
    public void downloadComplianceDetails_Fail() throws Exception
    {
        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(new JSONObject());

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = complianceController.downloadComplianceDetails("", "", "", httpResponse);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    public void downloadComplianceDetails_ThrowExeption() throws Exception
    {
        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn(prop.getProperty("FAILURE_STATUS_CODE"));
        Mockito.when(response.getResponse()).thenReturn(new JSONObject());

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");
        Mockito.when(complianceService.downloadComplianceDetails(
                Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyBoolean())).thenReturn(1);

        ResponseEntity<Object> responseEntity = complianceController.downloadComplianceDetails(null, null, null, null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals( response.getStatusCode(), snapWorkResponse.getStatusCode());
    }
}