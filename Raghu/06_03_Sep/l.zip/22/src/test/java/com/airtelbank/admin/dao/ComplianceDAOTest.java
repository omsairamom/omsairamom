package com.airtelbank.admin.dao;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.PropertyManager;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest
class ComplianceDAOTest
{
	@Autowired
	ComplianceDAO complianceDAO;
	
	@MockBean  
	JdbcTemplate jdbctemplate;

	@MockBean
	PropertyManager prop;

	@Test
	public void fetchComplRetailerDetails() throws Exception
	{
		SnapWorkRequest request = new SnapWorkRequest();
		request.setCircleId("All");
		request.setZoneId("All");
		request.setStartDate("12/2/2021");
		request.setEndDate("13/2/2021");
		
		
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CIRCLE_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = complianceDAO.fetchComplRetailerDetails(request);
		assertTrue(!row.equals(""));
	}

	@Test
	public void fetchComplRetailerDetails_Null() throws Exception
	{
		SnapWorkRequest request = new SnapWorkRequest();
		request.setCircleId(null);
		request.setZoneId(null);
		request.setStartDate(null);
		request.setEndDate(null);

		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CIRCLE_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = complianceDAO.fetchComplRetailerDetails(request);
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchComplRetailerDetails_1() throws Exception
	{
		SnapWorkRequest request = new SnapWorkRequest();
		request.setCircleId("All");
		request.setZoneId("1");
		request.setStartDate("12/2/2021");
		request.setEndDate("13/2/2021");
		
		
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CIRCLE_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = complianceDAO.fetchComplRetailerDetails(request);
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchComplRetailerDetails_2() throws Exception
	{
		SnapWorkRequest request = new SnapWorkRequest();
		request.setCircleId("1");
		request.setZoneId("All");
		request.setStartDate("12/2/2021");
		request.setEndDate("13/2/2021");
		
		
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CIRCLE_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = complianceDAO.fetchComplRetailerDetails(request);
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void fetchComplRetailerDetails_3() throws Exception
	{
		SnapWorkRequest request = new SnapWorkRequest();
		request.setCircleId("1");
		request.setZoneId("1");
		request.setStartDate("12/2/2021");
		request.setEndDate("13/2/2021");
		
		
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CIRCLE_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = complianceDAO.fetchComplRetailerDetails(request);
		assertTrue(!row.equals(""));
	}
}
