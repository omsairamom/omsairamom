package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.*;
import com.airtelbank.admin.service.AdminReportService;
import com.airtelbank.admin.service.AppVersionService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.KibanaLoggerUtils;
import com.airtelbank.admin.util.PropertyManager;
import com.airtelbank.admin.util.RestClientUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AppVersionServiceImplTest
{
    @Autowired
    AppVersionService appVersionService;

    @Autowired
    PropertyManager prop;

    @MockBean
    AppVersionDAO appVersionDao;

    @MockBean
    CommonUtils commonUtil;

    @Autowired
    SnapWorkResponse response;

    @Autowired
    RestClientUtil restClient;

    @Autowired
    KibanaLoggerUtils kibanaLoggerObj;

    @Autowired
    SnapWorkRequest request;

    @Test
    void onLoadAppVersionDetails_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9000011462");

        Map<String, Object> catRow = new HashMap<>();
        catRow.put("USER_AGENT", "9718056667");
        catRow.put("LOAD_FLAG", "Abhishek Saxena");
        catRow.put("MANDATORY", "8975645342");
        catRow.put("APP_MESSAGE", "8975645342");
        catRow.put("URL", "8975645342");

        List<Map<String, Object>> catRows = new ArrayList<>();
        catRows.add(catRow);

        Mockito.when(appVersionDao.fetchAppVersionDetails()).thenReturn(catRows);

        SnapWorkResponse snapWorkResponse =
                appVersionService.onLoadAppVersionDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("APPVER_FETCH_DTLS_SUCC_MSG"));

        System.out.println(snapWorkResponse.getMessage() + " ==== " + prop.getProperty("APPVER_FETCH_DTLS_SUCC_MSG"));
    }

    @Test
    void onLoadAppVersionDetails_Success_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9000011462");

        Map<String, Object> catRow = new HashMap<>();
        catRow.put("USER_AGENT", null);
        catRow.put("LOAD_FLAG", null);
        catRow.put("MANDATORY", null);
        catRow.put("APP_MESSAGE", null);
        catRow.put("URL", null);

        List<Map<String, Object>> catRows = new ArrayList<>();
        catRows.add(catRow);

        Mockito.when(appVersionDao.fetchAppVersionDetails()).thenReturn(catRows);

        SnapWorkResponse snapWorkResponse =
                appVersionService.onLoadAppVersionDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("APPVER_FETCH_DTLS_SUCC_MSG"));

        System.out.println(snapWorkResponse.getMessage() + " ==== " + prop.getProperty("APPVER_FETCH_DTLS_SUCC_MSG"));
    }

    @Test
    void onLoadAppVersionDetails_Fail() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("");

        SnapWorkResponse snapWorkResponse =
                appVersionService.onLoadAppVersionDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("FAILURE_INVALID_REQUEST"));

        System.out.println(snapWorkResponse.getMessage() + " ==== " + prop.getProperty("FAILURE_INVALID_REQUEST"));
    }


    @Test
    void onLoadAppVersionDetails_Fail_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName(null);

        SnapWorkResponse snapWorkResponse =
                appVersionService.onLoadAppVersionDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("FAILURE_INVALID_REQUEST"));

        System.out.println(snapWorkResponse.getMessage() + " ==== " + prop.getProperty("FAILURE_INVALID_REQUEST"));
    }

    @Test
    void onLoadAppVersionDetails_Exception() throws Exception
    {
        SnapWorkResponse snapWorkResponse =
                appVersionService.onLoadAppVersionDetails(null);

        assertEquals("Server Error, please try after sometime.", snapWorkResponse.getMessage());

        System.out.println(snapWorkResponse.getMessage() + " ==== " + "Server Error, please try after sometime.");
    }
}