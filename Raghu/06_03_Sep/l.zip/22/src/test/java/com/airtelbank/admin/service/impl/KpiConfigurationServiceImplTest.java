package com.airtelbank.admin.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.airtelbank.admin.util.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.KpiConfigurationDAO;
import com.airtelbank.admin.service.KpiConfigurationService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.KibanaLoggerUtils;
import com.airtelbank.admin.util.PropertyManager;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class KpiConfigurationServiceImplTest
{
	@Autowired
	PropertyManager prop;

	@Autowired
	SnapWorkResponse response;

	@Autowired
	KpiConfigurationService kpiConfigurationService;

	@Autowired
	SnapWorkRequest request;

	@MockBean
	KpiConfigurationDAO kpiConfigDao;

	@MockBean
	CommonUtils commonUtil;

	@Autowired
	KibanaLoggerUtils kibanaLoggerObj;

	@Test
	public void kpiConfigurationDtlsSuccess() throws Exception {

		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setMobileNo("9000011462");
		snapWorkRequest.setPromoterType("Combined");
		snapWorkRequest.setAction("add");
		snapWorkRequest.setKpiName("TESTINGKPI");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("10");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setVer("1.0");
		snapWorkRequest.setChannel("PWEB");
		snapWorkRequest.setFeSessionId("abz12");

		when(kpiConfigDao.getStartDate()).thenReturn("10-02-2021");
		when(kpiConfigDao.getEndDate()).thenReturn("20-02-2021");
		when(kpiConfigDao.getWeightageSum("ABM")).thenReturn(90);
		when(kpiConfigDao.saveKpiConfigDtls(Mockito.any(), Mockito.anyString(), Mockito.anyString())).thenReturn(1);

		response = kpiConfigurationService.kpiConfigurationDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_SAVE_DTLS_SUCC_MSG"), response.getMessage());

	}

	@Test
	public void kpiConfigurationDtlslimitExceed() throws Exception {
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setMobileNo("9000011462");
		snapWorkRequest.setPromoterType("Combined");
		snapWorkRequest.setAction("add");
		snapWorkRequest.setKpiName("TESTINGKPI");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("10");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setVer("1.0");
		snapWorkRequest.setChannel("PWEB");
		snapWorkRequest.setFeSessionId("abz12");

		when(kpiConfigDao.getStartDate()).thenReturn("10-02-2021");
		when(kpiConfigDao.getEndDate()).thenReturn("20-02-2021");
		when(kpiConfigDao.getWeightageSum("ABM")).thenReturn(110);

		response = kpiConfigurationService.kpiConfigurationDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_WEIGHT_AGE_FAIL_MSG"), response.getMessage());
	}

	@Test
	public void kpiConfigurationDtlsNotSave() throws Exception {
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setMobileNo("9000011462");
		snapWorkRequest.setPromoterType("Combined");
		snapWorkRequest.setAction("add");
		snapWorkRequest.setKpiName("TESTINGKPI");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("10");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setVer("1.0");
		snapWorkRequest.setChannel("PWEB");
		snapWorkRequest.setFeSessionId("abz12");

		when(kpiConfigDao.getStartDate()).thenReturn("10-02-2021");
		when(kpiConfigDao.getEndDate()).thenReturn("20-02-2021");
		when(kpiConfigDao.getWeightageSum("ABM")).thenReturn(80);
		when(kpiConfigDao.saveKpiConfigDtls(Mockito.any(), Mockito.anyString(), Mockito.anyString())).thenReturn(0);

		response = kpiConfigurationService.kpiConfigurationDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_SAVE_DTLS_FAIL_MSG"), response.getMessage());

	}

	@Test
	public void kpiConfigurationDtlsUpdateSuccess() throws Exception {
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setMobileNo("9000011462");
		snapWorkRequest.setPromoterType("Combined");
		snapWorkRequest.setAction("update");
		snapWorkRequest.setKpiName("TESTINGKPI");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("10");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setVer("1.0");
		snapWorkRequest.setChannel("PWEB");
		snapWorkRequest.setFeSessionId("abz12");

		when(kpiConfigDao.getStartDate()).thenReturn("10-02-2021");
		when(kpiConfigDao.getEndDate()).thenReturn("20-02-2021");
		when(kpiConfigDao.getWeightageSum("ABM")).thenReturn(90);
		when(kpiConfigDao.updateKpiConfigDtls(Mockito.any())).thenReturn(1);

		response = kpiConfigurationService.kpiConfigurationDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_LESS_WEIGHT_AGE_SUCC_MSG"), response.getMessage());

	}

	@Test
	public void kpiConfigurationDtlsUpdateWeighageExceed() throws Exception {
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setMobileNo("9000011462");
		snapWorkRequest.setPromoterType("Combined");
		snapWorkRequest.setAction("update");
		snapWorkRequest.setKpiName("TESTINGKPI");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("10");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setVer("1.0");
		snapWorkRequest.setChannel("PWEB");
		snapWorkRequest.setFeSessionId("abz12");

		when(kpiConfigDao.getStartDate()).thenReturn("10-02-2021");
		when(kpiConfigDao.getEndDate()).thenReturn("20-02-2021");
		when(kpiConfigDao.getWeightageSum("ABM")).thenReturn(190);
		when(kpiConfigDao.updateKpiConfigDtls(Mockito.any())).thenReturn(1);

		response = kpiConfigurationService.kpiConfigurationDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_LESS_WEIGHT_AGE_SUCC_MSG"), response.getMessage());

	}

	@Test
	public void kpiConfigurationDtlsUpdateFail() throws Exception {
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setMobileNo("9000011462");
		snapWorkRequest.setPromoterType("Combined");
		snapWorkRequest.setAction("update");
		snapWorkRequest.setKpiName("TESTINGKPI");
		snapWorkRequest.setWeightAge("10");
		snapWorkRequest.setTarget("10");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setVer("1.0");
		snapWorkRequest.setChannel("PWEB");
		snapWorkRequest.setFeSessionId("abz12");

		when(kpiConfigDao.getStartDate()).thenReturn("10-02-2021");
		when(kpiConfigDao.getEndDate()).thenReturn("20-02-2021");
		when(kpiConfigDao.getWeightageSum("ABM")).thenReturn(190);
		when(kpiConfigDao.updateKpiConfigDtls(Mockito.any())).thenReturn(0);

		response = kpiConfigurationService.kpiConfigurationDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_WEIGHT_AGE_FAIL_MSG"), response.getMessage());

	}


	@Test
	public void kpiConfigurationDtlsStatusEnableY() throws Exception {
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setCategoryName("ABM");
		snapWorkRequest.setMobileNo("9000011462");
		snapWorkRequest.setPromoterType("Combined");
		snapWorkRequest.setAction("update");
		snapWorkRequest.setKpiName("TESTINGKPI");
		snapWorkRequest.setWeightAge("100");
		snapWorkRequest.setTarget("10");
		snapWorkRequest.setStatusEnable("Y");
		snapWorkRequest.setVer("1.0");
		snapWorkRequest.setChannel("PWEB");
		snapWorkRequest.setFeSessionId("abz12");

		when(kpiConfigDao.getStartDate()).thenReturn("10-02-2021");
		when(kpiConfigDao.getEndDate()).thenReturn("20-02-2021");
		when(kpiConfigDao.getWeightageSum("ABM")).thenReturn(120);

		when(kpiConfigDao.getKpiTargetDtlsFromDb(Mockito.any())).thenReturn("10");
		when(kpiConfigDao.getUpdatedWeightageSum(Mockito.anyString(), Mockito.anyString())).thenReturn(100);

		when(kpiConfigDao.updateKpiConfigDtls(Mockito.any())).thenReturn(1);

		response = kpiConfigurationService.kpiConfigurationDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_UPDATE_DTLS_SUCC_MSG"), response.getMessage());

	}

	@Test
	public void kpiConfigurationDtlsThrowException() throws Exception {
		response = kpiConfigurationService.kpiConfigurationDtls(null);

		assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());

	}

	@Test
	public void fetchKpiConfigurationOnloadDtlsSuccessTest() throws Exception
	{
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setMobileNo("7006980034");

		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("CAT_ID", "1");
		map.put("CAT_NAME", "Account");
		map.put("KPI_ID", "1");
		map.put("KPI_TYPE", "abc");
		map.put("TARGET", "100");
		map.put("WEIGHT_AGE", "23");
		map.put("STATUS_ENABLE", "Y");
		map.put("START_DATE", "02/12/2020");
		map.put("END_DATE", "01/02/2021");
		map.put("PROMOTER_TYPE", "Combined");
		list.add(map);

		when(kpiConfigDao.fetchKpiConfigDtls()).thenReturn(list);

		SnapWorkResponse response = kpiConfigurationService.fetchKpiConfigurationOnloadDtls(snapWorkRequest);

		assertEquals(prop.getProperty("KPI_CONFIG_FETCH_DTLS_SUCC_MSG"), response.getMessage());

		System.out.print(" " + prop.getProperty("KPI_CONFIG_FETCH_DTLS_SUCC_MSG") + " " + response.getMessage());
	}

	@Test
	public void fetchKpiConfigurationOnloadDtls_FailTest() throws Exception {
		SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
		snapWorkRequest.setMobileNo(" ");

		SnapWorkResponse response = kpiConfigurationService.fetchKpiConfigurationOnloadDtls(snapWorkRequest);

		assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"), response.getMessage());

		System.out.print(" " + prop.getProperty("FAILURE_INVALID_REQUEST") + " " + response.getMessage());

	}

	@Test
	public void when_fetchKpiConfigurationOnloadDtls_Then_ThrowExceptionTest() throws Exception
	{
		SnapWorkResponse response = kpiConfigurationService.fetchKpiConfigurationOnloadDtls(null);

		assertEquals(response.getMessage(), prop.getProperty("FAILURE_ERROR_MESSAGE"));

		System.out.print(" " + prop.getProperty("FAILURE_ERROR_MESSAGE") + " " + response.getMessage());
	}

	@Test
	public void fetchKpiConfigurationGetPromoterType_Success() throws Exception
	{
		Map<String, Object> catRow = new HashMap<>();
		catRow.put(Constants.PROMOTER_TYPE, "9718056667");

		Map<String, Object> catRow_1 = new HashMap<>();
		catRow_1.put(Constants.PROMOTER_TYPE, "9897108505");

		List<Map<String, Object>> catRows  = new ArrayList<>();
		catRows.add(catRow);
		catRows.add(catRow_1);

		Mockito.when(kpiConfigDao.fetchKpiConfigurationGetPromoterType(Mockito.anyString()))
				.thenReturn(catRows);

		SnapWorkResponse response =
				kpiConfigurationService.fetchKpiConfigurationGetPromoterType("1");

		assertEquals(prop.getProperty(Constants.KPI_CONFIG_FETCH_PROMOTER_TYPE), response.getMessage());

		System.out.print(prop.getProperty(Constants.KPI_CONFIG_FETCH_PROMOTER_TYPE) + " " + response.getMessage());
	}

	@Test
	public void fetchKpiConfigurationGetPromoterType_Fail_1() throws Exception
	{
		List<Map<String, Object>> catRows  = new ArrayList<>();

		Mockito.when(kpiConfigDao.fetchKpiConfigurationGetPromoterType(Mockito.anyString()))
				.thenReturn(catRows);

		SnapWorkResponse response =
				kpiConfigurationService.fetchKpiConfigurationGetPromoterType("1");

		assertEquals(prop.getProperty(Constants.FAILURE_NOT_FOUND), response.getMessage());

		System.out.print(prop.getProperty(Constants.FAILURE_NOT_FOUND) + " " + response.getMessage());
	}

	@Test
	public void fetchKpiConfigurationGetPromoterType_Fail_2() throws Exception
	{
		SnapWorkResponse response =
				kpiConfigurationService.fetchKpiConfigurationGetPromoterType("");

		assertEquals(prop.getProperty(Constants.FAILURE_INVALID_REQUEST), response.getMessage());

		System.out.print(prop.getProperty(Constants.FAILURE_INVALID_REQUEST) + " " + response.getMessage());
	}

	@Test
	public void fetchKpiConfigurationGetPromoterType_Exception() throws Exception
	{


		SnapWorkResponse response =
				kpiConfigurationService.fetchKpiConfigurationGetPromoterType(null);

		assertEquals(response.getMessage(), prop.getProperty(Constants.FAILURE_INVALID_REQUEST));

		System.out.print(response.getMessage() +" "+ prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
	}
}
