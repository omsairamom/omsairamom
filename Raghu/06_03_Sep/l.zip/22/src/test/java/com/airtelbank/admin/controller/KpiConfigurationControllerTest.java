package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.KpiConfigurationService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class KpiConfigurationControllerTest
{
    @InjectMocks
    KpiConfigurationController kpiConfigurationController;

    @Mock
    KpiConfigurationService kpiConfiguraService;

    @Autowired
    PropertyManager prop;

    @Mock
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @Test
    public void kpiConfigurationDetails_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980034");
        snapWorkRequest.setCategoryName("Accnt Opening");
        snapWorkRequest.setKpiName("Banking");
        snapWorkRequest.setWeightAge("90");
        snapWorkRequest.setTarget("80");
        snapWorkRequest.setStatusEnable("Y");
        snapWorkRequest.setAction("Y");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("KPI_CONFIG_SAVE_DTLS_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(kpiConfiguraService.kpiConfigurationDtls(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController.kpiConfigurationDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    public void kpiConfigurationDetails_Fail() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");
        snapWorkRequest.setCategoryName("");
        snapWorkRequest.setKpiName("");
        snapWorkRequest.setWeightAge("");
        snapWorkRequest.setTarget("");
        snapWorkRequest.setStatusEnable("");
        snapWorkRequest.setAction("");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController.kpiConfigurationDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void kpiConfigurationDetails_Fail_1() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(null);
        snapWorkRequest.setCategoryName(null);
        snapWorkRequest.setKpiName(null);
        snapWorkRequest.setWeightAge(null);
        snapWorkRequest.setTarget(null);
        snapWorkRequest.setStatusEnable(null);
        snapWorkRequest.setAction(null);

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController.kpiConfigurationDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void kpiConfigurationDetails_throwException() {

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = kpiConfigurationController.kpiConfigurationDetails(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void fetchKpiConfigurationOnloadDetails_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980034");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty("KPI_CONFIG_FETCH_DTLS_SUCC_MSG"));
        response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
        response.setResponse(jsonObject);

        Mockito.when(kpiConfiguraService.fetchKpiConfigurationOnloadDtls(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController
                .fetchKpiConfigurationOnloadDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    public void fetchKpiConfigurationOnloadDetails_Fail() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController
                .fetchKpiConfigurationOnloadDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());

    }

    @Test
    public void fetchKpiConfigurationOnloadDetails_Fail_1() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo(null);

        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController
                .fetchKpiConfigurationOnloadDetails(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void fetchKpiConfigurationOnloadDetails_throwException() {
        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = kpiConfigurationController.fetchKpiConfigurationOnloadDetails(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void fetchKpiConfigurationGetPromoterType_Success() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setCategoryId("2");

        JSONObject jsonObject = new JSONObject();

        SnapWorkResponse response = new SnapWorkResponse();
        response.setMessage(prop.getProperty(Constants.KPI_CONFIG_FETCH_PROMOTER_TYPE));
        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setResponse(jsonObject);

        Mockito.when(kpiConfiguraService.fetchKpiConfigurationGetPromoterType(Mockito.any())).thenReturn(response);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController
                .fetchKpiConfigurationGetPromoterType(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals(response.getStatusCode(), snapWorkResponse.getStatusCode());
    }

    @Test
    public void fetchKpiConfigurationGetPromoterType_Fail() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setCategoryId("");

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController
                .fetchKpiConfigurationGetPromoterType(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void fetchKpiConfigurationGetPromoterType_Fail_1() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setCategoryId(null);

        Mockito.when(response.getMessage()).thenReturn("Invalid Request Parameters");
        Mockito.when(response.getStatusCode()).thenReturn("500");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        ResponseEntity<Object> responseEntity = kpiConfigurationController
                .fetchKpiConfigurationGetPromoterType(snapWorkRequest);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }

    @Test
    public void fetchKpiConfigurationGetPromoterType_throwException() throws Exception {
        Mockito.when(response.getMessage()).thenReturn(prop.getProperty("FAILURE_INVALID_REQUEST"));
        Mockito.when(response.getStatusCode()).thenReturn("500");

        ResponseEntity<Object> responseEntity = kpiConfigurationController.fetchKpiConfigurationGetPromoterType(null);
        SnapWorkResponse snapWorkResponse = (SnapWorkResponse) responseEntity.getBody();

        assertEquals("500", snapWorkResponse.getStatusCode());
    }
}