package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.bean.MarketVisitBean;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.AdminReportDAO;
import com.airtelbank.admin.service.AdminReportService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import com.airtelbank.admin.util.SecureBuilderVer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AdminReportServiceImplTest
{

    @Autowired
    AdminReportServiceImpl adminReportServiceImpl;

    @Autowired
    PropertyManager prop;

    @MockBean
    AdminReportDAO adminReportDAO;

    @MockBean
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @Autowired
    SnapWorkResponse snapWorkResponse;

    @Mock
    SecureBuilderVer secureBuilderVer_1;

    SecureBuilderVer secureBuilderVer = mock(SecureBuilderVer.class);

    @Test
    void dashboardMarketVisitDetails_Success() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9000011462");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setCircleName("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setZoneName("All");
        snapWorkRequest.setRoleId("All");
        snapWorkRequest.setRoleName("All");
        snapWorkRequest.setCategoryId("All");
        snapWorkRequest.setCategoryName("All");
        snapWorkRequest.setStartDate("01-01-2021");
        snapWorkRequest.setEndDate("31-01-2021");
        snapWorkRequest.setVer("0");
        snapWorkRequest.setChannel("PWEB");
        snapWorkRequest.setFeSessionId("PWEBxPQOtmtmK97K9");

        Map<String, Object> catRow = new HashMap<>();
        catRow.put("PROMTR_MOBNO", "9718056667");
        catRow.put("USER_NAME", "Abhishek Saxena");
        catRow.put("LAPU_NO", "8975645342");

        Map<String, Object> catRow_1 = new HashMap<>();
        catRow_1.put("PROMTR_MOBNO", "9897108505");
        catRow_1.put("USER_NAME", "Varun2");
        catRow_1.put("LAPU_NO", "7042709703");

        Map<String, Object> catRow_2 = new HashMap<>();
        catRow_2.put("PROMTR_MOBNO", "9897108404");
        catRow_2.put("USER_NAME", "xyz1");
        catRow_2.put("LAPU_NO", "7042709702");

        Map<String, Object> catRow_3 = new HashMap<>();
        catRow_3.put("PROMTR_MOBNO", "9897108505");
        catRow_3.put("USER_NAME", "Varun2");
        catRow_3.put("LAPU_NO", "8975645342");

        List<Map<String, Object>> catRows  = new ArrayList<>();
        catRows.add(catRow);
        catRows.add(catRow_1);
        catRows.add(catRow_2);
        catRows.add(catRow_3);

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        Mockito.when(adminReportDAO.fetchMarketVisitedRetailerDetails(Mockito.anyString())).thenReturn("Deeksha");
        Mockito.when(adminReportDAO.getOutletVisistedCount(Mockito.anyString(), Mockito.anyString())).thenReturn(10);

        Map<String, Object> checkinoutdtl = new HashMap<>();
        catRow_3.put("IN_OR_OUT", "0");

        Map<String, Object> checkinoutdt2 = new HashMap<>();
        catRow_3.put("IN_OR_OUT", "1");

        List<Map<String, Object>> list = new ArrayList<>();
        list.add(checkinoutdtl);
        list.add(checkinoutdt2);

        Mockito.when(adminReportDAO.fetchMarketVisitedCheckInDetails
                (Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);

        Map<String, Object> checkInRows = new HashMap<>();
        checkInRows.put("LATITUDE", "05:50");
        checkInRows.put("LONGITUDE", "-122.084");
        checkInRows.put("LAPU_NO", "1");
        checkInRows.put("DATE_OF_VISIT", "1");
        checkInRows.put("DISP_DATE", "1");
        checkInRows.put("Check_In", "05:50");
        checkInRows.put("Check_In_Lat", "1");
        checkInRows.put("Check_In_Long", "1");
        checkInRows.put("Date", "1");

        List<Map<String, Object>> list_1 = new ArrayList<>();
        list_1.add(checkInRows);
        Mockito.when(adminReportDAO.fetchCheckInDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list_1);

        Mockito.when(adminReportDAO.fetchCheckOutDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list_1);

        Map<String, Object> latlngdtls = new HashMap<>();
        latlngdtls.put("LATITUDE", "05:50");
        latlngdtls.put("LONGITUDE", "-122.084");
        latlngdtls.put("PROMOTER_LATITUDE", "-122.084");
        latlngdtls.put("PROMOTER_LONGITUDE", "-122.084");

        List<Map<String, Object>> latlngdtls_list = new ArrayList<>();
        latlngdtls_list.add(latlngdtls);

        Mockito.when(adminReportDAO.getLatLongDtls(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(latlngdtls_list);

        Mockito.when(commonUtil.calculateMarketDistance(
                "37.421998", "37.421998",
                "37.421998", "37.421998")).thenReturn(0.00);

        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.dashboardMarketVisitDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("ADMIN_FETCH_MARKET_DTLS_SUCC_MSG"));

    }

    @Test
    void dashboardMarketVisitDetails_Fail_1() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9000011462");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setCircleName("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setZoneName("All");
        snapWorkRequest.setRoleId("All");
        snapWorkRequest.setRoleName("All");
        snapWorkRequest.setCategoryId("All");
        snapWorkRequest.setCategoryName("All");
        snapWorkRequest.setStartDate("01-01-2021");
        snapWorkRequest.setEndDate("31-01-2021");
        snapWorkRequest.setVer("0");
        snapWorkRequest.setChannel("PWEB");
        snapWorkRequest.setFeSessionId("PWEBxPQOtmtmK97K9");

        Map<String, Object> catRow = new HashMap<>();
        catRow.put("PROMTR_MOBNO", "9718056667");
        catRow.put("USER_NAME", "Abhishek Saxena");
        catRow.put("LAPU_NO", "8975645342");

        Map<String, Object> catRow_1 = new HashMap<>();
        catRow_1.put("PROMTR_MOBNO", "9897108505");
        catRow_1.put("USER_NAME", "Varun2");
        catRow_1.put("LAPU_NO", "7042709703");

        Map<String, Object> catRow_2 = new HashMap<>();
        catRow_2.put("PROMTR_MOBNO", "9897108404");
        catRow_2.put("USER_NAME", "xyz1");
        catRow_2.put("LAPU_NO", "7042709702");

        Map<String, Object> catRow_3 = new HashMap<>();
        catRow_3.put("PROMTR_MOBNO", "9897108505");
        catRow_3.put("USER_NAME", "Varun2");
        catRow_3.put("LAPU_NO", "8975645342");

        List<Map<String, Object>> catRows  = new ArrayList<>();
        catRows.add(catRow);
        catRows.add(catRow_1);
        catRows.add(catRow_2);
        catRows.add(catRow_3);

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.dashboardMarketVisitDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("MARKET_FETCH_DTLS_FAIL_MSG"));

    }

    @Test
    void dashboardMarketVisitDetails_Fail_2() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9000011462");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setCircleName("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setZoneName("All");
        snapWorkRequest.setRoleId("All");
        snapWorkRequest.setRoleName("All");
        snapWorkRequest.setCategoryId("All");
        snapWorkRequest.setCategoryName("All");
        snapWorkRequest.setStartDate("01-01-2021");
        snapWorkRequest.setEndDate("31-01-2021");
        snapWorkRequest.setVer("0");
        snapWorkRequest.setChannel("PWEB");
        snapWorkRequest.setFeSessionId("PWEBxPQOtmtmK97K9");

        List<Map<String, Object>> catRows  = new ArrayList<>();

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.dashboardMarketVisitDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("MARKET_FETCH_DTLS_FAIL_MSG"));

    }

    @Test
    void dashboardMarketVisitDetails_Fail_3() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9000011462");
        snapWorkRequest.setCircleId("All");
        snapWorkRequest.setCircleName("All");
        snapWorkRequest.setZoneId("All");
        snapWorkRequest.setZoneName("All");
        snapWorkRequest.setRoleId("All");
        snapWorkRequest.setRoleName("All");
        snapWorkRequest.setCategoryId("All");
        snapWorkRequest.setCategoryName("All");
        snapWorkRequest.setStartDate("");
        snapWorkRequest.setEndDate("");
        snapWorkRequest.setVer("0");
        snapWorkRequest.setChannel("PWEB");
        snapWorkRequest.setFeSessionId("PWEBxPQOtmtmK97K9");

        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.dashboardMarketVisitDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("MARKET_FETCH_DTLS_FAIL_MSG"));

    }

    @Test
    void dashboardMarketVisitDetails_Fail_4() throws Exception
    {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName(null);
        snapWorkRequest.setCircleId(null);
        snapWorkRequest.setCircleName(null);
        snapWorkRequest.setZoneId(null);
        snapWorkRequest.setZoneName(null);
        snapWorkRequest.setRoleId(null);
        snapWorkRequest.setRoleName(null);
        snapWorkRequest.setCategoryId(null);
        snapWorkRequest.setCategoryName(null);
        snapWorkRequest.setStartDate(null);
        snapWorkRequest.setEndDate(null);
        snapWorkRequest.setVer(null);
        snapWorkRequest.setChannel(null);
        snapWorkRequest.setFeSessionId(null);

        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.dashboardMarketVisitDetails(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("MARKET_FETCH_DTLS_FAIL_MSG"));

    }

    @Test
    void dashboardMarketVisitDetails_Exception() throws Exception
    {
        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.dashboardMarketVisitDetails(null);

        assertEquals("Server Error, please try after sometime.", snapWorkResponse.getMessage());

    }

    @Test
    void downloadMarketVisit_Success_1() throws Exception
    {
        Map<String, Object> catRow = new HashMap<>();
        catRow.put("PROMTR_MOBNO", "9718056667");
        catRow.put("USER_NAME", "Abhishek Saxena");
        catRow.put("LAPU_NO", "8975645342");

        Map<String, Object> catRow_1 = new HashMap<>();
        catRow_1.put("PROMTR_MOBNO", "9897108505");
        catRow_1.put("USER_NAME", "Varun2");
        catRow_1.put("LAPU_NO", "7042709703");

        Map<String, Object> catRow_2 = new HashMap<>();
        catRow_2.put("PROMTR_MOBNO", "9897108404");
        catRow_2.put("USER_NAME", "xyz1");
        catRow_2.put("LAPU_NO", "7042709702");

        Map<String, Object> catRow_3 = new HashMap<>();
        catRow_3.put("PROMTR_MOBNO", "9897108505");
        catRow_3.put("USER_NAME", "Varun2");
        catRow_3.put("LAPU_NO", "8975645342");

        List<Map<String, Object>> catRows  = new ArrayList<>();
        catRows.add(catRow);
        catRows.add(catRow_1);
        catRows.add(catRow_2);
        catRows.add(catRow_3);

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        Mockito.when(adminReportDAO.fetchMarketVisitedRetailerDetails(Mockito.any())).thenReturn("9839057135");

        Mockito.when(adminReportDAO.getOutletVisistedCount(Mockito.any(), Mockito.any())).thenReturn(1);

        Map<String, Object> market_row = new HashMap<>();
        market_row.put("IN_OR_OUT", "0");

        List<Map<String, Object>> mktlist  = new ArrayList<>();
        mktlist.add(market_row);

        Mockito.when(adminReportDAO.fetchMarketVisitedCheckInDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mktlist);

        Map<String, Object> chkin_row = new HashMap<>();
        chkin_row.put(Constants.LATITUDE, "12.0218218");
        chkin_row.put(Constants.LONGITUDE, "-8.294547");
        chkin_row.put(Constants.LAPU_NO, "983905713");
        chkin_row.put(Constants.DATE_OF_VISIT, "12/03/2021");
        chkin_row.put("DISP_DATE", "12/03/2021");

        List<Map<String, Object>> chkin_list  = new ArrayList<>();
        chkin_list.add(market_row);

        Mockito.when(adminReportDAO.fetchCheckInDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(chkin_list);


        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.downloadMarketVisit(
                "All",
                "All",
                "All",
                "All",
                "01-01-2021 ", "12-03-2021");

        assertEquals(prop.getProperty(Constants.SUCCESS_STATUS_CODE), snapWorkResponse.getStatusCode());

    }

    @Test
    void downloadMarketVisit_Success_2() throws Exception
    {
        Map<String, Object> catRow = new HashMap<>();
        catRow.put("PROMTR_MOBNO", "9718056667");
        catRow.put("USER_NAME", "Abhishek Saxena");
        catRow.put("LAPU_NO", "8975645342");

        Map<String, Object> catRow_1 = new HashMap<>();
        catRow_1.put("PROMTR_MOBNO", "9897108505");
        catRow_1.put("USER_NAME", "Varun2");
        catRow_1.put("LAPU_NO", "7042709703");

        Map<String, Object> catRow_2 = new HashMap<>();
        catRow_2.put("PROMTR_MOBNO", "9897108404");
        catRow_2.put("USER_NAME", "xyz1");
        catRow_2.put("LAPU_NO", "7042709702");

        Map<String, Object> catRow_3 = new HashMap<>();
        catRow_3.put("PROMTR_MOBNO", "9897108505");
        catRow_3.put("USER_NAME", "Varun2");
        catRow_3.put("LAPU_NO", "8975645342");

        List<Map<String, Object>> catRows  = new ArrayList<>();
        catRows.add(catRow);
        catRows.add(catRow_1);
        catRows.add(catRow_2);
        catRows.add(catRow_3);

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        Mockito.when(adminReportDAO.fetchMarketVisitedRetailerDetails(Mockito.any())).thenReturn("9839057135");

        Mockito.when(adminReportDAO.getOutletVisistedCount(Mockito.any(), Mockito.any())).thenReturn(1);

        Map<String, Object> market_row = new HashMap<>();
        market_row.put("IN_OR_OUT", "1");

        List<Map<String, Object>> mktlist  = new ArrayList<>();
        mktlist.add(market_row);

        Mockito.when(adminReportDAO.fetchMarketVisitedCheckInDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mktlist);

        Map<String, Object> chkin_row = new HashMap<>();
        chkin_row.put(Constants.LATITUDE, "12.0218218");
        chkin_row.put(Constants.LONGITUDE, "-8.294547");
        chkin_row.put(Constants.LAPU_NO, "983905713");
        chkin_row.put(Constants.DATE_OF_VISIT, "12/03/2021");
        chkin_row.put("DISP_DATE", "12/03/2021");

        List<Map<String, Object>> chkin_list  = new ArrayList<>();
        chkin_list.add(market_row);

        Mockito.when(adminReportDAO.fetchCheckInDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(chkin_list);


        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.downloadMarketVisit(
                "All",
                "All",
                "All",
                "All",
                "01-01-2021 ", "12-03-2021");

        assertEquals(prop.getProperty(Constants.SUCCESS_STATUS_CODE), snapWorkResponse.getStatusCode());

    }

    @Test
    void downloadMarketVisit_Fail() throws Exception
    {
        Map<String, Object> catRow = new HashMap<>();
        catRow.put("PROMTR_MOBNO", "9718056667");
        catRow.put("USER_NAME", "Abhishek Saxena");
        catRow.put("LAPU_NO", "8975645342");

        Map<String, Object> catRow_1 = new HashMap<>();
        catRow_1.put("PROMTR_MOBNO", "9897108505");
        catRow_1.put("USER_NAME", "Varun2");
        catRow_1.put("LAPU_NO", "7042709703");

        Map<String, Object> catRow_2 = new HashMap<>();
        catRow_2.put("PROMTR_MOBNO", "9897108404");
        catRow_2.put("USER_NAME", "xyz1");
        catRow_2.put("LAPU_NO", "7042709702");

        Map<String, Object> catRow_3 = new HashMap<>();
        catRow_3.put("PROMTR_MOBNO", "9897108505");
        catRow_3.put("USER_NAME", "Varun2");
        catRow_3.put("LAPU_NO", "8975645342");

        List<Map<String, Object>> catRows  = new ArrayList<>();
        catRows.add(null);

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.downloadMarketVisit(
                "All",
                "All",
                "All",
                "All",
                "01-01-2021 ", "12-03-2021");

        assertEquals(prop.getProperty(Constants.SUCCESS_STATUS_CODE), snapWorkResponse.getStatusCode());

    }

    @Test
    void downloadMarketVisit_Exception() throws Exception
    {
        Map<String, Object> catRow = new HashMap<>();
        catRow.put("PROMTR_MOBNO", "9718056667");
        catRow.put("USER_NAME", "Abhishek Saxena");
        catRow.put("LAPU_NO", "8975645342");

        Map<String, Object> catRow_1 = new HashMap<>();
        catRow_1.put("PROMTR_MOBNO", "9897108505");
        catRow_1.put("USER_NAME", "Varun2");
        catRow_1.put("LAPU_NO", "7042709703");

        Map<String, Object> catRow_2 = new HashMap<>();
        catRow_2.put("PROMTR_MOBNO", "9897108404");
        catRow_2.put("USER_NAME", "xyz1");
        catRow_2.put("LAPU_NO", "7042709702");

        Map<String, Object> catRow_3 = new HashMap<>();
        catRow_3.put("PROMTR_MOBNO", "9897108505");
        catRow_3.put("USER_NAME", "Varun2");
        catRow_3.put("LAPU_NO", "8975645342");

        List<Map<String, Object>> catRows  = new ArrayList<>();
        catRows.add(null);

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        SnapWorkResponse snapWorkResponse = adminReportServiceImpl.downloadMarketVisit(
                null,
                null,
                null,
                null,
                null, null);

        assertEquals(prop.getProperty(Constants.SUCCESS_STATUS_CODE), snapWorkResponse.getStatusCode());

    }

    @Test
    void getMarketVisitList_Success() throws Exception
    {
        Map<String, Object> catRow = new HashMap<>();
        catRow.put("PROMTR_MOBNO", "9718056667");
        catRow.put("USER_NAME", "Abhishek Saxena");
        catRow.put("LAPU_NO", "8975645342");

        Map<String, Object> catRow_1 = new HashMap<>();
        catRow_1.put("PROMTR_MOBNO", "9897108505");
        catRow_1.put("USER_NAME", "Varun2");
        catRow_1.put("LAPU_NO", "7042709703");

        Map<String, Object> catRow_2 = new HashMap<>();
        catRow_2.put("PROMTR_MOBNO", "9897108404");
        catRow_2.put("USER_NAME", "xyz1");
        catRow_2.put("LAPU_NO", "7042709702");

        Map<String, Object> catRow_3 = new HashMap<>();
        catRow_3.put("PROMTR_MOBNO", "9897108505");
        catRow_3.put("USER_NAME", "Varun2");
        catRow_3.put("LAPU_NO", "8975645342");

        List<Map<String, Object>> catRows  = new ArrayList<>();
        catRows.add(catRow);
        catRows.add(catRow_1);
        catRows.add(catRow_2);
        catRows.add(catRow_3);

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        Mockito.when(adminReportDAO.fetchMarketVisitedRetailerDetails(Mockito.anyString())).thenReturn("Deeksha");

        Mockito.when(adminReportDAO.getOutletVisistedCount(Mockito.anyString(), Mockito.anyString())).thenReturn(10);

        Map<String, Object> checkinoutdtl = new HashMap<>();
        catRow_3.put("IN_OR_OUT", "0");

        Map<String, Object> checkinoutdt2 = new HashMap<>();
        catRow_3.put("IN_OR_OUT", "1");

        List<Map<String, Object>> list = new ArrayList<>();
        list.add(checkinoutdtl);
        list.add(checkinoutdt2);

        Mockito.when(adminReportDAO.fetchMarketVisitedCheckInDetails
                (Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);

        Map<String, Object> checkInRows = new HashMap<>();
        checkInRows.put("LATITUDE", "05:50");
        checkInRows.put("LONGITUDE", "-122.084");
        checkInRows.put("LAPU_NO", "1");
        checkInRows.put("DATE_OF_VISIT", "1");
        checkInRows.put("DISP_DATE", "1");
        checkInRows.put("Check_In", "05:50");
        checkInRows.put("Check_In_Lat", "1");
        checkInRows.put("Check_In_Long", "1");
        checkInRows.put("Date", "1");

        List<Map<String, Object>> list_1 = new ArrayList<>();
        list_1.add(checkInRows);
        Mockito.when(adminReportDAO.fetchCheckInDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list_1);

        Mockito.when(adminReportDAO.fetchCheckOutDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list_1);

        Map<String, Object> latlngdtls = new HashMap<>();
        latlngdtls.put("LATITUDE", "05:50");
        latlngdtls.put("LONGITUDE", "-122.084");
        latlngdtls.put("PROMOTER_LATITUDE", "-122.084");
        latlngdtls.put("PROMOTER_LONGITUDE", "-122.084");

        List<Map<String, Object>> latlngdtls_list = new ArrayList<>();
        latlngdtls_list.add(latlngdtls);

        Mockito.when(adminReportDAO.getLatLongDtls(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(latlngdtls_list);

        Mockito.when(commonUtil.calculateMarketDistance(
                "37.421998", "37.421998",
                "37.421998", "37.421998")).thenReturn(0.00);

        List<MarketVisitBean> getMarketVisitList = adminReportServiceImpl.getMarketVisitList("All",
                "All", "All", "All" , "01-03-2021", "31-03-2021");

        assertNotNull(getMarketVisitList);
    }

    @Test
    void getMarketVisitList_Fail() throws Exception
    {
        List<Map<String, Object>> catRows  = new ArrayList<>();

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        Mockito.when(response.getStatusCode()).thenReturn("500");

        List<MarketVisitBean> getMarketVisitList = adminReportServiceImpl.getMarketVisitList("All",
                "All", "All", "All" , "01-03-2021", "31-03-2021");

        assertTrue(getMarketVisitList.isEmpty());
    }

    @Test
    void getMarketVisitList_Exception() throws Exception
    {
        List<Map<String, Object>> catRows  = new ArrayList<>();

        Mockito.when(adminReportDAO.fetchMarketRoleDetails(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(catRows);

        Mockito.when(response.getStatusCode()).thenReturn("500");

        List<MarketVisitBean> getMarketVisitList = adminReportServiceImpl.getMarketVisitList(null, null
        , null, null, null, null);

        assertTrue(getMarketVisitList.isEmpty());
    }
}