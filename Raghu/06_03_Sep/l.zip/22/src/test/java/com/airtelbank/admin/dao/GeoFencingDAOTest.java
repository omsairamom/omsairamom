package com.airtelbank.admin.dao;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtelbank.admin.util.PropertyManager;

@SpringBootTest
class GeoFencingDAOTest {

	@Autowired
	GeoFencingDAO geoFencingDAO;

	@MockBean
	JdbcTemplate jdbctemplate;

	@MockBean
	PropertyManager prop;
	
	@Test
	public void getCircleMasterDetails_Success() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = geoFencingDAO.getCircleMasterDetails();
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void getCategoryMasterDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = geoFencingDAO.getCategoryMasterDetails();
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void getZoneMasterDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = geoFencingDAO.getZoneMasterDetails();
		assertTrue(!row.equals(""));
	}
	
	@Test
	public void getRoleMasterDetails() throws Exception
	{
		List<Map<String, Object>> rows = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("CAT_ID", "1");
		rows.add(map);

		String query = "";

		when(prop.getProperty(Mockito.anyString())).thenReturn(query);
		when(jdbctemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(rows);

		List<Map<String, Object>> row = geoFencingDAO.getRoleMasterDetails();
		assertTrue(!row.equals(""));
	}
}
