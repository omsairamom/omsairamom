package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.bean.AdminLoginInfoTrackerBean;
import com.airtelbank.admin.bean.AttendanceBean;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.AdminPortalLoginDAO;
import com.airtelbank.admin.dao.PromoterUserProfileMSTDAO;
import com.airtelbank.admin.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.admin.jwt.AeroCache;
import com.airtelbank.admin.jwt.CommonJWTUtil;
import com.airtelbank.admin.service.AdminPortalLoginService;
import com.airtelbank.admin.util.*;
import org.apache.commons.collections.map.HashedMap;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AdminPortalLoginServiceImplTest {
    @MockBean
    AeroCache aeroCache;

    @Autowired
    AdminPortalLoginService loginService;

    @MockBean
    AdminPortalLoginDAO adminLoginDao;

    @MockBean
    PromoterUserProfileMSTDAO promoterUserProfileMSTDAO;

    @Autowired
    PropertyManager prop;

    @Autowired
    SnapWorkResponse response;

    @Autowired
    AdminPortalLoginService adminPortalLoginService;

    @Autowired
    AdminPortalLoginServiceImpl adminPortalLoginServiceImpl;

    @MockBean
    RestClientUtil restClient;

    @Autowired
    KibanaLoggerUtils kibanaLoggerObj;

    @Autowired
    SnapWorkRequest request;

    @MockBean
    CommonJWTUtil commonJWTUtil;

    @Autowired
    CommonUtils commonUtil;

    @MockBean
    PropertyManager propM;

    @Mock
    SecureBuilderVer secureBuilderVer_1;

    SecureBuilderVer secureBuilderVer = mock(SecureBuilderVer.class);

    @Test
    public void adminLoginDetailsSuccess() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9839057135");
        snapWorkRequest.setPassword("Airtel@1234");

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("9839057135");
        promoterUserProfileMSTEntity.get().setPassword("73c28b0b16bedeac4ffd38ee0c04aa02e0c33c4a0c6a3a0002c5c67f3a630b8c");
        promoterUserProfileMSTEntity.get().setUserType("ADMIN");
        promoterUserProfileMSTEntity.get().setChannel("PADMIN");
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(null);
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setAttempts(0);

        Mockito.when(adminLoginDao.validateAdminLoginDetails_V2(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        String jwtFlag = "Y";
        when(propM.getProperty(Mockito.any()))
                .thenReturn(jwtFlag);
        when(commonJWTUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
                .thenReturn(
                        "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxODAwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYyNjI1MDIwOCwiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijk4MzkwNTcxMzUiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYyNjI2ODIxMywiaWF0IjoxNjI2MjUwMjEzLCJqdGkiOiI0MzA5MzE0Yy1iYjYzLTRjZmQtYjlmMy0wNmRiNzU2YzA3YzIifQ.5I7QwYY4vvlR9Wv7jr7iHCEA8MYOekkyp_Rdr5VF6t2YSFyeyGtuCj7ZRwrHfVxnovd_ayh0lJuvij0gLmMcnQ");

        SnapWorkResponse snapWorkResponse = adminPortalLoginService.adminLoginDetails("ADMIN", "Airtel@1234", snapWorkRequest);

//		List<Map<String, Object>> rows = new ArrayList<>();
//		@SuppressWarnings("unchecked")
//		Map<String, Object> map = new HashedMap();
//		map.put("ADM_NAME", "Admin");
//		map.put("ADM_PWD", "fea972fee62d11e45844a1fb91b7c1572d33c1e06ac5723112293d6ea74d5bc1");
//		map.put("ADM_TYPE", "Admin");
//		rows.add(map);
//
//		when(adminLoginDao.validateAdminLoginDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
//
//		Map<String, String> map1 = new HashMap<>(2);
//		map1.put("tempBlock", "false");
//		map1.put("count", "0");
//
//		when(aeroCache.get(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(map1);

//		AdminLoginInfoTrackerBean obj = new AdminLoginInfoTrackerBean();
//		obj.setUserName("7607842101");
//		obj.setLoginType(0);
//		obj.setField1("NA");
//		obj.setField2("NA");
//		obj.setField3("NA");
//		obj.setField4("NA");
//		obj.setField5("NA");

//		String jwtFlag = "Y";
//		when(propM.getProperty(Mockito.any()))
//				.thenReturn(jwtFlag);
//
//		String jwtToken = "jwtToken@123";


        //	when(adminLoginDao.updateJWT(Mockito.anyString(), Mockito.anyString())).thenReturn(1);

//		when(adminLoginDao.saveAdminLoginInfoTrackerDetails(obj)).thenReturn(1);

//		response = adminPortalLoginService.adminLoginDetails("Admin", "Airte@123", request);

        assertEquals(prop.getProperty("ADMIN_LOGIN_USER_SUCC_MSG"), snapWorkResponse.getMessage());

    }

    @Test
    public void adminLoginDetailsJWTTOKENFail() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9839057135");
        snapWorkRequest.setPassword("A@123");

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("9839057135");
        promoterUserProfileMSTEntity.get().setDeviceId("23434");
        promoterUserProfileMSTEntity.get().setPassword("73c28b0b16bedeac4ffd38ee0c04aa02e0c33c4a0c6a3a0002c5c67f3a630b8c");
        promoterUserProfileMSTEntity.get().setUserType("ADMIN");
        promoterUserProfileMSTEntity.get().setChannel("PADMIN");
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(null);
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setAttempts(0);

        Mockito.when(adminLoginDao.validateAdminLoginDetails_V2(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);

        String jwtFlag = "Y";
        when(propM.getProperty(Mockito.any()))
                .thenReturn(jwtFlag);
        when(commonJWTUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
                .thenReturn(
                        "");

        SnapWorkResponse snapWorkResponse = adminPortalLoginService.adminLoginDetails("ADMIN", "A@123", snapWorkRequest);

        assertEquals(prop.getProperty("LOGIN_JWT_TOKEN_GEN_FAILED"), snapWorkResponse.getMessage());

    }

    @Test
    public void adminLoginDetails_MobileNoEmptyFail() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("");
        snapWorkRequest.setPassword("A@123");

        SnapWorkResponse snapWorkResponse = loginService.adminLoginDetails("", "A@123", snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_LOGIN_INVALID_PASSWD_MSG"), snapWorkResponse.getMessage());

    }

    @Test
    public void adminLoginDetails_UserBlock() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9839057135");
        snapWorkRequest.setPassword("Airtel@1234");

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("9839057135");
        promoterUserProfileMSTEntity.get().setPassword("73c28b0b16bedeac4ffd38ee0c04aa02e0c33c4a0c6a3a0002c5c67f3a630b8c");
        promoterUserProfileMSTEntity.get().setUserType("ADMIN");
        promoterUserProfileMSTEntity.get().setChannel("PADMIN");
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(LocalDateTime.now().plusMinutes(30));
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setAttempts(0);

        Mockito.when(adminLoginDao.validateAdminLoginDetails_V2(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        String jwtFlag = "Y";
        when(propM.getProperty(Mockito.any()))
                .thenReturn(jwtFlag);
        when(commonJWTUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
                .thenReturn(
                        "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxODAwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYyNjI1MDIwOCwiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijk4MzkwNTcxMzUiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYyNjI2ODIxMywiaWF0IjoxNjI2MjUwMjEzLCJqdGkiOiI0MzA5MzE0Yy1iYjYzLTRjZmQtYjlmMy0wNmRiNzU2YzA3YzIifQ.5I7QwYY4vvlR9Wv7jr7iHCEA8MYOekkyp_Rdr5VF6t2YSFyeyGtuCj7ZRwrHfVxnovd_ayh0lJuvij0gLmMcnQ");

        SnapWorkResponse snapWorkResponse = adminPortalLoginService.adminLoginDetails("ADMIN", "Airtel@123", snapWorkRequest);

        assertEquals(prop.getProperty("USER_BLOCKED_FOR_WRONG_ATTEMPT"), snapWorkResponse.getMessage());
    }
    @Test
    public void adminLoginDetails_InValidCredentials() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9839057135");
        snapWorkRequest.setPassword("Airtel@1234");

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("9839057135");
        promoterUserProfileMSTEntity.get().setPassword("73c28b0b16bedeac4ffd38ee0c04aa02e0c33c4a0c6a3a0002c5c67f3a630b8c");
        promoterUserProfileMSTEntity.get().setUserType("ADMIN");
        promoterUserProfileMSTEntity.get().setChannel("PADMIN");
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(null);
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setAttempts(3);

        Mockito.when(adminLoginDao.validateAdminLoginDetails_V2(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        String jwtFlag = "Y";
        when(propM.getProperty(Mockito.any()))
                .thenReturn(jwtFlag);
        when(commonJWTUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
                .thenReturn(
                        "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxODAwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYyNjI1MDIwOCwiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijk4MzkwNTcxMzUiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYyNjI2ODIxMywiaWF0IjoxNjI2MjUwMjEzLCJqdGkiOiI0MzA5MzE0Yy1iYjYzLTRjZmQtYjlmMy0wNmRiNzU2YzA3YzIifQ.5I7QwYY4vvlR9Wv7jr7iHCEA8MYOekkyp_Rdr5VF6t2YSFyeyGtuCj7ZRwrHfVxnovd_ayh0lJuvij0gLmMcnQ");

        SnapWorkResponse snapWorkResponse = adminPortalLoginService.adminLoginDetails("ADMIN", "Airtel@123", snapWorkRequest);

        assertEquals(prop.getProperty("USER_BLOCKED_FOR_WRONG_ATTEMPT"), response.getMessage());
    }
    @Test
    public void adminLoginDetails_InValidCredentials_Unblocked() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("9839057135");
        snapWorkRequest.setPassword("Airtel@1234");

        Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity =
                Optional.of(new PromoterUserProfileMSTEntity());
        promoterUserProfileMSTEntity.get().setId(1L);
        promoterUserProfileMSTEntity.get().setUserNo("9839057135");
        promoterUserProfileMSTEntity.get().setPassword("73c28b0b16bedeac4ffd38ee0c04aa02e0c33c4a0c6a3a0002c5c67f3a630b8c");
        promoterUserProfileMSTEntity.get().setUserType("ADMIN");
        promoterUserProfileMSTEntity.get().setChannel("PADMIN");
        promoterUserProfileMSTEntity.get().setBlockExpiryDate(LocalDateTime.now().minusMinutes(30));
        promoterUserProfileMSTEntity.get().setStatus("A");
        promoterUserProfileMSTEntity.get().setAttempts(0);

        Mockito.when(adminLoginDao.validateAdminLoginDetails_V2(Mockito.anyString(), Mockito.anyString())).thenReturn(promoterUserProfileMSTEntity);
        String jwtFlag = "Y";
        when(propM.getProperty(Mockito.any()))
                .thenReturn(jwtFlag);
        when(commonJWTUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
                .thenReturn(
                        "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ0b2tlbkV4cFRpbWUiOiIxODAwMCIsImFjdG9yVHlwZSI6IlJFVCIsIm5iZiI6MTYyNjI1MDIwOCwiY2hhbm5lbCI6IlBBUFAiLCJtb2JpbGVubyI6Ijk4MzkwNTcxMzUiLCJ1c2VyVHlwZSI6IlJFVCIsImV4cCI6MTYyNjI2ODIxMywiaWF0IjoxNjI2MjUwMjEzLCJqdGkiOiI0MzA5MzE0Yy1iYjYzLTRjZmQtYjlmMy0wNmRiNzU2YzA3YzIifQ.5I7QwYY4vvlR9Wv7jr7iHCEA8MYOekkyp_Rdr5VF6t2YSFyeyGtuCj7ZRwrHfVxnovd_ayh0lJuvij0gLmMcnQ");

        SnapWorkResponse snapWorkResponse = adminPortalLoginService.adminLoginDetails("ADMIN", "Airtel@123", snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_LOGIN_INVALID_PASSWD_MSG"), response.getMessage());
    }


    @Test
    public void adminLoginDetailsThrowException() throws Exception {

        response = adminPortalLoginService.adminLoginDetails("Admin", "Airtel@123", null);

        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());

    }

    @Test
    public void sendOTPSuccessTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        JSONObject jsonMetaObj = new JSONObject();
        jsonMetaObj.put("status", "0");
        jsonMetaObj.put("description", "sms sent");
        jsonMetaObj.put("code", "000");
        jsonMetaObj.put("fesessionid", "PAPPsHzOdpTcYgCp");
        jsonMetaObj.put("verificationToken", "d8f5313e-06cf-4e0f-b2da-707b44aff9d4");

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPhe2AQNnWUx3M\",\"verificationToken\":\"7437b695-15e7-4eac-88fc-98d4b7e05219\"},\"meta\":{\"code\":\"000\",\"description\":\"sms sent\",\"status\":0}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.sendOTP("7006980036", snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_SEND_OTP_SUCC_MSG"), response.getMessage());

    }

    @Test
    public void sendOTPFailStatusTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        JSONObject jsonMetaObj = new JSONObject();
        jsonMetaObj.put("status", "0");
        jsonMetaObj.put("description", "sms sent");
        jsonMetaObj.put("code", "000");
        jsonMetaObj.put("fesessionid", "PAPPsHzOdpTcYgCp");
        jsonMetaObj.put("verificationToken", "d8f5313e-06cf-4e0f-b2da-707b44aff9d4");

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPhe2AQNnWUx3M\",\"verificationToken\":\"7437b695-15e7-4eac-88fc-98d4b7e05219\"},\"meta\":{\"description\":\"sms sent\",\"status\":0}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.sendOTP("7006980036", snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_SEND_OTP_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void sendOTPFailStatusCodeNot000Test() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        JSONObject jsonMetaObj = new JSONObject();
        jsonMetaObj.put("status", "0");
        jsonMetaObj.put("description", "sms sent");
        jsonMetaObj.put("code", "000");
        jsonMetaObj.put("fesessionid", "PAPPsHzOdpTcYgCp");
        jsonMetaObj.put("verificationToken", "d8f5313e-06cf-4e0f-b2da-707b44aff9d4");

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPhe2AQNnWUx3M\"},\"meta\":{\"code\":\"001\",\"description\":\"sms sent\",\"status\":0}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.sendOTP("7006980036", snapWorkRequest);

        assertEquals("sms sent", response.getMessage());

    }

    @Test
    public void sendOTPFailTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn("");

        SnapWorkResponse response = loginService.sendOTP("7006980036", snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_SEND_OTP_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void sendOTPFailTest1() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        SnapWorkResponse response = loginService.sendOTP("", snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_SEND_OTP_FAIL_MSG"), response.getMessage());

        System.out.print(" " + prop.getProperty("ADMIN_SEND_OTP_FAIL_MSG") + " " + response.getMessage());

    }

    @Test
    public void sendOTPFailThrowException() throws Exception {
        SnapWorkResponse response = loginService.sendOTP(null, null);
        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
    }

    @Test
    public void fetchCircleDetailsSuccess() throws Exception {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setUserName("7607842101");

        List<Map<String, Object>> rows = new ArrayList<>();
        @SuppressWarnings("unchecked")
        Map<String, Object> map = new HashedMap();
        map.put("CIRCLE_NAME", "Kanpur");
        map.put("CIRCLE_ID", "123");
        rows.add(map);

        when(adminLoginDao.getCircleMasterDetails()).thenReturn(rows);

        response = adminPortalLoginService.fetchCircleDetails("7607842101", request);

        assertEquals(prop.getProperty("ADMIN_FETCH_CIRCLE_MST_DTLS_SUCC_MSG"), response.getMessage());
    }

    @Test
    public void fetchCircleDetailsFail() throws Exception {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setUserName("7607842101");

        List<Map<String, Object>> rows = new ArrayList<>();

        when(adminLoginDao.getCircleMasterDetails()).thenReturn(rows);

        response = adminPortalLoginService.fetchCircleDetails("7607842101", request);

        assertEquals(prop.getProperty("ADMIN_FETCH_CIRCLE_MST_DTLS_FAIL_MSG"), response.getMessage());
    }

    @Test
    public void fetchCircleDetailsThrowException() throws Exception {

        response = adminPortalLoginService.fetchCircleDetails("7607842101", null);

        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
    }

    @Test
    public void dashboardAttendanceDetailsSuccess() throws Exception {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setCircleId("1");
        request.setStartDate("18-11-2020");
        request.setEndDate("21-12-2020");

        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashedMap();
        map.put("LAPU_NO", "7607842101");
        map.put("ATT_DATETIME", "12-02-2021");
        rows.add(map);

        List<Map<String, Object>> rows1 = new ArrayList<>();

        Map<String, Object> map1 = new HashedMap();
        map1.put("LATITUDE", "35.929673");
        map1.put("LONGITUDE", "-78.948237");

        Map<String, Object> map2 = new HashedMap();
        map2.put("LATITUDE", "38.889510");
        map2.put("LONGITUDE", "-77.032000");
        rows1.add(map1);
        rows1.add(map2);

        when(adminLoginDao.fetchAttendanceDataDetails(request)).thenReturn(rows);
        when(adminLoginDao.getOutletVisistedCount(Mockito.anyString(), Mockito.anyString())).thenReturn(1);

        when(adminLoginDao.getLatLongDtls(Mockito.anyString(), Mockito.anyString())).thenReturn(rows1);

        response = adminPortalLoginService.dashboardAttendanceDetails(request);

        assertEquals(prop.getProperty("ADMIN_FETCH_ATTEND_DTLS_SUCC_MSG"), response.getMessage());
    }

    @Test
    public void dashboardAttendanceDetailsSuccess_NULL() throws Exception {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setCircleId(null);
        request.setStartDate(null);
        request.setEndDate(null);

        List<Map<String, Object>> rows = new ArrayList<>();

        Map<String, Object> map = new HashedMap();
        map.put("LAPU_NO", "7607842101");
        map.put("ATT_DATETIME", "12-02-2021");
        rows.add(map);

        List<Map<String, Object>> rows1 = new ArrayList<>();
        @SuppressWarnings("unchecked")
        Map<String, Object> map1 = new HashedMap();
        map1.put("LATITUDE", "35.929673");
        map1.put("LONGITUDE", "-78.948237");

        Map<String, Object> map2 = new HashedMap();
        map2.put("LATITUDE", "38.889510");
        map2.put("LONGITUDE", "-77.032000");
        rows1.add(map1);
        rows1.add(map2);

        when(adminLoginDao.fetchAttendanceDataDetails(request)).thenReturn(rows);
        when(adminLoginDao.getOutletVisistedCount(Mockito.anyString(), Mockito.anyString())).thenReturn(1);

        when(adminLoginDao.getLatLongDtls(Mockito.anyString(), Mockito.anyString())).thenReturn(rows1);

        response = adminPortalLoginService.dashboardAttendanceDetails(request);

        //	assertEquals("Server Error, please try after sometime.", response.getMessage());
    }

    @Test
    public void dashboardAttendanceDetailsFail() throws Exception {
        SnapWorkRequest request = new SnapWorkRequest();
        request.setCircleId("1");
        request.setStartDate("18-11-2020");
        request.setEndDate("21-12-2020");

        List<Map<String, Object>> rows = new ArrayList<>();

        when(adminLoginDao.fetchAttendanceDataDetails(request)).thenReturn(rows);
        when(adminLoginDao.getOutletVisistedCount(Mockito.anyString(), Mockito.anyString())).thenReturn(1);

        response = adminPortalLoginService.dashboardAttendanceDetails(request);

        assertEquals(prop.getProperty("ADMIN_FETCH_ATTEND_DTLS_FAIL_MSG"), response.getMessage());
    }

    @Test
    public void dashboardAttendanceDetailsThrowException() throws Exception {

        response = adminPortalLoginService.dashboardAttendanceDetails(null);

        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
    }

    @Test
    public void resetPasswordSuccess() throws Exception {

        SnapWorkRequest request = new SnapWorkRequest();
        request.setUserName("7607842110");
        request.setPassword("Airtel@123");

        when(adminLoginDao.updateAdminPasswordDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(1);

        response = adminPortalLoginService.resetPassword("7607842110", "Airtel@123", request);

        assertEquals(prop.getProperty("ADMIN_RESET_PASSWD_SUCC_MSG"), response.getMessage());
    }

    @Test
    public void resetPasswordFail() throws Exception {

        SnapWorkRequest request = new SnapWorkRequest();
        request.setUserName("7607842110");
        request.setPassword("Airtel@123");

        when(adminLoginDao.updateAdminPasswordDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(0);

        response = adminPortalLoginService.resetPassword("7607842110", "Airtel@123", request);

        assertEquals(prop.getProperty("ADMIN_RESET_PASSWD_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void resetPasswordThrowException() throws Exception {

        response = adminPortalLoginService.resetPassword("", "", null);

        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
    }

    @Test
    public void verifyOTPSuccessTest() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"000\",\"description\":\"OTP verified\",\"status\":0}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_VERIFY_OTP_SUCC_MSG"), response.getMessage());

    }

    @Test
    public void verifyOTPFailAPIResponseEmpty() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_VERIFY_OTP_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void verifyOTPFailAPIStatusNotContain() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"000\",\"description\":\"OTP verified\"}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals(prop.getProperty("ADMIN_VERIFY_OTP_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void verifyOTPFailAPIdescriptionNotContain() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7006980036");

        String otpVerficatonCode = "000";
        String otp = "980036";

        String apiResponse = "{\"data\":{\"fesessionid\":\"PAPPF2OjB7HE6ZLv\",\"authToken\":\"8ad0641d-dcc3-4955-98fb-f292012cc504\",\"verificationToken\":\"c8ceb6fe-c737-4ec0-b790-782d9708fe42\"},\"meta\":{\"code\":\"001\",\"description\":\"OTP Not verified\",\"status\":0}}";

        when(restClient.sendPostRequest(Mockito.any(), Mockito.any())).thenReturn(apiResponse);

        SnapWorkResponse response = loginService.verifyOTP("7006980036", otpVerficatonCode, otp, snapWorkRequest);

        assertEquals("OTP Not verified", response.getMessage());

    }

    @Test
    public void verifyOTPFailTest1() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        SnapWorkResponse response = loginService.verifyOTP("", "", "", snapWorkRequest);

        assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"), response.getMessage());

    }

    @Test
    public void verifyOTPThrowException() throws Exception {
        SnapWorkResponse response = loginService.verifyOTP(null, "", "", null);
        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
    }

    @Test
    public void getAttendanceListSuccessTest() throws Exception {

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("7006980034");

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("USER_NAME", "7006980034");
        map.put("LAPU_NO", "7006980034");
        map.put("ATT_DATETIME", "02/12/2020");
        map.put("ATT_DATETIME", "02/12/2020");
        list.add(map);

        when(adminLoginDao.fetchAttendanceDataDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(list);
        List<AttendanceBean> user = adminPortalLoginServiceImpl.getAttendanceList("1", "02/12/2020", "03/12/2020");

        assertTrue(!user.equals(""));

    }

    @Test
    public void processLogOutRequestSuccessTest() throws Exception {
        int insertCount = 1;

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("7006980034");

        when(adminLoginDao.saveAdminLoginInfoTrackerDetails(Mockito.any())).thenReturn(insertCount);

        SnapWorkResponse response = loginService.processLogOutRequest("7006980034");

        assertEquals(prop.getProperty("ADMIN_LOGOUT_SUCC_MSG"), response.getMessage());
    }

    @Test
    public void processLogOutRequestInsertCount_0_Test() throws Exception {
        int insertCount = 0;

        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("7006980036");

        when(adminLoginDao.saveAdminLoginInfoTrackerDetails(Mockito.any())).thenReturn(insertCount);
        SnapWorkResponse response = loginService.processLogOutRequest("7006980034");

        assertEquals(prop.getProperty("ADMIN_LOGOUT_FAIL_MSG"), response.getMessage());

    }

    @Test
    public void processLogOutRequestFailTest() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setUserName("");

        SnapWorkResponse response = loginService.processLogOutRequest("");

        assertEquals(prop.getProperty("FAILURE_INVALID_REQUEST"), response.getMessage());
    }

    @Test
    public void processLogOutRequestThrowException() throws Exception {
        SnapWorkResponse response = loginService.processLogOutRequest(null);
        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), response.getMessage());
    }

    @Test
    public void isRefreshToKenSuccess() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("7607842110");
        String jwtToken = "jwtToekn123";
        when(commonJWTUtil.generateJwtToken(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
                .thenReturn(jwtToken);

        when(adminLoginDao.updateJWT(Mockito.anyString(), Mockito.anyString())).thenReturn(1);

        SnapWorkResponse response = loginService.isRefreshToKen(snapWorkRequest);

        assertEquals(prop.getProperty("JWT_GENERATED_SUCCESSFULLY"), response.getMessage());
    }

//	@Test
//	void downloadAttendance_Success() throws Exception
//	{
//		String decryptedString = "Q8BaFtsclLu93GvziOY+vOQTnf7Buzm0wnRWC6vzPj8FRIBMXQepAmZvAq+IeFcPrljOcKPohezAGOsZv5siPcxcnVjIw+eJ7TIPW9MWvoLLCiZBfNxybo55CENUrElf251RbZqmAOkOeQu5vZXhqg==";
//
//		MockHttpServletResponse httpResponse = new MockHttpServletResponse();
//		httpResponse.addHeader("parameterName", "someValue");
//
//		Mockito.when(secureBuilderVer.decrypt(Mockito.anyString(),
//				Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(decryptedString);
//
//		SnapWorkResponse response = adminPortalLoginService
//				.downloadAttendance("All", "01-01-2021", "12-03-2021");
//
////		Assertions.assertEquals( "200", response.getStatusCode());
//	}

    @Test
    void downloadAttendance_Success() throws Exception {
        int count = 1;
        Map<String, Object> catRow = new HashMap<>();
        catRow.put("USER_NAME", "9718056667");
        catRow.put("LAPU_NO", "Abhishek Saxena");
        catRow.put("ATT_DATETIME", "8975645342");
        catRow.put("PROMTR_MOBNO", "9897108505");
        catRow.put("USER_NAME", "Varun2");
        catRow.put("LAPU_NO", "7042709703");


        List<Map<String, Object>> catRows = new ArrayList<>();
        catRows.add(catRow);

        Mockito.when(adminLoginDao.fetchAttendanceDataDetails(Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(catRows);

        Mockito.when(adminLoginDao.getOutletVisistedCount(Mockito.any(), Mockito.any())).thenReturn(count);

        SnapWorkResponse response = adminPortalLoginService.downloadAttendance("All", "01-01-2021", "12-03-2021");

        //	assertEquals( "200", response.getStatusCode());
    }

    @Test
    void downloadAttendance_Fail() throws Exception {
        String param_1 = "ezaHxaB7XvbtMDeLPmmnrA==";
        String param_2 = "UThCYUZ0c2NsTHU5M0d2emlPWSt2T1FUbmY3QnV6bTB3blJXQzZ2elBqOEZSSUJNWFFlcEFtWnZBcStJZUZjUHJsak9jS1BvaGV6QUdPc1p2NXNpUGN4Y25Wakl3K2VKN1RJUFc5TVd2b0xMQ2laQmZOeHlibzU1Q0VOVXJFbGYyNTFSYlpxbUFPa09lUXU1dlpYaHFnPT0=";

        String decryptedString = "Q8BaFtsclLu93GvziOY+vOQTnf7Buzm0wnRWC6vzPj8FRIBMXQepAmZvAq+IeFcPrljOcKPohezAGOsZv5siPcxcnVjIw+eJ7TIPW9MWvoLLCiZBfNxybo55CENUrElf251RbZqmAOkOeQu5vZXhqg==";

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(secureBuilderVer.decrypt(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(decryptedString);

        SnapWorkResponse response = adminPortalLoginService
                .downloadAttendance("All", "01-01-2021", "12-03-2021");

        //Assertions.assertEquals( "500", response.getStatusCode());
    }

    @Test
    void downloadAttendance_Exception() throws Exception {
        String param_1 = "ezaHxaB7XvbtMDeLPmmnrA==";
        String param_2 = "UThCYUZ0c2NsTHU5M0d2emlPWSt2T1FUbmY3QnV6bTB3blJXQzZ2elBqOEZSSUJNWFFlcEFtWnZBcStJZUZjUHJsak9jS1BvaGV6QUdPc1p2NXNpUGN4Y25Wakl3K2VKN1RJUFc5TVd2b0xMQ2laQmZOeHlibzU1Q0VOVXJFbGYyNTFSYlpxbUFPa09lUXU1dlpYaHFnPT0=";

        String decryptedString = "Q8BaFtsclLu93GvziOY+vOQTnf7Buzm0wnRWC6vzPj8FRIBMXQepAmZvAq+IeFcPrljOcKPohezAGOsZv5siPcxcnVjIw+eJ7TIPW9MWvoLLCiZBfNxybo55CENUrElf251RbZqmAOkOeQu5vZXhqg==";

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        httpResponse.addHeader("parameterName", "someValue");

        Mockito.when(secureBuilderVer_1.decrypt(param_1,
                param_2, "WEB19", "web"))
                .thenReturn(decryptedString);

        SnapWorkResponse response =
                adminPortalLoginService.downloadAttendance(null, null, null);

//		Assertions.assertEquals( "200", response.getStatusCode());
    }
}
