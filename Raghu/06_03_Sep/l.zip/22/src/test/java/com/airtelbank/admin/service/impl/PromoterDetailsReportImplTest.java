package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.PromoterDetailsReportDAO;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class PromoterDetailsReportImplTest {

    @Autowired
    PromoterDetailsReportImpl promoterDetailsReportImpl;

    @Autowired
    PropertyManager prop;

    @MockBean
    PromoterDetailsReportDAO promoterDetailsReportDAO;

    @MockBean
    CommonUtils commonUtil;

    @Mock
    SnapWorkResponse response;

    @Test
    public void getPromoterDtlsSuccess() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("9000011462");

        Map<String, Object> proRow = new HashMap<>();
        proRow.put("LAPU_NO", "9718056667");
        proRow.put("NAME", "Abhishek Saxena");
        proRow.put("AGENCY", "8975645342");
        proRow.put("EMPLOYEE_ID", "9718056667");
        proRow.put("DOB", "02/04/2001");
        proRow.put("DOJ", "8975645342");
        proRow.put("USER_NAME", "xyz1");
        proRow.put("USER_TYPE", "7042709702");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(proRow);

        Mockito.when(promoterDetailsReportDAO.getPromoterDtls(Mockito.any())).thenReturn(rows);

        Map<String, Object> outRows = new HashMap<>();
        outRows.put("LAPU_NO", "05:50");
        outRows.put("RT_NAME", "-122.084");
        outRows.put("LAPU_NO", "1");
        outRows.put("DATE_OF_VISIT", "1");
        outRows.put("DISP_DATE", "1");
        outRows.put("Check_In", "05:50");
        outRows.put("Check_In_Lat", "1");
        outRows.put("Check_In_Long", "1");
        outRows.put("Date", "1");

        List<Map<String, Object>> list = new ArrayList<>();
        list.add(outRows);

        Mockito.when(promoterDetailsReportDAO.getOutletDtls(Mockito.anyString())).thenReturn(list);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        SnapWorkResponse snapWorkResponse = promoterDetailsReportImpl.getPromoterDtls(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("OUTLET_DETAILS_SUCC_MGS"));

    }

    @Test
    public void getPromoterDtlsFail() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        SnapWorkResponse snapWorkResponse = promoterDetailsReportImpl.getPromoterDtls(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("FAILURE_INVALID_REQUEST"));

    }

    @Test
    void getPromoterDtls_Exception() throws Exception
    {
        try{

        SnapWorkResponse snapWorkResponse = promoterDetailsReportImpl.getPromoterDtls(null);
        assertEquals(prop.getProperty("FAILURE_ERROR_MESSAGE"), snapWorkResponse.getMessage());
    }
        catch (Exception exe) {
            CommonException.getPrintStackTrace(exe);
        }
    }


    @Test
    public void getOutletDtlsSuccess() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("9718056667");

        Map<String, Object> proRow = new HashMap<>();
        proRow.put("LAPU_NO", "9718056667");
        proRow.put("RT_NAME", "Abhishek Saxena");
        proRow.put("LATITUDE", "22.084");
        proRow.put("LONGITUDE", "82.084");
        proRow.put("VILLAGE_NAME", "Noida");
        proRow.put("VILLAGE_TYPE", "abc");
        proRow.put("VILLAGE_POP", "325456");
        proRow.put("CITY", "Noida");
        proRow.put("BLOCK_TEHSIL", "Noida");
        proRow.put("DISTRICT", "Noida");
        proRow.put("SITE_ID", "xyz1");
        proRow.put("CATEGORY", "abc");
        proRow.put("OUTLET_TYPE", "Rt");

        List<Map<String, Object>> rows = new ArrayList<>();
        rows.add(proRow);

        Mockito.when(promoterDetailsReportDAO.getOutletDtl(Mockito.any())).thenReturn(rows);

        Map<String, Object> outRows = new HashMap<>();
        outRows.put("LAPU_NO", "9718056667");
        outRows.put("NAME", "Abhishek Saxena");
        outRows.put("AGENCY", "8975645342");
        outRows.put("EMPLOYEE_ID", "9718056667");
        outRows.put("DOB", "02/04/2001");
        outRows.put("DOJ", "02/04/2001");
        outRows.put("USER_TYPE", "Rt");

        List<Map<String, Object>> list = new ArrayList<>();
        list.add(outRows);

        Mockito.when(promoterDetailsReportDAO.getMappedPromotersList(Mockito.anyString())).thenReturn(list);

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        SnapWorkResponse snapWorkResponse = promoterDetailsReportImpl.getOutletDtls(snapWorkRequest);

//        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("PROMOTERS_DETAILS_SUCC_MGS"));

    }

    @Test
    public void getOutletDtlsFail() throws Exception {
        SnapWorkRequest snapWorkRequest = new SnapWorkRequest();
        snapWorkRequest.setMobileNo("");

        Mockito.when(commonUtil.convertMillis(Mockito.anyLong())).thenReturn("");

        SnapWorkResponse snapWorkResponse = promoterDetailsReportImpl.getOutletDtls(snapWorkRequest);

        assertEquals(snapWorkResponse.getMessage(), prop.getProperty("FAILURE_INVALID_REQUEST"));

    }

    @Test
    void downloadPromoterDtls_Success() throws Exception {
        Map<String, Object> outRows = new HashMap<>();
        outRows.put("LAPU_NO", "983905713");
        outRows.put("NAME", "Abhishek Saxena");
        outRows.put("AGENCY", "8975645342");
        outRows.put("EMPLOYEE_ID", "9718056667");
        outRows.put("DOB", "02/04/1996");
        outRows.put("DOJ", "02/04/2010");
        outRows.put("USER_TYPE", "7042709702");

        List<Map<String, Object>> list = new ArrayList<>();
        list.add(outRows);

        Mockito.when(promoterDetailsReportDAO.getMappedPromotersList(Mockito.any())).thenReturn(list);

        SnapWorkResponse snapWorkResponse = promoterDetailsReportImpl.downloadPromoterDtls("983905713");

        assertEquals(prop.getProperty(Constants.SUCCESS_STATUS_CODE), snapWorkResponse.getStatusCode());

    }

    @Test
    void downloadOutletDtls_Success() throws Exception {
        Map<String, Object> proRow = new HashMap<>();
        proRow.put("LAPU_NO", "9718056667");
        proRow.put("RT_NAME", "Abhishek Saxena");
        proRow.put("LATITUDE", "22.084");
        proRow.put("LONGITUDE", "82.084");
        proRow.put("VILLAGE_NAME", "Noida");
        proRow.put("VILLAGE_TYPE", "abc");
        proRow.put("VILLAGE_POP", "325456");
        proRow.put("CITY", "Noida");
        proRow.put("BLOCK_TEHSIL", "Noida");
        proRow.put("DISTRICT", "Noida");
        proRow.put("SITE_ID", "xyz1");
        proRow.put("CATEGORY", "abc");
        proRow.put("OUTLET_TYPE", "Rt");

        List<Map<String, Object>> list = new ArrayList<>();
        list.add(proRow);

        Mockito.when(promoterDetailsReportDAO.getOutletDtls(Mockito.any())).thenReturn(list);

        SnapWorkResponse snapWorkResponse = promoterDetailsReportImpl.downloadOutletDtls("983905713");

        assertEquals(prop.getProperty(Constants.SUCCESS_STATUS_CODE), snapWorkResponse.getStatusCode());

    }

}