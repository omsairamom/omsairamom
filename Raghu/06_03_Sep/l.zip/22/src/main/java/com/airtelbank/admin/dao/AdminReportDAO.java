package com.airtelbank.admin.dao;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AdminReportDAO
{
	private static Logger logger = LoggerFactory.getLogger(AdminReportDAO.class);

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	@Autowired
	SnapWorkResponse response;

	String time =" 11:59:59 PM";

	public List<Map<String, Object>> fetchMarketRoleDetails(String categoryId, String circleId, String zoneId,String roleName) throws Exception
	{

		List<Map<String, Object>> rows = null;
		String query = "";

		try
		{

			if (roleName.equals("All")  && categoryId.equals("All") && circleId.equals("All") && zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL);
				rows = jdbctemplate.queryForList(query, new Object[] {});
			} else if (roleName.equals("All") && !categoryId.equals("All") &&  circleId.equals("All") && zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + " AND CAT_ID=?";
				rows = jdbctemplate.queryForList(query, categoryId);
			}else if (roleName.equals("All") &&  categoryId.equals("All") && !circleId.equals("All") && zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + "AND CIRCLE_ID=?";
				rows = jdbctemplate.queryForList(query, circleId);
			} else if ( roleName.equals("All") && categoryId.equals("All") && circleId.equals("All") && !zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL)+ " AND ZONE_ID=?";
				rows = jdbctemplate.queryForList(query, zoneId);
			}else if ( roleName.equals("All") && categoryId.equals("All") && !circleId.equals("All") && !zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + "AND CIRCLE_ID=? AND ZONE_ID=?";
				rows = jdbctemplate.queryForList(query, circleId,zoneId);
			}else if ( roleName.equals("All") && !categoryId.equals("All") && !circleId.equals("All") && !zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + "AND CAT_ID=? AND CIRCLE_ID=? AND ZONE_ID=?";
				rows = jdbctemplate.queryForList(query, categoryId,circleId,zoneId);
			}

			else if (!roleName.equals("All")  && categoryId.equals("All") && circleId.equals("All") && zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) +"AND " +roleName+"ID=0";
				rows = jdbctemplate.queryForList(query, new Object[] {});
			} else if (!roleName.equals("All") && !categoryId.equals("All") &&  circleId.equals("All") && zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) +"AND " +roleName+"ID=0" +" AND CAT_ID=?";
				rows = jdbctemplate.queryForList(query, categoryId);
			}else if (!roleName.equals("All") &&  categoryId.equals("All") && !circleId.equals("All") && zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + "AND " +roleName+"ID=0" +"AND CIRCLE_ID=?";
				rows = jdbctemplate.queryForList(query, circleId);
			} else if (! roleName.equals("All") && categoryId.equals("All") && circleId.equals("All") && !zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + "AND " +roleName+"ID=0" + " AND ZONE_ID=?";
				rows = jdbctemplate.queryForList(query, zoneId);
			}else if ( !roleName.equals("All") && categoryId.equals("All") && !circleId.equals("All") && !zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + "AND " +roleName+"ID=0" + "AND CIRCLE_ID=? AND ZONE_ID=?";
				rows = jdbctemplate.queryForList(query, circleId,zoneId);
			}else if ( !roleName.equals("All") && !categoryId.equals("All") && !circleId.equals("All") && !zoneId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_DTLS_ALL) + "AND " +roleName+"ID=0" + "AND CAT_ID=? AND CIRCLE_ID=? AND ZONE_ID=?";
				rows = jdbctemplate.queryForList(query, categoryId,circleId,zoneId);
			}

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}

	public String fetchMarketVisitedRetailerDetails(String retailerNo) throws Exception
	{

		String query = "";
		String retailerName = "";

		try
		{
			query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_RETAILER_DTLS);
			List<Map<String, Object>> rows = jdbctemplate.queryForList(query, retailerNo );
			if (rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					retailerName = row.get("USER_NAME") == null ? "" : row.get("USER_NAME").toString();
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return retailerName;
	}

	@SuppressWarnings("rawtypes")
	public int getOutletVisistedCount(String roleName,String mobileNo) throws Exception
	{

		String query = "";
		List<Map<String, Object>> rows = null;
		int count = 0;
		String retCount="";

		try{

			String roleNameFromDb = getRollDetails(mobileNo);
			if(roleName.equalsIgnoreCase("All"))
			{
				roleNameFromDb = getRollDetails(mobileNo);
				query = prop.getProperty(Constants.DASHBOARD_FETCH_ASSIGNED_OUTLET_DTLS)+ "  AND "+roleNameFromDb+"ID=?";
				rows = jdbctemplate.queryForList(query, mobileNo);
			}
			if(!roleName.equalsIgnoreCase("All") && roleName.equalsIgnoreCase("PR") || roleName.equalsIgnoreCase("TL"))
			{
				query = prop.getProperty(Constants.DASHBOARD_FETCH_ASSIGNED_OUTLET_DTLS)  + " AND " +roleNameFromDb+"ID=?";
				rows = jdbctemplate.queryForList(query, mobileNo);

			}
			if(rows != null && !rows.isEmpty())
			{
				for (Map row : rows)
				{
					retCount = row.get("count") == null ? "0" : row.get("count").toString();
					count = Integer.parseInt(retCount);
				}
			}
			logger.info("mobileNo {}:",mobileNo);
			logger.info("count {}:",count);
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public String getRollDetails(String mobileNo) throws Exception
	{
		String roleName = "";

		try
		{

			String query = prop.getProperty(Constants.LOGIN_FETCH_ROLE_DTLS_OTHER_HIERARCHY);

			List<Map<String, Object>> rows =  jdbctemplate.queryForList(query, mobileNo);

			if(rows != null && !rows.isEmpty())
			{
				Map<String, Object> promoType  = rows.get(0);
				roleName = (String) promoType.get("USER_TYPE") == null ? "" : promoType.get("USER_TYPE").toString();
			}

		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return roleName ;
	}

	public List<Map<String, Object>> fetchMarketVisitedCheckInDetails(String retailerNo, String LapuNo, String startDate, String endDate)
			throws Exception {

		List<Map<String, Object>> checkInrows = null;
		String query = "";
		endDate = endDate + time;
		try {
			if (StringUtils.isNotBlank(retailerNo) && StringUtils.isNotBlank(LapuNo)) {
				query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_CHECK_IN_DTLS);
				checkInrows = jdbctemplate.queryForList(query, retailerNo, LapuNo,  startDate, endDate );
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return checkInrows;
	}

	public List<Map<String, Object>> fetchCheckInDetails(String retailerNo,String LapuNo , String startDate, String endDate)
			throws Exception {

		List<Map<String, Object>> rows = null;
		String query = "";
		endDate = endDate + time;
		try {

			query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_CHECK_IN);
			rows = jdbctemplate.queryForList(query, retailerNo,LapuNo, startDate, endDate);

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return rows;

	}

	public List<Map<String, Object>> fetchCheckOutDetails(String retailerNo,String LapuNo, String startDate, String endDate)
			throws Exception {

		List<Map<String, Object>> rows = null;
		String query = "";
		endDate = endDate + time;
		try {
			query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_CHECK_OUT);
			rows = jdbctemplate.queryForList(query, retailerNo,LapuNo, startDate, endDate);
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return rows;

	}

	public List<Map<String, Object>> getLatLongDtls(String displayDate, String mobileNo, String retailerNo) throws Exception
	{
		List<Map<String, Object>> rows = null;
		String query = "";
		try {
			query = prop.getProperty(Constants.ADMIN_FETCH_MARKET_VISITED_LAT_LONG);
			rows = jdbctemplate.queryForList(query, displayDate,retailerNo,mobileNo);
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}

}
