package com.airtelbank.admin.service;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.CustomException;

public interface KpiConfigurationService
{
	public SnapWorkResponse kpiConfigurationDtls(SnapWorkRequest request)throws CustomException;

	public SnapWorkResponse fetchKpiConfigurationOnloadDtls(SnapWorkRequest request)throws CustomException;

	public SnapWorkResponse fetchKpiConfigurationGetPromoterType(String categoryId) throws CustomException;
}
