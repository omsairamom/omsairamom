package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.KpiConfigurationService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class KpiConfigurationController
{
    private static Logger logger = LoggerFactory.getLogger(KpiConfigurationController.class);

    @Autowired
    SnapWorkResponse response;

    @Autowired
    KpiConfigurationService kpiConfiguraService;

    @Autowired
    PropertyManager prop;

    @Autowired
    CommonUtils commonUtil;

    JSONObject json = new JSONObject();
    long startTime = 0;
    long endTime = 0;
    long elapsedTimeMillis = 0;
    GsonBuilder gsonBuilder = new GsonBuilder();
    Gson gson = gsonBuilder.create();

    @PostMapping(path = "/v1/kpi/config")
    public ResponseEntity<Object> kpiConfigurationDetails(@Valid @RequestBody SnapWorkRequest request)
    {
        try
        {
            startTime = System.currentTimeMillis();

            String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
            String categoryName = request.getCategoryName() == null ? "" : request.getCategoryName().trim();
            String kpiName = request.getKpiName() == null ? "" : request.getKpiName().trim();
            String weightAge = request.getWeightAge() == null ? "" : request.getWeightAge().trim();
            String target = request.getTarget() == null ? "" : request.getTarget().trim();
            String statusEnable = request.getStatusEnable() == null ? "" : request.getStatusEnable().trim();
            String action = request.getAction() == null ? "" : request.getAction().trim();


            if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNotBlank(categoryName) && StringUtils.isNotBlank(kpiName)
                    && StringUtils.isNotBlank(weightAge) && StringUtils.isNotBlank(target) && StringUtils.isNotBlank(statusEnable) && StringUtils.isNotBlank(action)
                    && StringUtils.isNumeric(weightAge) && StringUtils.isNumeric(target))
            {
                response = kpiConfiguraService.kpiConfigurationDtls(request);
            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            logger.info("KPI Configuration details, Request end timeInMillis {}:" , endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("************************************************************************************************************************************* {}:", "");
        }
        catch (Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(path = "/v1/kpi/onload")
    public ResponseEntity<Object> fetchKpiConfigurationOnloadDetails(@Valid @RequestBody SnapWorkRequest request)
    {
        try
        {
            startTime = System.currentTimeMillis();

            String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();

            if (StringUtils.isNotBlank(mobileNo))
            {
                response = kpiConfiguraService.fetchKpiConfigurationOnloadDtls(request);
            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            logger.info("Fetch KpiConfiguration onload details, Request end timeInMillis {}:" , endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("*************************************************************************************************************************************{}:", "");
        }
        catch (Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(path = "/v1/kpi/getPromoterType")
	public ResponseEntity<Object> fetchKpiConfigurationGetPromoterType(@Valid @RequestBody SnapWorkRequest request)
    {
        try
        {
            startTime = System.currentTimeMillis();

            String categoryId = request.getCategoryId() == null ? "" : request.getCategoryId().trim();

            if (StringUtils.isNotBlank(categoryId))
            {
                response = kpiConfiguraService.fetchKpiConfigurationGetPromoterType(categoryId);
            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            logger.info("Fetch KpiConfiguration onload details, Request end timeInMillis {}:" , endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("************************************************************************************************************************************* {}:" , "");
        }
        catch (Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}