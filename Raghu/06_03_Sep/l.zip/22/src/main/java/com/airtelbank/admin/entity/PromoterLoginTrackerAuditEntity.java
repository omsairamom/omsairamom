package com.airtelbank.admin.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Table(name = "PROMOTER_LOGIN_TRACKER_MST",
indexes = { 
		@Index(name = "IndexUserNo",  columnList="userNo"),
		@Index(name = "IndexUserId",  columnList="user_id")
	})
@EntityListeners(AuditingEntityListener.class)
public class PromoterLoginTrackerAuditEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column
    @NotNull
    private String userNo;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    private String latitude;

    @Column
    private String longitude;

    @Column
    @NotNull
    private String logInType;

    @Column
    private String deviceId;

    @Column
    @NotNull
    private String channel;

    @Column
    private String custom_field1;

    @Column
    private String custom_field2;

    @Column
    private String custom_field3;

    @Column
    private String custom_field4;

    @Column
    private String custom_field5;

    @Column
    @UpdateTimestamp
    private LocalDateTime updatedDate;

    @Column
    @CreationTimestamp
    private LocalDateTime createdDate;
}