package com.airtelbank.admin.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.repository.PromoterUploadFileAuditRepository;

@Service
public class PromoterUploadFileAuditDao {
	
	 @Autowired
	 private PromoterUploadFileAuditRepository promoterUploadFileAuditRepository;
	 
	 
	 public PromoterUploadFileAuditEntity fetchFileByName(String filename)
	 {
		 return promoterUploadFileAuditRepository.findOneByFileName(filename);
	 }
	
	 public void updateFile(PromoterUploadFileAuditEntity file)
	 {
		 promoterUploadFileAuditRepository.save(file);
	 }
}
