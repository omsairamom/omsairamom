package com.airtelbank.admin.service.impl;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.airtelbank.admin.bean.KibanaLoggerBean;
import com.airtelbank.admin.dao.PromoterUserMSTDao;
import com.airtelbank.admin.dto.WhitelistedPromoter;
import com.airtelbank.admin.dto.WhitlelistedPromoterResponse;
import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.entity.PromoterUserMSTEntity;
import com.airtelbank.admin.enums.UserType;
import com.airtelbank.admin.service.FileProcessingService;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.CustomMappingStrategy;
import com.airtelbank.admin.util.KibanaLoggerUtils;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

@Service
public class PromoterUserFileProcessImpl implements FileProcessingService{
	
	private static Logger logger = LoggerFactory.getLogger(PromoterUserFileProcessImpl.class);
	
	@Value("#{'${promoter.user.memberFieldsToBindTo.headers}'.split(',')}")
	private List<String> memberFieldsToBindToPromoterUserList;
	
	
	@Value("${promoter.whitelist.file.processing.directory.path}")
	private String inputFilePathDir;
	
	@Value("${promoter.whitelist.file.output.directory.path}")
	private String outputFilePathDir;
	
	@Value("${outlet.max.pool.size}")
	private int maxPoolSizeOutlet;
	
	@Value("${prWhitelist.record.validation.timeout}")
	private int prWhitelistRecordValidationTimeout;
	
	
	@Autowired
	private PromoterUserMSTDao promoterUserMSTDao;
	

	@Autowired
	private AsyncFileProcessor asyncFileProcessor;
	
	@Value("${aerospike.setname.promoter_user}")
	private String promoterUserSet;
	
	@Autowired
	private KibanaLoggerUtils kibanaUtils;
		
	@Override
	 public void processFile(String filename,int type,PromoterUploadFileAuditEntity file) throws Exception {
 
		logger.info("PromoterUserFileProcessImpl | processFile() | start ");
    	
    	//file path for output
        String outputFilePath =  outputFilePathDir+filename;
    	
    	//Read the file from serverpath
    	String inputfilepath = inputFilePathDir+filename;
    	
    	
    	try (
                Reader reader = Files.newBufferedReader(Paths.get(inputfilepath));
            ) {
    		
    		  
    		
    		  ColumnPositionMappingStrategy strategy = new ColumnPositionMappingStrategy();
              strategy.setType(WhitelistedPromoter.class);

              String[] memberFieldsToBindTo = memberFieldsToBindToPromoterUserList.toArray(new String[0]);
              strategy.setColumnMapping(memberFieldsToBindTo);

              CsvToBean<WhitelistedPromoter> csvToBean = new CsvToBeanBuilder(reader)
            		  .withMappingStrategy(strategy)
                      .withSkipLines(1)
                      .withIgnoreLeadingWhiteSpace(true)
                      .build();

              try ( 
             
              Writer writer = Files.newBufferedWriter(Paths.get(outputFilePath));
              ){ 
            	  
              CustomMappingStrategy<WhitlelistedPromoterResponse> mappingStrategy = new CustomMappingStrategy<WhitlelistedPromoterResponse>();
            	  
              mappingStrategy.setType(WhitlelistedPromoterResponse.class);
              StatefulBeanToCsv<WhitlelistedPromoterResponse> beanToCsv = new StatefulBeanToCsvBuilder(writer)
                              .withMappingStrategy(mappingStrategy)
                              .build();

              CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponses = new CopyOnWriteArrayList<>();
             
              CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponsesValidationSuccess = new CopyOnWriteArrayList<>();
              Map<Integer,WhitlelistedPromoterResponse> mapEntityOutputPrWhitelist = new ConcurrentHashMap<>();
              int lineNo=0;
              
              Iterator<WhitelistedPromoter> whitelistedPromoter = csvToBean.iterator();
       
              Collection< CompletableFuture<PromoterUserMSTEntity>> futures = new ArrayList< CompletableFuture<PromoterUserMSTEntity>>();
              
              int count=0;
              CopyOnWriteArrayList<PromoterUserMSTEntity> promoterUserMSTEntityList = new CopyOnWriteArrayList<>();
              boolean processAsync=false;int countProcessedRecords=0;
              Map<String,Long> promoterUserMgmtCache = new HashMap<>();
              while (whitelistedPromoter.hasNext()) 
               {
            
            	  	lineNo++;
                	

                	
                	WhitelistedPromoter user = whitelistedPromoter.next();
               
                	if(null != user && !user.getUserType().equalsIgnoreCase(String.valueOf(UserType.PR.getCode())))
                	{
                	   
                	   processRecordInSync(user,recordResponses,file,promoterUserMgmtCache);
                	      
                	}
                	else if(null != user && user.getUserType().equalsIgnoreCase(String.valueOf(UserType.PR.getCode())))
                	{
                		count++;
                		processAsync=true;
                		futures.add( asyncFileProcessor.processPromoterUserFileRecordsAsync(user,recordResponses,recordResponsesValidationSuccess,file,promoterUserMSTEntityList,mapEntityOutputPrWhitelist,lineNo,promoterUserMgmtCache ));
                	}
                	
                	if(processAsync && (count==maxPoolSizeOutlet || !whitelistedPromoter.hasNext()))
	               	{
	               		for ( CompletableFuture<PromoterUserMSTEntity> future : futures) 
	               		{
	               			PromoterUserMSTEntity prWhitelistEntity=null;
	                        try {
	                        	//future.get();
	                        	prWhitelistEntity = future.get(prWhitelistRecordValidationTimeout, TimeUnit.MILLISECONDS);
	                        }catch(TimeoutException e)
							{
								logger.error("PromoterUserFileProcessImpl | processFile() | Exception Timeout Message {}, Cause {}",e.getMessage(),e.getCause());
								future.cancel(true);
							}
	                        catch (InterruptedException | ExecutionException e) {
	                        	logger.error("PromoterUserFileProcessImpl | processFile() | Exception while waiting for chunk of threads to complete process. Message {} Cause {}",e.getMessage(),e.getCause());
	                        	future.cancel(true);
	                        }catch(Exception e)
	                        {
	                        	logger.error("PromoterUserFileProcessImpl | processFile() | Exception Message {} Cause {}",e.getMessage(),e.getCause());
	                        	future.cancel(true); 
	                        }
	                    }
	               		
	               		logger.info("PromoterUserFileProcessImpl -> processFile() | Total count of threads in this chunk {}",count);
	               		
	               		logger.info("PromoterUserFileProcessImpl -> processFile() | Count of records which failed validation {}",recordResponses.size());
	               		
	               		logger.info("PromoterUserFileProcessImpl -> processFile() | Count of records which passed validation {}",recordResponsesValidationSuccess.size());
	               		count=0;
	               		
	               		
	               		List<PromoterUserMSTEntity> duplicateEntitiesList = new ArrayList<>();
	               		
	               		Set<PromoterUserMSTEntity> set = new HashSet<PromoterUserMSTEntity>();
	               		for(PromoterUserMSTEntity entity: promoterUserMSTEntityList)
	               		{
	               			if(set.contains(entity))
	               			{
	               				duplicateEntitiesList.add(entity);
	               
	               			}else {
	               				set.add(entity);
	               			}	

	               		}
	               		List<PromoterUserMSTEntity> uniqueEntitiesList = new ArrayList<PromoterUserMSTEntity>(set);
	               		boolean isSaveSucess = saveInDBAsync(uniqueEntitiesList,recordResponsesValidationSuccess);
	               		
	               		
	               		markDuplicateRecords(mapEntityOutputPrWhitelist, duplicateEntitiesList, isSaveSucess);
	               		
	               		//add every element from recordResponseChunk into recordResponses list
	               		for(WhitlelistedPromoterResponse recordFromChunk : recordResponsesValidationSuccess)
	               		{
	               			recordResponses.add(recordFromChunk);
	               		}
	               		
	               		countProcessedRecords = countProcessedRecords+ recordResponses.size();
	               		file.setProcessedRecords(countProcessedRecords);
	               		populateKibanaLoggingObject(recordResponses,file);
	               		beanToCsv.write(recordResponses);
	               		recordResponsesValidationSuccess.clear();
	               		promoterUserMSTEntityList.clear();
	               		mapEntityOutputPrWhitelist.clear();
	               		recordResponses.clear();
	               		
	               	}
                	
                	if(!processAsync)
                	{
                		countProcessedRecords = countProcessedRecords+ recordResponses.size();
	               		file.setProcessedRecords(countProcessedRecords);
	               		populateKibanaLoggingObject(recordResponses,file);
	               		beanToCsv.write(recordResponses);
	               		recordResponses.clear();
                	}
        
                }

              	logger.info("PromoterUserFileProcessImpl | processFile() | All threads have finished working");
              
              	
               //When all async threads completed their work, write list of records to csv file 
              	promoterUserMgmtCache.clear();
              	writer.close();
              	

              } catch (IOException | CsvDataTypeMismatchException | CsvRequiredFieldEmptyException e) {
            	  logger.error("PromoterUserFileProcessImpl | processFile() | Exception occured while writing into file. Message {} Cause {}",e.getMessage(),e.getCause());
			}
            } catch (IOException e1) {
            	logger.error("PromoterUserFileProcessImpl | processFile() | Exception occured while reading from file. Message {} Cause {}",e1.getMessage(),e1.getCause());
			}
        }
	
		private void populateKibanaLoggingObject(CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponses,PromoterUploadFileAuditEntity file) 
		{
			for(WhitlelistedPromoterResponse record : recordResponses)
			{
				KibanaLoggerBean kb = new KibanaLoggerBean();
				kb.setId1(record.getUserNumber());
				kb.setId5(record.getRemarks());
				kb.setId8(record.getAction());
				kb.setId7(file.getFileName());
				kibanaUtils.printKibanaLogs(kb);
				
			}
		}

		private void markDuplicateRecords(Map<Integer, WhitlelistedPromoterResponse> mapEntityOutputOutlet,
				List<PromoterUserMSTEntity> duplicateEntitiesList, boolean isSaveSucess) {
			if(isSaveSucess)
			{
				for(PromoterUserMSTEntity entity: duplicateEntitiesList)
				{
					WhitlelistedPromoterResponse outletResp = (mapEntityOutputOutlet != null) ? mapEntityOutputOutlet.get(entity.getLineNo()) : null;
					if(null != outletResp)
					{
						outletResp.setRemarks(Constants.Validate_Success+Constants.COMMA+ Constants.DUPLICATE_RECORD);
					}
				}
			}
		}

		private void processRecordInSync(WhitelistedPromoter user, CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponses, PromoterUploadFileAuditEntity file, Map<String,Long> promoterUserMgmtCache) {
			logger.info("PromoterUserFileProcessImpl | processRecordInSync() | start");	
			PromoterUserMSTEntity promoterUserMSTEntity = new PromoterUserMSTEntity();
			
			//populate with existing record for writing in output csv file 
			WhitlelistedPromoterResponse whitlelistedPromoterResponse = asyncFileProcessor.populatePromoterUserResponseRecordWithExistingDetails(user);
			
			//validate columns and populate remark field for output file and  zoneid,parentid,fileid for save in db
			asyncFileProcessor.validateAndPoulatePromoterUserData(user, whitlelistedPromoterResponse, promoterUserMSTEntity,promoterUserMgmtCache);
			
			//if remark success, save in DB
			promoterUserMSTEntity.setPromoterUploadFileAuditEntity(file);
			if(whitlelistedPromoterResponse.getRemarks().equalsIgnoreCase(Constants.Validate_Success))
			{
				// Populate PromoterWhitelist entity object also and save
				saveInDB(promoterUserMSTEntity,whitlelistedPromoterResponse);
			}
			
			//if record success or rejected due to error, add in list to save in csv file
			recordResponses.add(whitlelistedPromoterResponse);	
			
			
			logger.info("PromoterUserFileProcessImpl | processRecordInSync() | end"); 
		}

		@Transactional
		private void saveInDB(PromoterUserMSTEntity promoterUserMSTEntity,WhitlelistedPromoterResponse whitlelistedPromoterResponse) {
			logger.info("PromoterUserFileProcessImpl | saveInDB() | start"); 
			try {
				promoterUserMSTDao.saveInDB(promoterUserMSTEntity);
				appendPrWhiteListResponseRemarksSync(whitlelistedPromoterResponse,Constants.SUCCESS, Constants.TWO_HUNDRED);
				
				}
			catch(Exception e) {
				logger.error("PromoterUserFileProcessImpl | saveInDB() | Exception while saving in db. Message {} Cause {}", e.getMessage() , e.getCause());
				appendPrWhiteListResponseRemarksSync(whitlelistedPromoterResponse,Constants.INTERNAL_ERROR, Constants.THREE_HUNDRED);
			}
			logger.info("PromoterUserFileProcessImpl | saveInDB() | end");
		}
		
		private void appendPrWhiteListResponseRemarksSync(WhitlelistedPromoterResponse whitlelistedPromoterResponse,
				String message, String messageCode) {
			
			String remarks = whitlelistedPromoterResponse.getRemarks();
			remarks = remarks+Constants.COMMA+message+Constants.COLON+messageCode;
			whitlelistedPromoterResponse.setRemarks(remarks);	
		}

		@Transactional
		private boolean saveInDBAsync(List<PromoterUserMSTEntity> uniqueEntitiesList,CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponseChunk) {
			boolean isSaveSucess=false;
			logger.info("PromoterUserFileProcessImpl | saveInDBAsync() | start"); 
			try {
				if(!uniqueEntitiesList.isEmpty()) {
					promoterUserMSTDao.saveAllInDB(uniqueEntitiesList);
					appendPrWhiteListResponseRemarksAsync(recordResponseChunk,Constants.SUCCESS, Constants.TWO_HUNDRED);//marking the complete chunk(which also contains duplicate entries)with success 
					isSaveSucess=true;
				}
			}
			catch(Exception e) {
				logger.error("PromoterUserFileProcessImpl | saveInDBAsync() | Exception while saving in db. Message {} Cause {}"+ e.getMessage() + e.getCause());
				appendPrWhiteListResponseRemarksAsync(recordResponseChunk,Constants.INTERNAL_ERROR, Constants.THREE_HUNDRED); //marking the complete chunk(which also contains duplicate entries) with error 
				isSaveSucess=false;
			}
			
			logger.info("PromoterUserFileProcessImpl | saveInDBAsync() | end");
			return isSaveSucess;
		}
		
		private void appendPrWhiteListResponseRemarksAsync(CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponseChunk,String message, String messageCode) 
		{	
			for(WhitlelistedPromoterResponse record: recordResponseChunk)
			{
					String remarks = record.getRemarks();
					remarks = remarks+Constants.COMMA+message+Constants.COLON+messageCode;
					record.setRemarks(remarks);
			}
		}
	
}
