package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.bean.*;
import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.FileUploadDAO;
import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.enums.FileStatus;
import com.airtelbank.admin.enums.FileType;
import com.airtelbank.admin.jwt.AeroCache;
import com.airtelbank.admin.repository.PromoterUploadFileAuditRepository;
import com.airtelbank.admin.service.FileUploadService;
import com.airtelbank.admin.util.*;
import com.opencsv.CSVReader;
import net.bytebuddy.implementation.bytecode.Throw;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Primary
public class FileUploadServiceImpl implements FileUploadService
{

	private static Logger logger = LoggerFactory.getLogger(FileUploadServiceImpl.class);

	@Autowired
	PropertyManager prop;

	@Autowired
	FileUploadDAO fileUploadDao;

	@Autowired
	SnapWorkResponse response;

	@Autowired
	SnapWorkRequest request;

	@Autowired
	CommonUtils commonUtil;

	@Autowired
	private AeroCache aeroCache;

	@Autowired
	private PromoterUploadFileAuditRepository promoterUploadFileAuditRepository;

	@Value("${promoter.whitelist.file.type}")
	private String promoterWhitelistFileType;

	@Value("${promoter.outlet.mapping.file.type}")
	private String promoterOutletMappingFileType;

	@Value("${promoter.whitelist.file.headers.count}")
	private int promoterWhitelistFileHeadersCount;

	@Value("${promoter.outlet.mapping.file.headers.count}")
	private int promoterOutletMappingFileHeadersCount;

	@Value("${promoter.whitelist.file.headers}")
	private String promoterWhitelistFileHeaders;

	@Value("${promoter.outlet.mapping.file.headers}")
	private String promoterOutletMappingFileHeaders;

	@Value("${promoter.file.max.row.count}")
	private Long promoterfileMaxRowCount;

	@Value("${promoter.whitelist.file.input.directory.path}")
	private String promoterWhitelistFileDirectoryPath;

	@Value("${promoter.whitelist.file.output.directory.path}")
	private String promoterWhitelistFileOutputDirectoryPath;

	@Value("${promoter.outlet.file.output.directory.path}")
	private String promoterOutletFileOutputDirectoryPath;

	@Value("${promoter.outlet.file.input.directory.path}")
	private String promoterOutletFileDirectoryPath;

	private String setName = "FILE_MGMT";

	public SnapWorkResponse retailerUploadDetails(MultipartFile file)
	{

		JSONObject json = new JSONObject();
		List csvRecordsList = new ArrayList();
		List retailerList = null;
		List circleList = null;
		List othersList = null;
		RetailerDetailsBean retailerBean = new RetailerDetailsBean();
		CircleMasterBean circleBean = new CircleMasterBean();
		OthersHierarchyBean othersBean = new OthersHierarchyBean();
		int rows = 0;
		int row = 0;
		String circleId = "";
		String zoneId = "";
		String catId = "";

		try
		{

			logger.info("Inside retailerUploadDetails() method in FileUploadServiceImpl class... {}:" , "");

			String uploadFilePath = prop.getProperty("FILE_UPLOAD_RETAILER_PATH");
			String fileName = file.getOriginalFilename();

			logger.info("contains {}:", fileName.contains("C:\\fakepath\\"));

			int idx = fileName.replaceAll("\\\\", "/").lastIndexOf("/");
			fileName = idx >= 0 ? fileName.substring(idx + 1) : fileName;

			logger.info("after if {}:", fileName);

			boolean isValidFileExtnFlag = FileExtenValidation.validateFileExtn(fileName);
			logger.info("isValidFileExtnFlag{} :", isValidFileExtnFlag);

			boolean isValidFileName = FileExtenValidation.validateFileName(fileName);
			logger.info("isValidFileName{} :", isValidFileName);

			if (isValidFileExtnFlag && isValidFileName)
			{
				logger.info("isValidFileExtnFlag & isValidFileName values are true{} :", "");
				byte[] bytes = file.getBytes();
				Path path = Paths.get(uploadFilePath + file.getOriginalFilename());
				Files.write(path, bytes);

				List<List<String>> subRecordList = new ArrayList<>();

				try (CSVReader csvReader = new CSVReader(
						new FileReader(uploadFilePath + file.getOriginalFilename()));) {
					String[] values = null;
					while ((values = csvReader.readNext()) != null) {
						subRecordList.add(Arrays.asList(values));
					}
				}

				String csvHeader = subRecordList.get(0).toString();
				logger.info("subRecordList.size {}:" , subRecordList.size());

				String snapworkHeader = prop.getProperty("RETAILER_HEADERS");
				if (StringUtils.isBlank(snapworkHeader))
				{

					snapworkHeader = "[Retailer No, Retailer name, Outlet_Type, LONGITUDE, LATITUDE, Village-name, Villages Type, Village-pop, City, block/tehsil, District, Site-Id, Circle_Code, Circle_Name, Category, Promoter LAPU No, Promoter Name, Promoter Agency, Promoter Employee ID, Promoter DOB, Promoter DOJ, TL NO, TL_NAME, TL Agency, TL Employee ID, TL DOB, TL DOJ, Zone name, ZM No, ZM Name, RM MSISDN, RM Name, CPH No, CPH_NAME, AddOrDeactivateStatus, AddOrDeactivateStatusDate, Promoter_Type]";
				}

				logger.info("csvHeader {}:" , csvHeader);
				logger.info("snapworkHeader {}:" , snapworkHeader);

				HashMap<String, String> circleMap = fileUploadDao.populateCircleMaster();
				logger.info("ADMIN_FETCH_CIRCLE_ID circleMap.size() {}:" , circleMap.size());

				HashMap<String, String> zoneMap = fileUploadDao.populateZoneMaster();
				logger.info("UPLOAD_RET_CSV_FETCH_ZONE_ID zoneMap.size() {}:" , zoneMap.size());

				HashMap<String, String> categoryMap = fileUploadDao.getCategoryIdDtlsMap();
				logger.info("ADMIN_FETCH_CATEGORY_ID categoryMap.size() {}:" , categoryMap.size());

				ArrayList<String> mobileNolist = fileUploadDao.populateAppUserDtls();
				logger.info("ADMIN_APP_USER_LAPU_NO_DTLS mobileNolist.size() {}:" , mobileNolist.size());

				ArrayList<String> otherMobilelist = fileUploadDao.populateOthersDtls();
				logger.info("ADMIN_OTHERS_LAPU_NO_DTLS otherMobilelist.size() {}:" , otherMobilelist.size());

				for (int i = 1; i < subRecordList.size(); i++)
				{
					logger.info("inside for loop subRecordList.size {}:" , i);

					retailerList = subRecordList.get(i).subList(0, 15);

					circleList = subRecordList.get(i).subList(12, 14);

					othersList = subRecordList.get(i).subList(15, 38);

					Collections.replaceAll(retailerList, "", "NA");
					Collections.replaceAll(circleList, "", "NA");
					Collections.replaceAll(othersList, "", "NA");

					setValuesToRetailerBean(retailerList, retailerBean);
					setValuesToCircleBean(circleList, circleBean);
					setValuesToOthersBean(othersList, othersBean);

					// Add Records into DB
					if (othersBean.getAction().equals("A"))
					{
						logger.info("retailerUploadDetails() Action equals A for retailer: {} & promoter:{} :" , retailerBean.getRetailerNo(), othersBean.getPromoterLapuNo());

						if (categoryMap.containsKey(retailerBean.getCategory()))
						{
							catId = categoryMap.get(retailerBean.getCategory());
						}

						if (circleMap.containsKey(circleBean.getCircleName()))
						{
							circleId = circleMap.get(circleBean.getCircleName());
						}
						else
						{
							circleId = fileUploadDao.getCircleIdDtls(circleBean);
							logger.info("ADMIN_CSV_CIRCLE_DTLS circleId: {} for retailerNo: {} & promoterNo: {}:" , circleId, retailerBean.getRetailerNo(),othersBean.getPromoterLapuNo());
							circleMap.put(circleBean.getCircleName(), circleId);
						}

						if (zoneMap.containsKey(othersBean.getZoneName()))
						{
							zoneId = zoneMap.get(othersBean.getZoneName());
						}
						else
						{
							zoneId = fileUploadDao.getZoneIdDtls(othersBean);
							logger.info("UPLOAD_RET_CSV_SAVE_ZONE_MST_DETAILS zoneId:{} for retailer: {} & promoter:{} :" , retailerBean.getRetailerNo(),othersBean.getPromoterLapuNo() , zoneId);
							zoneMap.put(othersBean.getZoneName(), zoneId);
						}

						try
						{
							if (StringUtils.isNotBlank(catId) && StringUtils.isNotBlank(circleId)
									&& StringUtils.isNotBlank(zoneId))
							{
								logger.info("retailerUploadDetails() method Action A {}:" , "CatID/circleId/zoneId Details not blank");

								row = fileUploadDao.storeDtlsInAppUserForBatch(retailerBean, circleBean, othersBean,
										circleId, zoneId, catId, mobileNolist, i);

								logger.info("ADMIN_CSV_APP_USER row {}:" , row);

								if (row > 0)
								{
									try
									{
										rows = fileUploadDao.storeUserDtls(row, retailerBean, circleBean, othersBean, otherMobilelist);
										logger.info("ADMIN_CSV_RETAILER_DTLS rows {}:" , rows);
									}
									catch (Exception exe)
									{
										logger.error("retailerUploadDetails()  Exception in storeUserDtls method: {}, {}:", exe.getMessage(), exe.getCause());
										CommonException.getPrintStackTrace(exe);
										fileUploadDao.saveErrorReocrdDtls(
												"AppUsers insert Failed,For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>",
												retailerBean.getRetailerNo());
										logger.info("ADMIN_RETAILER_CSV_ERROR_DTLS: {}:" , "");
									}
								}
							}
							else
							{
								logger.error("retailerUploadDetails() method {}:" , "CatID/circleId/zoneId Details not found");
								fileUploadDao.saveErrorReocrdDtls(
										"CatID/circleId/zoneId Details not found, For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>",
										retailerBean.getRetailerNo());
							}

						}
						catch (Exception exe)
						{
							logger.error("retailerUploadDetails()  Exception as CatID/circleId/zoneId Details are blank {}, {}:", exe.getMessage(), exe.getCause());
							fileUploadDao.saveErrorReocrdDtls(
									"Action-A,For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>",
									retailerBean.getRetailerNo());
							CommonException.getPrintStackTrace(exe);
						}
					}
					// Deactivate the promoter
					else if (othersBean.getAction().equals("D"))
					{
						logger.info("retailerUploadDetails() Action equals Dfor retailer: {} & promoter:{} :" , retailerBean.getRetailerNo(),othersBean.getPromoterLapuNo());
						ArrayList<String> delList = new ArrayList<>();

						if (StringUtils.isNotBlank(retailerBean.getRetailerNo())
								&& !delList.contains(retailerBean.getRetailerNo())) {
							delList.add(retailerBean.getRetailerNo());
						}
						if (StringUtils.isNotBlank(othersBean.getPromoterLapuNo())
								&& !delList.contains(othersBean.getPromoterLapuNo())) {
							delList.add(othersBean.getPromoterLapuNo());
						}
						if (StringUtils.isNotBlank(othersBean.getTlNo()) && !delList.contains(othersBean.getTlNo())) {
							delList.add(othersBean.getTlNo());
						}
						if (StringUtils.isNotBlank(othersBean.getZmNo()) && !delList.contains(othersBean.getZmNo())) {
							delList.add(othersBean.getZmNo());
						}
						if (StringUtils.isNotBlank(othersBean.getRmMsisdn())
								&& !delList.contains(othersBean.getRmMsisdn())) {
							delList.add(othersBean.getRmMsisdn());
						}
						if (StringUtils.isNotBlank(othersBean.getCphNo()) && !delList.contains(othersBean.getCphNo())) {
							delList.add(othersBean.getCphNo());
						}
						if (StringUtils.isNotBlank(othersBean.getMmno()) && !delList.contains(othersBean.getMmno())) {
							delList.add(othersBean.getMmno());
						}

						if (delList.size() > 0) {
							for (int j = 0; j < delList.size(); j++) {
								String lapu = delList.get(j);
								String name = retailerBean.getRetailerName();
								try {
									if (!lapu.equals("NA") && !name.equals("NA")) {
										logger.error("retailerUploadDetails() method Action equals D{}:" , "Retailerlapu/name Details not found");

										try {

											rows = fileUploadDao.updateDelUserDtls(lapu, name, retailerBean,
													othersBean);
											logger.info("ADMIN_UPDATE_DEL_BLOCK_FLAG rows {}:" , rows);
//											 check promoterType is merchant or combined call blacklisting Api for merchant

											if (othersBean.getPromoterType().equals("Merchant")
													|| othersBean.getPromoterType().equals("Combined")) {
												logger.info("update merchant promoterprofile {}:"
														, othersBean.getPromoterLapuNo());
												// promoter-profile-table

												RestTemplate restTemplate = new RestTemplate();

												final String baseUrl = prop.getProperty("API_MERCHANT_BLACKLISTING");
												URI uri = new URI(baseUrl);

												SnapWorkRequest request = new SnapWorkRequest();
												request.setMobileNo(othersBean.getPromoterLapuNo());

												ResponseEntity<String> result = restTemplate.postForEntity(uri, request,
														String.class);

												logger.info("=======updateMerchantPromoter profile: {}" ,  result.getStatusCodeValue());

											}

										}
										catch (Exception exe)
										{
											logger.error("retailerUploadDetails()  Exception in updateDelUserDtls() method Action D{}, {}:", exe.getMessage(), exe.getCause());
											CommonException.getPrintStackTrace(exe);
											fileUploadDao.saveErrorReocrdDtls(
													"Delete failed,For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>  ",
													retailerBean.getRetailerNo());
										}
									}
									else
									{
										logger.info("retailerUploadDetails() method Action equals D  {} :", "RetailerNo/Name Details not equals NA");
										fileUploadDao.saveErrorReocrdDtls(
												"RetailerNo/Name Details Not Found,For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>  ",
												retailerBean.getRetailerNo());
									}
								}
								catch (Exception exe)
								{
									logger.error("retailerUploadDetails() Exception as lapu/name equals to NA Action D {}:", exe.getMessage(), exe.getCause());
									CommonException.getPrintStackTrace(exe);
									fileUploadDao.saveErrorReocrdDtls(
											"Action-D,For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>",
											retailerBean.getRetailerNo());
								}

							}
						}
					}
					// Update Record into
					if (othersBean.getAction().equals("E"))
					{
						logger.error("retailerUploadDetails() Action equals E for retailer: {} & promoter:{} :" , retailerBean.getRetailerNo(),othersBean.getPromoterLapuNo());

						if (categoryMap.containsKey(retailerBean.getCategory()))
						{
							catId = categoryMap.get(retailerBean.getCategory());
						}

						if (circleMap.containsKey(circleBean.getCircleName())) {
							circleId = circleMap.get(circleBean.getCircleName());
						}
						else {
							circleId = fileUploadDao.getCircleIdDtls(circleBean);
							logger.info("ADMIN_CSV_CIRCLE_DTLS circleId: {} for retailer: {} & promoter:{} :" , retailerBean.getRetailerNo(),othersBean.getPromoterLapuNo(), circleId);
							circleMap.put(circleBean.getCircleName(), circleId);
						}

						if (zoneMap.containsKey(othersBean.getZoneName())) {
							zoneId = zoneMap.get(othersBean.getZoneName());
						} else {
							zoneId = fileUploadDao.getZoneIdDtls(othersBean);
							logger.info("UPLOAD_RET_CSV_SAVE_ZONE_MST_DETAILS zoneId:{} for retailer: {} & promoter:{} :" , retailerBean.getRetailerNo(),othersBean.getPromoterLapuNo(), zoneId);
							zoneMap.put(othersBean.getZoneName(), zoneId);
						}

						try {
							if (StringUtils.isNotBlank(catId) && StringUtils.isNotBlank(circleId)
									&& StringUtils.isNotBlank(zoneId))
							{
								logger.info("retailerUploadDetails() method Action E{}:" , "CatID/circleId/zoneId Details not blank");

								row = fileUploadDao.updateDtlsInAppUserForBatch(retailerBean, circleBean, othersBean,
										circleId, zoneId, catId, mobileNolist, i);
								logger.info("ADMIN_CSV_APP_USER_UPDATE row {}:", row);

								if (row > 0)
								{
									try
									{
										rows = fileUploadDao.updateUserDtls(row, retailerBean, circleBean, othersBean,
												otherMobilelist);
										logger.info("ADMIN_CSV_RETRAILER_DTLS_UPDATE rows {}:", rows);
									}
									catch (Exception exe)
									{
										logger.error("retailerUploadDetails() Exception in updateUserDtls() method Action E{}, {}:", exe.getMessage(), exe.getCause());

										fileUploadDao.saveErrorReocrdDtls(
												"AppUsers update Failed,For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>",
												retailerBean.getRetailerNo());
									}
								}
							}
							else
							{
								logger.info("retailerUploadDetails() method Action E: {}:" , "CatID/circleId/zoneId Details not found");
								fileUploadDao.saveErrorReocrdDtls(
										"CatID/circleId/zoneId Details not found, For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>",
										retailerBean.getRetailerNo());
							}

						} catch (Exception exe) {
							fileUploadDao.saveErrorReocrdDtls(
									"Action-A,For failed records please refer table <<PAPP_ERROR_RETAILER_RECORDS>>",
									retailerBean.getRetailerNo());
							logger.error("retailerUploadDetails()  Exception as CatID/circleId/zoneId Details blank Action E{}:", exe.getMessage(), exe.getCause());
							CommonException.getPrintStackTrace(exe);
						}
					}
					else
					{
						logger.info("retailerUploadDetails() method: {}: ", "Requested row does not have action column value");
					}
				}

				logger.info("after mobileNolist.size() {}: " , mobileNolist.size());
				logger.info("after otherhierarcyMobileno.size(){}: " , otherMobilelist.size());
				logger.info("Successfully uploaded Retailer CSV {}:" , "");
				response.setMessage(prop.getProperty(Constants.UPLOAD_RETAIL_FILE_SUCC_MSG));
				response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
				response.setResponse(json);
			}
			else
			{
				logger.error("retailerUploadDetails() method:  {}:" , "invalid file name/extn");
				response.setMessage(prop.getProperty(Constants.UPLOAD_RETAIL_INVALID_FILE_EXTN_MSG));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("retailerUploadDetails() Response generated: {}:" , "");
			return response;
		}
		catch (Exception exe)
		{
			logger.error("retailerUploadDetails() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setResponse(json);
			return response;
		}
	}

	@SuppressWarnings("rawtypes")
	public RetailerDetailsBean setValuesToRetailerBean(List retailerList, RetailerDetailsBean retailerBean)
	{
		try
		{
			logger.info("Inside setValuesToRetailerBean() method in FileUploadServiceImpl class {}:" ,"");

			String retailerNo = retailerList.get(0) == "NA" ? "0" : (String) retailerList.get(0);
			String retailerName = (String) retailerList.get(1);
			String OutletType = (String) retailerList.get(2);
			String longitude = (String) retailerList.get(3);
			String latitude = (String) retailerList.get(4);
			String villageName = (String) retailerList.get(5);
			String villagesType = (String) retailerList.get(6);
			String villagePop = (String) retailerList.get(7);
			String city = (String) retailerList.get(8);


			if (!StringUtils.isAlphaSpace(city))
			{
				city = "NA";
			}
			String blockTehsil = (String) retailerList.get(9);
			String district = (String) retailerList.get(10);
			String siteId = (String) retailerList.get(11);
			String category = (String) retailerList.get(14);

			retailerBean.setRetailerNo(retailerNo);
			retailerBean.setRetailerName(retailerName);
			retailerBean.setOutletType(OutletType);
			retailerBean.setLongitude(longitude);
			retailerBean.setLatitude(latitude);
			retailerBean.setVillageName(villageName);
			retailerBean.setVillagesType(villagesType);
			retailerBean.setVillagePop(villagePop);
			retailerBean.setCity(city);
			retailerBean.setBlockTehsil(blockTehsil);
			retailerBean.setDistrict(district);
			retailerBean.setSiteId(siteId);
			retailerBean.setCategory(category);

		}
		catch (Exception exe)
		{
			logger.error("setValuesToRetailerBean() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
		}

		logger.info("setValuesToRetailerBean() Response generated: {} :" , "");
		return retailerBean;
	}

	@SuppressWarnings("rawtypes")
	public CircleMasterBean setValuesToCircleBean(List circleList, CircleMasterBean circleBean)
	{

		try
		{
			logger.info("Inside setValuesToCircleBean() method in FileUploadServiceImpl class {}:" ,"");
			String circleCode = (String) circleList.get(0);
			String circleName = (String) circleList.get(1);
			circleBean.setCircleCode(circleCode);
			circleBean.setCircleName(circleName);

		}
		catch (Exception e)
		{
			logger.error("setValuesToCircleBean() Internal Exception {}, {}:" , e.getMessage(), e.getCause());
			CommonException.getPrintStackTrace(e);
		}
		logger.info("setValuesToCircleBean() Response generated: {} :" , "");
		return circleBean;
	}

	@SuppressWarnings("rawtypes")
	public OthersHierarchyBean setValuesToOthersBean(List othersList, OthersHierarchyBean othersBean)
	{

		try
		{
//		    0			1			2					3			4		 5		6			7			8						9            10         11    12       13      14			15		   16			17				18			19       20
//		[9557521111, Promoter, Anamika Deeksha, Kutumbh HR Care, KHAP192184, NA, 3-Sep-19, 9084215325, Satendra Kumar Tiwari, Kutumbh HR Care, KHAP192184, NA, 3-Sep-19, Agra, 9631949433, Tapan Kumar, 9934049049, Virender Kumar, 9889009984, Pawan Kumar, A]
			logger.info("Inside setValuesToOthersBean() method in FileUploadServiceImpl class {}:" ,"");

			String promoterLapuNo = othersList.get(0) == "NA" ? "0" : (String) othersList.get(0);
			String promoterType = (String) othersList.get(1);
			String promoterName = (String) othersList.get(2);
			String promoterAgency = (String) othersList.get(3);
			String promoterEmployeeID = (String) othersList.get(4);
			String promoterDob = othersList.get(5) == null ? "" : (String) othersList.get(5);
			String promoterDoj = othersList.get(6) == null ? "" : (String) othersList.get(6);
			String tlNo = othersList.get(7) == "NA" ? "0" : (String) othersList.get(7);
			String tlName = (String) othersList.get(8);
			String tlAgency = (String) othersList.get(9);
			String tlEmployeeID = (String) othersList.get(10);
			String tlDob = othersList.get(11) == null ? "" : (String) othersList.get(11);
			String tlDoj = othersList.get(12) == null ? "" : (String) othersList.get(12);

			String zoneName = (String) othersList.get(13);
			String zmNo = othersList.get(14) == "NA" ? "0" : (String) othersList.get(14);
			String zmName = (String) othersList.get(15);
			String rmMsisdn = othersList.get(16) == "NA" ? "0" : (String) othersList.get(16);
			String rmName = (String) othersList.get(17);
			String cphNo = othersList.get(18) == "NA" ? "0" : (String) othersList.get(18);
			String cphName = (String) othersList.get(19);
			// insert data for MMno and MMName in otherhierarchy table
			String MMNo = othersList.get(20) == "NA" ? "0" : (String) othersList.get(20);

			String MMName = (String) othersList.get(21);

			String action = (String) othersList.get(22);


			if (promoterDob.equals("NA"))
			{
				promoterDob = "";
			}
			else if (promoterDoj.equals("NA"))
			{
				promoterDoj = "";
			}

			if (tlDob.equals("NA"))
			{
				tlDob = "";
			}
			else if (tlDoj.equals("NA"))
			{
				tlDoj = "";
			}

			othersBean.setPromoterLapuNo(promoterLapuNo);
			othersBean.setPromoterType(promoterType);
			othersBean.setPromoterName(promoterName);
			othersBean.setPromoterAgency(promoterAgency);
			othersBean.setPromoterEmployeeID(promoterEmployeeID);

			if (StringUtils.isNotBlank(promoterDob) && StringUtils.isNotBlank(promoterDoj))
			{
				othersBean.setPromoterDob(convertDate(promoterDob));
				othersBean.setPromoterDoj(convertDate(promoterDoj));
			}
			else
			{
				othersBean.setPromoterDob("");
				othersBean.setPromoterDoj("");
			}

			othersBean.setTlNo(tlNo);
			othersBean.setTlName(tlName);
			othersBean.setTlAgency(tlAgency);
			othersBean.setTlEmployeeID(tlEmployeeID);

			if (StringUtils.isNotBlank(tlDob) && StringUtils.isNotBlank(tlDoj))
			{
				othersBean.setTlDob(convertDate(tlDob));
				othersBean.setTlDoj(convertDate(tlDoj));
			}
			else
			{
				othersBean.setTlDob("");
				othersBean.setTlDoj("");
			}

			othersBean.setZoneName(zoneName);
			othersBean.setZmNo(zmNo);
			othersBean.setZmName(zmName);
			othersBean.setRmMsisdn(rmMsisdn);
			othersBean.setRmName(rmName);
			othersBean.setCphNo(cphNo);
			othersBean.setCphName(cphName);
			othersBean.setMmno(MMNo);
			othersBean.setMmname(MMName);
			othersBean.setAction(action);

		}
		catch (Exception exe)
		{
			logger.error("setValuesToOthersBean() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
		}
		logger.info("setValuesToOthersBean() Response generated: {} :" , "");
		return othersBean;
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	@Override
	public SnapWorkResponse kpiUploadDetailsv2(MultipartFile file) throws CustomException
	{
		JSONObject json = new JSONObject();
		List kpiCSVRecordsList = new ArrayList<>();
		List subKpiCSVRecordList = null;
		int rows = 0;
		long startTime = System.currentTimeMillis();

		try
		{
			logger.info("Inside kpiUploadDetailsv2() method in FileUploadServiceImpl class {}:" ,"");

			String uploadFilePath = prop.getProperty("FILE_UPLOAD_KPI_PATH");
			String fileName = file.getOriginalFilename();

			int idx = fileName.replaceAll("\\\\", "/").lastIndexOf("/");
			fileName = idx >= 0 ? fileName.substring(idx + 1) : fileName;

			boolean isValidFileExtnFlag = FileExtenValidation.validateFileExtn(fileName);

			boolean isValidFileName = FileExtenValidation.validateFileName(fileName);

			if (isValidFileExtnFlag && isValidFileName)
			{
				byte[] bytes = file.getBytes();
				Path path = Paths.get(uploadFilePath + file.getOriginalFilename());
				Files.write(path, bytes);

				try (CSVReader csvReader = new CSVReader(new FileReader(uploadFilePath + file.getOriginalFilename()))) {
					String[] values = null;
					while ((values = csvReader.readNext()) != null) {
						kpiCSVRecordsList.add(Arrays.asList(values));
					}
				}

				logger.info("KPI CSV RecordsList {}:" , kpiCSVRecordsList.size());

				String csvHeader = kpiCSVRecordsList.get(0).toString();
				String snapworkHeader = "[Promoter No, Promoter Name, Category, KPI Name, LMTD, MTD, Achieved Percent]";

				if (csvHeader.equals(snapworkHeader))
				{
					// Getting Lapu Number List from DB
					ArrayList<String> mobileNolist = fileUploadDao.get_pramoter_kpi_mst_mobile_number();
					logger.info("PROMOTER_KPI_MST_USER_LAPU_NO_DTLS mobileNolist: {} :"  ,mobileNolist.size());

					for (int i = 1; i < kpiCSVRecordsList.size(); i++) {
						subKpiCSVRecordList = (List) kpiCSVRecordsList.get(i);
						KpiMasterBean kpiDetailsBean = valuesSetToPromoter_KPI_MST(subKpiCSVRecordList);
						rows = fileUploadDao.saveKpiDetails_V2(kpiDetailsBean, mobileNolist);
						logger.info("PROMOTER_KPI_MST_V2_FIND_LAPU_&&_CAT_NAME_&&_KPI_NAME rows: {} :"  ,rows);
					}


					response.setMessage(prop.getProperty(Constants.UPLOAD_KPI_FILE_SUCC_MSG));
					response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
					response.setResponse(json);
					logger.info("Success Response generated:{} :", "");
				}
				else
				{
					logger.error("kpiUploadDetailsv2() method : {}", "csvHeader not equal to snapworkHeader");
					response.setMessage(prop.getProperty(Constants.UPLOAD_HEADER_FILE_SUCC_MSG));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
				}
			}
			else
			{
				logger.error("kpiUploadDetailsv2() method:  {}:" , "invalid filename/extn");
				response.setMessage(prop.getProperty(Constants.UPLOAD_RETAIL_INVALID_FILE_EXTN_MSG));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}
			logger.info("kpiUploadDetailsv2() Response generated: {} :" , "");
			return response;
		}
		catch (Exception exe)
		{
			logger.error("kpiUploadDetailsv2() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setResponse(json);
			return response;
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public KpiMeasuresMasterBean valuesSetToMeasures(List subKpiRecordList)
	{

		KpiMeasuresMasterBean kpiMeasures = new KpiMeasuresMasterBean();

		try
		{
			logger.info("Inside valuesSetToMeasures() method in FileUploadServiceImpl class {}:" ,"");
			List othersList = subKpiRecordList.subList(2, 3);
			Collections.replaceAll(othersList, "", "NA");
			String target = (String) subKpiRecordList.get(2);
			String weightAge = (String) subKpiRecordList.get(3);
			kpiMeasures.setTarget(target);
			kpiMeasures.setWeightAge(weightAge);
			kpiMeasures.setUpdatedBy("Admin");

		}
		catch (Exception e)
		{
			logger.error("valuesSetToMeasures() Internal Exception {}, {}:" , e.getMessage(), e.getCause());
			CommonException.getPrintStackTrace(e);
		}
		logger.info("valuesSetToMeasures() Response generated: {}:" , "");
		return kpiMeasures;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public KpiCaterogyMasterBean valuesSetToCategoryBean(List subKpiRecordList)
	{

		KpiCaterogyMasterBean categoryBean = new KpiCaterogyMasterBean();
		String categoryName = "";

		try
		{
			logger.info("Inside valuesSetToCategoryBean() method in FileUploadServiceImpl class {}:" ,"");
			List othersList = subKpiRecordList.subList(0, 1);
			Collections.replaceAll(othersList, "", "NA");
			String categoryDesc = (String) subKpiRecordList.get(0);
			categoryDesc = categoryDesc.replaceAll(" ", "_");
			try {
				categoryName = prop.getProperty("KPI_" + categoryDesc);
				if (StringUtils.isNotBlank(categoryName)) {
					categoryDesc = categoryDesc.replaceAll("_", " ");
				}
			} catch (Exception e) {
				logger.error("valuesSetToCategoryBean() Internal Exception {}, {}:" , e.getMessage(), e.getCause());
				CommonException.getPrintStackTrace(e);
			}

			logger.info("categoryName with underscore {}:" , categoryName);
			categoryDesc = categoryDesc.replaceAll("_", " ");
			logger.info("categoryDesc without underscore {}:" , categoryDesc);
			categoryBean.setCategoryNameDesc(categoryDesc);
			categoryBean.setCategoryName(categoryName);
			categoryBean.setCategoryUpdatedBy("Admin");
		}
		catch (Exception exe)
		{
			logger.error("valuesSetToCategoryBean() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
		}
		logger.info("valuesSetToCategoryBean() Response generated:  {}:" , "");
		return categoryBean;
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	public KpiDetailsMaterBean valuesSetToDetailsBean(List subKpiRecordList)
	{

		KpiDetailsMaterBean kpiDetailsBean = new KpiDetailsMaterBean();

		try
		{
			logger.info("Inside valuesSetToDetailsBean() method in FileUploadServiceImpl class {}:" ,"");

			List othersList = subKpiRecordList.subList(1, 2);
			Collections.replaceAll(othersList, "", "NA");
			String categoryDesc = (String) subKpiRecordList.get(1);
			kpiDetailsBean.setKpiType(categoryDesc);
			kpiDetailsBean.setKpiDesc(categoryDesc);
			kpiDetailsBean.setSqlQuery("NA");
			kpiDetailsBean.setKpiUpdatedBy("Admin");
		}
		catch (Exception exe)
		{
			logger.error("valuesSetToDetailsBean() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
		}
		logger.info("valuesSetToDetailsBean() Response generated: {} :" , "");
		return kpiDetailsBean;
	}

	int i = 0;

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	public KpiMasterBean valuesSetToPromoter_KPI_MST(List promoter_kpi_mst_list)
	{

		KpiMasterBean kpiDetailsBean = new KpiMasterBean();

		try
		{
			logger.info("Inside valuesSetToPromoter_KPI_MST() method in FileUploadServiceImpl class {}:" ,"");

			List othersList = promoter_kpi_mst_list.subList(0, 1);

			Collections.replaceAll(othersList, "", "NA");

			String lapuNo = (String) promoter_kpi_mst_list.get(0);
			String promoterName = (String) promoter_kpi_mst_list.get(1);
			String CAT_Name = (String) promoter_kpi_mst_list.get(2);
			String KPI_Name = (String) promoter_kpi_mst_list.get(3);
			String LMTD = (String) promoter_kpi_mst_list.get(4);
			String MTD = (String) promoter_kpi_mst_list.get(5);
			String AchievedPercent = (String) promoter_kpi_mst_list.get(6);

			kpiDetailsBean.setLapuNo(lapuNo);
			kpiDetailsBean.setPromoterName(promoterName);
			kpiDetailsBean.setCatName(CAT_Name);
			kpiDetailsBean.setKpiName(KPI_Name);
			kpiDetailsBean.setLmtd(LMTD);
			kpiDetailsBean.setMtd(MTD);
			kpiDetailsBean.setAchievedPercent(AchievedPercent);

			i++;
		}
		catch (Exception exe)
		{
			logger.error("valuesSetToPromoter_KPI_MST() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
		}
		logger.info("valuesSetToPromoter_KPI_MST() Response generated: {} :" , "");
		return kpiDetailsBean;
	}

	public String convertDate(String dateInput)
	{
		String resultDate = "";
		try
		{
			logger.info("Inside convertDate() method in FileUploadServiceImpl class {}:" ,"");
			logger.info("dateInput {}:" , dateInput);
			DateFormat df = new SimpleDateFormat("dd-MMM-yy");
			DateFormat outputformat = new SimpleDateFormat("dd-MMM-yyyy");
			Date date = df.parse(dateInput);
			resultDate = outputformat.format(date);
			logger.info("resultDate {}:" , resultDate);
		}
		catch (Exception exe)
		{
			logger.error("convertDate() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			return resultDate;
		}
		logger.info("convertDate() Response generated:  {}:" , "");
		return resultDate;
	}

	@Override
	public SnapWorkResponse uploadPromoterCSVDetails(MultipartFile file, String type, String mobileNo) throws CustomException, IOException {
		logger.info("Inside uploadPromoterCSVDetails() method in FileUploadServiceImpl class for filetype {}:" ,type);

		Pattern p = Pattern.compile("[^A-Za-z0-9.]", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(file.getOriginalFilename());
		boolean b = m.find();
		int numOfDots = file.getOriginalFilename().length() - file.getOriginalFilename().replaceAll("\\.", "").length();
		if (numOfDots!=1 || b)
			return buildResponse(Constants.FIVE_HUNDRED, Constants.InvalidFileName, false, Constants.ValidFileNameConstitutesOf, Constants.FAILED);

		if (file.getOriginalFilename().lastIndexOf('.') < 0 || !file.getOriginalFilename().substring(file.getOriginalFilename()
				.lastIndexOf('.')).equalsIgnoreCase(Constants.CSV))
			return buildResponse(Constants.FIVE_HUNDRED, Constants.INCORRECT_FILE_EXTENSION, false, file.getOriginalFilename(), Constants.FAILED);
		if (promoterUploadFileAuditRepository.findByFileName(file.getOriginalFilename()).isPresent())
			return buildResponse(Constants.FIVE_HUNDRED, Constants.FILE_ALREADY_EXISTS, false, file.getOriginalFilename(), Constants.FAILED);
		
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(file.getInputStream()));
		String headers;
		try {
			headers = bufferedReader.readLine().trim();
		}
		catch (Exception exception){
			logger.info("Invalid or empty file {} {}:" ,file.getName() ,"");
			return buildResponse(Constants.FIVE_HUNDRED, Constants.InvalidFile, false, file.getOriginalFilename(), Constants.FAILED);
		}
		
		if (!(headers.charAt(0) >= 65 && headers.charAt(0) <= 90))
			headers = headers.substring(1);			
		
		List<String> headerList = Arrays.asList(headers.split(","));
		List<String> comparisonHeaderList = null;
		String fileDirectoryPath = null;

		if(type.trim().equals(promoterWhitelistFileType.trim())) {
			logger.info("Inside uploadPromoterCSVDetails() method in FileUploadServiceImpl class for promoterWhitelistFileType detected {}:" , "");
			if (headerList.size() == promoterWhitelistFileHeadersCount) {
				comparisonHeaderList = Arrays.asList(promoterWhitelistFileHeaders.split(","));
				fileDirectoryPath = promoterWhitelistFileDirectoryPath;
			}
			else
				return buildResponse(Constants.FIVE_HUNDRED, (promoterWhitelistFileHeadersCount-headerList
						.size())+Constants.COLUMNS_MISSING, false, file.getOriginalFilename(), Constants.FAILED);
		}
		else if(type.trim().equals(promoterOutletMappingFileType.trim())) {
			logger.info("Inside uploadPromoterCSVDetails() method in FileUploadServiceImpl class for promoterOutletMappingFileType detected {}:" , "");
			if (headerList.size() == promoterOutletMappingFileHeadersCount) {
					comparisonHeaderList = Arrays.asList(promoterOutletMappingFileHeaders.split(","));
					fileDirectoryPath = promoterOutletFileDirectoryPath;
				}
				else
					return buildResponse(Constants.FIVE_HUNDRED, (promoterOutletMappingFileHeadersCount-headerList
							.size())+Constants.COLUMNS_MISSING, false, file.getOriginalFilename(), Constants.FAILED);
			}
		else
			return buildResponse(Constants.FIVE_HUNDRED, Constants.INVALID_TYPE, false, file.getOriginalFilename(), Constants.FAILED);

		boolean areTheyEqual = compareHeaders(headerList, comparisonHeaderList);
		if (!areTheyEqual)
			return buildResponse(Constants.FIVE_HUNDRED, Constants.INCORRECT_HEADERS, false, file.getOriginalFilename(), Constants.FAILED);
		int numberOfRows = countRows(file);
		
		if (numberOfRows > promoterfileMaxRowCount){
			Long extraRows = numberOfRows - promoterfileMaxRowCount;
			return buildResponse(Constants.FIVE_HUNDRED, extraRows+Constants.EXTRA_ROWS, false, file.getOriginalFilename(), Constants.FAILED);
		}
		PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = new PromoterUploadFileAuditEntity();
		promoterUploadFileAuditEntity.setFileName(file.getOriginalFilename());
		promoterUploadFileAuditEntity.setStatus(FileStatus.PENDING.name());
		promoterUploadFileAuditEntity.setType(FileType.get(Integer.parseInt(type)).name());
		promoterUploadFileAuditEntity.setLocation(fileDirectoryPath);
		promoterUploadFileAuditEntity.setTotalRecords(numberOfRows-1);//-1 for header row
		promoterUploadFileAuditEntity.setAuthor(mobileNo);
		
		try {
			promoterUploadFileAuditRepository.save(promoterUploadFileAuditEntity);
		}
		catch (DataIntegrityViolationException exception){
			logger.info("DataIntegrityViolationException in file upload due to {} with stack {}:" , exception.getCause(), exception.getStackTrace());
			return buildResponse(Constants.FIVE_HUNDRED, Constants.FILE_ALREADY_EXISTS, false, file.getOriginalFilename(), Constants.FAILED);
		}
		catch (Exception exception){
			logger.info("Exception when saving file details in dB while in file upload due to {} with stack {}:" , exception.getCause(), exception.getStackTrace());
			return buildResponse(Constants.FIVE_HUNDRED, Constants.INTERNAL_ERROR, false, file.getOriginalFilename(), Constants.FAILED);
		}
		logger.info("Saved file details to dB {}:" ,"");
		Files.write(Paths.get(fileDirectoryPath + file.getOriginalFilename()), file.getBytes());
		logger.info("Uploaded file {} to input directory {}:" , file.getOriginalFilename() ,"");
		return buildResponse(Constants.TWO_HUNDRED, Constants.PROCESSING, true, file.getOriginalFilename(), Constants.SUCCESS);
	}

	private boolean compareHeaders(List<String> headerList, List<String> comparisonHeaderList) {
		for (int i = 0; i < headerList.size(); i++)
			if (!headerList.get(i).toString().trim().equalsIgnoreCase(comparisonHeaderList.get(i).toString().trim()))
				return false;
		return true;
	}

	private Integer countRows(MultipartFile file) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(file.getInputStream()));
		int numberOfLines = 0;
		while(bufferedReader.readLine() != null)
			numberOfLines++;
		return numberOfLines;
	}

	private SnapWorkResponse buildResponse(String statusCode, String message, Boolean response, String fileName, String status) {
		SnapWorkResponse snapWorkResponse = new SnapWorkResponse();
		JSONObject json = new JSONObject();
		json.put(Constants.FILEUPLOAD, response.toString());
		json.put(Constants.FILENAME, fileName);
		snapWorkResponse.setResponse(json);
		snapWorkResponse.setMessage(message);
		snapWorkResponse.setStatusCode(statusCode);
		snapWorkResponse.setStatus(status);
		return snapWorkResponse;
	}

	private SnapWorkResponse buildResponse(String statusCode, String message, String description, Boolean response, String fileName, String status) {
		SnapWorkResponse snapWorkResponse = buildResponse(statusCode, message, response, fileName, status);
		snapWorkResponse.setDescription(description);
		return snapWorkResponse;
	}

	private SnapWorkResponse buildResponse(String statusCode, String message, String description, String fileName, Boolean response, boolean download, String fileType, String status) throws IOException {
		SnapWorkResponse snapWorkResponse = buildResponse(statusCode, message, description, response, fileName, status);
		JSONObject json = snapWorkResponse.getResponse();
		json.put(Constants.DATA, "");
		snapWorkResponse.setResponse(json);
		return snapWorkResponse;
	}

	private String getFileData(String fileName, String fileType) throws IOException {
		BufferedReader bufferedReader;
		if (String.valueOf(FileType.valueOf(fileType).getCode()).equalsIgnoreCase(promoterWhitelistFileType))
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(promoterWhitelistFileOutputDirectoryPath + fileName)));
		else
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(promoterOutletFileOutputDirectoryPath + fileName)));
		StringBuilder data = new StringBuilder();
		String line;
		while((line = bufferedReader.readLine()) != null)
			data.append(line).append("\n");
		return data.toString().replaceAll("\"", "");
	}

	@Override
	public SnapWorkResponse enquirePromoterCSVDetails(String fileName) throws IOException {
		logger.info("Inside enquirePromoterCSVDetails() method in FileUploadServiceImpl class {}:" ,"");

		Pattern p = Pattern.compile("[^A-Za-z0-9.]", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(fileName);
		boolean b = m.find();
		int numOfDots = fileName.length() - fileName.replaceAll("\\.", "").length();
		if (numOfDots!=1 || b)
			return buildResponse(Constants.FIVE_HUNDRED, Constants.InvalidFileName, false, Constants.ValidFileNameConstitutesOf, Constants.FAILED);

		Optional<PromoterUploadFileAuditEntity> promoterUploadFileAuditEntityOptional = promoterUploadFileAuditRepository.findByFileName(fileName);
		if (!promoterUploadFileAuditEntityOptional.isPresent())
			return buildResponse(Constants.FOUR_HUNDRED_FOUR, Constants.FILE_NOT_FOUND, false, fileName, Constants.FAILED);

		else if (promoterUploadFileAuditEntityOptional.get().getStatus().trim().equalsIgnoreCase(FileStatus.PENDING.name()))
			return buildResponse(Constants.TWO_HUNDRED, Constants.PENDING, true, fileName, Constants.PENDING);

		else if (promoterUploadFileAuditEntityOptional.get().getStatus().trim().equalsIgnoreCase(FileStatus.PROCESSED.name()))
			return buildResponse(Constants.TWO_HUNDRED, Constants.DATA_WAS_UPLOADED_SUCCESSFULLY, "", fileName, true, true,
					promoterUploadFileAuditEntityOptional.get().getType(), Constants.PROCESSED);

		else if (promoterUploadFileAuditEntityOptional.get().getStatus().trim().equalsIgnoreCase(FileStatus.FAILED.name()))
			return buildResponse(Constants.TWO_HUNDRED, Constants.PLEASE_TRY_AGAIN_WITH_A_DIFFERENT_FILE_NAME, true, fileName, Constants.FAILED);

		else if (promoterUploadFileAuditEntityOptional.get().getStatus().trim().equalsIgnoreCase(FileStatus.IN_PROGRESS.name()))
			return buildResponse(Constants.TWO_HUNDRED, Constants.THE_FILE_IS_UNDER_PROCESSING, true, fileName, FileStatus.IN_PROGRESS.name());

		else
			return buildResponse(Constants.TWO_HUNDRED, promoterUploadFileAuditEntityOptional.get().getStatus(), "", true, fileName
					, promoterUploadFileAuditEntityOptional.get().getStatus());
	}

	@Override
	public Resource downloadPromoterCSVDetails(String fileName) throws Exception {
		logger.info("Inside downloadPromoterCSVDetails() method in FileUploadServiceImpl class {}:" ,"");
		Pattern p = Pattern.compile("[^A-Za-z0-9.]", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(fileName);
		boolean b = m.find();
		int numOfDots = fileName.length() - fileName.replaceAll("\\.", "").length();
		if (numOfDots!=1 || b)
			throw new Exception("Invalid file name.");
		Optional<PromoterUploadFileAuditEntity> promoterUploadFileAuditEntityOptional = promoterUploadFileAuditRepository.findByFileName(fileName);
		if (promoterUploadFileAuditEntityOptional.get().getStatus().trim().equalsIgnoreCase(FileStatus.PROCESSED.name()))
			return downloadCSVDetails(fileName, promoterUploadFileAuditEntityOptional.get().getType());
		else
			throw new Exception("File not processed yet.");
	}

	private Resource downloadCSVDetails(String fileName, String fileType) throws IOException {
		logger.info("Inside downloadCSVDetails() method in FileUploadServiceImpl class {}:" ,"");
		File file;
		if (String.valueOf(FileType.valueOf(fileType).getCode()).equalsIgnoreCase(promoterWhitelistFileType))
			file = new File(promoterWhitelistFileOutputDirectoryPath + fileName);
		else
			file = new File(promoterOutletFileOutputDirectoryPath + fileName);

		ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(Paths.get(file.getAbsolutePath())));

		return resource;
	}
}