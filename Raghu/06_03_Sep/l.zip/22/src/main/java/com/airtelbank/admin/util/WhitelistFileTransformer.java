package com.airtelbank.admin.util;

import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.enums.FileStatus;
import com.airtelbank.admin.factory.ProcessFile;
import com.airtelbank.admin.repository.PromoterUploadFileAuditRepository;
import com.airtelbank.admin.service.FileUploadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@Component
public class WhitelistFileTransformer {

    private static Logger logger = LoggerFactory.getLogger(WhitelistFileListener.class);

    @Autowired
	private ProcessFile processFile;

    @Autowired
    private PromoterUploadFileAuditRepository promoterUploadFileAuditRepository;

	@Value("${promoter.whitelist.file.type}")
	private String promoterWhitelistFileType;

    @Value("${promoter.whitelist.file.processing.directory.path}")
    private String promoterWhitelistFileProcessingDirectoryPath;

    @Value("${promoter.file.listener.waiting.time}")
    private Long waitingTime;

    public void transform(String filePath) throws IOException, InterruptedException {
        logger.info("Inside transform() method in WhitelistFileTransformer class for filepath:{}, {}:" ,filePath,"");
        File file = new File(filePath);
        logger.info("Inside transform() method in WhitelistFileTransformer class with loaded file :{}, {}:" ,file.getName(),"");
        Path temp = Files.move
                (Paths.get(filePath),
                        Paths.get(promoterWhitelistFileProcessingDirectoryPath+file.getName()));
        logger.info("Transferred file {} from input directory to process directory {},:" , file.getName(),"");
        Optional<PromoterUploadFileAuditEntity> optionalPromoterUploadFileAuditEntity = promoterUploadFileAuditRepository.findByFileName(file.getName());
        for (int i=0; i<3; i++)
            if (!optionalPromoterUploadFileAuditEntity.isPresent()){
                Thread.sleep(waitingTime);
                optionalPromoterUploadFileAuditEntity = promoterUploadFileAuditRepository.findByFileName(file.getName());
            }
            else
                break;

        PromoterUploadFileAuditEntity promoterUploadFileAuditEntity = optionalPromoterUploadFileAuditEntity.get();
        promoterUploadFileAuditEntity.setLocation(promoterWhitelistFileProcessingDirectoryPath);
        promoterUploadFileAuditRepository.save(promoterUploadFileAuditEntity);

        try {
            logger.info("file {} heading for processing {}:" ,file.getName() ,"");
            processFile.processFile(file.getName(), Integer.valueOf(promoterWhitelistFileType));
		} catch (Exception e) {
            promoterUploadFileAuditEntity.setStatus(FileStatus.FAILED.name());
			promoterUploadFileAuditRepository.save(promoterUploadFileAuditEntity);
            logger.info("file {} status is failed {}:" ,file.getName() ,"");
		}
    }
}
