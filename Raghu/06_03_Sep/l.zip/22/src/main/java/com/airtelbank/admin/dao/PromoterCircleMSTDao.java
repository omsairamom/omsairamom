package com.airtelbank.admin.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.entity.PromoterCircleMSTEntity;
import com.airtelbank.admin.repository.PromoterCircleMSTRepository;

@Service
public class PromoterCircleMSTDao {
	
	@Autowired
	PromoterCircleMSTRepository promoterCircleMSTRepository;
	 
	 
	public PromoterCircleMSTEntity fetchCirclebyCircleId(String circleid)
	 {
		 return promoterCircleMSTRepository.findOneByCircleId(circleid);
	 }

}
