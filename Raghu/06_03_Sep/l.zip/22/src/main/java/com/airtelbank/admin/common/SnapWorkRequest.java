package com.airtelbank.admin.common;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.lang.NonNull;
import javax.validation.constraints.Pattern;

@Configuration
public class SnapWorkRequest
{
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid userName.")
    private String userName;

    @Pattern(regexp = "^((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20})$", message = "Please enter valid password with atleast 8 charcters with uppercase, lowercase, numeric and special symbal.")
    private String password;

    @Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid mobileNo.")
    private String mobileNo;

    @Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid deviceId.")
    private String deviceId;

    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private String startDate;

    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private String endDate;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid circleId.")
    private String circleId;

    @NumberFormat
    private String otp;

    String encString;

    @Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid otpVerficatonCode.")
    private String otpVerificationCode;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid catId.")
    private String categoryId;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid action.")
    private String action;

    public String getEncString() {
        return encString;
    }

    public void setEncString(String encString) {
        this.encString = encString;
    }

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid statusEnable.")
    private String statusEnable;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid geoFenceArea.")
    private String geoFenceArea;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid categoryName.")
    private String categoryName;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid circleName.")
    private String circleName;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid zoneId.")
    private String zoneId;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid roleId.")
    private String roleId;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid roleName.")
    private String roleName;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid notifTitle.")
    private String notifTitle;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid notifDesc.")
    private String notifDesc;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid zoneName.")
    private String zoneName;
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid userAgent.")
    private String userAgent;

    @Pattern(regexp = "\\d+(\\.\\d{1,2})?", message = "Please enter valid appVersion.")
    private String appVersion;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid loadFlag.")
    private String loadFlag;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid mandatoryFlag.")
    private String mandatoryFlag;

    @Pattern(regexp = "^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]", message = "Please enter valid url.")
    private String url;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid message.")
    private String message;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid kpiName.")
    private String kpiName;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid kpiId.")
    private String kpiId;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid weightAge.")
    private String weightAge;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid target.")
    private String target;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid rewardTitle.")
    private String rewardTitle;

    //	@Pattern(regexp = "[a-zA-Z0-9_\s]+", message = "Please enter valid rewardDesc.")
    @NonNull
    private String rewardDesc;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid trainingTitle.")
    private String trainingTitle;

    //	@Pattern(regexp = "[a-zA-Z0-9_\s]+", message = "Please enter valid trainingDesc.")
    @NonNull
    private String trainingDesc;

    @Pattern(regexp = "^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]", message = "Please enter valid trainingUrl.")
    private String trainingUrl;

    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private String trainingDate;

    //	@Pattern(regexp = "(^$|[0-9]{2})", message = "Please enter valid ver.")
    @Pattern(regexp = "\\d+(\\.\\d{1,2})?", message = "Please enter valid ver.")
    private String ver;

    @Pattern(regexp = "^[a-zA-Z0-9!@#$&()-`.+,/\"]*$", message = "Please enter valid channel.")
    private String channel;

    @Pattern(regexp = "^([0-9a-zA-z]).{0,20}$", message = "Please enter valid feSessionId.")
    private String feSessionId;

    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Please enter valid promoterType.")
    private String promoterType;

    @Pattern(regexp = "^$|[a-zA-Z ]+$", message = "Please enter Y or N.")
    private String reference1;

    public String getReference1() {
        return reference1;
    }

    public void setReference1(String reference1) {
        this.reference1 = reference1;
    }

    public String getPromoterName() {
        return PromoterName;
    }

    public void setPromoterName(String promoterName) {
        PromoterName = promoterName;
    }

    private String PromoterName;

    public String getVer() {
        return ver;
    }

    public void setVer(String ver) {
        this.ver = ver;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getFeSessionId() {
        return feSessionId;
    }

    public void setFeSessionId(String feSessionId) {
        this.feSessionId = feSessionId;
    }

    public String getTrainingTitle() {
        return trainingTitle;
    }

    public void setTrainingTitle(String trainingTitle) {
        this.trainingTitle = trainingTitle;
    }

    public String getTrainingDesc() {
        return trainingDesc;
    }

    public void setTrainingDesc(String trainingDesc) {
        this.trainingDesc = trainingDesc;
    }

    public String getTrainingUrl() {
        return trainingUrl;
    }

    public void setTrainingUrl(String trainingUrl) {
        this.trainingUrl = trainingUrl;
    }

    public String getTrainingDate() {
        return trainingDate;
    }

    public void setTrainingDate(String trainingDate) {
        this.trainingDate = trainingDate;
    }

    public String getRewardTitle() {
        return rewardTitle;
    }

    public void setRewardTitle(String rewardTitle) {
        this.rewardTitle = rewardTitle;
    }

    public String getRewardDesc() {
        return rewardDesc;
    }

    public void setRewardDesc(String rewardDesc) {
        this.rewardDesc = rewardDesc;
    }

    public String getKpiName() {
        return kpiName;
    }

    public void setKpiName(String kpiName) {
        this.kpiName = kpiName;
    }

    public String getKpiId() {
        return kpiId;
    }

    public void setKpiId(String kpiId) {
        this.kpiId = kpiId;
    }

    public String getWeightAge() {
        return weightAge;
    }

    public void setWeightAge(String weightAge) {
        this.weightAge = weightAge;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getLoadFlag() {
        return loadFlag;
    }

    public void setLoadFlag(String loadFlag) {
        this.loadFlag = loadFlag;
    }

    public String getMandatoryFlag() {
        return mandatoryFlag;
    }

    public void setMandatoryFlag(String mandatoryFlag) {
        this.mandatoryFlag = mandatoryFlag;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getNotifTitle() {
        return notifTitle;
    }

    public void setNotifTitle(String notifTitle) {
        this.notifTitle = notifTitle;
    }

    public String getNotifDesc() {
        return notifDesc;
    }

    public void setNotifDesc(String notifDesc) {
        this.notifDesc = notifDesc;
    }

    @Bean
    public SnapWorkRequest request() {
        return new SnapWorkRequest();
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCircleName() {
        return circleName;
    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getStatusEnable() {
        return statusEnable;
    }

    public void setStatusEnable(String statusEnable) {
        this.statusEnable = statusEnable;
    }

    public String getGeoFenceArea() {
        return geoFenceArea;
    }

    public void setGeoFenceArea(String geoFenceArea) {
        this.geoFenceArea = geoFenceArea;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getOtpVerificationCode() {
        return otpVerificationCode;
    }

    public void setOtpVerificationCode(String otpVerificationCode) {
        this.otpVerificationCode = otpVerificationCode;
    }

    public String getCircleId() {
        return circleId;
    }

    public void setCircleId(String circleId) {
        this.circleId = circleId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public String getPromoterType() {
        return promoterType;
    }

    public void setPromoterType(String promoterType) {
        this.promoterType = promoterType;
    }
}
