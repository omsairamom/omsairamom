package com.airtelbank.admin.util;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 19, 2019 12:34:45 PM
 */
public class FileExtenValidation
{
	private static Logger logger = LoggerFactory.getLogger(FileExtenValidation.class);

	private static Pattern FileExtnPtrn = Pattern.compile("([^\\s]+(\\.(?i)(csv|CSV))$)");

	private static Pattern fileNamePattern = Pattern.compile("^[0-9a-zA-Z_\\-. ]+$");

	public static boolean validateFileExtn(String fileName)
	{      
      
      logger.info("Inside validateFileExtn method fileName..{}:", fileName);
		fileName = fileName.replaceAll("\\s+","");
		Matcher mtch = FileExtnPtrn.matcher(fileName);
		if(mtch.matches())
		{
			return true;
		}
		return false;
	}
	
	public static boolean validateFileName(String fileName) {
		String extension = fileName.split("\\.")[1];
		System.out.println("====extension{}:" + extension);
		fileName = fileName.replaceAll("\\s+", "");
		Matcher mtch = fileNamePattern.matcher(fileName);
		if (mtch.matches() && extension.equalsIgnoreCase("csv")) {
			return true;
		}

		return false;
	}
}
