package com.airtelbank.admin.encryption;

import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import javax.crypto.Cipher;
import java.io.IOException;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.UUID;

public class EncryptionRSA {

    private String transformation = "RSA/ECB/PKCS1Padding";
    public static final String RSA = "RSA";
    public static final String UTF8 = "UTF-8";

    @Autowired
    PropertyManager prop;

    public String encryptKey(String rawText, byte[] publicKey, String encoding) throws IOException, GeneralSecurityException {

        Cipher cipher = Cipher.getInstance(transformation);
        cipher.init(Cipher.ENCRYPT_MODE, KeyFactory.getInstance(RSA).generatePublic(new X509EncodedKeySpec(publicKey)));
        return Base64.encodeBase64String(cipher.doFinal(rawText.getBytes(encoding)));
    }

    public String simpleEncrypt(String data, byte[] publicKey) throws IOException, GeneralSecurityException {

        String secretKey = UUID.randomUUID().toString().substring(0, 24);
        SecurityApp securityApp = new SecurityApp(secretKey);
        String encryptedData = securityApp.encrypt(data).trim().replaceAll(StringUtils.SPACE, StringUtils.EMPTY).replaceAll("\r\n", StringUtils.EMPTY);

        String encryptedTime = securityApp.encrypt(String.valueOf(System.currentTimeMillis())).trim()
                .replaceAll(StringUtils.SPACE, StringUtils.EMPTY).replaceAll("\r\n", StringUtils.EMPTY);

        String encryptedKey = encryptKey(secretKey, publicKey, UTF8).trim()
                .replaceAll(StringUtils.SPACE, StringUtils.EMPTY).replaceAll("\r\n", StringUtils.EMPTY);

        return "data=" + URLEncoder.encode(encryptedData, UTF8) + "&key=" + URLEncoder.encode(encryptedKey, UTF8);

    }
}
