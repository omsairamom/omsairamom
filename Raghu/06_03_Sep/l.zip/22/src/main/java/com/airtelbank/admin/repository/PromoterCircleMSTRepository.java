package com.airtelbank.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.airtelbank.admin.entity.PromoterCircleMSTEntity;

@Repository
public interface PromoterCircleMSTRepository extends JpaRepository<PromoterCircleMSTEntity, Long> {
	
	public PromoterCircleMSTEntity findOneByCircleId (String circleId);

}
