package com.airtelbank.admin.service.impl;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.airtelbank.admin.bean.KibanaLoggerBean;
import com.airtelbank.admin.dao.PromoterOutletMSTDao;
import com.airtelbank.admin.dto.OutletRequest;
import com.airtelbank.admin.dto.OutletRequestResponse;
import com.airtelbank.admin.entity.PromoterOutletMSTEntity;
import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.service.FileProcessingService;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.CustomMappingStrategy;
import com.airtelbank.admin.util.KibanaLoggerUtils;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

@Service
public class PromoterOutletFileProcessImpl implements FileProcessingService  {

	private static Logger logger = LoggerFactory.getLogger(PromoterOutletFileProcessImpl.class);
	
	@Value("#{'${promoter.outlet.memberFieldsToBindTo.headers}'.split(',')}")
	private List<String> memberFieldsToBindToOutletList;
	
	@Value("${promoter.outlet.file.processing.directory.path}")
	private String inputFilePathDir;
	
	@Value("${promoter.outlet.file.output.directory.path}")
	private String outputFilePathDir;
	
	@Value("${outlet.max.pool.size}")
	private int maxPoolSizeOutlet;
	
	@Value("${outlet.record.validation.timeout}")
	private int outletRecordValidationTimeout;
	
	@Autowired
	private PromoterOutletMSTDao promoterOutletMSTDao;
	
	@Autowired
	private AsyncFileProcessor asyncFileProcessor;
	
	@Autowired
	private KibanaLoggerUtils kibanaUtils;

	
	@Override
	public void processFile(String filename, int type, PromoterUploadFileAuditEntity file) throws Exception{
	    
    
    logger.info("PromoterOutletFileProcessImpl : processFile() method start. Filename {} Type {}", filename, type);

   	//file path for output
    String outputFilePath = outputFilePathDir+filename;
   	
   	//Read the file from path
   	String inputFilepath = inputFilePathDir+filename;
   	
   	try (
               Reader reader = Files.newBufferedReader(Paths.get(inputFilepath));
           ) {
   		
   		     ColumnPositionMappingStrategy strategy = new ColumnPositionMappingStrategy();
             strategy.setType(OutletRequest.class);

             String[] memberFieldsToBindTo = memberFieldsToBindToOutletList.toArray(new String[0]);
             strategy.setColumnMapping(memberFieldsToBindTo);

             CsvToBean<OutletRequest> csvToBean = new CsvToBeanBuilder(reader)
                     .withMappingStrategy(strategy)
                     .withSkipLines(1)
                     .withIgnoreLeadingWhiteSpace(true)
                     .build();

             try ( 
            
            		 Writer writer = Files.newBufferedWriter(Paths.get(outputFilePath));
             ){ 
            	 CustomMappingStrategy<OutletRequestResponse> mappingStrategy = new CustomMappingStrategy<OutletRequestResponse>();
            	 
             mappingStrategy.setType(OutletRequestResponse.class);
             StatefulBeanToCsv<OutletRequestResponse> beanToCsv = new StatefulBeanToCsvBuilder(writer)
            		 		 .withMappingStrategy(mappingStrategy)
                             .build();

             CopyOnWriteArrayList<OutletRequestResponse> recordResponses = new CopyOnWriteArrayList<>();
             Collection< CompletableFuture<PromoterOutletMSTEntity>> futures = new ArrayList< CompletableFuture<PromoterOutletMSTEntity>>();
             Iterator<OutletRequest> outletRequest = csvToBean.iterator();
             

             int count=0;
             CopyOnWriteArrayList<PromoterOutletMSTEntity> promoterOutletMSTEntityList = new CopyOnWriteArrayList<>();
             CopyOnWriteArrayList<OutletRequestResponse> recordResponsesValidationSuccess = new CopyOnWriteArrayList<>();
             Map<Integer,OutletRequestResponse> mapEntityOutputOutlet = new ConcurrentHashMap<>();
             int lineNo=0; int countProcessedRecords=0;
             Map<String,Long> promoterUserMgmtCache = new HashMap<>();
             while (outletRequest.hasNext()) 
              {	
            	 	lineNo++;
            	    count++;
	               	OutletRequest user = outletRequest.next();
	               	logger.info("PromoterOutletFileProcessImpl -> processFile() method start. Input user {}", user.toString());
	               	
  	
	               	if(null != user)
	               	{
	               		futures.add( asyncFileProcessor.processOutletFileRecordsAsync(user,recordResponses,recordResponsesValidationSuccess,file,promoterOutletMSTEntityList,mapEntityOutputOutlet,lineNo,promoterUserMgmtCache  ));
	               	}

	               	if(count == maxPoolSizeOutlet || !outletRequest.hasNext())
	               	{
	               		for ( CompletableFuture<PromoterOutletMSTEntity> future : futures) 
	               		{
	               			PromoterOutletMSTEntity prOutletEntity=null;
	                        try {
	                        	prOutletEntity = future.get(outletRecordValidationTimeout, TimeUnit.MILLISECONDS);
	                   
	                        }catch (InterruptedException | ExecutionException e) 
	                        {	
	                        	logger.error("PromoterOutletFileProcessImpl | processFile() | Exception while waiting for chunk of threads to complete process. Message {} Cause {}",e.getMessage(),e.getCause());
	                        	future.cancel(true);
	                        
	                        }catch(Exception e)
	                        {
	                        	logger.error("PromoterOutletFileProcessImpl | processFile() | Exception Message {} Cause {}",e.getMessage(),e.getCause());
	                        	future.cancel(true); 
	                        }
	                    }
	               		
	               		
	               		logger.info("PromoterOutletFileProcessImpl -> processFile() | Total count of threads in this chunk {}",count);
	               		
	               		logger.info("PromoterOutletFileProcessImpl -> processFile() | Count of records which failed validation {}",recordResponses.size());
	               		
	               		logger.info("PromoterOutletFileProcessImpl -> processFile() | Count of records which passed validation {}",recordResponsesValidationSuccess.size());
	               		
	               		count=0;
	               		List<PromoterOutletMSTEntity> duplicateEntitiesList = new ArrayList<>();
	               		
	               		Set<PromoterOutletMSTEntity> set = new HashSet<PromoterOutletMSTEntity>();
	               		for(PromoterOutletMSTEntity entity: promoterOutletMSTEntityList)
	               		{
	               			if(set.contains(entity))
	               			{
	               				duplicateEntitiesList.add(entity);
	               
	               			}else {
	               				set.add(entity);
	               			}	

	               		}
	               		List<PromoterOutletMSTEntity> uniqueEntitiesList = new ArrayList<PromoterOutletMSTEntity>(set);
	               		
	               		boolean isSaveSucess = saveInDB(uniqueEntitiesList,recordResponsesValidationSuccess);
	               			               		
	               		//if save success, update the duplicate entities remark with "Already exists in system"(As it was marked success)
	               		markDuplicateRecords(mapEntityOutputOutlet, duplicateEntitiesList, isSaveSucess);
	               		
	               		
	               		//add every element from recordResponseChunk into recordResponses list
	               		for(OutletRequestResponse recordFromChunk : recordResponsesValidationSuccess)
	               		{
	               			recordResponses.add(recordFromChunk);
	               		}
	               		
	               		countProcessedRecords = countProcessedRecords+ recordResponses.size();
	               		file.setProcessedRecords(countProcessedRecords);
	               		beanToCsv.write(recordResponses);
	               		populateKibanaLoggingObject(recordResponses,file);
	               		recordResponsesValidationSuccess.clear();
	               		promoterOutletMSTEntityList.clear();
	               		mapEntityOutputOutlet.clear();
	               		recordResponses.clear();
	               	
	               	}
	                    	               
               }
            
               logger.info("PromoterOutletFileProcessImpl | processFile() | All threads have finished working");
               promoterUserMgmtCache.clear();
               writer.close();


             } catch (IOException | CsvDataTypeMismatchException | CsvRequiredFieldEmptyException e) {
            	
            	 logger.error("PromoterOutletFileProcessImpl | processFile() | Exception occured while writing into file. Message {} Cause {}",e.getMessage(),e.getCause());
             }
           } catch (IOException e1) {
        	   logger.error("PromoterOutletFileProcessImpl | processFile() | Exception occured while reading from file. Message {} Cause {}",e1.getMessage(),e1.getCause());
			}
   	
   
   	
   		logger.info("PromoterOutletFileProcessImpl : processFile() method exit");
       }
	
	private void populateKibanaLoggingObject(CopyOnWriteArrayList<OutletRequestResponse> recordResponses,PromoterUploadFileAuditEntity file) 
	{
		for(OutletRequestResponse record : recordResponses)
		{
			KibanaLoggerBean kb = new KibanaLoggerBean();
			kb.setId2(record.getOutletPhoneNumber());
			kb.setId3(record.getOutletType());
			kb.setId8(record.getAction());
			kb.setId7(file.getFileName());
			kibanaUtils.printKibanaLogs(kb);
			
		}
	}

		private void markDuplicateRecords(Map<Integer, OutletRequestResponse> mapEntityOutputOutlet,
				List<PromoterOutletMSTEntity> duplicateEntitiesList, boolean isSaveSucess) {
			if(isSaveSucess)
			{
				for(PromoterOutletMSTEntity entity: duplicateEntitiesList)
				{
					OutletRequestResponse outletResp = (mapEntityOutputOutlet != null) ? mapEntityOutputOutlet.get(entity.getLineNo()) : null;
					if(null != outletResp)
					{
						outletResp.setRemarks(Constants.Validate_Success+Constants.COMMA+ Constants.DUPLICATE_RECORD);
					}
				}
			}
		}

		@Transactional
		private boolean saveInDB(List<PromoterOutletMSTEntity> uniqueEntitiesList,CopyOnWriteArrayList<OutletRequestResponse> recordResponseChunk ) {
			
			boolean isSaveSucess=false;
			logger.info("PromoterOutletFileProcessImpl | saveInDB() | start");
			try {
				if(!uniqueEntitiesList.isEmpty()) {
				promoterOutletMSTDao.saveAllInDB(uniqueEntitiesList);
				appendOutletResponseRemarks(recordResponseChunk,Constants.SUCCESS, Constants.TWO_HUNDRED);//marking the complete chunk(which also contains duplicate entries)with success 
				isSaveSucess=true;
				}
			
			} catch(Exception e) {		
				
				logger.error("PromoterOutletFileProcessImpl | processFile() | Exception while saving in db. Message {} Cause {}",e.getMessage(),e.getCause());			
				appendOutletResponseRemarks(recordResponseChunk,Constants.INTERNAL_ERROR, Constants.THREE_HUNDRED); //marking the complete chunk(which also contains duplicate entries) with error 
				isSaveSucess=false;
			}
			
			logger.info("PromoterOutletFileProcessImpl | saveInDB() | exit");
			return isSaveSucess;
		}

		private void appendOutletResponseRemarks(CopyOnWriteArrayList<OutletRequestResponse> recordResponseChunk,String message, String messageCode) 
		{	
			for(OutletRequestResponse record: recordResponseChunk)
			{
					String remarks = record.getRemarks();
					remarks = remarks+Constants.COMMA+message+Constants.COLON+messageCode;
					record.setRemarks(remarks);
			}
		}

}

