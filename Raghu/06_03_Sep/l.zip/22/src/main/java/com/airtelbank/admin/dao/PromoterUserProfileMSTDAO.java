package com.airtelbank.admin.dao;

import com.airtelbank.admin.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.admin.repository.PromoterUserProfileMSTRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PromoterUserProfileMSTDAO
{
    @Autowired
    PromoterUserProfileMSTRepository promoterUserProfileMSTRepository;

//    public Optional<PromoterUserProfileMSTEntity> fetchUserByUserNo(String userNo)
//    {
//        return promoterUserProfileMSTRepository.findOneByUserNo(userNo);
//    }
//
//    public Optional<PromoterUserProfileMSTEntity> fetchActiveUserByUserNo(String userNo)
//    {
//        return promoterUserProfileMSTRepository.findOneByUserNoAndStatus(userNo, UserProfileStatus.A.getCode());
//    }

    public void saveUserProfile(PromoterUserProfileMSTEntity promoterUserProfileMSTEntity){
        promoterUserProfileMSTRepository.save(promoterUserProfileMSTEntity);
    }

    public int updateProfile(String password, String userNo){
        return promoterUserProfileMSTRepository.updatePassword(password, userNo);
    }
}