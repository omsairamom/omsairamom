package com.airtelbank.admin.entity;


import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@ToString
@Getter
@Setter
@Table(name = "PROMOTER_OUTLET_MST",
	uniqueConstraints={@UniqueConstraint(columnNames = {"outletNo", "outletType"})}, 
	indexes = {
			@Index( name="IndexOutletNoOutletType", columnList="outletNo, outletType", unique = true ),
			@Index(name = "IndexOutletNo", columnList = "outletNo"),
			@Index(name = "IndexPromoterNo", columnList = "promoterNo"),
			@Index(name = "IndexPromoterId", columnList = "promoter_id")
})
@EntityListeners(AuditingEntityListener.class)
public class PromoterOutletMSTEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private long id;

    @Column
    @NotNull
    private String outletNo;

    @Column
    @NotNull
    private String outletName;

    @Column
    @NotNull
    private String outletType;

    @OneToOne
    @JoinColumn(name = "promoter_id", nullable = false, referencedColumnName = "id")
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    private String promoterNo;

    @Column
    private String latitude;

    @Column
    private String longitude;

    @OneToOne
    @NotNull
    @JoinColumn(name = "file_id", nullable = false, referencedColumnName = "id")
    private PromoterUploadFileAuditEntity promoterUploadFileAuditEntity;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdDate;

   
    @LastModifiedDate
    @Column
    private LocalDateTime updatedDate;
    
    @Column
    private String custom_field1;
    
    @Column
    private String custom_field2;
    
    @Column
    private String custom_field3;
    
    @Column
    private String custom_field4;
    
    @Column
    private String custom_field5;
    
    @Transient
    private Integer lineNo;
    
    @Column
    @NotNull
    private String status;
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass()!= this.getClass()) {
            return false;
        }
        if (obj instanceof PromoterOutletMSTEntity) {
            if (((PromoterOutletMSTEntity) obj).getOutletNo().equals(this.getOutletNo())  && ((PromoterOutletMSTEntity) obj).getOutletType().equals(this.getOutletType())) {
                return true;
            }
        }

        return false;
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(this.getOutletNo(), this.getOutletType());
    }

}
