package com.airtelbank.admin.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "PAPP_KPI_MEASURES")
@EntityListeners(AuditingEntityListener.class)
public class PromoterKPIMeasuresEntity {

    @Id
    @Column
    private Long kpiMid;

    @Column
    private Long kpiId;

    @Column
    private Long target;

    @Column
    private Long weightAge;

    @Column
    private LocalDateTime startDate;

    @Column
    private LocalDateTime endDate;

    @Column
    private String uploadedBy;

    @Column
    @CreatedDate
    private LocalDateTime createdDt;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDt;

    @Column
    private String custom_field1;

    @Column
    private String custom_field2;

    @Column
    private String custom_field3;

    @Column
    private String custom_field4;

    @Column
    private String custom_field5;

}

