package com.airtelbank.admin.dto;

public class WhitelistedPromoter {
	
    private String userPhoneNumber;
    private String userName;
	private String userType;
	private String category;
	
	private String circleId;
	private String agency;
	
	private String empid;
	private String dob;
	private String doj;
	private String supervisorNumber;
	private String supervisorType;
	private String action;
	private String interviewerNo;
	private String interviewDate;
    
	public String getUserPhoneNumber() {
		return userPhoneNumber;
	}
	public void setUserPhoneNumber(String userPhoneNumber) {
		this.userPhoneNumber = userPhoneNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	
	public String getCircleId() {
		return circleId;
	}
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getInterviewDate() {
		return interviewDate;
	}
	public void setInterviewDate(String interviewDate) {
		this.interviewDate = interviewDate;
	}
	
	public String getSupervisorNumber() {
		return supervisorNumber;
	}
	public void setSupervisorNumber(String supervisorNumber) {
		this.supervisorNumber = supervisorNumber;
	}
	public String getSupervisorType() {
		return supervisorType;
	}
	public void setSupervisorType(String supervisorType) {
		this.supervisorType = supervisorType;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getInterviewerNo() {
		return interviewerNo;
	}
	public void setInterviewerNo(String interviewerNo) {
		this.interviewerNo = interviewerNo;
	}
	
    
    
   
    
    

}
