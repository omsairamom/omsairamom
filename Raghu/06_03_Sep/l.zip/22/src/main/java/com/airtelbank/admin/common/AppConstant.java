package com.airtelbank.admin.common;

public interface AppConstant
{
    String FAILURE_STATUS_CODE = "500";
    String FAILURE_ERROR_MESSAGE = "Server Error, please try after sometime";
    String FAILURE_INVALID_REQUEST = "Invalid Request Parameters";
    String EXCEPTION_EXCEPTION = "1000";
    String ROLENAME_RELATIONALMANAGER = "RM";
    String NOTIFICATION_DESC = "Notification sent successfully";
    String ERROR_EXCEPTION = "1000";
}
