package com.airtelbank.admin.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.airtelbank.admin.service.FileProcessingService;
import com.airtelbank.admin.service.impl.PromoterOutletFileProcessImpl;
import com.airtelbank.admin.service.impl.PromoterUserFileProcessImpl;

@Component
public class ProcessFileFactory {
	
	
	@Autowired
	PromoterUserFileProcessImpl promoterUserFileProcessImpl;
	
	@Autowired 
	PromoterOutletFileProcessImpl promoterOutletFileProcessImpl;
	
	   public FileProcessingService getFileProcessor(int fileType){
		   
		   switch(fileType)
		   {
			   case 0 : return promoterUserFileProcessImpl; 
			   case 1 : return promoterOutletFileProcessImpl;
			   default : return null;
		   
		   }
	     		
	  }

}
