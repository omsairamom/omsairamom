package com.airtelbank.admin.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum FileType {
	
	Pr_whitelisting(0),
	Outlet_mapping(1);
	
	
	private static final Map<Integer,FileType> lookup = new HashMap<Integer,FileType>();

	static {
	    for(FileType s : EnumSet.allOf(FileType.class))
	         lookup.put(s.getCode(), s);
	}
	
	private int code;
	
	private FileType(int code) {
	    this.code = code;
	}
	
	public int getCode() { return code; }
	
	public static FileType get(int code) { 
	    return lookup.get(code); 
	}

}
