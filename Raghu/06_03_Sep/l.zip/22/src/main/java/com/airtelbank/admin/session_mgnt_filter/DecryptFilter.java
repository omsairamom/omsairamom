package com.airtelbank.admin.session_mgnt_filter;

import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.jwt.CommonJWTUtil;
import lombok.Cleanup;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebFilter(urlPatterns = {"/v1/users/*"}, filterName = "decryptFilter")
@Slf4j
@Component
public class DecryptFilter implements Filter 
{
    private static Logger logger = LoggerFactory.getLogger(DecryptFilter.class);

    @Autowired
    CommonJWTUtil commonJWTUtil;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
    {
        /**
         * 1.Forced transfer of original request / response object
         */

        HttpServletRequest originalRequest = (HttpServletRequest) request;
        HttpServletResponse originalResponse = (HttpServletResponse) response;

        List<String> urls = new ArrayList<>();
        urls.add("/adminportal-services/v1/users/Login");
        urls.add("/adminportal-services/v1/users/verify-otp");
        urls.add("/adminportal-services/v1/users/send-otp");
        urls.add("/adminportal-services/v1/users/reset-password");

        logger.info("requestURL:{}", originalRequest.getRequestURI());

        final String requestTokenHeader = originalRequest.getHeader("x-access-token");
        logger.info("requestTokenHeader:{}", requestTokenHeader);


        ModifyResponseBodyWrapper responseWrapper = new ModifyResponseBodyWrapper(originalResponse);
        chain.doFilter(originalRequest, responseWrapper);
        String originalResponseBody = responseWrapper.getResponseBody(); // Original response body (clear text)


        SnapWorkResponse snapWorkResponse = new SnapWorkResponse();
        try 
        {
            org.json.JSONObject json = new org.json.JSONObject(originalResponseBody);

            if (!urls.contains(originalRequest.getRequestURI()) && json.opt("statusCode").equals("200") && requestTokenHeader != null) 
            {
                JSONObject payload = commonJWTUtil.verifyToken(requestTokenHeader);
                String mobileNo = (String) payload.get("mobileno");

                String jwtToken = commonJWTUtil.generateJwtToken(mobileNo, 0, "mobile");

                logger.info("jwtToken in Session Mgt Filter:{}", jwtToken);

                json.put("jwtToken", jwtToken);
            }

            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(json.toString());
            snapWorkResponse.setResponse(jsonObject);

        }
        catch (JSONException | ParseException jsonException) 
        {
            logger.error("doFilter() Internal Exception {}, {}:", jsonException.getMessage(), jsonException.getCause());
        }

        /**
         * 4.Output the modified response body with the output stream of the original response object
         * To ensure that the response type is consistent with the original request, and reset the response body size
         */

        originalResponse.setContentType("application/json"); // Be consistent with the request

        byte[] responseData;
        if (originalRequest.getRequestURI().contains("/v1/file/download"))
            responseData = responseWrapper.getResponseBody().getBytes();
        else
            responseData = snapWorkResponse.getResponse().toString().getBytes(responseWrapper.getCharacterEncoding()); // The coding is consistent with the actual response
        originalResponse.setContentLength(responseData.length);

        @Cleanup
        ServletOutputStream out = originalResponse.getOutputStream();
        out.write(responseData);
    }
}