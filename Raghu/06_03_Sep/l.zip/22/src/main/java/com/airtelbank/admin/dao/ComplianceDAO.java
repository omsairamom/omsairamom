package com.airtelbank.admin.dao;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


@Service
public class ComplianceDAO {

	@Autowired  
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	public List<Map<String, Object>> fetchComplRetailerDetails(SnapWorkRequest request) throws Exception
	{
		List<Map<String, Object>> rows = null;
		String query = "";
		
		try
		{
			String circle = request.getCircleId() == null ? "" : request.getCircleId().trim();
			String zone = request.getZoneId() == null ? "" : request.getZoneId().trim();
			String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
			String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();
			
			endDate = endDate + " 11:59:59 PM";		
			if(StringUtils.isNotBlank(circle) && !circle.equals("All") && StringUtils.isNotBlank(zone) && !zone.equals("All"))
			{
				query = prop.getProperty("COMPLIANCE_FETCH_SPEC_CIRZONE_DTLS");
				rows = jdbctemplate.queryForList(query, new Object[] {Integer.parseInt(circle),Integer.parseInt(zone),startDate,endDate});
			}
			else if(StringUtils.isNotBlank(circle) && !circle.equals("All"))
			{
				query = prop.getProperty("COMPLIANCE_FETCH_SPEC_CIR_ALL_ZONE_DTLS");
				rows = jdbctemplate.queryForList(query, new Object[] {Integer.parseInt(circle),startDate,endDate});
			}
			else if(StringUtils.isNotBlank(zone) && !zone.equals("All"))
			{
				query = prop.getProperty("COMPLIANCE_FETCH_SPEC_ZONE_ALL_CIR_DTLS");
				rows = jdbctemplate.queryForList(query, new Object[] {Integer.parseInt(zone),startDate,endDate});
			}
			else
			{
				query = prop.getProperty("COMPLIANCE_FETCH_ALL_CIRZONE_DTLS");
				rows = jdbctemplate.queryForList(query, new Object[] {startDate,endDate});
			}
		}
		catch (Exception e)
		{
				CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}
}
