package com.airtelbank.admin.jwt;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;


/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Aug 02, 2019 10:14:45 PM
 */
@Service
public class JTIToken {

	private static Logger logger = LoggerFactory.getLogger(AeroCache.class);
	private String setName = "JTI_TOKEN";
	private String JTI_MPIN_TOKEN = "JTI_MPIN_TOKEN";
	
	@Autowired
	PropertyManager prop;
	
	@Autowired
	AeroCache aeroCache;

	public boolean expire(String actorId, String ref) {
		return expire(actorId, ref, null);
	}

	public boolean expire(String actorId, String ref, String jtiId) {
		logger.info(String.format("Expiring JTI token : actorId=%s, ref=%s, jitId=%s", actorId, ref, jtiId));
		return isActive(actorId, ref, jtiId, true);
	}

	public boolean isActive(String actorId, String ref, String jtiId, boolean expire) {
		Map<String, String> map = (Map<String, String>) aeroCache.get(setName, actorId, AeroCache.defaultColumn);
		boolean isActive = false;
		if (map != null) {
			if (ref != null && map.containsKey(ref)) {
				String token = map.get(ref);
				map.remove(ref);
				if (StringUtils.isNotBlank(token) && token.equals(jtiId)) isActive = true;
				else logger.info(String.format("Active JTI token: actorId=%s, ref=%s, jitId=%s", actorId, ref, token));
			} else if (jtiId != null && map.containsValue(jtiId)) {
				Iterator<Map.Entry<String, String>> iter = map.entrySet().iterator();
				while (iter.hasNext()) {
					if (jtiId.equals(iter.next().getValue())) {
						iter.remove();
						isActive = true;
						break;
					}
				}
			}
			if (expire) {
				if (map.isEmpty()) aeroCache.remove(setName, actorId);
				else aeroCache.put(setName, actorId, aeroCache.defaultColumn, map);
			}
		} else if (expire) logger.info("nothing to expire!! actorId:" + actorId + ", ref:" + ref + ", jtiId:" + jtiId);
		logger.info(String.format("JTI token Stats: actorId=%s, ref=%s, jitId=%s, status=%s", actorId, ref, jtiId, "" + isActive));
		return isActive;
	}

	public boolean add(String actorId, String ref, String jtiId) {
		return add(actorId, ref, jtiId, 0);
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	public boolean add(String actorId, String ref, String jtiId, int exp) {

		boolean flag = false;

		try {
			logger.info("Inside add() method in JTIToken class :");
			setName = prop.getProperty("AEROSPIKE_SETNAME");
			logger.info("setName {}:" ,setName);
			logger.info("actorId {}:" ,actorId);
			logger.info("ref {}: " ,ref);
			logger.info("jtiId {}:" ,jtiId);
			logger.info("jtiId {}:" ,jtiId);
			logger.info("defaultColumn   :"+aeroCache.defaultColumn);
			ref = StringUtils.defaultIfBlank(ref, "DEFAULT");
			if (StringUtils.isBlank(actorId) || StringUtils.isBlank(ref) || StringUtils.isBlank(jtiId)) return false;
			Map<String, String> map = (Map<String, String>) aeroCache.get(setName, actorId, aeroCache.defaultColumn);
			if (map == null) map = new HashMap<String, String>(1);
			map.put(ref, jtiId);
			if (exp > 0)
			{
				logger.info("line no 84 :");
				flag = aeroCache.put(exp, setName, actorId, aeroCache.defaultColumn, map);
				logger.info("flag :"+flag);
			}
			else
			{
				logger.info("line no 89 :");
				flag = aeroCache.put(setName, actorId, aeroCache.defaultColumn, map);
				logger.info("flag {}:" ,flag);
			}
		}
		catch(Exception exe)
		{
			CommonException.getPrintStackTrace(exe);
		}
		return flag;
	}

	public boolean isActive(String actorId, String ref, String jtiId)
	{
		return isActive(actorId, ref, jtiId, false);
	}

	
	public static String parseMobileNumber(String msisdn)
	{
	    int mobileNumberLength = 10;
	    String countryCode = "91";
	    logger.debug("Parsing " + msisdn);
	    if (StringUtils.isBlank(msisdn))
	    {
	        return null;
	    }

	    StringBuffer mobileNumber = new StringBuffer(
	            msisdn.replace(" ", Constants.EMPTY_STRING).replace("-", Constants.EMPTY_STRING).replace("+", Constants.EMPTY_STRING));

	    if (mobileNumber.length() > mobileNumberLength)
	    {
	        mobileNumber = mobileNumber.delete(0, mobileNumber.length() - mobileNumberLength);
	    }

	    mobileNumber.insert(0, countryCode);
	    String expression = "(\\d{" + String.valueOf(mobileNumberLength + countryCode.length()) + "})$";
	    CharSequence inputStr = mobileNumber;
	    Pattern pattern = Pattern.compile(expression);
	    Matcher matcher = pattern.matcher(inputStr);

	    if (!matcher.matches())
	    {
	        return null;
	    }

	    return mobileNumber.toString();
	}
}