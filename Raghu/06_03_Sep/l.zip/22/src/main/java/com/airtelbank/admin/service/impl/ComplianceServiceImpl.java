package com.airtelbank.admin.service.impl;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import com.airtelbank.admin.util.*;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.ComplianceDAO;
import com.airtelbank.admin.dao.GeoFencingDAO;
import com.airtelbank.admin.service.ComplianceService;


@Service
public class ComplianceServiceImpl implements ComplianceService {

	private static Logger logger = LoggerFactory.getLogger(ComplianceServiceImpl.class);

	@Autowired
	PropertyManager prop;

	@Autowired
	ComplianceDAO complianceDao;

	@Autowired
	GeoFencingDAO geoFencingDao;

	@Autowired
	SnapWorkResponse response;
	
	@Autowired
	SnapWorkRequest request;
	
	@Autowired
	CommonUtils commonUtil;

	@Autowired
	SecureBuilderVer secureBuilderVer;

	@SuppressWarnings("unchecked")
	@Override
	public SnapWorkResponse viewComplianceDetails(SnapWorkRequest request) throws CustomException
	{
		JSONObject json = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		JSONObject imagesJson = null;

		try
		{
			logger.info("Inside viewComplianceDetails() method in ComlianceServiceImpl classs... {}:","");
			String userName = request.getUserName() == null ? "" : request.getUserName().trim();
			String circleId = request.getCircleId() == null ? "" : request.getCircleId().trim();
			String zoneId = request.getZoneId() == null ? "" : request.getZoneId().trim();
			String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
			String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

			if (StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(circleId) && StringUtils.isNotBlank(zoneId)
					&& StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate))
			{

				List<Map<String, Object>> rows = complianceDao.fetchComplRetailerDetails(request);
				logger.info("COMPLIANCE_FETCH_SPEC_CIRZONE_DTLS ROWS--->: {} for userName: {}:" , rows.size(),userName);

				if (!rows.isEmpty() && rows != null)
				{
					logger.info("COMPLIANCE_FETCH_SPEC_CIRZONE_DTLS ROWS--->: {} for userName: {}:" , rows.size(),userName);


					for (Map<String, Object> row : rows)
					{
						logger.info("viewComplianceDetails() setting retailersJson: {} for userName: {}:"  ,row,userName);
						JSONObject retailersJson = new JSONObject();
						JSONArray imagesJsonArray = new JSONArray();

						String retailerMobileNo = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
						String retailerName = row.get("USER_NAME") == null ? "" : row.get("USER_NAME").toString();

						logger.info(" RET mobileNo AUR NAME--->: {} for retailerName: {}:" ,  retailerMobileNo, retailerName);

						if (StringUtils.isNotBlank(retailerMobileNo))
						{

							String path = prop.getProperty("FILE_SAVE_COMPLIANCE_PATH") + retailerMobileNo + "/";
							logger.info("COMPLIANCE PATH ---->: {} for userName: {}:" , path,userName);

							File folder = new File(path);
							String[] files = folder.list();

							if(files != null && files.length > 0)
							{
								logger.info("FILES LENGTH ---->: {} for userName: {}:" , files.length,userName);

								retailersJson.put("retailerMobileNo", retailerMobileNo);
								retailersJson.put("retailerName", retailerName);
								for (String fileName : files)
								{
									imagesJson = new JSONObject();
									imagesJson.put("path", path);
									imagesJson.put("fileName", fileName);
									imagesJsonArray.add(imagesJson);
									retailersJson.put("images", imagesJsonArray);
								}
								jsonArray.add(retailersJson);
							}
						}
					}

					json.put("retailers", jsonArray);
					json.put("userName", userName);
					response.setMessage(prop.getProperty(Constants.COMPLIANCE_FETCH_DTLS_SUCC_MSG));
					response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
					response.setResponse(json);
					logger.info("jsonArray : {} for userName: {}:" , jsonArray.size(),userName);
				}
				else
				{
					response.setMessage(prop.getProperty(Constants.COMPLIANCE_FETCH_DTLS_FAIL_MSG));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
					logger.info("compliance: {} for userName: {}: " , "",userName);
				}
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_RESPONSE_CODE));
				response.setResponse(json);
			}
			logger.info("viewComplianceDetails() Response generated: {} for userName: {}:" , "",userName);
			return response;

		}
		catch (Exception exe)
		{
			logger.info("viewComplianceDetails() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
			return response;
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public SnapWorkResponse onloadDashboardDetails(SnapWorkRequest request) throws CustomException
	{
		JSONArray circleJsonArray = new JSONArray();
		JSONArray categoryJsonArray = new JSONArray();
		JSONArray zoneJsonArray = new JSONArray();
		JSONArray roleJsonArray = new JSONArray();
		JSONObject json = new JSONObject();
		List<Map<String, Object>> rows = null;

		try
		{
			logger.info("Inside onloadDashboardDetails() method in ComlianceServiceImpl class.. {}:", "");
			String userName = request.getUserName() == null ? "" : request.getUserName().trim();

			if(StringUtils.isNotBlank(userName))
			{
				rows = geoFencingDao.getCircleMasterDetails();
				logger.info("onloadDashboardDetails() method rows {}:"  ,rows.size());

				if(rows != null && !rows.isEmpty() )
				{
					logger.info("onloadDashboardDetails() method rows {}:"  ,rows.size());

					for(Map row : rows)
					{
						logger.info("onloadDashboardDetails() setting circleJsonObj :{}"  ,row);

						JSONObject circleJsonObj = new JSONObject();
						circleJsonObj.put("circleName", row.get("CIRCLE_NAME")== null ? "" : row.get("CIRCLE_NAME").toString());
						circleJsonObj.put("circleCode", row.get("CIRCLE_CODE")== null ? "" : row.get("CIRCLE_CODE").toString());
						circleJsonObj.put("circleId", row.get("CIRCLE_ID")== null ? "" : row.get("CIRCLE_ID").toString());
						circleJsonArray.add(circleJsonObj);
					}
					json.put("circleDetails", circleJsonArray);
				}

				rows = geoFencingDao.getCategoryMasterDetails();
				logger.info("GEO_FETCH_CATEGORY_MST_DTLS rows {}:"  ,rows.size());

				if(rows != null && !rows.isEmpty())
				{
					logger.info("onloadDashboardDetails() method rows {}:"  ,rows.size());

					for(Map row : rows)
					{
						logger.info("onloadDashboardDetails() setting zoneJsonObj :{}"  ,row);

						JSONObject zoneJsonObj = new JSONObject();
						zoneJsonObj.put("categoryId", row.get("CAT_ID")== null ? "" : row.get("CAT_ID").toString());
						zoneJsonObj.put("categoryName", row.get("CAT_NAME")== null ? "" : row.get("CAT_NAME").toString());
						zoneJsonObj.put("categoryDesc", row.get("CAT_DESC")== null ? "" : row.get("CAT_DESC").toString());
						categoryJsonArray.add(zoneJsonObj);
					}
					json.put("categoryDetails", categoryJsonArray);
				}

				rows = geoFencingDao.getZoneMasterDetails();
				logger.info("GEO_FETCH_ZONE_MST_DTLS rows {}:"  ,rows.size());

				if(rows != null && !rows.isEmpty())
				{
					for(Map row : rows)
					{
						logger.info("onloadDashboardDetails() setting zoneJsonObj :{}"  ,row);
						JSONObject zoneJsonObj = new JSONObject();
						zoneJsonObj.put("zoneId", row.get("ZONE_ID")== null ? "" : row.get("ZONE_ID").toString());
						zoneJsonObj.put("zoneName", row.get("ZONE_NAME")== null ? "" : row.get("ZONE_NAME").toString());
						zoneJsonObj.put("zoneDesc", row.get("ZONE_DESC")== null ? "" : row.get("ZONE_DESC").toString());
						zoneJsonArray.add(zoneJsonObj);
					}
					json.put("zoneDetails", zoneJsonArray);
				}

				rows = geoFencingDao.getRoleMasterDetails();
				logger.info("DASHBOARD_FETCH_ROLE_MST_DTLS rows {}:"  ,rows.size());

				if(rows != null && !rows.isEmpty())
				{
					for(Map row : rows)
					{
						logger.info("onloadDashboardDetails() setting roleJsonObj :{}"  ,row);
						JSONObject roleJsonObj = new JSONObject();
						String roleId = row.get("ROLE_ID")== null ? "" : row.get("ROLE_ID").toString();
						logger.info("roleId {}:" , roleId);
						roleJsonObj.put("roleId", row.get("ROLE_ID")== null ? "" : row.get("ROLE_ID").toString());
						roleJsonObj.put("roleName", row.get("ROLE_NAME")== null ? "" : row.get("ROLE_NAME").toString());
						roleJsonObj.put("roleDesc", row.get("ROLE_DESC")== null ? "" : row.get("ROLE_DESC").toString());
						roleJsonArray.add(roleJsonObj);
					}
					json.put("roleDetails", roleJsonArray);
				}

				response.setMessage(prop.getProperty(Constants.DASHBOARD_ONLOAD_DATA_FETCH_SUCC_MSG));
				response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
				response.setResponse(json);
				logger.info("Success Response generated {}:", "");
			}
			else
			{
				logger.info("onloadDashboardDetails() User name is blank {}:" , "");
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}
			logger.info("onloadDashboardDetails() Response generated {}:" , "");
			return response;

		}
		catch (Exception exe)
		{
			logger.info("onloadDashboardDetails() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
			return response;
		}
	}

	@Override
	public int downloadComplianceDetails(String encrandomkey, String decodedString, String sessionKey, HttpServletResponse httpResponse, boolean testCaseInvoked) throws CustomException
	{
		byte[] byteBuffer = new byte[1024];
		String path = "";
		String fileName = "";
		String mobileNo= "";
		int length = 0;
		org.json.JSONArray imagesJsonArr =null;
		ZipOutputStream	zout = null;
		FileInputStream fin  = null ;

		try
		{
			logger.info("Inside downloadComplianceDetails() method in ComlianceServiceImpl class..{}:" ,"");

			String decryptedString = null;

			if (!testCaseInvoked)
			{
				decryptedString = secureBuilderVer.decrypt(encrandomkey, decodedString, sessionKey,"web");
			}
			else
			{
				decryptedString =
						"userName=9000011463&categoryId=All&roleName=All&circleId=All&zoneId=All&startDate=01-03-2021&endDate=31-03-2021";
			}

			logger.info("decryptedString {}:" , decryptedString);
		
			 if (StringUtils.isNotBlank(decryptedString))
			 {
				org.json.JSONObject reqJsonObj = new org.json.JSONObject(decryptedString);
				logger.info("reqJsonObj {}:" ,reqJsonObj.toString());
				org.json.JSONArray reqJsonArr = reqJsonObj.getJSONArray("retailers");

				if (reqJsonArr.length() > 0)
				{
					for (int m = 0; m < reqJsonArr.length(); m++)
					{
						org.json.JSONObject retailerJsonObj = reqJsonArr.getJSONObject(m);

						mobileNo = retailerJsonObj.getString("retailerMobileNo") == null ? "": retailerJsonObj.getString("retailerMobileNo").trim();
						imagesJsonArr = retailerJsonObj.getJSONArray("images");
						logger.info("imagesJsonArr.length() {}:" ,imagesJsonArr.length());

						if (imagesJsonArr.length() > 0)
						{
							for (int n = 0; n < imagesJsonArr.length(); n++)
							{
								org.json.JSONObject imageJsonObj = imagesJsonArr.getJSONObject(n);
								path = imageJsonObj.getString("path") == null ? "": imageJsonObj.getString("path").trim();
								fileName = imageJsonObj.getString("fileName") == null ? "": imageJsonObj.getString("fileName").trim();
							}
						}
					}
				}

				if (imagesJsonArr != null)
				{
					File folder = new File(path);
					File[] files = folder.listFiles();
					if (files != null && files.length > 0)
					{
						String pdfFile = path + fileName;	
						if (imagesJsonArr.length() > 1)
						{
							try
							{
								httpResponse.setContentType("application/zip");
								httpResponse.setHeader("Content-Disposition","attachment;filename=\"" + mobileNo + ".zip\"");
								zout = new ZipOutputStream(httpResponse.getOutputStream());

								for (int i = 0; i < files.length; i++)
								{
									fin  = new FileInputStream(files[i]);
									zout.putNextEntry(new ZipEntry(files[i].getName()));
									while ((length = fin.read(byteBuffer)) > 0)
									{
										zout.write(byteBuffer, 0, length);
									}
									zout.closeEntry();

									if(fin != null)
									{
										fin.close();
									}
								}
							}
							finally
							{
								if(zout != null)
								{
									zout.close();
								}
							}
						}
						else
						{
							httpResponse.setContentType("application/octet-stream");
							httpResponse.setHeader(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=\"" + mobileNo + "_" + fileName + "\"");
							ServletOutputStream outStream = httpResponse.getOutputStream();
							DataInputStream in = new DataInputStream(new FileInputStream(pdfFile));

							while ((in != null) && ((length = in.read(byteBuffer)) != -1))
							{
								outStream.write(byteBuffer, 0, length);
							}

							in.close();
							outStream.close();
						}
					}
				}
				else
				{
					logger.info("imagesJsonArr is null at line no 370 ");
				}
			}
			 else
			 {
				logger.info("decryptedString is null at line no 374 ");
			 }
		}
		catch (Exception exe)
		{
			logger.info("downloadComplianceDetails() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
		}
		finally
		{
			try
			{
				if(fin != null)
				{
					fin.close();
				}
			}
			catch(Exception exe)
			{
				CommonException.getPrintStackTrace(exe);
			}
		}
		return  1;
	}
}

