package com.airtelbank.admin.common;

import org.json.simple.JSONObject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.InputStreamResource;

@Configuration
public class SnapWorkResponse
{
    private JSONObject response;
    private String message;
    private String statusCode;
    private String description;
    private String status;
    private String expMsg; //NEW FIELD 
	private String expCause; //NEW FIELD
	private String  expLocalMsg; //NEW FILED

    @Bean
    public SnapWorkResponse response()
    {
        return new SnapWorkResponse();
    }

    public JSONObject getResponse() {
        return response;
    }

    public void setResponse(JSONObject response) {
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getExpMsg() {
		return expMsg;
	}

	public void setExpMsg(String expMsg) {
		this.expMsg = expMsg;
	}

	public String getExpCause() {
		return expCause;
	}

	public void setExpCause(String expCause) {
		this.expCause = expCause;
	}

	public String getExpLocalMsg() {
		return expLocalMsg;
	}

	public void setExpLocalMsg(String expLocalMsg) {
		this.expLocalMsg = expLocalMsg;
	}

}
