package com.airtelbank.admin.controller;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.ComplianceService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@RestController
public class ComplianceController {

    private static Logger logger = LoggerFactory.getLogger(ComplianceController.class);

    @Autowired
    SnapWorkResponse response;

    @Autowired
    ComplianceService complianceService;

    @Autowired
    PropertyManager prop;

    @Autowired
    CommonUtils commonUtil;
    
    JSONObject json = new JSONObject();
    long startTime = 0;
    long endTime = 0;
    long elapsedTimeMillis = 0;
    GsonBuilder gsonBuilder = new GsonBuilder();
    Gson gson = gsonBuilder.create();

    @PostMapping("/v1/compliance/view")
    public ResponseEntity<Object> fetchComplianceDetails(@Valid @RequestBody SnapWorkRequest request)
    {
        try
        {
            startTime = System.currentTimeMillis();
            String userName = request.getUserName() == null ? "" : request.getUserName().trim();
            String circleId = request.getCircleId() == null ? "" : request.getCircleId().trim();
            String zoneId = request.getZoneId() == null ? "" : request.getZoneId().trim();
            String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
            String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

            if (StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(circleId) && StringUtils.isNotBlank(zoneId)
                    && StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate))
            {
                response = complianceService.viewComplianceDetails(request);
            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("Fetch Compliance Details, response generated successful {}: ", "");
            endTime = System.currentTimeMillis();
            logger.info("Fetch Compliance Details, Request end timeInMillis {}:", endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info(
                    "************************************************************************************************************************************* {}:",
                    "");
        }
        catch (Exception exe)
        {
            CommonException.getPrintStackTrace(exe);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/v1/dashboard/onload")
    @ResponseBody
    public ResponseEntity<Object> dashboardOnLoadDetails(@RequestBody SnapWorkRequest request)
    {
        try
        {
            startTime = System.currentTimeMillis();
            
            logger.info("Fetch Dashboard onload Details, Request start timeInMillis{} :", startTime);

            String userName = request.getUserName() == null ? "" : request.getUserName().trim();

            if (StringUtils.isNotBlank(userName))
            {
                response = complianceService.onloadDashboardDetails(request);
            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("Fetch Dashboard onload Details, Response {}: ", gson.toJson(response));
            endTime = System.currentTimeMillis();
            logger.info("Fetch Compliance Details, Request end timeInMillis {}:", endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("*********************************************************************{}: ", "");
        }
        catch (Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/v3/compliance/download")
    public ResponseEntity<Object> downloadComplianceDetails(@RequestParam String encrandomkey, String encString,
                                                            String sessionKey, HttpServletResponse httpResponse)
    {
        Base64 base64 = new Base64();

        try
        {
            startTime = System.currentTimeMillis();
            logger.info("Download Compliance Details, Request start timeInMillis {}:", startTime);
            logger.info("encrandomkey {}:", encrandomkey.trim());
            logger.info("encString {}:", encString.trim());
            logger.info("sessionKey {}:", sessionKey.trim());

            if (StringUtils.isNotBlank(encrandomkey.trim()) && StringUtils.isNotBlank(encString.trim())
                    && StringUtils.isNotBlank(sessionKey.trim()))
            {
                if (encrandomkey.contains(""))
                {
                    encrandomkey = encrandomkey.replace(" ", "+").trim();
                }
                String decodedString = new String(base64.decode(encString.getBytes()));

                if (StringUtils.isNotBlank(decodedString.trim()))
                {
                    complianceService.downloadComplianceDetails(encrandomkey, decodedString, sessionKey, httpResponse, false);
                }
                else
                {
                    response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
                    response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
                    response.setResponse(json);
                }
            }
            else
             {
                response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
                response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            logger.info("Download Compliance Details, Request end timeInMillis {}:", endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info(
                    "*************************************************************************************************************************************");
        }
        catch (Exception exe)
        {
            CommonException.getPrintStackTrace(exe);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
