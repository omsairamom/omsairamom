package com.airtelbank.admin.cache;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class CircleMgmtCache {
	
	private  Map<String,Long> map = new HashMap<>();
		
	public  void put(String key, Long value)
	{
		map.put(key,value);		
	}
	
	public  Long get(String key)
	{
		return map.get(key);		
	}
		
	public  void clear()
	{
		map.clear();		
	}
	

}
