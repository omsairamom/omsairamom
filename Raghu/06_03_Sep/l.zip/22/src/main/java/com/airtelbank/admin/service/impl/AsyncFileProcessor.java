package com.airtelbank.admin.service.impl;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.airtelbank.admin.cache.CircleMgmtCache;
import com.airtelbank.admin.dao.PromoterCircleMSTDao;
import com.airtelbank.admin.dao.PromoterOutletMSTDao;
import com.airtelbank.admin.dao.PromoterUploadFileAuditDao;
import com.airtelbank.admin.dao.PromoterUserMSTDao;
import com.airtelbank.admin.dto.OutletRequest;
import com.airtelbank.admin.dto.OutletRequestResponse;
import com.airtelbank.admin.dto.WhitelistedPromoter;
import com.airtelbank.admin.dto.WhitlelistedPromoterResponse;
import com.airtelbank.admin.entity.PromoterCircleMSTEntity;
import com.airtelbank.admin.entity.PromoterOutletMSTEntity;
import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.entity.PromoterUserMSTEntity;
import com.airtelbank.admin.enums.UserType;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.ValidationUtil;

@Service
public class AsyncFileProcessor {

	private static final String INTERVIEWER_NO_INVALID = "Interviewer no is invalid. It should be of 10 digits.";
	private static final String INTERVIEW_DATE_MANDATORY_FOR_RETAILER_PROMOTERS = "InterviewDate mandatory for retailer Promoters(User Type=1)";
	private static final String INTERVIEWER_NO_MANDATORY_FOR_RETAILER_PROMOTERS = "InterviewerNo mandatory for retailer Promoters(User Type=1)";
	private static final String EMP_ID_MANDATORY_FOR_PROMOTERS = "EmpId mandatory for Promoters(User Type=1)";
	private static final String AGENCY_MANDATORY_FOR_PROMOTERS = "Agency mandatory for Promoters(User Type=1)";
	private static final String DOB_MANDATORY_FOR_PROMOTERS = "Dob mandatory for Promoters(User Type=1)";
	private static final String PROMOTER_CATEGORY_NOT_MATCH_WITH_SUPERVISOR_USERTYPE = "Promoter category do not match with Supervisor's usertype";
	private static final String SUPERVISOR_TYPE_NOT_MATCH_USERTYPE_IN_SYSTEM = "Entered Supervisor's type do not match with the type present in the system";
	private static final String USERTYPE_NOT_BELONG_ENTERED_CATEGORY = "Usertype do not belong to the entered category";
	public static final String RETAILER = "RET";
	public static final String OUTLET_TYPE_DO_NOT_MATCH_WITH_SUPERVISORS_S_TYPE = "Outlet type do not match with supervisors's type";
	private static final String OUTLET_TYPE_EMPTY_OR_INVALID = "Outlet type field empty or invalid. It should be Mer/Ret";

	private static final String OUTLET_NAME_EMPTY = "Outlet name field empty.";

	private static final String OUTLET_NUMBER_EMPTY_OR_INVALID = "Outlet number field empty or invalid. It should be of 10 digits only.";

	private static final String CIRCLE_ID_EMPTY = "Circle ID  field empty.";

	private static final String CIRCLE_ID_INVALID = "Circle ID value does not exists.";

	private static final String OUTLET_PARENT_DEACTIVE_STATE = "Outlet's promoter is in Deactive state.";

	private static final String USER_ACTION_EMPTY_INVALID = "User action is empty or invalid. It should be A/D.";

	private static final String Active = "A";

	private static final String Deactive = "D";

	private static final String CATEGORY_EMPTY_OR_INVALID = "Category field empty or invalid. It should be Mer/Ret.";

	private static final String USERTYPE_EMPTY_OR_INVALID = "Usertype field empty or invalid.";

	private static final String USER_NAME_EMPTY_OR_INVALID = "User name field empty or invalid. It should contain alphabets and spaces only.";

	private static final String USER_NUMBER_EMPTY_OR_INVALID = "User number field empty or invalid. It should be of 10 digits only.";

	private static final String DOJ_INVALID_DATE_FORMAT = "Doj date format not dd-MM-yyyy (e.g 24-07-1998)";

	private static final String DOB_INVALID_DATE_FORMAT = "Dob date format not dd-MM-yyyy (e.g 24-07-1998)";
	private static final String INTERVIEW_DATE_INVALID_DATE_FORMAT = "Interview date format not dd-MM-yyyy (e.g 24-07-1998)";

	private static final String PARENT_TYPE_EMPTY_OR_INVALID = "Supervisor type field empty or invalid.";

	private static final String USER_PARENT_DEACTIVE = "User's supervisor status is D.";

	private static final String PARENT_NUMBER_EMPTY = "Parent Number field empty";

	private static final String PARENT_NUMBER_INVALID = "Parent Number field does not exists";

	private static final String OUTLET_NOT_EXISTS_CANNNOT_BE_DEACTIVATED = "Outlet does not exists. Cannnot be deactivated";
	private static final String MERCHANT = "MER";

	private static Logger logger = LoggerFactory.getLogger(AsyncFileProcessor.class);

	@Value("${promoter.user.topHierarchyList}")
	private String promoterUserTopHierarchyList;


	@Value("#{'${promoter.user.category}'.split(',')}")
	private List<String> promoterUserCategoryList;

	@Value("#{'${promoter.allowed.action}'.split(',')}")
	private List<String> promoterAllowedActionValues;

	@Value("#{'${promoter.retailer.userType}'.split(',')}")
	private List<String> promoterRetailerUserTypeList;

	@Value("#{'${promoter.merchant.userType}'.split(',')}")
	private List<String> promoterMerchantUserTypeList;

	@Autowired
	private PromoterUploadFileAuditDao promoterUploadFileAuditDao;

	@Autowired
	private PromoterOutletMSTDao promoterOutletMSTDao;

	@Autowired
	private PromoterCircleMSTDao promoterCircleMSTDao;

	@Autowired
	private PromoterUserMSTDao promoterUserMSTDao;

	@Autowired
	private CommonUtils commonUtils;

	@Autowired
	private Session session;

	@Autowired
	private CircleMgmtCache circleMgmtCache;


	@Async("asyncOutletExecutor")
	public  CompletableFuture<PromoterOutletMSTEntity> processOutletFileRecordsAsync(OutletRequest user, CopyOnWriteArrayList<OutletRequestResponse> recordResponses,CopyOnWriteArrayList<OutletRequestResponse> recordResponsesValidationSuccess, PromoterUploadFileAuditEntity file, CopyOnWriteArrayList<PromoterOutletMSTEntity> promoterOutletMSTEntityList,Map<Integer,OutletRequestResponse> mapEntityOutputOutlet,int lineNo, Map<String,Long> promoterUserMgmtCache) {

		logger.info("AsyncFileProcessor : processOutletFileRecordsAsync() | start");

		PromoterOutletMSTEntity promoterOutletMSTEntity = new PromoterOutletMSTEntity();
		promoterOutletMSTEntity.setLineNo(lineNo);
		//populate with existing record for writing in output csv file
		OutletRequestResponse outletRequestResponse = populateOutletResponseRecordWithExistingDetails(user);
		mapEntityOutputOutlet.put(promoterOutletMSTEntity.getLineNo(),outletRequestResponse);


		//validate columns and populate remark field for output file and  zoneid,parentid,fileid for save in db
		validateAndPoulateOutletData(user, outletRequestResponse,promoterOutletMSTEntity,promoterUserMgmtCache);

		promoterOutletMSTEntity.setPromoterUploadFileAuditEntity(file);



		//if remark success, save in DB
		if(outletRequestResponse.getRemarks().equalsIgnoreCase(Constants.Validate_Success))
		{
			promoterOutletMSTEntityList.add(promoterOutletMSTEntity);
			recordResponsesValidationSuccess.add(outletRequestResponse);
		}else

		//if record success or rejected due to error, add in list to save in csv file
		{
			recordResponses.add(outletRequestResponse);
		}

		logger.info("AsyncFileProcessor : processOutletFileRecordsAsync() | end");

		return CompletableFuture.completedFuture(promoterOutletMSTEntity);
	}


	private void validateAndPoulateOutletData(OutletRequest user, OutletRequestResponse outletRequestResponse,PromoterOutletMSTEntity promoterOutletMSTEntity,Map<String,Long> promoterUserMgmtCache) {

		logger.info("AsyncFileProcessor : validateAndPoulateOutletData() | start");

		String remarks ="";

		//outlet no, name and type and siteid
		remarks = validateOutletBasicDetails(user, promoterOutletMSTEntity);
		if(!StringUtils.isEmpty(remarks))
		{
			outletRequestResponse.setRemarks(remarks);
			return;
		}

		//Parent Number
		remarks = validateParentDetails(user, outletRequestResponse, promoterOutletMSTEntity,promoterUserMgmtCache);
		if(!StringUtils.isEmpty(remarks))
		{
			outletRequestResponse.setRemarks(remarks);
			return;
		}


		//Check if user already exists in DB or not
		PromoterOutletMSTEntity outletEntity = null;
		try {
			outletEntity = promoterOutletMSTDao.fetchOutletByOutletPhoneNumberAndType(user.getOutletPhoneNumber(),user.getOutletType().toUpperCase());
		}
		catch(Exception e)
		{
			logger.error("AsyncFileProcessor : validateAndPoulateOutletData() | Exception occured while fetching outlet details from db for outlet no {}, outlet type {}. Message {}, Cause {}",user.getOutletPhoneNumber(),user.getOutletType(),e.getMessage(),e.getCause());
			outletRequestResponse.setRemarks("Details could not be fetched for this outlet no and type");
			return;
		}
		//if user does not exist and status is D, append error
		if(outletEntity == null && user.getAction().equalsIgnoreCase(Deactive))
		{
			outletRequestResponse.setRemarks(OUTLET_NOT_EXISTS_CANNNOT_BE_DEACTIVATED);
			return;

		}else if(outletEntity != null)
		{
			promoterOutletMSTEntity.setId(outletEntity.getId());
		}

		outletRequestResponse.setRemarks(Constants.Validate_Success);

		logger.info("AsyncFileProcessor : validateAndPoulateOutletData() | end");
	}


	//Outlet parent or we can say outlet ka promoter
	private String validateParentDetails(OutletRequest user, OutletRequestResponse outletRequestResponse,
										 PromoterOutletMSTEntity promoterOutletMSTEntity, Map<String,Long> promoterUserMgmtCache) {

		logger.info("AsyncFileProcessor : validateParentDetails() | start");
		String remarks = "";
		PromoterUserMSTEntity parent=null;
		String promoterNumber = user.getPromoterPhoneNumber();
		if(!StringUtils.isEmpty(promoterNumber))
		{
			//get parent number from aerospike if not exists there then get it from db
			parent = fetchParent(promoterNumber,promoterUserMgmtCache);

			if(parent != null)
			{	promoterOutletMSTEntity.setPromoterUserMSTEntity(parent);
				promoterOutletMSTEntity.setPromoterNo(parent.getUserNo());
				if(!parent.getStatus().equalsIgnoreCase(Deactive))
					promoterUserMgmtCache.put(promoterNumber, parent.getId());
			}
			else {
				remarks = PARENT_NUMBER_INVALID;
				return remarks;
			}
		}else
		{
			remarks = PARENT_NUMBER_EMPTY;
			return remarks;
		}

		//Action
		remarks = validateUserParentStatus(user, remarks, parent);
		if(!StringUtils.isEmpty(remarks))
		{
			outletRequestResponse.setRemarks(remarks);
			return remarks;
		}
		promoterOutletMSTEntity.setStatus(user.getAction().toUpperCase());



		//Parent type should be according to the outlet type
		//if merchant type outlet, then supervisor ka user type should be of merchant and similarly for retailer
		String outletType = user.getOutletType();
		if((outletType.equalsIgnoreCase(MERCHANT) && parent.getCategory().toUpperCase().equalsIgnoreCase(RETAILER)) || ((outletType.equalsIgnoreCase(RETAILER) && parent.getCategory().toUpperCase().equalsIgnoreCase(MERCHANT))))
		{
			remarks = OUTLET_TYPE_DO_NOT_MATCH_WITH_SUPERVISORS_S_TYPE;
			return remarks;
		}


		logger.info("AsyncFileProcessor : validateParentDetails() | end");
		return remarks;
	}


	private String validateUserParentStatus(OutletRequest user, String remarks, PromoterUserMSTEntity parent) {

		logger.info("AsyncFileProcessor : validateUserParentStatus() | start");

		String action = user.getAction();
		if(StringUtils.isEmpty(action) || (!StringUtils.isEmpty(action) && !promoterAllowedActionValues.contains(action.toUpperCase())))
		{
			remarks = USER_ACTION_EMPTY_INVALID;
			return remarks;
		}
		else if(!StringUtils.isEmpty(action) && action.equalsIgnoreCase(Active) && null != parent && parent.getStatus().equalsIgnoreCase(Deactive))
		{
			//Check parent status
			String existingParentAction = parent.getStatus();
			if(existingParentAction.equalsIgnoreCase(Deactive))
			{
				remarks = OUTLET_PARENT_DEACTIVE_STATE;
				return remarks;
			}

		}

		logger.info("AsyncFileProcessor : validateUserParentStatus() | end");
		return remarks;
	}


	private PromoterUserMSTEntity fetchParent(String promoterNumber,Map<String,Long> promoterUserMgmtCache) {

		logger.info("AsyncFileProcessor : fetchParent() | start");

		PromoterUserMSTEntity parent = null;

		Long id=  promoterUserMgmtCache.get(promoterNumber);
		if(id != null)
		{
			parent = session.load(PromoterUserMSTEntity.class, id);
		}else {

			try{
				parent = promoterUserMSTDao.fetchUserByUserNumber(promoterNumber);
			}
			catch(Exception e)
			{
				logger.error("AsyncFileProcessor | fetchParent() | Exception occured while fetching data for parent no {}. Message {} Cause {}", promoterNumber ,e.getMessage(),e.getCause());
			}
		}
		//}
		logger.info("AsyncFileProcessor : fetchParent() | end");
		return parent;
	}



	private String validateCircle( WhitelistedPromoter user,PromoterUserMSTEntity promoterUserMSTEntity) {
		logger.info("AsyncFileProcessor : validateCircle() | start");

		PromoterCircleMSTEntity circle =null;
		String remarks = "";
		String circleId = user.getCircleId();
		if(!StringUtils.isEmpty(circleId))
		{

			//Check if circleid exists in aerospike otherwise fetch from db
			circle = fetchCircle(circleId);

			if(null != circle)
			{
				promoterUserMSTEntity.setPromoterCircleMSTEntity(circle);
				circleMgmtCache.put(circleId, circle.getId());
			}
			else
			{
				remarks = CIRCLE_ID_INVALID;
				return remarks;
			}

		}else
		{
			remarks = CIRCLE_ID_EMPTY;
			return remarks;
		}

		logger.info("AsyncFileProcessor : validateCircle() | end");
		return remarks;
	}


	private PromoterCircleMSTEntity fetchCircle(String circleId) {

		logger.info("AsyncFileProcessor : fetchCircle() | start");
		PromoterCircleMSTEntity circle=null;

		Long id=  circleMgmtCache.get(circleId);
		if(id != null)
		{
			circle = session.load(PromoterCircleMSTEntity.class, id);
		}else {
			try {
				circle = promoterCircleMSTDao.fetchCirclebyCircleId(circleId);
			}catch(Exception e)
			{
				logger.error("AsyncFileProcessor | fetchCircle() | Exception occured while fetching circle for circleid {}. Message {} Cause {}",circleId ,e.getMessage(),e.getCause());
			}
		}


		logger.info("AsyncFileProcessor : fetchCircle() | end");
		return circle;
	}


	private String validateOutletBasicDetails(OutletRequest user,PromoterOutletMSTEntity promoterOutletMSTEntity) {
		logger.info("AsyncFileProcessor : validateOutletBasicDetails() | start");

		String remarks="";
		String outletNo = user.getOutletPhoneNumber();
		if(StringUtils.isEmpty(outletNo) || ( !StringUtils.isEmpty(outletNo) && !ValidationUtil.validatePhoneNumber(outletNo)))

		{
			remarks = OUTLET_NUMBER_EMPTY_OR_INVALID;
			return remarks;

		}
		promoterOutletMSTEntity.setOutletNo(outletNo);


		String  outletName = user.getOutletName();
		if(StringUtils.isEmpty(outletName))
		{
			remarks =OUTLET_NAME_EMPTY;
			return remarks;
		}

		promoterOutletMSTEntity.setOutletName(outletName);

		String outletType = user.getOutletType();
		if(StringUtils.isEmpty(outletType) || (!StringUtils.isEmpty(outletType) && !promoterUserCategoryList.contains(outletType.toUpperCase())))
		{
			remarks=OUTLET_TYPE_EMPTY_OR_INVALID;
			return remarks;

		}
		promoterOutletMSTEntity.setOutletType(outletType.toUpperCase());

		logger.info("AsyncFileProcessor : validateOutletBasicDetails() | end");
		return remarks;
	}

	private OutletRequestResponse populateOutletResponseRecordWithExistingDetails(OutletRequest user) {

		logger.info("AsyncFileProcessor : populateOutletResponseRecordWithExistingDetails() | start");
		OutletRequestResponse outletRequestResponse = new OutletRequestResponse();
		outletRequestResponse.setOutletPhoneNumber(user.getOutletPhoneNumber());
		outletRequestResponse.setOutletName(user.getOutletName());
		outletRequestResponse.setOutletType(user.getOutletType());
		outletRequestResponse.setPromoterPhoneNumber(user.getPromoterPhoneNumber());
		outletRequestResponse.setAction(user.getAction());
		logger.info("AsyncFileProcessor : populateOutletResponseRecordWithExistingDetails() | end");
		return outletRequestResponse;
	}


	@Async("asyncPromoterUserExecutor")
	public CompletableFuture<PromoterUserMSTEntity> processPromoterUserFileRecordsAsync(WhitelistedPromoter user,
																						CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponses,CopyOnWriteArrayList<WhitlelistedPromoterResponse> recordResponsesValidationSuccess, PromoterUploadFileAuditEntity file,
																						CopyOnWriteArrayList<PromoterUserMSTEntity> promoterUserMSTEntityList,Map<Integer,WhitlelistedPromoterResponse> mapEntityOutputPrWhitelist,int lineNo, Map<String,Long> promoterUserMgmtCache) {

		logger.info("AsyncFileProcessor | processPromoterUserFileRecordsAsync() start");
		PromoterUserMSTEntity promoterUserMSTEntity = new PromoterUserMSTEntity();
		promoterUserMSTEntity.setLineNo(lineNo);

		//populate with existing record for writing in output csv file
		WhitlelistedPromoterResponse whitlelistedPromoterResponse = populatePromoterUserResponseRecordWithExistingDetails(user);
		mapEntityOutputPrWhitelist.put(promoterUserMSTEntity.getLineNo(), whitlelistedPromoterResponse);

		//validate columns and populate remark field for output file and  zoneid,parentid,fileid for save in db
		validateAndPoulatePromoterUserData(user, whitlelistedPromoterResponse,promoterUserMSTEntity,promoterUserMgmtCache);


		promoterUserMSTEntity.setPromoterUploadFileAuditEntity(file);
		//if remark success, save in DB
		if(whitlelistedPromoterResponse.getRemarks().equalsIgnoreCase(Constants.Validate_Success))
		{
			recordResponsesValidationSuccess.add(whitlelistedPromoterResponse);
			promoterUserMSTEntityList.add(promoterUserMSTEntity);


		}else
		{//if record success or rejected due to error, add in list to save in csv file
			recordResponses.add(whitlelistedPromoterResponse);
		}

		logger.info("AsyncFileProcessor | processPromoterUserFileRecordsAsync() end");

		return CompletableFuture.completedFuture(promoterUserMSTEntity);
	}


	public void validateAndPoulatePromoterUserData(WhitelistedPromoter user,
												   WhitlelistedPromoterResponse whitlelistedPromoterResponse, PromoterUserMSTEntity promoterUserMSTEntity,Map<String,Long> promoterUserMgmtCache) {

		logger.info("AsyncFileProcessor : validateAndPoulatePromoterUserData() start");

		String remarks = "";
		remarks = validateBasicPromoterDetails(user, promoterUserMSTEntity);
		if(!StringUtils.isEmpty(remarks))
		{
			whitlelistedPromoterResponse.setRemarks(remarks);
			return;
		}

		//circleid
		remarks = validateCircle(user, promoterUserMSTEntity);
		if(!StringUtils.isEmpty(remarks))
		{
			whitlelistedPromoterResponse.setRemarks(remarks);
			return;
		}

		//Dob//Doj
		remarks =validatePromoterDobDoj(user, promoterUserMSTEntity);
		if(!StringUtils.isEmpty(remarks))
		{
			whitlelistedPromoterResponse.setRemarks(remarks);
			return;
		}


		//Parent Number
		remarks = validatePromoterUserParentDetails(user, promoterUserMSTEntity,promoterUserMgmtCache);
		if(!StringUtils.isEmpty(remarks))
		{
			whitlelistedPromoterResponse.setRemarks(remarks);
			return;
		}

		//Check if user already exists in DB or not
		PromoterUserMSTEntity userEntity=null;
		try {
			userEntity = promoterUserMSTDao.fetchUserByUserNumber(user.getUserPhoneNumber());
		}catch(Exception e)
		{
			logger.error("AsyncFileProcessor : validateAndPoulatePromoterUserData() | Exception occured while checking user in db. Message {} Cause {} ",e.getMessage(),e.getCause());

		}
		//if user does not exist and status is D, append error
		if(userEntity == null && user.getAction().equalsIgnoreCase(Deactive))
		{
			whitlelistedPromoterResponse.setRemarks("User does not exists. Cannnot be deactivated");
			return;
		}else if(userEntity != null)
		{
			promoterUserMSTEntity.setId(userEntity.getId());
		}

		whitlelistedPromoterResponse.setRemarks(Constants.Validate_Success);

		logger.info("AsyncFileProcessor : validateAndPoulatePromoterUserData() | end");
	}


	public String validatePromoterUserParentDetails(WhitelistedPromoter user, PromoterUserMSTEntity promoterUserMSTEntity,Map<String,Long> promoterUserMgmtCache) {

		logger.info("AsyncFileProcessor : validatePromoterUserParentDetails() | start");
		String remarks="";
		PromoterUserMSTEntity parent=null;
		String parentNumber = user.getSupervisorNumber();
		if(!StringUtils.isEmpty(parentNumber))
		{
			//get parent number from aerospike if not exists there then get it from db
			parent = fetchParent(parentNumber,promoterUserMgmtCache);

			if(parent != null)
			{	promoterUserMSTEntity.setPromoterUserMSTEntity(parent);
				promoterUserMSTEntity.setParentNo(parent.getUserNo());
				if(!parent.getStatus().equalsIgnoreCase(Deactive))
					promoterUserMgmtCache.put(parentNumber, parent.getId());

			}
			else {
				remarks = PARENT_NUMBER_INVALID;
				return remarks;
			}


		}else if(!promoterUserTopHierarchyList.contains((UserType.get(Integer.valueOf(user.getUserType()))).name()))
		{
			remarks = PARENT_NUMBER_EMPTY;
			return remarks;
		}

		//Parent Type
		remarks = validatePromoterUserParentType(user, promoterUserMSTEntity,parent);
		if(!StringUtils.isEmpty(remarks))
		{
			return remarks;
		}

		//Action
		remarks = validateActionPromoterUser(user, promoterUserMSTEntity, parent);
		if(!StringUtils.isEmpty(remarks))
		{
			return remarks;
		}
		logger.info("AsyncFileProcessor : validatePromoterUserParentDetails() | end");
		return remarks;
	}


	public String validateActionPromoterUser(WhitelistedPromoter user, PromoterUserMSTEntity promoterUserMSTEntity,
											 PromoterUserMSTEntity parent) {
		logger.info("AsyncFileProcessor : validateActionPromoterUser() | start");
		String remarks="";
		String action = user.getAction();

		if(StringUtils.isEmpty(action) || (!StringUtils.isEmpty(action) && !promoterAllowedActionValues.contains(action.toUpperCase())))
		{
			remarks = USER_ACTION_EMPTY_INVALID;
			return remarks;
		}
		else if(!StringUtils.isEmpty(action) && action.equalsIgnoreCase(Active) && null != parent && parent.getStatus().equalsIgnoreCase(Deactive))
		{
			//Check parent status
			String existingParentAction = parent.getStatus();
			if(existingParentAction.equalsIgnoreCase(Deactive))
			{
				remarks =USER_PARENT_DEACTIVE;
				return remarks;
			}
		}
		promoterUserMSTEntity.setStatus(action);
		logger.info("AsyncFileProcessor : validateActionPromoterUser() | end");
		return remarks;
	}


	public String validatePromoterUserParentType(WhitelistedPromoter user, PromoterUserMSTEntity promoterUserMSTEntity, PromoterUserMSTEntity parent) {
		logger.info("AsyncFileProcessor : validatePromoterUserParentType() | start");
		String remarks ="";
		String parentType = user.getSupervisorType();

		if(!StringUtils.isEmpty(parentType) && null != UserType.get(Integer.valueOf(parentType)))
		{
			promoterUserMSTEntity.setParentType((UserType.get(Integer.valueOf(parentType))).name());

		}else if(!promoterUserTopHierarchyList.contains((UserType.get(Integer.valueOf(user.getUserType()))).name()))
		{
			remarks = PARENT_TYPE_EMPTY_OR_INVALID;
			return remarks;
		}

		//if parent exists, then parent type in db should match with parent type given here
		if(null != parent && !((UserType.get(Integer.valueOf(parentType))).name()).equals(parent.getUserType()))
		{
			remarks = SUPERVISOR_TYPE_NOT_MATCH_USERTYPE_IN_SYSTEM;
			return remarks;
		}

		//if promoter retailer then supervisor should also be retailer and same with merchant
		String userCategory = user.getCategory();

		if(null != parent) {
			if((userCategory.toUpperCase().equals(MERCHANT) && promoterMerchantUserTypeList.contains((UserType.get(Integer.valueOf(parentType))).name())) || (userCategory.toUpperCase().equals(RETAILER) && promoterRetailerUserTypeList.contains((UserType.get(Integer.valueOf(parentType))).name())))
				promoterUserMSTEntity.setParentType((UserType.get(Integer.valueOf(parentType))).name());
			else
			{
				remarks= PROMOTER_CATEGORY_NOT_MATCH_WITH_SUPERVISOR_USERTYPE;
				return remarks;
			}
		}

		logger.info("AsyncFileProcessor : validatePromoterUserParentType() | end");
		return remarks;
	}


	public String validatePromoterDobDoj(WhitelistedPromoter user, PromoterUserMSTEntity promoterUserMSTEntity) {

		logger.info("AsyncFileProcessor : validatePromoterDobDoj() | start");
		String remarks="";
		String dob = user.getDob();
		if(StringUtils.isEmpty(dob) && user.getUserType().equals(String.valueOf(UserType.PR.getCode())))
		{
			remarks = DOB_MANDATORY_FOR_PROMOTERS;
			return remarks;
		}

		if( !StringUtils.isEmpty(dob) && !ValidationUtil.validDateFormat(dob))
		{
			remarks = DOB_INVALID_DATE_FORMAT;
			return remarks;
		}
		if(!StringUtils.isEmpty(dob))
		{
			LocalDateTime dateOfBirth = commonUtils.convertDateToLocalDateTime(dob);
			promoterUserMSTEntity.setDob(dateOfBirth);
		}


		//Doj
		String doj = user.getDoj();
		if(!StringUtils.isEmpty(doj) && !ValidationUtil.validDateFormat(doj))
		{
			remarks = DOJ_INVALID_DATE_FORMAT;
			return remarks;
		}
		if(!StringUtils.isEmpty(doj)) {
			LocalDateTime dateOfJoining = commonUtils.convertDateToLocalDateTime(doj);
			promoterUserMSTEntity.setDoj(dateOfJoining);
		}
		logger.info("AsyncFileProcessor : validatePromoterDobDoj() | end");
		return remarks;
	}

	public String validateBasicPromoterDetails(WhitelistedPromoter user, PromoterUserMSTEntity promoterUserMSTEntity) {

		logger.info("AsyncFileProcessor : validateBasicPromoterDetails() | start");
		String remarks = "";

		String userNumber = user.getUserPhoneNumber();
		if(StringUtils.isEmpty(userNumber) ||( !StringUtils.isEmpty(userNumber) && !ValidationUtil.validatePhoneNumber(userNumber)))
		{
			remarks= USER_NUMBER_EMPTY_OR_INVALID;
			return remarks;

		}
		promoterUserMSTEntity.setUserNo(userNumber);


		String  userName = user.getUserName();
		if(StringUtils.isEmpty(userName) ||( !StringUtils.isEmpty(userName) && !ValidationUtil.validateName(userName)))
		{
			remarks = USER_NAME_EMPTY_OR_INVALID;
			return remarks;
		}
		promoterUserMSTEntity.setUsername(userName);


		String category = user.getCategory();
		if(StringUtils.isEmpty(category) ||( !StringUtils.isEmpty(category) && !promoterUserCategoryList.contains(category.toUpperCase())))
		{
			remarks = CATEGORY_EMPTY_OR_INVALID;
			return remarks;

		}
		promoterUserMSTEntity.setCategory(category.toUpperCase());

		String userType = user.getUserType();
		if(!StringUtils.isEmpty(userType) && null != UserType.get(Integer.valueOf(userType)))
		{
			if((category.toUpperCase().equals(MERCHANT) && promoterMerchantUserTypeList.contains((UserType.get(Integer.valueOf(userType))).name())) || (category.toUpperCase().equals(RETAILER) && promoterRetailerUserTypeList.contains((UserType.get(Integer.valueOf(userType))).name())))
				promoterUserMSTEntity.setUserType((UserType.get(Integer.valueOf(userType))).name());
			else
			{
				remarks= USERTYPE_NOT_BELONG_ENTERED_CATEGORY;
				return remarks;
			}
		}else
		{
			remarks = USERTYPE_EMPTY_OR_INVALID;
			return remarks;
		}


		//Agency
		String agency = user.getAgency();
		if(StringUtils.isEmpty(agency) && userType.equals(String.valueOf(UserType.PR.getCode())))
		{
			remarks = AGENCY_MANDATORY_FOR_PROMOTERS;
			return remarks;
		}
		promoterUserMSTEntity.setAgency(user.getAgency());


		//Emp id
		String empid = user.getEmpid();
		if(StringUtils.isEmpty(empid) && userType.equals(String.valueOf(UserType.PR.getCode())))
		{
			remarks = EMP_ID_MANDATORY_FOR_PROMOTERS;
			return remarks;
		}
		promoterUserMSTEntity.setEmployeeId(user.getEmpid());


		//Interviewer No
		String interviewerNo = user.getInterviewerNo();
		if(userType.equals(String.valueOf(UserType.PR.getCode())) && category.toUpperCase().equals(RETAILER))
		{
			if(StringUtils.isEmpty(interviewerNo))
			{
				remarks = INTERVIEWER_NO_MANDATORY_FOR_RETAILER_PROMOTERS;
				return remarks;
			}

			if(( !StringUtils.isEmpty(interviewerNo) && !ValidationUtil.validatePhoneNumber(interviewerNo)))
			{
				remarks= INTERVIEWER_NO_INVALID;
				return remarks;

			}
			promoterUserMSTEntity.setInterviewerNo(interviewerNo);
		}
		else
		{
			promoterUserMSTEntity.setInterviewerNo(interviewerNo);
		}

		//Interviewer Date
		String interviewDate = user.getInterviewDate();
		if(userType.equals(String.valueOf(UserType.PR.getCode())) && category.toUpperCase().equals(RETAILER))
		{
			if(StringUtils.isEmpty(interviewDate))
			{
				remarks = INTERVIEW_DATE_MANDATORY_FOR_RETAILER_PROMOTERS;
				return remarks;
			}

			if(!StringUtils.isEmpty(interviewDate) && !ValidationUtil.validDateFormat(interviewDate))
			{
				remarks = INTERVIEW_DATE_INVALID_DATE_FORMAT;
				return remarks;
			}
			else
			{
				LocalDateTime interviewDt = commonUtils.convertDateToLocalDateTime(interviewDate);
				promoterUserMSTEntity.setInterviewDate(interviewDt);
			}
		}
		else
		{
			LocalDateTime interviewDt = commonUtils.convertDateToLocalDateTime(interviewDate);
			promoterUserMSTEntity.setInterviewDate(interviewDt);
		}

		logger.info("AsyncFileProcessor : validateBasicPromoterDetails() | end");
		return remarks;

	}


	public WhitlelistedPromoterResponse populatePromoterUserResponseRecordWithExistingDetails(
			WhitelistedPromoter user) {
		logger.info("AsyncFileProcessor : populatePromoterUserResponseRecordWithExistingDetails() | start");
		WhitlelistedPromoterResponse whitlelistedPromoterResponse = new WhitlelistedPromoterResponse();
		whitlelistedPromoterResponse.setUserNumber(user.getUserPhoneNumber());
		whitlelistedPromoterResponse.setUserName(user.getUserName());
		whitlelistedPromoterResponse.setUserType(user.getUserType());
		whitlelistedPromoterResponse.setCategory(user.getCategory());

		whitlelistedPromoterResponse.setAgency(user.getAgency());
		whitlelistedPromoterResponse.setCircleId(user.getCircleId());
		whitlelistedPromoterResponse.setEmpid(user.getEmpid());

		whitlelistedPromoterResponse.setDob(user.getDob());
		whitlelistedPromoterResponse.setDoj(user.getDoj());


		whitlelistedPromoterResponse.setSupervisorNumber(user.getSupervisorNumber());
		whitlelistedPromoterResponse.setSupervisorType(user.getSupervisorType());

		whitlelistedPromoterResponse.setAction(user.getAction());
		whitlelistedPromoterResponse.setInterviewerNo(user.getInterviewerNo());
		whitlelistedPromoterResponse.setInterviewDate(user.getInterviewDate());
		logger.info("AsyncFileProcessor : populatePromoterUserResponseRecordWithExistingDetails() | end");
		return whitlelistedPromoterResponse;
	}


	@Transactional
	@Async
	public void updateFile(PromoterUploadFileAuditEntity file) {
		logger.info("AsyncFileProcessor : updateFile() | start");
		try {
			promoterUploadFileAuditDao.updateFile(file);}
		catch(Exception e) {
			logger.error("AsyncFileProcessor | updateFile() | Exception occured in updating file. Message {} Cause {} ",e.getMessage(),e.getCause());
		}
		logger.info("AsyncFileProcessor : updateFile() | end");
	}

	@Transactional
	public void updateFileInSync(PromoterUploadFileAuditEntity file) {
		logger.info("AsyncFileProcessor : updateFileInSync() | start");
		try {
			promoterUploadFileAuditDao.updateFile(file);}
		catch(Exception e) {
			logger.error("AsyncFileProcessor | updateFileInSync() | Exception occured in updating file. Message {} Cause {} ",e.getMessage(),e.getCause());
		}
		logger.info("AsyncFileProcessor : updateFileInSync() | end");
	}

}
