package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.AdminReportService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class AdminReportsController
{
	private static Logger logger = LoggerFactory.getLogger(AdminReportsController.class);

	@Autowired
	SnapWorkResponse response;

	@Autowired
    AdminReportService reportService;

	@Autowired
	PropertyManager prop;
	
	@Autowired
	CommonUtils commonUtil;

	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();

	@PostMapping(path="/v1/dashboard/market-visit")
	public ResponseEntity<Object> fetchDashboardMarketVisitDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Fetch MarketVisit Report Details, Request start timeInMillis {} :", startTime);
			logger.info("Fetch MarketVisit Report Details, Request params {} :", gson.toJson(request));
			String roleName = request.getRoleName()== null ? "" : request.getRoleName().trim();
			String categoryId = request.getCategoryId()== null ? "" : request.getCategoryId().trim();
			String circleId = request.getCircleId() == null ? "" : request.getCircleId().trim();
			String zoneId = request.getZoneId() == null ? "" : request.getZoneId().trim();
			String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
			String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

			if(StringUtils.isNotBlank(roleName) && StringUtils.isNotBlank(categoryId) && StringUtils.isNotBlank(circleId) 
					&& StringUtils.isNotBlank(zoneId) && StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate))
			{
				response = reportService.dashboardMarketVisitDetails(request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Fetch MarketVisit Report Details, response {} : ", gson.toJson(response));
			endTime = System.currentTimeMillis();
			logger.info("Fetch MarketVisit Report Details, Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("*************************************************************************************************************************************{} :" , "");
		}
		catch(Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(value = "/v1/dashboard/download-market")
	public ResponseEntity<Object> downloadMarketDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Download-Market Report Details, Request start timeInMillis {} :", startTime);
			logger.info("Download-Market Report Details, Request params {} :", gson.toJson(request));

			String roleName = request.getRoleName()== null ? "" : request.getRoleName().trim();
			String categoryId = request.getCategoryId()== null ? "" : request.getCategoryId().trim();
			String circleId = request.getCircleId() == null ? "" : request.getCircleId().trim();
			String zoneId = request.getZoneId() == null ? "" : request.getZoneId().trim();
			String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
			String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

			if(StringUtils.isNotBlank(roleName) && StringUtils.isNotBlank(categoryId) && StringUtils.isNotBlank(circleId)
					&& StringUtils.isNotBlank(zoneId) && StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate))
			{
				reportService.downloadMarketVisit(roleName, categoryId, circleId, zoneId, startDate, endDate);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Download-Market Report Details, response {} : ", gson.toJson(response));
			endTime = System.currentTimeMillis();
			logger.info("Download-Market Report Details, Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("*************************************************************************************************************************************{} :" , "");
		}
		catch(Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}


}