package com.airtelbank.admin.jwt;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.util.PropertyManager;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Aug 02, 2019 10:14:45 PM
 */
@Service
public class CommonJWTUtil
{
	private static Logger logger = LoggerFactory.getLogger(CommonJWTUtil.class);

	@Autowired
	PropertyManager prop;

	@Autowired
	JTIToken jtiToken;

	@Autowired
	JWTSigner signer;

	public String generateJwtToken(String mobileNo, int expiry, String appType)
	{
		String token = "";

		try
		{

			logger.info("Inside generateJwtToken() method in CommonJWTUtil class...");
			HashMap<String, Object> claims = new HashMap<String, Object>();

			claims.put("mobileno", mobileNo);
			claims.put("actorType", prop.getProperty("jwt.request.actorType"));
			claims.put("tokenExpTime", prop.getProperty("jwt.request.tokenExpTime"));
			if (appType.equalsIgnoreCase("mobile")) {
				claims.put("channel", prop.getProperty("jwt.request.app.channel"));
			} else {
				claims.put("channel", prop.getProperty("jwt.request.portal.channel"));
			}
			claims.put("userType", prop.getProperty("jwt.request.userType"));

			if (claims == null)
				return null;
			String signKey = prop.getProperty("JWT_SIGNER");
			String notValidtime = prop.getProperty("JWT_NOT_VALID");
			String issuedAt = prop.getProperty("JWT_ISSUED_AT");

			signer.getSignKeyBytes(signKey);

			String jitToken = UUID.randomUUID().toString();
			claims.put("jti", jitToken);
			String customerId = (String) claims.get("mobileno");
			String channel = (String) claims.get("channel");
			String tokenTime = (String) claims.get("tokenExpTime") == "" ? "300000"
					: (String) claims.get("tokenExpTime");

			int expiryTimeInt = Integer.parseInt(tokenTime);
			/*
			 * token = signer.sign(claims, new
			 * JWTSigner.Options().setExpirySeconds(expiryTimeInt)
			 * .setNotValidBeforeLeeway(Integer.parseInt(notValidtime))
			 * .setIssuedAt(Boolean.parseBoolean(issuedAt)).setJwtId(false));
			 */
			
			 token = signer.sign(claims, new JWTSigner.Options().setExpirySeconds(expiryTimeInt).setNotValidBeforeLeeway(Integer.parseInt(notValidtime)).setIssuedAt(Boolean.parseBoolean(issuedAt))
					.setJwtId(false), prop);

			logger.info("customerId :" + customerId);
			logger.info("channel    :" + channel);
			logger.info("jitToken   :" + jitToken);
			logger.info("expiry     :" + expiry);

			if (!prop.getProperty("jwt.request.aeroapike.flag").equalsIgnoreCase("N")) {
				boolean generateFlag = jtiToken.add(customerId, channel, jitToken, expiry);
				if (generateFlag) {
					logger.info("token  :" + token);
					System.out.println("token  :" + token);
				} else {
					token = "";
					logger.info(String.format("Failed to add JTI token : customerId=%s, channel=%s, jitToken=%s",
							customerId, channel, jitToken));
				}
			} else {
				logger.info("SIT, jwt token  :" + token);
			}
		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		}
		return token;
	}

	public static <T> List<String> getDeclcaredFieldNames(Class<T> typeClass) {
		Field[] declaredFields = typeClass.getDeclaredFields();
		List<String> bins = new ArrayList<String>();
		for (int i = 0; i < declaredFields.length; i++) {
			if (!Modifier.isStatic(declaredFields[i].getModifiers()))
				bins.add(declaredFields[i].getName());
		}
		return bins;
	}

	public JSONObject verifyToken(String token) {
		JSONObject payload = signer.getPayloadDatafromToken(token);
		return payload;
	}

	/**
	 * validate token
	 * @param token
	 * @param email
	 * @return true if token is valid otherwise false
	 */
	public boolean validateToken(String customerId, String channel, String jitToken) {
		return jtiToken.isActive(customerId, channel, jitToken);
	}

}
