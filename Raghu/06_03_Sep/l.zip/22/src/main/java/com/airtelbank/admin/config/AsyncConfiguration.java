package com.airtelbank.admin.config;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class AsyncConfiguration {
	
	@Value("${outlet.core.pool.size}")
	private int corePoolSizeOutlet;

	@Value("${outlet.max.pool.size}")
	private int maxPoolSizeOutlet;

	@Value("${outlet.queue.capacity}")
	private int queueCapacityOutlet;
	
	@Value("${promoter.core.pool.size}")
	private int corePoolSizePromoter;

	@Value("${promoter.max.pool.size}")
	private int maxPoolSizePromoter;

	@Value("${promoter.queue.capacity}")
	private int queueCapacityPromoter;
	

	    @Bean(name = "asyncOutletExecutor")
	    public Executor asyncOutletExecutor() 

	    {
	        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	        executor.setCorePoolSize(corePoolSizeOutlet);
	        executor.setMaxPoolSize(maxPoolSizeOutlet);
	        executor.setQueueCapacity(queueCapacityOutlet);
	        executor.setThreadNamePrefix("AsynchOutletThread-");
	        executor.initialize();
	        return executor;
	    }
	    
	    @Bean(name = "asyncPromoterUserExecutor")
	    public Executor asyncPromoterUserExecutor() 
	    {
	        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	        executor.setCorePoolSize(corePoolSizePromoter);
	        executor.setMaxPoolSize(maxPoolSizePromoter);
	        executor.setQueueCapacity(queueCapacityPromoter);
	        executor.setThreadNamePrefix("AsynchPromoterUserThread-");
	        executor.initialize();
	        return executor;
	    }
	

}
