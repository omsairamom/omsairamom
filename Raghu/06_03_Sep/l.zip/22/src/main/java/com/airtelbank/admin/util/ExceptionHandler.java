package com.airtelbank.admin.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class ExceptionHandler {

	@Autowired
	PropertyManager prop;

	private static Logger logger = LoggerFactory.getLogger(ExceptionHandler.class);

	@org.springframework.web.bind.annotation.ExceptionHandler
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	Map<String, String> showCustomMessage(Exception e)
	{
		Map<String, String> response = new HashMap<>();
		response.put("statusCode", prop.getProperty("BAD_REQUEST"));
		response.put("message", prop.getProperty("INVALID_INPUT"));

		logger.error("ExceptionHandler{} :" + e.getMessage());
		return response;
	}
	
//	
//	@ResponseBody
//	@org.springframework.web.bind.annotation.ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
//	public String handleHttpMediaTypeNotAcceptableException() {
//	    return "acceptable MIME type:" + MediaType.APPLICATION_JSON_VALUE;
//	}
}