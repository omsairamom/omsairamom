package com.airtelbank.admin.dao;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class PromoterDetailsReportDAO {
    private static Logger logger = LoggerFactory.getLogger(PromoterDetailsReportDAO.class);

    @Autowired
    JdbcTemplate jdbctemplate;

    @Autowired
    PropertyManager prop;

    @Autowired
    SnapWorkResponse response;


    public List<Map<String, Object>> getPromoterDtls(String lapuNo) throws Exception {

        logger.info("Inside getPromoterDtls() method in PromoterDetailsReportDAO class.. {}:", "");

        List<Map<String, Object>> rows = null;
        String query = "";
        try {
            query = prop.getProperty(Constants.GET_PROMOTER_DETAILS);
            rows = jdbctemplate.queryForList(query, lapuNo);

        } catch (Exception e) {
            CommonException.printStackTraceForDAO(e);
        }
        return rows;
    }

    public List<Map<String, Object>> getOutletDtls(String lapuNo) throws Exception {
        logger.info("Inside getOutletDtls() method in PromoterDetailsReportDAO class.. {}:", "");

        List<Map<String, Object>> rows = null;
        String query = "";
        try {
            query = prop.getProperty(Constants.GET_OUTLET_DETAILS);
            rows = jdbctemplate.queryForList(query, lapuNo);
        } catch (Exception e) {
            CommonException.printStackTraceForDAO(e);
        }
        return rows;
    }


    public List<Map<String, Object>> getOutletDtl(String lapuNo) throws Exception {
        logger.info("Inside getOutletDtls() method in PromoterDetailsReportDAO class.. {}:", "");
        List<Map<String, Object>> rows = null;
        String query = "";
        try {
            query = prop.getProperty(Constants.GET_OUTLET_DETAIL);
            rows = jdbctemplate.queryForList(query, lapuNo);
        } catch (Exception e) {
            CommonException.printStackTraceForDAO(e);
        }
        return rows;
    }

    public List<Map<String, Object>> getMappedPromotersList(String lapuNo) throws Exception {
        logger.info("Inside getMappedPromotersList() method in PromoterDetailsReportDAO class.. {}:", "");
        List<Map<String, Object>> rows = null;
        String query = "";
        try {
            query = prop.getProperty(Constants.GET_MAPPEDPROMOTERS_LIST);
            rows = jdbctemplate.queryForList(query, lapuNo);
        } catch (Exception e) {
            CommonException.printStackTraceForDAO(e);
        }
        return rows;
    }

}
