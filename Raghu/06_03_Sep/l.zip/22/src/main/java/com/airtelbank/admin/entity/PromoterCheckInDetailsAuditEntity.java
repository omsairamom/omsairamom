package com.airtelbank.admin.entity;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import javax.persistence.Index;
@Entity
@Table(name = "PROMOTER_CHECKIN_DETAILS_AUDIT",indexes = 
{
		@Index(name = "IndexPromoterID",  columnList="promoter_id"),
		@Index(name = "IndexOutletID", columnList = "outlet_id"),
		@Index(name = "IndexCircleId", columnList = "circle_id")
})
@EntityListeners(AuditingEntityListener.class)
public class PromoterCheckInDetailsAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "promoter_id", nullable = false, referencedColumnName = "id")
    @NotNull
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    @NotNull
    private String promoterNo;

    @Column
    @NotNull
    private String outletNo;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "outlet_id", nullable = false, referencedColumnName = "id")
    @NotNull
    private PromoterOutletMSTEntity promoterOutletMSTEntity;

    @Column
    @NotNull
    private String checkInType;

    @Column
    private String outletLatitude;

    @Column
    private String outletLongitude;

    @Column
    private String promoterLatitude;

    @Column
    private String promoterLongitude;

    @Column
    private String marryDistance;

    @Column
    private String status;

    @ManyToOne
    @JoinColumn(name = "circle_id", referencedColumnName = "id")
    private PromoterCircleMSTEntity promoterCircleMSTEntity;

    @Column
    @CreatedDate
    private LocalDateTime createdDate;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDate;
    
    @Column
    private String custom_field1;
    
    @Column
    private String custom_field2;
    
    @Column
    private String custom_field3;
    
    @Column
    private String custom_field4;
    
    @Column
    private String custom_field5;
}
