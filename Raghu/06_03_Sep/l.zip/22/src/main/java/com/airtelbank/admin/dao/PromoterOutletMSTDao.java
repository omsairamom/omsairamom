package com.airtelbank.admin.dao;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.entity.PromoterOutletMSTEntity;
import com.airtelbank.admin.repository.PromoterOutletMSTRepository;

@Service
public class PromoterOutletMSTDao {
	
	@Autowired
	private PromoterOutletMSTRepository promoterOutletMSTRepository;
	

	public PromoterOutletMSTEntity fetchOutletByOutletPhoneNumberAndType(String outletPhoneNumber,String outletType)
	{
		return promoterOutletMSTRepository.findOneByOutletNoAndOutletType(outletPhoneNumber,outletType);
	}


	public void saveInDB(PromoterOutletMSTEntity promoterOutletMSTEntity) {
		
		promoterOutletMSTRepository.save(promoterOutletMSTEntity);
		
	}
	
	public void saveAllInDB(List<PromoterOutletMSTEntity> promoterOutletMSTEntityList) {
		
		promoterOutletMSTRepository.saveAll(promoterOutletMSTEntityList);
	}
	
	


}
