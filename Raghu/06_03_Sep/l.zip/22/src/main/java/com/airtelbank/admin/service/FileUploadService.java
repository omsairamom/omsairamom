package com.airtelbank.admin.service;

import java.io.IOException;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.CustomException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 19, 2019 12:34:45 PM
 */

public interface FileUploadService
{
	SnapWorkResponse retailerUploadDetails(MultipartFile file) throws CustomException;

	SnapWorkResponse kpiUploadDetailsv2(MultipartFile file) throws CustomException;

	SnapWorkResponse uploadPromoterCSVDetails(MultipartFile file, String type, String mobileNo) throws CustomException, IOException;

	SnapWorkResponse enquirePromoterCSVDetails(String fileName) throws IOException;

	Resource downloadPromoterCSVDetails(String fileName) throws Exception;
}
