package com.airtelbank.admin.util;

import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.util.SimpleByteSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.airtelbank.admin.common.CommonException;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date June 07, 2019 04:02:45 PM
 */
public class EncryptionUtil
{
	private static Logger logger = LoggerFactory.getLogger(EncryptionUtil.class);
	
	public static String generateEncryptPassword(String password,String SALTKEY)
	{
		String encryptedpin = "";
		
		try {
			logger.info("Inside generateEncryptPassword() method in EncryptionUtil class...");
			Sha256Hash sha256Hash = new Sha256Hash((String)password, (new SimpleByteSource(SALTKEY)).getBytes());
			encryptedpin = sha256Hash.toHex();
			logger.info("MPIN Encryption :"+encryptedpin);
			
		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
			encryptedpin=password;
		}
		return encryptedpin;
	}
}
