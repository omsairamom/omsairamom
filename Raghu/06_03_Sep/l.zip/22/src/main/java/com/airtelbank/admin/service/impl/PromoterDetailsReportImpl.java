package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.PromoterDetailsReportDAO;
import com.airtelbank.admin.service.PromoterDetailsReport;
import com.airtelbank.admin.util.*;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class PromoterDetailsReportImpl implements PromoterDetailsReport {

    private static final Logger logger = LoggerFactory.getLogger(PromoterDetailsReportImpl.class);

    @Autowired
    PropertyManager prop;

    @Autowired
    PromoterDetailsReportDAO adminReportDAO;

    @Autowired
    SnapWorkResponse response;

    @Autowired
    SnapWorkRequest request;

    @Autowired
    CommonUtils commonUtil;

    private String[] CSV_HEADER;

    @Autowired
    SecureBuilderVer secureBuilderVer;

    public SnapWorkResponse getPromoterDtls(SnapWorkRequest snapWorkRequest) throws CustomException {
        String mobileNo = snapWorkRequest.getMobileNo();
        JSONObject json = new JSONObject();

        try {
            if (StringUtils.isNotBlank(mobileNo)) {

                List<Map<String, Object>> rows = adminReportDAO.getPromoterDtls(mobileNo);
                if (rows != null && !rows.isEmpty()) {
                    logger.info("getPromoterDtls rows: {}:", rows.size());
                    JSONObject promoterObj = new JSONObject();
                    for (Map<String, Object> row : rows) {
                        promoterObj.put("LAPU_NO", row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString());
                        promoterObj.put("NAME", row.get("NAME") == null ? "" : row.get("NAME").toString());
                        promoterObj.put("AGENCY", row.get("AGENCY") == null ? "" : row.get("AGENCY").toString());
                        promoterObj.put("EMPLOYEE_ID", row.get("EMPLOYEE_ID") == null ? "" : row.get("EMPLOYEE_ID").toString());
                        promoterObj.put("DOB", row.get("DOB") == null ? "" : row.get("DOB").toString());
                        promoterObj.put("DOJ", row.get("DOJ") == null ? "" : row.get("DOJ").toString());
                        promoterObj.put("USER_TYPE", row.get("USER_TYPE") == null ? "" : row.get("USER_TYPE").toString());
                    }

                    json.put("promoterDetails", promoterObj);
                }


                List<Map<String, Object>> rows1 = adminReportDAO.getOutletDtls(mobileNo);
                if (rows1 != null && !rows1.isEmpty()) {
                    logger.info("getOutletDtls rows: {}:", rows1.size());
                    JSONArray outletList = new JSONArray();
                    for (Map<String, Object> row : rows1) {
                        JSONObject outletDetail = new JSONObject();
                        outletDetail.put("LAPU_NO", row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString());
                        outletDetail.put("RT_NAME", row.get("RT_NAME") == null ? "" : row.get("RT_NAME").toString());
                        outletDetail.put("LATITUDE", row.get("LATITUDE") == null ? "" : row.get("LATITUDE").toString());
                        outletDetail.put("LONGITUDE", row.get("LONGITUDE") == null ? "" : row.get("LONGITUDE").toString());
                        outletDetail.put("VILLAGE_NAME", row.get("VILLAGE_NAME") == null ? "" : row.get("VILLAGE_NAME").toString());
                        outletDetail.put("VILLAGE_TYPE", row.get("VILLAGE_TYPE") == null ? "" : row.get("VILLAGE_TYPE").toString());
                        outletDetail.put("VILLAGE_POP", row.get("VILLAGE_POP") == null ? "" : row.get("VILLAGE_POP").toString());
                        outletDetail.put("CITY", row.get("CITY") == null ? "" : row.get("CITY").toString());
                        outletDetail.put("BLOCK_TEHSIL", row.get("BLOCK_TEHSIL") == null ? "" : row.get("BLOCK_TEHSIL").toString());
                        outletDetail.put("DISTRICT", row.get("DISTRICT") == null ? "" : row.get("DISTRICT").toString());
                        outletDetail.put("SITE_ID", row.get("SITE_ID") == null ? "" : row.get("SITE_ID").toString());
                        outletDetail.put("CATEGORY", row.get("CATEGORY") == null ? "" : row.get("CATEGORY").toString());
                        outletDetail.put("OUTLET_TYPE", row.get("OUTLET_TYPE") == null ? "" : row.get("OUTLET_TYPE").toString());

                        outletList.add(outletDetail);
                    }

                    json.put("outletDetails", outletList);
                }
                response.setMessage(prop.getProperty(Constants.OUTLET_DETAILS_SUCC_MGS));
                response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                response.setResponse(json);

            } else {
                logger.error("getPromoterDtls() mobile No is blank {}:", "");
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

        } catch (Exception exe) {
            logger.error("getPromoterDtls() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            return response;
        }
        return response;
    }

    @Override
    public SnapWorkResponse getOutletDtls(SnapWorkRequest snapWorkRequest) throws CustomException {
        String mobileNo = snapWorkRequest.getMobileNo();
        JSONObject json = new JSONObject();

        try {
            if (StringUtils.isNotBlank(mobileNo)) {

                List<Map<String, Object>> rows = adminReportDAO.getOutletDtl(mobileNo);
                if (rows != null && !rows.isEmpty()) {
                    logger.info("getPromoterDtls rows: {}:", rows.size());
                    JSONObject outletDetail = new JSONObject();
                    for (Map<String, Object> row : rows) {
                        outletDetail.put("LAPU_NO", row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString());
                        outletDetail.put("RT_NAME", row.get("RT_NAME") == null ? "" : row.get("RT_NAME").toString());
                        outletDetail.put("LATITUDE", row.get("LATITUDE") == null ? "" : row.get("LATITUDE").toString());
                        outletDetail.put("LONGITUDE", row.get("LONGITUDE") == null ? "" : row.get("LONGITUDE").toString());
                        outletDetail.put("VILLAGE_NAME", row.get("VILLAGE_NAME") == null ? "" : row.get("VILLAGE_NAME").toString());
                        outletDetail.put("VILLAGE_TYPE", row.get("VILLAGE_TYPE") == null ? "" : row.get("VILLAGE_TYPE").toString());
                        outletDetail.put("VILLAGE_POP", row.get("VILLAGE_POP") == null ? "" : row.get("VILLAGE_POP").toString());
                        outletDetail.put("CITY", row.get("CITY") == null ? "" : row.get("CITY").toString());
                        outletDetail.put("BLOCK_TEHSIL", row.get("BLOCK_TEHSIL") == null ? "" : row.get("BLOCK_TEHSIL").toString());
                        outletDetail.put("DISTRICT", row.get("DISTRICT") == null ? "" : row.get("DISTRICT").toString());
                        outletDetail.put("SITE_ID", row.get("SITE_ID") == null ? "" : row.get("SITE_ID").toString());
                        outletDetail.put("CATEGORY", row.get("CATEGORY") == null ? "" : row.get("CATEGORY").toString());
                        outletDetail.put("OUTLET_TYPE", row.get("OUTLET_TYPE") == null ? "" : row.get("OUTLET_TYPE").toString());

                    }

                    json.put("OutletDetails", outletDetail);
                }


                List<Map<String, Object>> rows1 = adminReportDAO.getMappedPromotersList(mobileNo);
                if (rows1 != null && !rows1.isEmpty()) {
                    logger.info("getOutletDtls rows: {}:", rows1.size());
                    JSONArray outletList = new JSONArray();
                    for (Map<String, Object> row : rows1) {
                        JSONObject promoterObj = new JSONObject();
                        promoterObj.put("LAPU_NO", row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString());
                        promoterObj.put("NAME", row.get("NAME") == null ? "" : row.get("NAME").toString());
                        promoterObj.put("AGENCY", row.get("AGENCY") == null ? "" : row.get("AGENCY").toString());
                        promoterObj.put("EMPLOYEE_ID", row.get("EMPLOYEE_ID") == null ? "" : row.get("EMPLOYEE_ID").toString());
                        promoterObj.put("DOB", row.get("DOB") == null ? "" : row.get("DOB").toString());
                        promoterObj.put("DOJ", row.get("DOJ") == null ? "" : row.get("DOJ").toString());
                        promoterObj.put("USER_TYPE", row.get("USER_TYPE") == null ? "" : row.get("USER_TYPE").toString());

                        outletList.add(promoterObj);
                    }

                    json.put("Promoters", outletList);
                }
                response.setMessage(prop.getProperty(Constants.PROMOTERS_DETAILS_SUCC_MGS));
                response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                response.setResponse(json);

            } else {
                logger.error("getPromoterDtls() mobile No is blank {}:", "");
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

        } catch (Exception exe) {
            logger.error("getPromoterDtls() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            return response;
        }

        return response;
    }

    @Override
    public SnapWorkResponse downloadOutletDtls(String lapuNo) throws CustomException {

        JSONObject json = new JSONObject();
        StringBuilder data = new StringBuilder();

        try {
            logger.info("Inside downloadOutletDtls() method in AdminReportServiceImpl class.. {}:", "");

            CSV_HEADER = new String[]{"LAPU_NO", "RT_NAME", "LATITUDE", "LONGITUDE", "VILLAGE_NAME", "VILLAGE_TYPE",
                    "VILLAGE_POP", "CITY", "BLOCK_TEHSIL", "DISTRICT", "SITE_ID", "CATEGORY", "OUTLET_TYPE"};

            for (int i = 0; i < CSV_HEADER.length; i++) {
                 data = data.append(CSV_HEADER[i]);

                if (CSV_HEADER.length - 1 == i) {
                    data = data.append("\n");
                } else {
                    data = data.append(",");
                }
            }


            List<Map<String, Object>> rows = adminReportDAO.getOutletDtls(lapuNo);
            logger.info("getPromoterDtls rows: {}:", rows.size());

            if (rows == null && rows.isEmpty()) {
                logger.info("getPromoterDtls if: {}:", rows.size());
                 data = data.append("");
                json.put("data", data);
            } else {
                logger.info("getPromoterDtls else: {}:", rows.size());
                for (Map<String, Object> row : rows) {
                    String LAPU_NO = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
                    String RT_NAME = row.get("RT_NAME") == null ? "" : row.get("RT_NAME").toString();
                    String LATITUDE = row.get("LATITUDE") == null ? "" : row.get("LATITUDE").toString();
                    String LONGITUDE = row.get("LONGITUDE") == null ? "" : row.get("LONGITUDE").toString();
                    String VILLAGE_NAME = row.get("VILLAGE_NAME") == null ? "" : row.get("VILLAGE_NAME").toString();
                    String VILLAGE_TYPE = row.get("VILLAGE_TYPE") == null ? "" : row.get("VILLAGE_TYPE").toString();
                    String VILLAGE_POP = row.get("VILLAGE_POP") == null ? "" : row.get("VILLAGE_POP").toString();
                    String CITY = row.get("CITY") == null ? "" : row.get("CITY").toString();
                    String BLOCK_TEHSIL = row.get("BLOCK_TEHSIL") == null ? "" : row.get("BLOCK_TEHSIL").toString();
                    String DISTRICT = row.get("DISTRICT") == null ? "" : row.get("DISTRICT").toString();
                    String SITE_ID = row.get("SITE_ID") == null ? "" : row.get("SITE_ID").toString();
                    String CATEGORY = row.get("CATEGORY") == null ? "" : row.get("CATEGORY").toString();
                    String OUTLET_TYPE = row.get("OUTLET_TYPE") == null ? "" : row.get("OUTLET_TYPE").toString();

                    data = data.append(LAPU_NO).append(",");
                    data = data.append(RT_NAME).append(",");
                    data = data.append(LATITUDE).append(",");
                    data = data.append(LONGITUDE).append(",");
                    data = data.append(VILLAGE_NAME).append(",");
                    data = data.append(VILLAGE_TYPE).append(",");
                    data = data.append(VILLAGE_POP).append(",");
                    data = data.append(CITY).append(",");
                    data = data.append(BLOCK_TEHSIL).append(",");
                    data = data.append(DISTRICT).append(",");
                    data = data.append(SITE_ID).append(",");
                    data = data.append(CATEGORY).append(",");
                    data = data.append(OUTLET_TYPE).append("\n");

                }

                json.put("data", data);
            }
            logger.info("getOutletDtl.size() {}:", rows.size());


            response.setMessage("Download Outlet details fetched successfully");
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
            response.setResponse(json);
            logger.info("Success Response generated {}:", "");
        } catch (Exception exe) {
            logger.error("downloadOutletDtls() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }
        logger.info("downloadOutletDtls() Response generated {}:", "");
        return response;
    }

    @Override
    public SnapWorkResponse downloadPromoterDtls(String lapuNo) throws CustomException {

        JSONObject json = new JSONObject();
        StringBuilder data = new StringBuilder();

        try {
            logger.info("Inside downloadPromoterDtls() method in AdminReportServiceImpl class.. {}:", "");

            CSV_HEADER = new String[]{"LAPU_NO", "NAME", "AGENCY", "EMPLOYEE_ID", "DOB", "DOJ",
                    "USER_TYPE"};

            for (int i = 0; i < CSV_HEADER.length; i++) {
                 data = data.append(CSV_HEADER[i]);

                if (CSV_HEADER.length - 1 == i) {
                    data = data.append("\n");
                } else {
                    data = data.append(",");
                }
            }

            List<Map<String, Object>> rows = adminReportDAO.getMappedPromotersList(lapuNo);
            if (rows == null && rows.isEmpty()) {
                 data = data.append("");
                json.put("data", data);
            } else {
                logger.info("getPromoterDtls rows: {}:", rows.size());
                for (Map<String, Object> row : rows) {
                    String LAPU_NO = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
                    String RT_NAME = row.get("NAME") == null ? "" : row.get("NAME").toString();
                    String AGENCY = row.get("AGENCY") == null ? "" : row.get("AGENCY").toString();
                    String EMPLOYEE_ID = row.get("EMPLOYEE_ID") == null ? "" : row.get("EMPLOYEE_ID").toString();
                    String DOB = row.get("DOB") == null ? "" : row.get("DOB").toString();
                    String DOJ = row.get("DOJ") == null ? "" : row.get("DOJ").toString();
                    String USER_TYPE = row.get("USER_TYPE") == null ? "" : row.get("USER_TYPE").toString();

                    if (!DOB.isEmpty() && DOB != null)
                        DOB = convertDateFormat(DOB);
                    if (!DOB.isEmpty() && DOB != null)
                        DOJ = convertDateFormat(DOJ);

                    data = data.append(LAPU_NO).append(",");
                    data = data.append(RT_NAME).append(",");
                    data = data.append(AGENCY).append(",");
                    data = data.append(EMPLOYEE_ID).append(",");
                    data = data.append(DOB).append(",");
                    data = data.append(DOJ).append(",");
                    data = data.append(USER_TYPE).append("\n");

                }

                json.put("data", data);
            }
            logger.info("getPromoterDtl.size() {}:", rows.size());


            response.setMessage("Download Promoter details fetched successfully");
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
            response.setResponse(json);
            logger.info("Success Response generated {}:", "");
        } catch (Exception exe) {
            logger.error("downloadPromoterDtls() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }
        logger.info("downloadPromoterDtls() Response generated {}:", "");
        return response;
    }

    private String convertDateFormat(String inputString) throws ParseException {
        DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        Date date = inputFormat.parse(inputString);

        DateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
        String outputString = outputFormat.format(date);
        return outputString;
    }
}
