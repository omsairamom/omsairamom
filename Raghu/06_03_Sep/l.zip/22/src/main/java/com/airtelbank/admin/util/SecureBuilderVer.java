package com.airtelbank.admin.util;

import com.airtelbank.admin.common.CommonException;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.spec.AlgorithmParameterSpec;

@Component
public class SecureBuilderVer
{
	private static Logger logger = LoggerFactory.getLogger(SecureBuilderVer.class);

	public String decrypt(String encrandomKey,
								 String value,
								 String salt,
								 String ostype) throws Exception
	{
		String decString="";
		
		try
		{
			logger.info("Inside of decrypt() method SecureBuilderVer Class " );
			String Key = generateEncKey(salt, encrandomKey, ostype);
			logger.info("Key :"+Key);
			SecretKey key = new SecretKeySpec(Base64.decodeBase64(Key), "AES");
			logger.info("Key at line no 60 {}:" , Key);
			AlgorithmParameterSpec iv = new IvParameterSpec(Base64.decodeBase64(Key));
			byte[] decodeBase64 = Base64.decodeBase64(value);
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, key, iv);
			decString= new String(cipher.doFinal(decodeBase64), "UTF-8");

			logger.info("decString :"+decString);
		}
		catch (Exception exe)
		{
			CommonException.getPrintStackTrace(exe);
		}
		return decString;
	}

	public static String generateEncKey(String input, String randomsaltkey, String osType)
	{
		String enckey = "";
		try
		{
			randomsaltkey = decryptRamdomKey(randomsaltkey);
			logger.info("randomsaltkey :"+randomsaltkey);
			String keypartcert = getKeyGenerationString(randomsaltkey);
			logger.info("keypartcert :"+keypartcert);
			input = keypartcert + "|" + input;
			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(randomsaltkey.getBytes(), "HmacSHA256");		
			sha256_HMAC.init(secret_key);
			enckey = Base64.encodeBase64String(sha256_HMAC.doFinal(input.getBytes()));			
			enckey = enckey.substring(0, 4) + enckey.substring(8, 12)+ enckey.substring(16, 20) + enckey.substring(24, 28);
			enckey = Base64.encodeBase64String(enckey.getBytes());
			logger.info("enckey :"+enckey);
		}
		catch (Exception exe)
		{
			CommonException.getPrintStackTrace(exe);
		}
		return enckey;
	}

	public static String getKeyGenerationString(String randomsaltkey) {

		String certthumb = "7e2f8b054a76b935c33d980023b5ffc6616e0b0b";
		String keystr = "";
		try {
			int firstdigit = Integer.parseInt(randomsaltkey.substring(0, 1));
			int seconfdigit = Integer.parseInt(randomsaltkey.substring(1, 2));
			keystr = certthumb.substring(firstdigit, firstdigit + seconfdigit);
		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		}
		return keystr;
	}

	public static String decryptRamdomKey(String value) throws Exception {
		String res = "";
		try {
			String Key = "NWJiMDQxMWIxOGI0YTkwZQ==";
			SecretKey key = new SecretKeySpec(Base64.decodeBase64(Key), "AES");
			AlgorithmParameterSpec iv = new IvParameterSpec(
					Base64.decodeBase64(Key));
			byte[] decodeBase64 = Base64.decodeBase64(value);
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, key, iv);
			res = new String(cipher.doFinal(decodeBase64), "UTF-8");

		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		} finally {

		}
		return res;
	}
}