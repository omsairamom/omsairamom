package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.KpiConfigurationDAO;
import com.airtelbank.admin.service.KpiConfigurationService;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.CustomException;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class KpiConfigurationServiceImpl implements KpiConfigurationService {

	private static Logger logger = LoggerFactory.getLogger(KpiConfigurationServiceImpl.class);

	@Autowired
	PropertyManager prop;

	@Autowired
	KpiConfigurationDAO kpiConfigDao;

	@Autowired
	SnapWorkResponse response;

	@Autowired
	SnapWorkRequest request;

	@SuppressWarnings("unchecked")
	@Override
	public SnapWorkResponse kpiConfigurationDtls(SnapWorkRequest request) throws CustomException
	{

		JSONObject json = new JSONObject();
		int count = 0;

		try
		{
			logger.info("Inside kpiConfigurationDtls() method in KpiConfigurationServiceImpl classs... {}:" ,"");

			if (request == null)
			{
				throw new Exception("request can't be null");
			}

			String categoryName = request.getCategoryName() == null ? "" : request.getCategoryName().trim();
			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
			String action = request.getAction() == null ? "" : request.getAction().trim();
			String weightAge = request.getWeightAge() == null ? "" : request.getWeightAge().trim();
			String statusEnable = request.getStatusEnable() == null ? "" : request.getStatusEnable().trim();
			String startDate = kpiConfigDao.getStartDate();
			String endDate = kpiConfigDao.getEndDate();
			String reqTarget = request.getTarget() == null ? "" : request.getTarget().trim();
			String kpiId = request.getKpiId() == null ? "" : request.getKpiId().trim();

			logger.info("categoryName  {}:" , categoryName);
			logger.info("mobileNo  {}:" , mobileNo);
			logger.info("action  {}:" , action);
			logger.info("weightAge  {}:" , weightAge);
			logger.info("statusEnable {}:" , statusEnable);
			logger.info("startDate  {}:" , startDate);
			logger.info("endDate  {}:" , endDate);
			logger.info("reqTarget {}:" , reqTarget);
			logger.info("kpiId {}:" , kpiId);

			int totalWeightAge = kpiConfigDao.getWeightageSum(categoryName);
			logger.info("KPI_CONFIG_WEIGHT_AGE_SUM totalWeightAge  {}:" , totalWeightAge);
			int requestWeightAge = Integer.parseInt(weightAge);
			totalWeightAge = totalWeightAge + requestWeightAge;
			logger.info("KPI_CONFIG_WEIGHT_AGE_SUM totalWeightAge  {}:" , totalWeightAge);

			if (totalWeightAge <= 100 && action.equalsIgnoreCase("add"))
			{
				count = kpiConfigDao.saveKpiConfigDtls(request, convertDate(startDate), convertDate(endDate));
				logger.info("KPI_CONFIG_SAVE_DETAILS_MST count {}:"  ,count);

				if (count > 0)
				{
					json.put(Constants.mobileNo, mobileNo);
					response.setMessage(prop.getProperty(Constants.KPI_CONFIG_SAVE_DTLS_SUCC_MSG));
					response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
					response.setResponse(json);
				}
				else
				{
					response.setMessage(prop.getProperty(Constants.KPI_CONFIG_SAVE_DTLS_FAIL_MSG));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
				}

			}
			else if (action.equalsIgnoreCase("update"))
			{

				count = kpiConfigDao.updateKpiConfigDtls(request);

				String dbTarget = kpiConfigDao.getKpiTargetDtlsFromDb(request);
				int dbWeightAge = kpiConfigDao.getUpdatedWeightageSum(kpiId, categoryName);

				int updatedWeightAge = dbWeightAge + Integer.parseInt(weightAge);

				logger.info("KPI_CONFIG_TARGET_DETAILS dbTarget {}:" , dbTarget);
				logger.info("KPI_CONFIG_WEIGHT_AGE_SUM2 dbWeightAge {}:" , dbWeightAge);
				logger.info("updatedWeightAge {}:" , updatedWeightAge);

				if (count > 0)
				{
					if (statusEnable.equals("N") || updatedWeightAge < 100 || !reqTarget.equals(dbTarget))
					{
						json.put(Constants.mobileNo, mobileNo);
						response.setMessage(prop.getProperty(Constants.KPI_CONFIG_LESS_WEIGHT_AGE_SUCC_MSG));
						response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
						response.setResponse(json);
					}
					else
					{
						json.put(Constants.mobileNo, mobileNo);
						response.setMessage(prop.getProperty(Constants.KPI_CONFIG_UPDATE_DTLS_SUCC_MSG));
						response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
						response.setResponse(json);
					}
				}
				else
				{
					logger.error("onLoadAppVersionDetails() count is less or equal to zero {}:" , "");
					response.setMessage(prop.getProperty(Constants.KPI_CONFIG_WEIGHT_AGE_FAIL_MSG));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
					response.setResponse(json);
				}
			}

			if (count == 0 && totalWeightAge > 100)
			{
				response.setMessage(prop.getProperty(Constants.KPI_CONFIG_WEIGHT_AGE_FAIL_MSG));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("kpiConfigurationDtls() Response generated {}:" , "");
			return response;
		}
		catch (Exception exe)
		{
			logger.info("kpiConfigurationDtls() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
			return response;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public SnapWorkResponse fetchKpiConfigurationOnloadDtls(SnapWorkRequest request) throws CustomException
	{
		JSONObject json = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		List<Map<String, Object>> rows = null;

		try
		{
			logger.info("Inside fetchKpiConfigurationOnloadDtls() method in KpiConfigurationServiceImpl classs... {}:" , "");
			String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();
			logger.info("mobileNo  {}:" , mobileNo);

			if (StringUtils.isNotBlank(mobileNo))
			{

				rows = kpiConfigDao.fetchKpiConfigDtls();
				logger.info("KPI_CONFIG_CHECK_DTLS_EXIST rows {}:"  ,rows.size());

				if (rows != null && !rows.isEmpty())
				{
					for (Map<String, Object> row : rows)
					{
						logger.info("fetchKpiConfigurationOnloadDtls() setting kpiJson :{}"  ,row);
						JSONObject kpiJson = new JSONObject();

						kpiJson.put("categoryId", row.get("CAT_ID") == null ? "" : row.get("CAT_ID").toString());
						kpiJson.put("categoryName", row.get("CAT_NAME") == null ? "" : row.get("CAT_NAME").toString());
						kpiJson.put("kpiId", row.get("KPI_ID") == null ? "" : row.get("KPI_ID").toString());
						kpiJson.put("kpiName", row.get("KPI_TYPE") == null ? "" : row.get("KPI_TYPE").toString());
						kpiJson.put("target", row.get("TARGET") == null ? "" : row.get("TARGET").toString());
						kpiJson.put("weightage", row.get("WEIGHT_AGE") == null ? "" : row.get("WEIGHT_AGE").toString());
						kpiJson.put("statusEnable",
								row.get("STATUS_ENABLE") == null ? "" : row.get("STATUS_ENABLE").toString());
						kpiJson.put("startDate", row.get("START_DATE") == null ? "" : row.get("START_DATE").toString());
						kpiJson.put("endDate", row.get("END_DATE") == null ? "" : row.get("END_DATE").toString());
						kpiJson.put("promoterType",
								row.get("PROMOTER_TYPE") == null ? "" : row.get("PROMOTER_TYPE").toString());

						jsonArray.add(kpiJson);
					}

					json.put("kpiDetails", jsonArray);
					response.setMessage(prop.getProperty(Constants.KPI_CONFIG_FETCH_DTLS_SUCC_MSG));
					response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
					response.setResponse(json);
					logger.info("Success Response generated {}:", "");
				}

			}
			else
			{
				logger.info("fetchKpiConfigurationOnloadDtls() Mobile No. is blank {}:" , "");
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_RESPONSE_CODE));
				response.setResponse(json);
			}
			logger.info("fetchKpiConfigurationOnloadDtls() Response generated {}:" , "");
			return response;
		}
		catch (Exception exe)
		{
			logger.info("fetchKpiConfigurationOnloadDtls() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
			return response;
		}
	}

	@Override
	public SnapWorkResponse fetchKpiConfigurationGetPromoterType(String categoryId) throws CustomException
	{
		JSONObject json = new JSONObject();
		List<Map<String, Object>> rows = null;
		JSONArray jsonArray = new JSONArray();

		try
		{
			logger.info("Inside fetchKpiConfigurationGetPromoterType() method in KpiConfigurationServiceImpl class {}:" ,"");

			if (StringUtils.isNotBlank(categoryId))
			{
				rows = kpiConfigDao.fetchKpiConfigurationGetPromoterType(categoryId);
				logger.info("KPI_CONFIG_GET_PROMOTER_TYPE rows:{} for categoryId: {}:"  ,rows.size(),categoryId);

				if (rows != null && !rows.isEmpty())
				{
					for (Map<String, Object> row : rows)
					{
						logger.info("fetchKpiConfigurationGetPromoterType() setting kpi_JSONPROMOTER_TYPEJsonObj:{} for categoryId: {}:"  ,row,categoryId);
						JSONObject kpi_JSONPROMOTER_TYPE = new JSONObject();

						kpi_JSONPROMOTER_TYPE.put(Constants.JSON_PROMOTER_TYPE,
								row.get(Constants.PROMOTER_TYPE) == null ? ""
										: row.get(Constants.PROMOTER_TYPE).toString());

						jsonArray.add(kpi_JSONPROMOTER_TYPE);
					}

					json.put(Constants.JSON_KPI_PROMOTER_TYPE, jsonArray);
					response.setMessage(prop.getProperty(Constants.KPI_CONFIG_FETCH_PROMOTER_TYPE));
					response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
					response.setResponse(json);
					logger.info("Success Response generated:{} for categoryId: {}:", "",categoryId);
				}
				else
				{
					response.setMessage(prop.getProperty(Constants.FAILURE_NOT_FOUND));
					response.setStatusCode(prop.getProperty(Constants.FAILURE_RESPONSE_CODE));
					response.setResponse(json);
				}
			}
			else
			{
				logger.info("fetchKpiConfigurationGetPromoterType() categoryId is blank {}:" , "");
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_RESPONSE_CODE));
				response.setResponse(json);
			}

			logger.info("fetchKpiConfigurationGetPromoterType():{} for categoryId: {}:" , "",categoryId);
			return response;

		}
		catch (Exception exe)
		{
			logger.info("fetchKpiConfigurationGetPromoterType() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
			response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
			response.setResponse(json);
			return response;
		}
	}

	public String convertDate(String dateInput) throws ParseException
	{
		String resultDate = "";

		logger.info("dateInput {}:" , dateInput);
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		DateFormat outputformat = new SimpleDateFormat("dd-MMM-yyyy");
		Date date = df.parse(dateInput);
		resultDate = outputformat.format(date);
		logger.info("resultDate {}:" , resultDate);

		return resultDate;
	}
}