package com.airtelbank.admin.bean;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class OthersHierarchyBean
{
    private String promoterLapuNo;
    private String promoterType;
    private String promoterName;
    private String promoterAgency;
    private String promoterEmployeeID;
    private String promoterDob;
    private String promoterDoj;
    private String tlNo;
    private String tlName;
    private String tlAgency;
    private String tlEmployeeID;
    private String tlDob;
    private String tlDoj;
    private String zoneName;
    private String zmNo;
    private String zmName;
    private String rmMsisdn;
    private String rmName;
    private String cphNo;
    private String cphName;
    private String mmno;
    private String mmname;
    private String action;


    public String getPromoterType() {
        return promoterType;
    }

    public void setPromoterType(String promoterType) {
        this.promoterType = promoterType;
    }

    public String getMmno() {
        return mmno;
    }

    public void setMmno(String mMNo) {
        this.mmno = mMNo;
    }

    public String getMmname() {
        return mmname;
    }

    public void setMmname(String mMName) {
        this.mmname = mMName;
    }

    public OthersHierarchyBean() {

    }

    public String getPromoterLapuNo() {
        return promoterLapuNo;
    }

    public void setPromoterLapuNo(String promoterLapuNo) {
        this.promoterLapuNo = promoterLapuNo;
    }

    public String getPromoterName() {
        return promoterName;
    }

    public void setPromoterName(String promoterName) {
        this.promoterName = promoterName;
    }

    public String getPromoterAgency() {
        return promoterAgency;
    }

    public void setPromoterAgency(String promoterAgency) {
        this.promoterAgency = promoterAgency;
    }

    public String getPromoterEmployeeID() {
        return promoterEmployeeID;
    }

    public void setPromoterEmployeeID(String promoterEmployeeID) {
        this.promoterEmployeeID = promoterEmployeeID;
    }

    public String getPromoterDob() {
        return promoterDob;
    }

    public void setPromoterDob(String promoterDob) {
        this.promoterDob = promoterDob;
    }

    public String getPromoterDoj() {
        return promoterDoj;
    }

    public void setPromoterDoj(String promoterDoj) {
        this.promoterDoj = promoterDoj;
    }

    public String getTlNo() {
        return tlNo;
    }

    public void setTlNo(String tlNo) {
        this.tlNo = tlNo;
    }

    public String getTlName() {
        return tlName;
    }

    public void setTlName(String tlName) {
        this.tlName = tlName;
    }

    public String getTlAgency() {
        return tlAgency;
    }

    public void setTlAgency(String tlAgency) {
        this.tlAgency = tlAgency;
    }

    public String getTlEmployeeID() {
        return tlEmployeeID;
    }

    public void setTlEmployeeID(String tlEmployeeID) {
        this.tlEmployeeID = tlEmployeeID;
    }

    public String getTlDob() {
        return tlDob;
    }

    public void setTlDob(String tlDob) {
        this.tlDob = tlDob;
    }

    public String getTlDoj() {
        return tlDoj;
    }

    public void setTlDoj(String tlDoj) {
        this.tlDoj = tlDoj;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public String getZmNo() {
        return zmNo;
    }

    public void setZmNo(String zmNo) {
        this.zmNo = zmNo;
    }

    public String getZmName() {
        return zmName;
    }

    public void setZmName(String zmName) {
        this.zmName = zmName;
    }

    public String getRmMsisdn() {
        return rmMsisdn;
    }

    public void setRmMsisdn(String rmMsisdn) {
        this.rmMsisdn = rmMsisdn;
    }

    public String getRmName() {
        return rmName;
    }

    public void setRmName(String rmName) {
        this.rmName = rmName;
    }

    public String getCphNo() {
        return cphNo;
    }

    public void setCphNo(String cphNo) {
        this.cphNo = cphNo;
    }

    public String getCphName() {
        return cphName;
    }

    public void setCphName(String cphName) {
        this.cphName = cphName;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

}
