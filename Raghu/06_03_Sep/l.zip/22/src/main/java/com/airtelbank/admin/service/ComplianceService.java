package com.airtelbank.admin.service;

import javax.servlet.http.HttpServletResponse;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.CustomException;

public interface ComplianceService
{
	SnapWorkResponse viewComplianceDetails(SnapWorkRequest request)throws CustomException;

	SnapWorkResponse onloadDashboardDetails(SnapWorkRequest request)throws CustomException;

	int downloadComplianceDetails(String encrandomkey,String encString,String sessionKey,HttpServletResponse response, boolean testCaseInvoked) throws CustomException;
}
