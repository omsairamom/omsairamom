package com.airtelbank.admin.service;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.CustomException;

public interface AdminReportService
{
	SnapWorkResponse dashboardMarketVisitDetails(SnapWorkRequest request) throws CustomException;

	SnapWorkResponse downloadMarketVisit(String roleName,
										 String categoryId,
										 String circleId,
										 String zoneId,
										 String startDate,
										 String endDate) throws CustomException;

  }
