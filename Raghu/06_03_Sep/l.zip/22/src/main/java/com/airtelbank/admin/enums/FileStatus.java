package com.airtelbank.admin.enums;

public enum FileStatus {
	
	PENDING, IN_PROGRESS, FAILED, PROCESSED

}
