package com.airtelbank.admin.entity;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import javax.persistence.Index;
@Entity
@Getter
@Setter
@Table(name = "PROMOTER_USER_PROFILE_MST",indexes = 
{
		@Index(name = "IndexUserNo",  columnList="userNo"),
		@Index(name = "IndexUserId", columnList = "user_id"),
		@Index(name = "IndexUserType", columnList = "userType")
})
@EntityListeners(AuditingEntityListener.class)
public class PromoterUserProfileMSTEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column
    @NotNull
    private String userNo;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    @NotNull
    private String password;

    @Column
    @NotNull
    private String deviceId;

    @Column
    @NotNull
    private String status;

    @Column
    @NotNull
    private LocalDateTime expiryDate;

    @Column
    private LocalDateTime blockExpiryDate;

    @Column
    @NotNull
    private String userType;

    @Column
    @NotNull
    private String channel;

    @Column
    @NotNull
    private int attempts;

    @Column
    @CreatedDate
    private LocalDateTime createdDate;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDate;
    
    @Column
    private String custom_field1;
    
    @Column
    private String custom_field2;
    
    @Column
    private String custom_field3;
    
    @Column
    private String custom_field4;
    
    @Column
    private String custom_field5;
}
