package com.airtelbank.admin.dao;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class KpiConfigurationDAO {

	private final Logger logger = LoggerFactory.getLogger(KpiConfigurationDAO.class.getClass());

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;
	String kpiIdKey = "KPI_ID";

	public int saveKpiConfigDtls(SnapWorkRequest request, String startDate, String endDate) throws Exception {

		int kpiDetailsCount = 0;
		int kpiMeasureCount = 0;
		int count = 0;
		String query = "";
		String kpiId = "";
		int id = 0;

		try {

			logger.info("Inside saveKpiConfigDtls() method in KpiConfigurationDAO class...{}:" ,"");
			String categoryName = request.getCategoryName() == null ? "" : request.getCategoryName().trim();
			String kpiName = request.getKpiName() == null ? "" : request.getKpiName().trim();
			String weightAge = request.getWeightAge() == null ? "" : request.getWeightAge().trim();
			String target = request.getTarget() == null ? "" : request.getTarget().trim();
			String statusEnable = request.getStatusEnable() == null ? "" : request.getStatusEnable().trim();
			String promoterType = request.getPromoterType() == null ? "" : request.getPromoterType().trim();

			final String CategoryId = getCategoryId(categoryName);
			logger.info("CategoryId {}:" , CategoryId);

			if (StringUtils.isNotBlank(CategoryId)) {

				if (!isExistKpiDetails(kpiName, CategoryId)) {
					logger.info("Line no 64 {}:" ,"");
					final String INSERT_SQL = prop.getProperty(Constants.KPI_CONFIG_SAVE_DETAILS_MST);
					KeyHolder keyHolder = new GeneratedKeyHolder();

					kpiDetailsCount = jdbctemplate.update(new PreparedStatementCreator() {
						public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
							PreparedStatement ps = connection.prepareStatement(INSERT_SQL, new String[] { kpiIdKey });
							ps.setString(1, CategoryId);
							ps.setString(2, kpiName);
							ps.setString(3, kpiName);
							ps.setString(4, "NA");
							ps.setString(5, statusEnable);
							ps.setString(6, "Admin");
							ps.setString(7, promoterType);

							return ps;
						}
					}, keyHolder);

					id = keyHolder.getKey().intValue();

					if (id != 0)
					{
						try
						{
							List<Map<String, Object>> rows = null;
							rows = jdbctemplate.queryForList("SELECT kpi_detailsmst_seq.currVal FROM dual",
									new Object[] {});

							for (Map<String, Object> map : rows) {
								for (Map.Entry<String, Object> entry : map.entrySet())
								{

									String stid = entry.getValue().toString();

									id = Integer.parseInt(stid);
								}

							}
						}
						catch (Exception e)
						{
							CommonException.printStackTraceForDAO(e);
						}
					}

					logger.info("kpiDetailsCount {}:" , kpiDetailsCount);

					kpiId = String.valueOf(id);
					logger.info("kpiId {}:" , kpiId);
				}

				if (StringUtils.isNotBlank(kpiId) && !isExistKpiMeasureId(kpiId))
				{
						logger.info("Line no 91 {}:" , "");
						query = prop.getProperty(Constants.KPI_CONFIG_SAVE_MEASURE_MST);
						kpiMeasureCount = jdbctemplate.update(query,
								kpiId, target, weightAge, startDate, endDate, "Admin" );
						logger.info("kpiMeasureCount {}:" ,kpiMeasureCount);
				}
				if (kpiDetailsCount != 0 && kpiMeasureCount != 0)
				{
					count++;
				}
			}

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		finally
		{
			try
			{
				if (kpiDetailsCount != 0 && kpiMeasureCount != 0)
				{
					int update = updateKpiConfigDtls();
					logger.info("update count {}:" , update);
				}
			}

			catch (Exception e) {
				CommonException.printStackTraceForDAO(e);
			}
		}

		return count;
	}

	public String getKpiTargetDtlsFromDb(SnapWorkRequest request) throws Exception {

		List<Map<String, Object>> rows = null;
		String kpiTarget = "";

		try {
			String categoryName = request.getCategoryName() == null ? "" : request.getCategoryName().trim();
			String weightAge = request.getWeightAge() == null ? "" : request.getWeightAge().trim();
			String statusEnable = request.getStatusEnable() == null ? "" : request.getStatusEnable().trim();
			String kpiId = request.getKpiId() == null ? "" : request.getKpiId().trim();
			String categoryId = getCategoryId(categoryName);
			logger.info("CategoryId {}:" , categoryId);

			String query = prop.getProperty(Constants.KPI_CONFIG_TARGET_DETAILS);
			rows = jdbctemplate.queryForList(query, kpiId, weightAge, statusEnable, categoryId );
			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					kpiTarget = row.get("TARGET") == null ? "" : row.get("TARGET").toString();
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return kpiTarget;

	}

	public int updateKpiConfigDtls(SnapWorkRequest request) throws Exception {

		int kpiDetailsCount = 0;
		int kpiMeasureCount = 0;
		int count = 0;
		String query = "";
		String kpiId = "";

		try {

			logger.info("Inside updateKpiConfigDtls() method in KpiConfigurationDAO class... {}:" , "");
			String categoryName = request.getCategoryName() == null ? "" : request.getCategoryName().trim();
			String kpiName = request.getKpiName() == null ? "" : request.getKpiName().trim();
			String weightAge = request.getWeightAge() == null ? "" : request.getWeightAge().trim();
			String target = request.getTarget() == null ? "" : request.getTarget().trim();
			String statusEnable = request.getStatusEnable() == null ? "" : request.getStatusEnable().trim();
			String promoterType = request.getPromoterType() == null ? "" : request.getPromoterType().trim();

			final String CategoryId = getCategoryId(categoryName);

			if (StringUtils.isNotBlank(CategoryId))
			{
				kpiId = request.getKpiId() == null ? "" : request.getKpiId().trim();
				int dbWeightAge = getUpdatedWeightageSum(kpiId, categoryName);
				logger.info("totalWeightAge at line no 144  {}:" , dbWeightAge);
				int updatedWeightAge = dbWeightAge + Integer.parseInt(weightAge);
				logger.info("updatedWeightAge  at line no 148 {}:" , updatedWeightAge);

					if (updatedWeightAge <= 100)
					{
						if (isExistKpiDetailsId(kpiId, CategoryId))
						{
							query = prop.getProperty(Constants.KPI_CONFIG_UPDATE_DETAILS);
							kpiDetailsCount = jdbctemplate.update(query,
									 kpiName, kpiName, statusEnable, promoterType, CategoryId, kpiId );
						}

						if (isExistKpiMeasureId(kpiId))
						{
							query = prop.getProperty(Constants.KPI_CONFIG_UPDATE_MEASURE_MST);
							kpiMeasureCount = jdbctemplate.update(query, target, weightAge, kpiId );
						}
					}

					if (kpiDetailsCount != 0 && kpiMeasureCount != 0)
					{
						count++;
					}

				logger.info("kpiDetailsCount {}:" , kpiDetailsCount);
				logger.info("kpiMeasureCount {}:" , kpiMeasureCount);

			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	private boolean isExistKpiDetailsId(String kpiId, String catId) throws Exception
	{

		boolean falg = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try {
			query = prop.getProperty(Constants.KPI_CONFIG_IS_EXIST_KPI_ID_DETAILS);

			rows = jdbctemplate.queryForList(query,  catId );

			if (rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows) {
					String kpiIdFromDB = row.get(kpiIdKey) == null ? "" : row.get(kpiIdKey).toString();

					if (StringUtils.isNoneBlank(kpiIdFromDB) && StringUtils.isNoneBlank(catId)
						&& kpiId.equalsIgnoreCase(kpiIdFromDB))
					{
						falg = true;
					}
				}

			}

			logger.info("falg {}:" , falg);
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return falg;

	}

	@SuppressWarnings("rawtypes")
	public String getCategoryId(String categoryName) throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows = null;
		String catId = "";

		try {
			query = prop.getProperty(Constants.KPI_CONFIG_CATEGORY_ID);
			rows = jdbctemplate.queryForList(query, categoryName );
			if (rows != null && !rows.isEmpty()) {
				for (Map row : rows) {
					catId = row.get("CAT_ID") == null ? "" : row.get("CAT_ID").toString();
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return catId;
	}

	@SuppressWarnings("rawtypes")
	public boolean isExistKpiDetails(String kpiType, String catId) throws Exception {

		boolean falg = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try {
			query = prop.getProperty(Constants.KPI_CONFIG_IS_EXIST_KPI_DETAILS);
			rows = jdbctemplate.queryForList(query,  kpiType, catId );
			if (rows != null && !rows.isEmpty()) {
				for (Map row : rows) {
					String kpitype = row.get("KPI_TYPE") == null ? "" : row.get("KPI_TYPE").toString();

					if (StringUtils.isNoneBlank(kpiType))
					{
						if (kpitype.equalsIgnoreCase(kpiType))
						{
							falg = true;
						}
					}
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return falg;
	}

	@SuppressWarnings("rawtypes")
	public String getKpiId(String kpiType, String catId) throws Exception {

		String query = "";
		List<Map<String, Object>> rows = null;
		String kpiId = "";

		try {
			query = prop.getProperty(Constants.KPI_CONFIG_DETAILS_ID);
			rows = jdbctemplate.queryForList(query, kpiType, catId );
			if (rows != null && !rows.isEmpty()) {
				for (Map row : rows) {
					kpiId = row.get(kpiIdKey) == null ? "" : row.get(kpiIdKey).toString();
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return kpiId;
	}

	public boolean isExistKpiMeasureId(String kpiId) throws Exception {

		boolean falg = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try {
			query = prop.getProperty(Constants.KPI_CONFIG_IS_EXIST_MEASURES_DETAILS);

			rows = jdbctemplate.queryForList(query, kpiId );

			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					String kpiIdFromDB = row.get(kpiIdKey) == null ? "" : row.get(kpiIdKey).toString();

					if (StringUtils.isNoneBlank(kpiIdFromDB) && StringUtils.isNoneBlank(kpiId)
							&& kpiId.equalsIgnoreCase(kpiIdFromDB))
					{
							falg = true;
					}
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return falg;

	}

	public List<Map<String, Object>> fetchKpiConfigurationGetPromoterType(String categoryId) throws Exception
	{
		List<Map<String, Object>> rows = null;
		String query = "";

		try {
			logger.info(
					"Inside fetchKpiConfigurationGetPromoterType() method in fetchKpiConfigurationGetPromoterType class... {}:" , "");
			query = prop.getProperty(Constants.KPI_CONFIG_GET_PROMOTER_TYPE);
			rows = jdbctemplate.queryForList(query, categoryId );
		}

		catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return rows;
	}

	public List<Map<String, Object>> fetchKpiConfigDtls() throws Exception {

		List<Map<String, Object>> rows = null;

		String query = "";

		try {
			logger.info("Inside fetchKpiConfigDtls() method in KpiConfigurationDAO class... {}:" , "");
			query = prop.getProperty(Constants.KPI_CONFIG_CHECK_DTLS_EXIST);
			rows = jdbctemplate.queryForList(query, new Object[] {});
		}

		catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return rows;
	}

	public String getStartDate() throws Exception {

		String startDate = "";
		String query = "";
		List<Map<String, Object>> rows = null;
		Date date = new Date();

		try {

			logger.info("Inside of getStartDate() at line 423 of KpiConfigurationDAO class {}:" , "");
			query = prop.getProperty(Constants.KPI_CONFIG_START_DATE_DTLS);
			rows = jdbctemplate.queryForList(query, new Object[] {});

			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					startDate = row.get("START_DATE") == null ? "" : row.get("START_DATE").toString();
					if (startDate.equals("")) {

					}
				}
			}
			if (startDate.equals("")) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				startDate = formatter.format(date);
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return startDate;
	}

	public String getEndDate() throws Exception {

		String endDate = "";
		String query = "";
		List<Map<String, Object>> rows = null;

		try {
			logger.info("Inside of getEndDate() of KpiConfigurationDAO class {}:" , "");
			query = prop.getProperty(Constants.KPI_CONFIG_END_DATE_DTLS);
			rows = jdbctemplate.queryForList(query, new Object[] {});

			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					endDate = row.get("END_DATE") == null ? "" : row.get("END_DATE").toString();
				}
			}
			if (endDate.equals("")) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				Date date = new Date();
				endDate = formatter.format(date);
			}

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return endDate;
	}

	public int updateKpiConfigDtls() throws Exception
	{
		int count = 0;
		try
		{
			logger.info(" Inside of updateKpiConfigDtls {}:" , "");
			List<Map<String, Object>> rows = fetchQuarterCreatedDate();
			if (rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					String CREATED_DT = row.get("CREATED_DT") == null ? "" : row.get("CREATED_DT").toString();
					CREATED_DT = convertDate(CREATED_DT);
					final String UPDATE_SQL = prop.getProperty(Constants.KPI_CONFIG_UPDATE_STATUS_DTLS);
					count = jdbctemplate.update(UPDATE_SQL, CREATED_DT );
				}
			}

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public List<Map<String, Object>> fetchQuarterCreatedDate() throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows = null;
		String startDate = "";
		String endDate = "";

		try
		{
			logger.info("Inside of fetchQuarterCreatedDate() in KpiConfigurationDAO class {}:" , "");
			List<String> list = fetchDateFromQuarter();
			if(list != null && !list.isEmpty()) {
				startDate = list.get(0);
				endDate = list.get(1);
			}
			query = prop.getProperty(Constants.KPI_CONFIG_EXISTING_QUARTER_DETAILS);
			rows = jdbctemplate.queryForList(query, startDate, endDate );
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return rows;
	}

	private List<String> fetchDateFromQuarter() throws Exception {
		List<String> list = new ArrayList<>();
		String startDate = "";
		String endDate = "";

		try {

			logger.info("Inside of fetchDateFromQuarter() in  KpiConfigurationDAO class {}:" , "");
			Calendar now = Calendar.getInstance();
			int value = now.get(Calendar.YEAR);
			String year = String.valueOf(value);

			String currentQuarter = getCurrentQuarter();
			switch (currentQuarter) {
				case "1":
					startDate = "01-01-" + year;
					endDate = "31-03-" + year;
					list.add(startDate);
					list.add(endDate);
					break;
				case "2":
					startDate = "01-04-" + year;
					endDate = "30-06-" + year;
					list.add(startDate);
					list.add(endDate);
					break;
				case "3":
					startDate = "01-07-" + year;
					endDate = "30-09-" + year;
					list.add(startDate);
					list.add(endDate);
					break;
				case "4":
					startDate = "01-10-" + year;
					endDate = "31-12-" + year;
					list.add(startDate);
					list.add(endDate);
					break;

				default:
					break;
			}

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return list;
	}

	public String getCurrentQuarter() throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows = null;
		String currentQuarter = "";

		try
		{
			logger.info("Inside of getCurrentQuarter() in KpiConfigurationDAO {}:" , "");
			query = prop.getProperty(Constants.KPI_CONFIG_CURRENT_QUARTER_DETAILS);
			rows = jdbctemplate.queryForList(query, new Object[] {});

			if (rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					currentQuarter = row.get("CURRENT_QUARTER") == null ? "" : row.get("CURRENT_QUARTER").toString();
				}
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return currentQuarter;
	}

	public int getWeightageSum(String categoryName) throws Exception
	{
		int totalSum = 0;
		String query = "";
		String sumFromDb = "";
		List<Map<String, Object>> rows = null;

		try
		{
			logger.info("Inside of getStartDate() at line 615 of KpiConfigurationDAO class {}:" , "");
			query = prop.getProperty(Constants.KPI_CONFIG_WEIGHT_AGE_SUM);
			rows = jdbctemplate.queryForList(query, categoryName);

			if (rows != null && !rows.isEmpty())
			{
				for (Map<String, Object> row : rows)
				{
					sumFromDb = row.get("WEIGHT_AGE_SUM") == null ? "0" : row.get("WEIGHT_AGE_SUM").toString();

					totalSum = Integer.parseInt(sumFromDb);
				}
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return totalSum;
	}

	public int getUpdatedWeightageSum(String kpiId, String categoryName) throws Exception
	{
		int totalSum = 0;
		String query = "";
		String sumFromDb = "";
		List<Map<String, Object>> rows = null;

		logger.info("Inside of getStartDate() at line 644 of KpiConfigurationDAO class {}:" , "");
		query = prop.getProperty(Constants.KPI_CONFIG_WEIGHT_AGE_SUM2);
		rows = jdbctemplate.queryForList(query, kpiId, categoryName);
		if (rows != null && !rows.isEmpty())
		{
			for (Map<String, Object> row : rows)
			{
				sumFromDb = row.get("WEIGHT_AGE_SUM") == null ? "0" : row.get("WEIGHT_AGE_SUM").toString();
				totalSum = Integer.parseInt(sumFromDb);
			}
		}

		return totalSum;
	}

	public String convertDate(String dateInput) throws Exception
	{
		String resultDate = "";
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss aa");
		DateFormat outputformat = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss aa");
		Date date = df.parse(dateInput);
		resultDate = outputformat.format(date);
		return resultDate;
	}
}
