package com.airtelbank.admin.util;

import com.airtelbank.admin.common.SnapWorkResponse;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.common.CommonException;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jun 28, 2019 11:41:55 AM
 */
@Service
public class CommonUtils {

	private static Logger logger = LoggerFactory.getLogger(CommonUtils.class);

	public double calculateOutletDistance(String lat1, String lat2, String lon1, String lon2) {

		double distance = 0;

		try {
			double latitude1 = Double.parseDouble(lat1);
			double latitude2 = Double.parseDouble(lat2);
			double longitude1 = Double.parseDouble(lon1);
			double longitude2 = Double.parseDouble(lon2);

			final int R = 6371;

			double latDistance = Math.toRadians(latitude2 - latitude1);
			double lonDistance = Math.toRadians(longitude2 - longitude1);

			double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(latitude1))
					* Math.cos(Math.toRadians(latitude2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);

			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

			distance = R * c;

		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		}

		return distance;

	}

	public double calculateMarketDistance(String lat1, String lat2, String lon1, String lon2)
	{

		double distance = 0;

		try
		{
			double latitude1 = Double.parseDouble(lat1);
			double latitude2 = Double.parseDouble(lat2);
			double longitude1 = Double.parseDouble(lon1);
			double longitude2 = Double.parseDouble(lon2);

			final int R = 6371;

			double latDistance = Math.toRadians(latitude2 - latitude1);
			double lonDistance = Math.toRadians(longitude2 - longitude1);

			double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(latitude1))
					* Math.cos(Math.toRadians(latitude2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);

			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

			distance = R * c * 1000;

		} catch (Exception exe) {
			CommonException.getPrintStackTrace(exe);
		}

		return distance;

	}

	public String convertMillis(long totalMilliseconds){
		String time = "";
		try {
			int seconds = (int) (totalMilliseconds / 1000) % 60 ;
			int minutes = (int) ((totalMilliseconds / (1000*60)) % 60);
			int hours   = (int) ((totalMilliseconds / (1000*60*60)) % 24);
			int milliSeconds = (int) (totalMilliseconds / 1000);
			time = "Total Time in HH:mm:ss:SSS ===> " + hours + ":" + minutes + ":" + seconds + ":" + milliSeconds;
			logger.info(time);

		}catch(Exception exe){
			CommonException.getPrintStackTrace(exe);
		}
		return time;
	}

	public void exceptionHandler(PropertyManager prop, Exception exe, SnapWorkResponse response, JSONObject json)
	{
		response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
		response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
		response.setResponse(json);
//		response.setExpMsg(exe.getMessage());
//		response.setExpLocalMsg(exe.getLocalizedMessage());
//		String cause="";
//		if(null != exe.getCause()) {
//			cause= exe.getCause().toString();
//		}
//		response.setExpCause(cause);
		CommonException.getPrintStackTrace(exe);
	}

	public Date convertDate(String dateInput)
	{
		Date date = null;

		try
		{
			logger.info("Inside convertDate() method in FileUploadServiceImpl class {}:" ,"");
			logger.info("dateInput {}:" , dateInput);
			DateFormat df = new SimpleDateFormat("dd-MM-uuuu");
			date = df.parse(dateInput);
			logger.info("resultDate {}:" , date);
		}
		catch (Exception exe)
		{
			logger.error("convertDate() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			return date;
		}
		logger.info("convertDate() Response generated:  {}:" , "");
		return date;
	}

	public LocalDateTime convertDateToLocalDateTime(String dateInput)
	{
		LocalDateTime date = null;

		try
		{
			logger.info("Inside convertDate() method in FileUploadServiceImpl class {}:" ,"");
			logger.info("dateInput {}:" , dateInput);

			DateTimeFormatter DATEFORMATTER = DateTimeFormatter.ofPattern("dd-MM-uuuu");
			LocalDate ld = LocalDate.parse(dateInput, DATEFORMATTER);
			date = LocalDateTime.of(ld, LocalDateTime.now().toLocalTime());

			logger.info("resultDate {}:" , date);
		}
		catch (Exception exe)
		{
			logger.error("convertDate() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
			CommonException.getPrintStackTrace(exe);
			return date;
		}
		logger.info("convertDate() Response generated:  {}:" , "");
		return date;
	}

}
