package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.AppVersionService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class AppVersionController
{
	private static Logger logger = LoggerFactory.getLogger(AppVersionController.class);

	@Autowired
	SnapWorkResponse response;

	@Autowired
    AppVersionService appVersionService;

	@Autowired
	PropertyManager prop;
	
	@Autowired
	CommonUtils commonUtil;

	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();

	@PostMapping(path="/v1/appversion/onload")
	public ResponseEntity<Object> processOnLoadAppVersionRequest(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();

			String userName = request.getUserName().trim();
			
			if(StringUtils.isNotBlank(userName))
			{
				response = appVersionService.onLoadAppVersionDetails(request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info("************************************************************************************************************************************* {} :", "");
		}
		catch(Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
