package com.airtelbank.admin.dao;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.entity.PromoterUserMSTEntity;
import com.airtelbank.admin.repository.PromoterUserMSTRepository;

@Service
public class PromoterUserMSTDao {
	
	@Autowired
	private PromoterUserMSTRepository promoterUserMSTRepository;
	
	
	public PromoterUserMSTEntity fetchUserByUserNumber(String usernumber)
	{
		return promoterUserMSTRepository.findOneByUserNo(usernumber);
	}


	public void saveInDB(PromoterUserMSTEntity promoterUserMSTEntity) {
		
		promoterUserMSTRepository.save(promoterUserMSTEntity);
	}

	public void saveAllInDB(List<PromoterUserMSTEntity> promoterUserMSTEntityList) {
		promoterUserMSTRepository.saveAll(promoterUserMSTEntityList);
		
	}

}
