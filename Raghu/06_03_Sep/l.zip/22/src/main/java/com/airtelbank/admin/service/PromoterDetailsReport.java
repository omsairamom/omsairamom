package com.airtelbank.admin.service;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.CustomException;

public interface PromoterDetailsReport {

    SnapWorkResponse getPromoterDtls(SnapWorkRequest request) throws CustomException;

    SnapWorkResponse getOutletDtls(SnapWorkRequest request) throws CustomException;

    SnapWorkResponse downloadPromoterDtls(String lapuNo) throws CustomException;

    SnapWorkResponse downloadOutletDtls(String lapuNo) throws CustomException;
}
