package com.airtelbank.admin.bean;

public class KpiMasterBean
{
    private String lapuNo;
    private String promoterName;
    private String catName;
    private String kpiName;
    private String lmtd;
    private String mtd;
    private String achievedPercent;

    public String getLapuNo() {
        return lapuNo;
    }

    public void setLapuNo(String lapuNo) {
        this.lapuNo = lapuNo;
    }

    public String getPromoterName() {
        return promoterName;
    }

    public void setPromoterName(String promoterName) {
        this.promoterName = promoterName;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public String getKpiName() {
        return kpiName;
    }

    public void setKpiName(String kpiName) {
        this.kpiName = kpiName;
    }

    public String getLmtd() {
        return lmtd;
    }

    public void setLmtd(String lMTD) {
        lmtd = lMTD;
    }

    public String getMtd() {
        return mtd;
    }

    public void setMtd(String mTD) {
        mtd = mTD;
    }

    public String getAchievedPercent() {
        return achievedPercent;
    }

    public void setAchievedPercent(String achievedPercent) {
        this.achievedPercent = achievedPercent;
    }

    @Override
    public String toString() {
        return "Kpi_V2_MasterBean [LAPU_NO=" + lapuNo + ", Promoter_Name=" + promoterName + ", CAT_Name=" + catName
                + ", KPI_Name=" + kpiName + ", LMTD=" + lmtd + ", MTD=" + mtd + ", Achieved_Percent="
                + achievedPercent + "]";
    }
}
