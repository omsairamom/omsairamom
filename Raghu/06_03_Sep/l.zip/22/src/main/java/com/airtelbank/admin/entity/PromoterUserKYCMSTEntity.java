package com.airtelbank.admin.entity;

import org.springframework.data.annotation.CreatedDate;
import javax.persistence.Index;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "PROMOTER_USER_KYC_MST",indexes = 
{
		@Index(name = "IndexUserId",  columnList="user_id"),
		@Index(name = "IndexKuaPincode", columnList = "kuaPincode"),
		@Index(name = "IndexKuaState", columnList = "kuaState")
})
@EntityListeners(AuditingEntityListener.class)
public class PromoterUserKYCMSTEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", nullable = false, referencedColumnName = "id")
    private PromoterUserMSTEntity promoterUserMSTEntity;

    @Column
    private String userNo;

    @Column
    private String latitude;

    @Column
    private String longitude;

    @Column
    private String grAddress;

    @Column
    private String grCity;

    @Column
    private String grPincode;

    @Column
    private String grState;

    @Column
    private String aadharPhotoId;

    @Column
    private String kuaEmailId;

    @Column
    private LocalDateTime kuaDob;

    @Column
    private String kuaTxnId;

    @Column
    private String aadhaarRefNumber;

    @Column
    private String kuaFirstName;

    @Column
    private String kuaMiddleName;

    @Column
    private String kuaLastName;

    @Column
    private String gender;

    @Column
    private String kuaAddress;

    @Column
    private String kuaState;

    @Column
    private String kuaCountry;

    @Column
    private String kuaPincode;

    @Column
    private String profilePhotoId;

    @Column
    @CreatedDate
    private LocalDateTime createdDate;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDate;

    @Column
    private String custom_field1;

    @Column
    private String custom_field2;

    @Column
    private String custom_field3;

    @Column
    private String custom_field4;

    @Column
    private String custom_field5;

}
