package com.airtelbank.admin.filter;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.KibanaLoggerUtils;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@Component
public class KibanaLoggingFilter extends OncePerRequestFilter {
    private static Logger logger = LoggerFactory.getLogger(KibanaLoggingFilter.class);

    @Autowired
    KibanaLoggerUtils kibanaLoggerObj;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        // Once we get the token validate it.

        if (true) {
            setAuthentication("userName", request);
        }


        //Step 1: Get data from HttpServletRequest
        long startTime = System.currentTimeMillis();

        final MultiReadHttpServletRequest httpRequestWrapper = new MultiReadHttpServletRequest(request);
        final HttpResponseWrapper httpResponseWrapper = new HttpResponseWrapper(response);

        //Step 2: Hit API
        try {
            filterChain.doFilter(httpRequestWrapper, httpResponseWrapper);
        } catch (Exception e) {

            logger.error("doFilterInternal() Internal Exception {}, {}:", e.getMessage(), e.getCause());
        } finally {
            // Step 3: Print kibana

            long endTime = System.currentTimeMillis();
            long requestProcessingTime = endTime - startTime;

            SnapWorkRequest snapWorkRequest =
                    new Gson().fromJson(httpRequestWrapper.getReader(), SnapWorkRequest.class);

           

            if (!request.getRequestURI().contains("/v1/file/download")) 
            {
                SnapWorkResponse snapWorkResponse =
                        new Gson().fromJson(httpResponseWrapper.getResponsePayload(), SnapWorkResponse.class);
                try {
                    kibanaLoggerObj.saveAdminWebKibanaLoggers(snapWorkRequest, snapWorkResponse, requestProcessingTime,
                            request.getRequestURI());
                } catch (Exception e) {
                    logger.error("saveAdminWebKibanaLoggers() method Exception  {}:", e.getMessage(), e.getCause());
                }
            }
        }
    }


    void setAuthentication(String username, HttpServletRequest request) {
        UserDetails userDetails = new org.springframework.security.core.userdetails.User(username, "password",
                new ArrayList<>());
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                userDetails, null, userDetails.getAuthorities());
        usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
    }
}