package com.airtelbank.admin.controller;


import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.service.PromoterDetailsReport;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class PromoterDetailsReportController {
    private static Logger logger = LoggerFactory.getLogger(PromoterDetailsReportController.class);

    @Autowired
    SnapWorkResponse response;

    @Autowired
    PromoterDetailsReport promoterDetailsReport;

    @Autowired
    PropertyManager prop;

    @Autowired
    CommonUtils commonUtil;

    JSONObject json = new JSONObject();
    long startTime = 0;
    long endTime = 0;
    long elapsedTimeMillis = 0;
    GsonBuilder gsonBuilder = new GsonBuilder();
    Gson gson = gsonBuilder.create();


    @PostMapping(path = "/v1/details/promoter")
    public ResponseEntity<Object> getPromoterDtls(@Valid @RequestBody SnapWorkRequest request)
    {
        try
        {
            startTime = System.currentTimeMillis();
            logger.info("Admin Portal Get Promoter Details, Request start timeInMillis {}:", startTime);


            String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();

            if (StringUtils.isNotBlank(mobileNo))
            {
                response = promoterDetailsReport.getPromoterDtls(request);
            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
        }
        catch (Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @PostMapping(path ="/v1/details/outlet")
    public ResponseEntity<Object> getOutletDtls(@Valid @RequestBody SnapWorkRequest request)
    {
        try
        {
            startTime = System.currentTimeMillis();
            logger.info("Admin Portal Get Outlet Details, Request start timeInMillis {}:", startTime);

            String mobileNo = request.getMobileNo() == null ? "" : request.getMobileNo().trim();

            if (StringUtils.isNotBlank(mobileNo))
            {
                response = promoterDetailsReport.getOutletDtls(request);
            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
        }
        catch (Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(path= "/v1/details/outlet/download")
    public ResponseEntity<Object> downloadOutletDtls(@Valid @RequestBody SnapWorkRequest request)
    {

        try
        {
            startTime = System.currentTimeMillis();
            logger.info("Download-OutLet Report Details, Request start timeInMillis {} :", startTime);
            logger.info("Download-OutLet Report Details, Request params {} :", gson.toJson(request));

            String mobileNo = request.getMobileNo()== null ? "" : request.getMobileNo().trim();

            if(StringUtils.isNotBlank(mobileNo))
            {
                promoterDetailsReport.downloadOutletDtls(mobileNo);

            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("Download-OutLet Report Details, response {} : ", gson.toJson(response));
            endTime = System.currentTimeMillis();
            logger.info("Download-OutLet Report Details, Request end timeInMillis {}:" , endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("*************************************************************************************************************************************{} :" , "");
        }
        catch(Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


        @PostMapping(path= "/v1/details/promoter/download")
    public ResponseEntity<Object> downloadPromoterDtls(@Valid @RequestBody SnapWorkRequest request)
    {
        try
        {

            startTime = System.currentTimeMillis();
            logger.info("Download-Promoter Report Details, Request start timeInMillis {} :", startTime);
            logger.info("Download-Promoter Report Details, Request params {} :", gson.toJson(request));

            String mobileNo = request.getMobileNo()== null ? "" : request.getMobileNo().trim();

            if(StringUtils.isNotBlank(mobileNo))
            {
                promoterDetailsReport.downloadPromoterDtls(mobileNo);

            }
            else
            {
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("Download-Promoter Report Details, response {} : ", gson.toJson(response));
            endTime = System.currentTimeMillis();
            logger.info("Download-Promoter Report Details, Request end timeInMillis {}:" , endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("*************************************************************************************************************************************{} :" , "");
        }
        catch(Exception exe)
        {
            commonUtil.exceptionHandler(prop, exe, response, json);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
