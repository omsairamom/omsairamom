package com.airtelbank.admin.service;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.CustomException;

public interface AdminPortalLoginService
{
	
	SnapWorkResponse adminLoginDetails(String userName,String password,SnapWorkRequest request) throws CustomException;
	
	SnapWorkResponse fetchCircleDetails(String mobileNo,SnapWorkRequest request) throws CustomException;
	
	SnapWorkResponse dashboardAttendanceDetails(SnapWorkRequest request) throws CustomException;
	
	SnapWorkResponse resetPassword(String userName,String password,SnapWorkRequest request) throws CustomException;
	
	SnapWorkResponse sendOTP(String mobileNo,SnapWorkRequest request) throws CustomException;
	
	SnapWorkResponse verifyOTP(String mobileNo,String otpVerificationCode,String otp,SnapWorkRequest request) throws CustomException;
	
	SnapWorkResponse processLogOutRequest(String userName) throws CustomException;
	
	SnapWorkResponse downloadAttendance(String circleId, String startDate, String endDate) throws CustomException;

	SnapWorkResponse isRefreshToKen(SnapWorkRequest request) throws Exception;
}
