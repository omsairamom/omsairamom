package com.airtelbank.admin.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class WhitlelistedPromoterResponse {
		
		@CsvBindByName(column = "UserNumber")
	    @CsvBindByPosition(position = 0)
	    private String userNumber;
	    
		@CsvBindByName(column = "UserName")
		@CsvBindByPosition(position = 1)
	    private String userName;
	    
		@CsvBindByName(column = "UserType")
	    @CsvBindByPosition(position = 2)
	    private String userType;
	    
		@CsvBindByName(column = "Category")
		@CsvBindByPosition(position = 3)
	    private String category;
		
		@CsvBindByName(column = "CircleID")
		@CsvBindByPosition(position = 4)
	    private String circleId;
	    
		@CsvBindByName(column = "Agency")
		@CsvBindByPosition(position = 5)
	    private String agency;
	    
		
	    
		@CsvBindByName(column = "EmpID")
		@CsvBindByPosition(position = 6)
	    private String empid;
	    
		@CsvBindByName(column = "Dob")
		@CsvBindByPosition(position = 7)
	    private String dob;
	    
		@CsvBindByName(column = "Doj")
	    @CsvBindByPosition(position = 8)
	    private String doj;
	    
		@CsvBindByName(column = "SupervisorNumber")
	    @CsvBindByPosition(position = 9)
	    private String supervisorNumber;
	    
		@CsvBindByName(column = "SupervisorType")
	    @CsvBindByPosition(position = 10)
	    private String supervisorType;
	    
		@CsvBindByName(column = "Action")
	    @CsvBindByPosition(position = 11)
	    private String action;
	    
		@CsvBindByName(column = "InterviewerNo")
	    @CsvBindByPosition(position = 12)
	    private String interviewerNo;
	    
		@CsvBindByName(column = "InterviewDate")
	    @CsvBindByPosition(position = 13)
	    private String interviewDate;
	    
		@CsvBindByName(column = "Remarks")
		@CsvBindByPosition(position = 14)
	    private String remarks;
	    
		public String getUserNumber() {
			return userNumber;
		}
		public void setUserNumber(String userNumber) {
			this.userNumber = userNumber;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getUserType() {
			return userType;
		}
		public void setUserType(String userType) {
			this.userType = userType;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getAgency() {
			return agency;
		}
		public void setAgency(String agency) {
			this.agency = agency;
		}
		
		public String getCircleId() {
			return circleId;
		}
		public void setCircleId(String circleId) {
			this.circleId = circleId;
		}
		public String getEmpid() {
			return empid;
		}
		public void setEmpid(String empid) {
			this.empid = empid;
		}
	
		
		public String getSupervisorNumber() {
			return supervisorNumber;
		}
		public void setSupervisorNumber(String supervisorNumber) {
			this.supervisorNumber = supervisorNumber;
		}
		public String getSupervisorType() {
			return supervisorType;
		}
		public void setSupervisorType(String supervisorType) {
			this.supervisorType = supervisorType;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getDoj() {
			return doj;
		}
		public void setDoj(String doj) {
			this.doj = doj;
		}
		public String getInterviewDate() {
			return interviewDate;
		}
		public void setInterviewDate(String interviewDate) {
			this.interviewDate = interviewDate;
		}
		public String getAction() {
			return action;
		}
		public void setAction(String action) {
			this.action = action;
		}
		public String getInterviewerNo() {
			return interviewerNo;
		}
		public void setInterviewerNo(String interviewerNo) {
			this.interviewerNo = interviewerNo;
		}
		
		public String getRemarks() {
			return remarks;
		}
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
	    
	    

}
