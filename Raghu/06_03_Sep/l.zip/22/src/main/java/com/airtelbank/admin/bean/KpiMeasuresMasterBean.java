package com.airtelbank.admin.bean;

public class KpiMeasuresMasterBean {

    private String target;
    private String weightAge;
    private String updatedBy;

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getWeightAge() {
        return weightAge;
    }

    public void setWeightAge(String weightAge) {
        this.weightAge = weightAge;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
}
