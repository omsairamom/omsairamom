package com.airtelbank.admin.bean;

public class KpiCaterogyMasterBean
{
    private String categoryName;
    private String categoryNameDesc;
    private String categoryUpdatedBy;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryNameDesc() {
        return categoryNameDesc;
    }

    public void setCategoryNameDesc(String categoryNameDesc) {
        this.categoryNameDesc = categoryNameDesc;
    }

    public String getCategoryUpdatedBy() {
        return categoryUpdatedBy;
    }

    public void setCategoryUpdatedBy(String categoryUpdatedBy) {
        this.categoryUpdatedBy = categoryUpdatedBy;
    }
}
