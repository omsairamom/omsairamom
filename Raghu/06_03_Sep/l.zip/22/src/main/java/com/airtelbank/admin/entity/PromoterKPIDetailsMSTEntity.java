package com.airtelbank.admin.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "PAPP_KPI_DETAILS_MST")
@EntityListeners(AuditingEntityListener.class)
public class PromoterKPIDetailsMSTEntity {

    @Id
    @Column
    private Long kpiId;

    @Column
    private Long catId;

    @Column
    private String kpiType;

    @Column
    private String kpiDesc;

    @Column
    private String sqlQuery;

    @Column
    private String statusEnable;

    @Column
    private String updatedBy;

    @Column
    private String promoterType;

    @Column
    @CreatedDate
    private LocalDateTime createdDt;

    @Column
    @LastModifiedDate
    private LocalDateTime updatedDt;

    @Column
    private String custom_field1;

    @Column
    private String custom_field2;

    @Column
    private String custom_field3;

    @Column
    private String custom_field4;

    @Column
    private String custom_field5;

}

