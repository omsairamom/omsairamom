package com.airtelbank.admin.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.filters.SimplePatternFileListFilter;
import java.io.File;

@Configuration
@EnableIntegration
public class OutletFileListener {

    private static Logger logger = LoggerFactory.getLogger(WhitelistFileListener.class);

    @Value("${promoter.outlet.file.input.directory.path}")
    private String promoterOutletFileDirectoryPath;
    private String FILE_PATTERN = "*.csv";

    @Autowired
    private OutletFileTransformer transformer;

    @Bean
    public IntegrationFlow outletIntegrationFlow(){
        logger.info("Inside outletIntegrationFlow() method in OutletFileListener class {}:" ,"");
        return IntegrationFlows.from(outletFileReadingMessageSource(),
                sourcePollingChannelAdapterSpec -> sourcePollingChannelAdapterSpec.poller(Pollers.fixedDelay(500)))
                .transform(transformer, "transform")
                .get();

    }

    @Bean
    public MessageSource<File> outletFileReadingMessageSource() {
        logger.info("Inside outletFileReadingMessageSource() method in OutletFileListener class {}:" ,"");
        FileReadingMessageSource sourceReader= new FileReadingMessageSource();
        sourceReader.setDirectory(new File(promoterOutletFileDirectoryPath));
        sourceReader.setFilter(new SimplePatternFileListFilter(FILE_PATTERN));
        sourceReader.setUseWatchService(true);
        sourceReader.setWatchEvents(FileReadingMessageSource.WatchEventType.CREATE);
        return sourceReader;
    }
}
