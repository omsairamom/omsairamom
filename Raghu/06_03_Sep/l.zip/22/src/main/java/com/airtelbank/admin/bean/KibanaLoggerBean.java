package com.airtelbank.admin.bean;

import org.json.JSONObject;

public class KibanaLoggerBean
{
    private String serviceid; //api url
    private String apiId;
    private String custMobileNo; //admin No.  from jwt token
    private String latitude;
	private String longitude; 
    
	private String contentId;
    private String tranId;
    private String amount;
    private String id1; // Promoter no
    private String id2; //outlet no
    private String id3; // outlet type
    private String id4; //file type
    private String id5; //remark
    private String id6; //file status
    private String id7; //file name
    private String id8; //action (A/D)
    private String id9;
    private String id10;
    private String number1; //file total input rows
    private String number2; //file total processed rows
    private String number3; //file process time	
    private String date1;
    private String date2;
    private JSONObject request;//TO SET
    private String response;
    private String respMsg;
    
    private String respDesc; //modify to respDesc // NEW FIELD. // Error description from backend to show on FE
    private String httpStatus; //modify to httpStatus // HTTP status
    private String respCode; //modify to respCode //Status code
    private String expMsg; //NEW FIELD //
	private String expCause; //NEW FIELD
	private String  expLocalMsg; //NEW FILED
    private long totalTime; //API time
    
   


    public JSONObject getRequest() {
        return request;
    }

    public void setRequest(JSONObject request) {
        this.request = request;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getServiceid() {
        return serviceid;
    }

    public void setServiceid(String serviceid) {
        this.serviceid = serviceid;
    }

    public String getApiId() {
        return apiId;
    }

    public void setApiId(String apiId) {
        this.apiId = apiId;
    }

    public String getCustMobileNo() {
        return custMobileNo;
    }

    public void setCustMobileNo(String custMobileNo) {
        this.custMobileNo = custMobileNo;
    }

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public String getTranId() {
        return tranId;
    }

    public void setTranId(String tranId) {
        this.tranId = tranId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getId1() {
        return id1;
    }

    public void setId1(String id1) {
        this.id1 = id1;
    }

    public String getId2() {
        return id2;
    }

    public void setId2(String id2) {
        this.id2 = id2;
    }

    public String getId3() {
        return id3;
    }

    public void setId3(String id3) {
        this.id3 = id3;
    }

    public String getId4() {
        return id4;
    }

    public void setId4(String id4) {
        this.id4 = id4;
    }

    public String getId5() {
        return id5;
    }

    public void setId5(String id5) {
        this.id5 = id5;
    }

    public String getId6() {
        return id6;
    }

    public void setId6(String id6) {
        this.id6 = id6;
    }

    public String getId7() {
        return id7;
    }

    public void setId7(String id7) {
        this.id7 = id7;
    }

    public String getId8() {
        return id8;
    }

    public void setId8(String id8) {
        this.id8 = id8;
    }

    public String getId9() {
        return id9;
    }

    public void setId9(String id9) {
        this.id9 = id9;
    }

    public String getId10() {
        return id10;
    }

    public void setId10(String id10) {
        this.id10 = id10;
    }

    public String getNumber1() {
        return number1;
    }

    public void setNumber1(String number1) {
        this.number1 = number1;
    }

    public String getNumber2() {
        return number2;
    }

    public void setNumber2(String number2) {
        this.number2 = number2;
    }

    public String getNumber3() {
        return number3;
    }

    public void setNumber3(String number3) {
        this.number3 = number3;
    }

    public String getDate1() {
        return date1;
    }

    public void setDate1(String date1) {
        this.date1 = date1;
    }

    public String getDate2() {
        return date2;
    }

    public void setDate2(String date2) {
        this.date2 = date2;
    }

    public String getRespMsg() {
        return respMsg;
    }

    public void setRespMsg(String respMsg) {
        this.respMsg = respMsg;
    }

   
    public String getRespDesc() {
		return respDesc;
	}

	public void setRespDesc(String respDesc) {
		this.respDesc = respDesc;
	}

	public String getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(String httpStatus) {
		this.httpStatus = httpStatus;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getExpMsg() {
		return expMsg;
	}

	public void setExpMsg(String expMsg) {
		this.expMsg = expMsg;
	}

	public String getExpCause() {
		return expCause;
	}

	public void setExpCause(String expCause) {
		this.expCause = expCause;
	}

	public String getExpLocalMsg() {
		return expLocalMsg;
	}

	public void setExpLocalMsg(String expLocalMsg) {
		this.expLocalMsg = expLocalMsg;
	}

	public long getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(long totalTime) {
        this.totalTime = totalTime;
    }
    public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}


}
