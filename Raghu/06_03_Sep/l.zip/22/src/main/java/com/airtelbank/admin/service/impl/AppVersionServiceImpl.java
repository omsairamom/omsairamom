package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.AppVersionDAO;
import com.airtelbank.admin.service.AppVersionService;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AppVersionServiceImpl implements AppVersionService {
    @Autowired
    PropertyManager prop;

    @Autowired
    AppVersionDAO appVersionDao;

    @Autowired
    SnapWorkResponse response;

    @Autowired
    SnapWorkRequest request;

    private static Logger logger = LoggerFactory.getLogger(AppVersionServiceImpl.class);

    @SuppressWarnings({"rawtypes", "unchecked"})
    public SnapWorkResponse onLoadAppVersionDetails(SnapWorkRequest request)
    {
        JSONArray appVerJsonArray = new JSONArray();
        JSONObject json = new JSONObject();
        List<Map<String, Object>> rows = null;

        try
        {
            String userName = request.getUserName() == null ? "" : request.getUserName().trim();

            logger.info("Inside onLoadAppVersionDetails() method in AppVersionServiceImpl class {}:" ,"");

            if (StringUtils.isNotBlank(userName))
            {
                rows = appVersionDao.fetchAppVersionDetails();
                logger.info("APPVER_FETCH_USERAGNT_DTLS rows: {} for username: {}:"  ,rows.size(),userName);

                if (rows != null && !rows.isEmpty())
                {
                    logger.info("APPVER_FETCH_USERAGNT_DTLS rows: {}:"  ,rows.size());

                    for (Map row : rows)
                    {
                        logger.info("onLoadAppVersionDetails() setting appVerJsonObj :{} for username: {}:"  ,row,userName);
                        JSONObject appVerJsonObj = new JSONObject();
                        appVerJsonObj.put("userAgent", row.get("USER_AGENT") == null ? "" : row.get("USER_AGENT").toString());
                        appVerJsonObj.put("appVersion", row.get("APP_VERSION") == null ? "" : row.get("APP_VERSION").toString());
                        appVerJsonObj.put("loadFlag", row.get("LOAD_FLAG") == null ? "" : row.get("LOAD_FLAG").toString());
                        appVerJsonObj.put("mandatoryFlag", row.get("MANDATORY") == null ? "" : row.get("MANDATORY").toString());
                        appVerJsonObj.put("message", row.get("APP_MESSAGE") == null ? "" : row.get("APP_MESSAGE").toString());
                        appVerJsonObj.put("url", row.get("URL") == null ? "" : row.get("URL").toString());
                        appVerJsonArray.add(appVerJsonObj);
                    }

                    json.put("appVersion", appVerJsonArray);
                }

                response.setMessage(prop.getProperty(Constants.APPVER_FETCH_DTLS_SUCC_MSG));
                response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                response.setResponse(json);
                logger.info("Success Response generated:{} for username: {}:", "", userName);
            }
            else
            {
                logger.error("onLoadAppVersionDetails() User name is blank: {} for username: {}:" , "" ,userName);
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }
            logger.info("onLoadAppVersionDetails() Response generated: {} for username: {}:" , "",userName);
            return response;
        }
        catch (Exception exe)
        {
            logger.error("onLoadAppVersionDetails() Internal Exception {}, {}:" , exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            return response;
        }
    }
}