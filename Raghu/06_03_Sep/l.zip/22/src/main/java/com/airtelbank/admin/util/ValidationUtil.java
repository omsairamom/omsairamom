package com.airtelbank.admin.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ValidationUtil {
	
	
	//Validates to true if phone number of 10 digits
	public static boolean validatePhoneNumber(String phonenumber)
	{
		String expression = "\\d{10}";
		return phonenumber.matches(expression);		
	}
	
	
	//Validates to true if name contain only alphabets and space
	public static boolean validateName(String name)
	{
		String expression = "[a-zA-Z ]*$";
		return name.matches(expression);
			
	}
	
	
	//Validates if the input date format is dd-MMM-yy or not (MMM like Jun/Jul and not JUN/JUL or jun/jul)
	public static boolean validDateFormat(String date) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		formatter.setLenient(false);
		try {
			formatter.parse(date);
		} catch (ParseException e) {
			return false;
		}
		return true;

	}

}
