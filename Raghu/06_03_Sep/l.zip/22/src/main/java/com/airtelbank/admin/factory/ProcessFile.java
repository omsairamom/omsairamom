package com.airtelbank.admin.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.airtelbank.admin.bean.KibanaLoggerBean;
import com.airtelbank.admin.dao.PromoterUploadFileAuditDao;
import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import com.airtelbank.admin.enums.FileStatus;
import com.airtelbank.admin.enums.FileType;
import com.airtelbank.admin.service.FileProcessingService;
import com.airtelbank.admin.service.impl.AsyncFileProcessor;
import com.airtelbank.admin.util.KibanaLoggerUtils;

@Component
public class ProcessFile {
	
	private static Logger logger = LoggerFactory.getLogger(ProcessFile.class);
	
	@Autowired
	private PromoterUploadFileAuditDao promoterUploadFileAuditDao;
	
	@Autowired
	private AsyncFileProcessor asyncFileProcessor;
	
	@Autowired
	private ProcessFileFactory processFileFactory;
	
	@Value("${promoter.outlet.file.processing.directory.path}")
	private String inputFilePathDirOutlet;
	
	@Value("${promoter.whitelist.file.processing.directory.path}")
	private String inputFilePathDirWhitelist;
	
	@Value("${promoter.outlet.file.output.directory.path}")
	private String outputFilePathDirOutlet;
	
	@Value("${promoter.whitelist.file.output.directory.path}")
	private String outputFilePathDirWhitelist;
	
	@Autowired
	private KibanaLoggerUtils kibanaUtils;
	
	
	
	public void processFile(String filename, int type) throws Exception {
		
		logger.info("ProcessFile : Inside processFile() : start");
		
		String status= "";	
		long startTime = 0;
	    long endTime = 0;
	    long elapsedTimeMillis = 0;
		
    	//Get status of file
    	PromoterUploadFileAuditEntity file =null;
    	try {
    	file = promoterUploadFileAuditDao.fetchFileByName(filename);}
    	catch(Exception e)
    	{
    		logger.error("ProcessFile | processFile() | Exception while fetching the file. Message {} Cause {}",e.getMessage(),e.getCause());
    		return;
    	}
    	
    	if(null == file)
    	{
    		logger.info("ProcessFile | processFile() |  No file found by name. Filename ",filename);
    		return;
    	}
    	
    	status = file.getStatus(); 
    	
    	//Get Impl instance to process file based on type
    	FileProcessingService fileProcessingService = processFileFactory.getFileProcessor(type);
    	
    
    	//If status is pending we will proceed further else if status is processed, in progress, failed - do nothing
    	if(status.equalsIgnoreCase(FileStatus.PENDING.name()) && null!=fileProcessingService)
    	{
    		
    		//put the file in progress status
    		file.setStatus(FileStatus.IN_PROGRESS.name());
    		startTime = System.currentTimeMillis();
    		if(file.getType().equalsIgnoreCase(FileType.Pr_whitelisting.name()))
    			file.setLocation(inputFilePathDirWhitelist);
    		else
    			file.setLocation(inputFilePathDirOutlet);
    		
    		asyncFileProcessor.updateFile(file);
    		populateKibanaLoggingObject(file);
    			
    		//process the file
    		fileProcessingService.processFile(filename,type,file);
    		
    		endTime=System.currentTimeMillis();
    		elapsedTimeMillis = endTime-startTime;
    		file.setProcessTime(elapsedTimeMillis);
    		
    		//update the file status to processed
    		file.setStatus(FileStatus.PROCESSED.name());
    		if(file.getType().equalsIgnoreCase(FileType.Pr_whitelisting.name()))
    			file.setLocation(outputFilePathDirWhitelist);
    		else
    			file.setLocation(outputFilePathDirOutlet);
    		asyncFileProcessor.updateFileInSync(file);
    		populateKibanaLoggingObject(file);
        				
    	}
    	
    	
    	logger.info("ProcessFile : Inside processFile() : end");
	}


	private void populateKibanaLoggingObject(PromoterUploadFileAuditEntity file) {
		KibanaLoggerBean kb = new KibanaLoggerBean();
		kb.setId4(file.getType());
		kb.setId6(file.getStatus());
		kb.setId7(file.getFileName());
		kb.setNumber1(String.valueOf(file.getTotalRecords()));
		kb.setNumber2(String.valueOf(file.getProcessedRecords()));
		kb.setNumber3(String.valueOf(file.getProcessTime()));
		kibanaUtils.printKibanaLogs(kb);
	}
}
