package com.airtelbank.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.airtelbank.admin.entity.PromoterOutletMSTEntity;

@Repository
public interface PromoterOutletMSTRepository extends JpaRepository<PromoterOutletMSTEntity, Long> {

	public  PromoterOutletMSTEntity findOneByOutletNoAndOutletType(String outletphoneNumber, String outletType);
}
