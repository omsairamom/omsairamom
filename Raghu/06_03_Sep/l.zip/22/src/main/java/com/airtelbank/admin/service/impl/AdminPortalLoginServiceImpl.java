package com.airtelbank.admin.service.impl;


import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.*;

import com.airtelbank.admin.dao.PromoterUserProfileMSTDAO;
import com.airtelbank.admin.entity.PromoterLoginTrackerAuditEntity;
import com.airtelbank.admin.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.admin.jwt.AeroCache;
import com.airtelbank.admin.util.*;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtelbank.admin.bean.AdminLoginInfoTrackerBean;
import com.airtelbank.admin.bean.AttendanceBean;
import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.AdminPortalLoginDAO;
import com.airtelbank.admin.jwt.CommonJWTUtil;
import com.airtelbank.admin.jwt.JTIToken;
import com.airtelbank.admin.service.AdminPortalLoginService;
import com.airtelbank.admin.encryption.EncryptionRSA;

import javax.annotation.PostConstruct;


@Service
public class AdminPortalLoginServiceImpl implements AdminPortalLoginService {

    private static Logger logger = LoggerFactory.getLogger(AdminPortalLoginServiceImpl.class);
    private static final String PUB_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnsUrIe1pCJLoggVpXwd3GWeoX+Fc6uAYUkPrgrewiXh8995uTPVKzfJAy5ioqFmOfpXKIuaFGd4wS/BraLlHxtM+/qvAkreDKmLaBYqn0p3EaEwKUIPXx4LATA9Uip3WZMmZ08ToHwJY8pCkDqWLyHJt45f6j2WLPwom45e+bO7UvUv1lhSxWCNuD8KbwPrhwKUOiY5PL+PSMgSyMnTVOMQICF5X8JSRFzTdwbNls/LFrDqBOxjj26QvL2oo9IYWsClrfupILFl5M6exxY2QATqF8En/LnD4eiow1I4Wt8scYmvplS22Upbwartf/9MB0gufXriA2vEl+QaB+j46OQIDAQAB";
    private String setName = "SESSION_MGMT";
    private  static final String nullException = "request can not be null";
    int count = 0;

    @Autowired
    AeroCache aeroCache;
    @Autowired
    PropertyManager prop;

    @Autowired
    AdminPortalLoginDAO adminLoginDao;

    @Autowired
    PromoterUserProfileMSTDAO promoterUserProfileMSTDAO;

    @Autowired
    SnapWorkResponse response;

    @Autowired
    RestClientUtil restClient;

    @Autowired
    SnapWorkRequest request;

    @Autowired
    CommonJWTUtil commonJwtUtil;

    @Autowired
    CommonUtils commonUtil;

    @Autowired
    JTIToken jtiToken;

    @Autowired
    SecureBuilderVer secureBuilderVer;

    private static Map<Integer, Integer> attemptToBlockTimeMap = new HashMap<>();
    private static Integer minWrongAttemptToBlock = 15;
    private static Integer maxWrongAttemptToBlock = 15;
    private static Integer blockTimeOnMaxWrongLogin = 15;


    @PostConstruct
    public void populateBlockTimerWithAttemptCountMap() {

        String attemptsToBlockTimeMap = prop.getProperty("ATTEMPTS_TO_BLOCK_TIME_IN_MINUTE_MAP");
        if(attemptsToBlockTimeMap==null)
            attemptsToBlockTimeMap= "3:15,4:15,5:15";
        minWrongAttemptToBlock = Integer.parseInt(attemptsToBlockTimeMap.split(",")[0].split(":")[0]);
        for (String token : attemptsToBlockTimeMap.split(",")) {
            attemptToBlockTimeMap.put(Integer.parseInt(token.split(":")[0]), Integer.parseInt(token.split(":")[1]));
            maxWrongAttemptToBlock = Integer.parseInt(token.split(":")[0]);
            blockTimeOnMaxWrongLogin = Integer.parseInt(token.split(":")[1]);
        }

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public SnapWorkResponse adminLoginDetails(String userName, String password, SnapWorkRequest request) {
        JSONObject json = new JSONObject();

        try {
            if (request == null) {
                throw new Exception(nullException);
            }

            logger.info("Inside adminLoginDetails() method in AdminPortalLoginServiceImpl class..");

            if (userName.isEmpty() || password.isEmpty()) {
                logger.info("adminLoginDetails() mobileNo/device id is blank: {} for mobileNo {} :", "",userName);
                // return Invalid Creds
                return loginFailedMessage(userName, response, json);
            }

            Optional<PromoterUserProfileMSTEntity> promoterUserProfileMSTEntity = adminLoginDao.validateAdminLoginDetails_V2(userName, password);

            if (!promoterUserProfileMSTEntity.isPresent()) {
                logger.info("adminLoginDetails() User is not present in promoterUserProfileMSTEntity: {} for userName {} :", "",userName);
                // return Error
                return loginFailedMessage(userName, response, json);
            }
            String dbUserName = promoterUserProfileMSTEntity.get().getUserNo();
            String dbEncPassword = promoterUserProfileMSTEntity.get().getPassword();
            String generatedEncPassword = EncryptionUtil.generateEncryptPassword(password, userName);
            String adminType = promoterUserProfileMSTEntity.get().getUserType();
            String channel = promoterUserProfileMSTEntity.get().getChannel();

            PromoterUserProfileMSTEntity promoterProfile = promoterUserProfileMSTEntity.get();

            if (generatedEncPassword.equals(dbEncPassword) && channel.equalsIgnoreCase("PADMIN")) {
                logger.info("adminLoginDetails() password is correct for userName {} :", userName);
                // If Unblocked or BlockTime is passed
                if (promoterProfile.getBlockExpiryDate() == null || promoterProfile.getBlockExpiryDate().isBefore(LocalDateTime.now())) {
                    logger.info("adminLoginDetails() user Unblocked or BlockTime is passed for userName {} :", userName);
                    // Reset attempt to 0 and Expiry Null.
                    adminLoginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, 0, null);
                    promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                    return proceedLogin(response, userName, dbUserName, adminType);

                }
                // If already blocked
                if (promoterProfile.getBlockExpiryDate() != null &&
                        promoterProfile.getBlockExpiryDate().isAfter(LocalDateTime.now())) {
                    logger.info("adminLoginDetails()  already blocked for userName {} :", userName);
                    // return Temporary Block Error
                    return loginBlockedMessage(response, json);
                }

            } else {

                logger.error("adminLoginDetails() Password is Incorrect for userName {} :", userName);

                int totalWrongAttempts = promoterProfile.getAttempts() + 1;

                if (promoterProfile.getBlockExpiryDate() == null) {
                    logger.info("adminLoginDetails() BlockExpirytime is null for userName {} :", userName);

                    // First time crossing Min Wrong Attempt
                    if (totalWrongAttempts >= minWrongAttemptToBlock) {
                        logger.info("adminLoginDetails() First time crossing Min Wrong Attempt(3): {} for userName {} :", totalWrongAttempts, userName);
                        //increaseAttemptAndSetBlockExpiryTime
                        adminLoginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, totalWrongAttempts, LocalDateTime.now().plusMinutes(attemptToBlockTimeMap.getOrDefault(minWrongAttemptToBlock, 15)));
                        promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                        // return block message
                        return loginBlockedMessage(response, json);

                    } else {
                        logger.info("adminLoginDetails() Wrong Attempts less than min wrong attempts to block: {} for userName {} :", totalWrongAttempts, userName);
                        //increment Attempt Only.
                        adminLoginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, totalWrongAttempts, null);
                        promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                        // Return server error
                        return loginFailedMessage(userName, response, json);
                    }

                }

                // If Unblocked or BlockTime is passed
                if (promoterProfile.getBlockExpiryDate() != null && promoterProfile.getBlockExpiryDate().isBefore(LocalDateTime.now())) {
                    logger.info("adminLoginDetails() Unblocked or BlockTime is passed for mobileNo {} :", userName);
                    //resetBlockCounterTo1AndBlockExpiryNull()
                    adminLoginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, 1, null);
                    promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                    // Return Temp Block Error
                    return loginFailedMessage(userName, response, json);
                }

                // If already blocked
                if (promoterProfile.getBlockExpiryDate() != null && promoterProfile.getBlockExpiryDate().isAfter(LocalDateTime.now())) {
                    logger.info("adminLoginDetails() Already blocked and Wrong Attempts more than min wrong attempts to block: {} for mobileNo {} :", totalWrongAttempts, userName);
                    // incrementAttemptAndUpdateBlockExpiry
                    //     LocalDateTime newBlockExpiry = promoterProfile.getBlockExpiryDate().plusMinutes(attemptToBlockTimeMap.getOrDefault(totalWrongAttempts, blockTimeOnMaxWrongLogin));
                    LocalDateTime newBlockExpiry = LocalDateTime.now().plusMinutes(attemptToBlockTimeMap.getOrDefault(totalWrongAttempts, blockTimeOnMaxWrongLogin));

                    adminLoginDao.setBlockCounterToXAndBlockExpiryY(promoterProfile, totalWrongAttempts, newBlockExpiry);
                    promoterUserProfileMSTDAO.saveUserProfile(promoterProfile);
                    // Return server error
                    return loginBlockedMessage(response, json);

                }
            }

            logger.info("adminLoginDetails() Response generated:  {} for userName: {} :", "", userName);
            return response;
        } catch (Exception exe) {
            logger.error("adminLoginDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            commonUtil.exceptionHandler(prop, exe, response, json);
            return response;
        }

    }
    private SnapWorkResponse loginFailedMessage(String mobileNo, SnapWorkResponse response, JSONObject json) {

        logger.error("adminLoginDetails() method {}:", "Invalid password");
        response.setMessage(prop.getProperty(Constants.ADMIN_LOGIN_INVALID_PASSWD_MSG));
        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
        response.setResponse(json);
        return response;
    }

    private SnapWorkResponse loginBlockedMessage(SnapWorkResponse response, JSONObject json) {
        logger.error("Account is temporarily blocked. Please try after some time: {} :", "");
        response.setStatusCode(prop.getProperty(Constants.WRONG_ATTEMPT_STATUS_CODE));
        response.setMessage(prop.getProperty(Constants.USER_BLOCKED_FOR_WRONG_ATTEMPT));
        response.setResponse(json);
        return response;
    }

    public SnapWorkResponse proceedLogin(SnapWorkResponse response, String userName, String dbUserName, String adminType) {

        JSONObject json = new JSONObject();

        if (StringUtils.isNotBlank(adminType)) {
            json.put("adminType", adminType);
        } else {
            json.put("adminType", "");
        }

        String jwtToken = "";
        // Updating JWT Token
        //  adminLoginDao.updateJWT(jwtToken, userName);
        String jwtFlag = prop.getProperty("JWT_FLAG");

        if (StringUtils.isNotBlank(jwtFlag) && jwtFlag.equalsIgnoreCase("Y")) {
            jwtToken = commonJwtUtil.generateJwtToken(userName, 0, "mobile");
            json.put("jwtToken", jwtToken);
        } else {
            jwtToken = "NA";
            json.put("jwtToken", jwtToken);
        }

        // Updating JWT Token

        if (StringUtils.isNotBlank(jwtToken)) {

            json.put("userName", dbUserName);
            response.setMessage(prop.getProperty(Constants.ADMIN_LOGIN_USER_SUCC_MSG));
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
            response.setResponse(json);
            logger.info("Success Response generated :  {} for userName: {} :", "", userName);
            PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity =
                    ProObjectHelper.getObjForLogInOutTracker(userName, "", "", "1", "", "PADMIN");
            try {
                PromoterLoginTrackerAuditEntity saveResp =
                        adminLoginDao.saveLoginAndLogOutDetails_V2(promoterLoginTrackerAuditEntity);
            }
            catch (Exception e){
                logger.error("Exception while saving login tracker:{}", e.getStackTrace());
            }
        } else {
            logger.error("adminLoginDetails() method {}:", "JWT token generation failed");
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.LOGIN_JWT_TOKEN_GEN_FAILED));
            response.setResponse(json);
        }
        return response;
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public SnapWorkResponse sendOTP(String mobileNo, SnapWorkRequest request) {

        JSONObject json = new JSONObject();

        try {
            logger.info("Inside sendOTP() method in AdminPortalLoginServiceImpl class.. {}:", "");

            if (mobileNo == null) {
                throw new Exception("mobileNo can not ne null");
            }

            if (StringUtils.isNotBlank(mobileNo)) {

                logger.info("sendOTP() setting sendOtpJsonReq :{}", mobileNo);
                JSONObject sendOtpJsonReq = new JSONObject();
                sendOtpJsonReq.put("ver", "1.0");
                sendOtpJsonReq.put("feSessionId", RestClientUtil.generateFeSessionID());
                sendOtpJsonReq.put("languageId", "001");
                sendOtpJsonReq.put("customerId", mobileNo);
                sendOtpJsonReq.put("custType", "SBA");
                sendOtpJsonReq.put("requestType", "ONBOARDING");
                sendOtpJsonReq.put("partnerId", "84657");
                sendOtpJsonReq.put("reference1", "");
                sendOtpJsonReq.put("reference2", "");
                sendOtpJsonReq.put("reference3", "");
                sendOtpJsonReq.put("reference4", "");
                sendOtpJsonReq.put("reference5", "");

                String reqParams = new EncryptionRSA().simpleEncrypt(sendOtpJsonReq.toString(),
                        Base64.decodeBase64(PUB_KEY));
                String url = prop.getProperty("API_SEND_OTP_URL");
                String apiResponse = restClient.sendPostRequest(url, reqParams);

                if (StringUtils.isNotBlank(apiResponse)) {
                    logger.info("sendOTP() apiResponse {}:", apiResponse);
                    JSONParser parser = new JSONParser();
                    JSONObject jsonApiResObj = (JSONObject) parser.parse(apiResponse);
                    logger.info("Send OTP Respose {}:", jsonApiResObj);
                    JSONObject jsonMetaObj = (JSONObject) jsonApiResObj.get("meta");
                    JSONObject jsonDataObj = (JSONObject) jsonApiResObj.get("data");

                    if (jsonMetaObj.containsKey("status") && jsonMetaObj.containsKey("code")) {
                        logger.info("line no 265 {}:", "");
                        if (jsonMetaObj.get("code").equals("000") && jsonDataObj.containsKey("verificationToken")) {
                            logger.info("line no 267 {}:", "");
                            json.put("mobileNo", mobileNo);
                            json.put("otpVerficatonCode", jsonDataObj.get("verificationToken") == null ? ""
                                    : jsonDataObj.get("verificationToken"));
                            response.setMessage(prop.getProperty("ADMIN_SEND_OTP_SUCC_MSG"));
                            response.setStatusCode(prop.getProperty("SUCCESS_STATUS_CODE"));
                            response.setResponse(json);
                            logger.info("Success Response generated:  {} for mobileNo: {} :", "", mobileNo);

                        } else {

                            json.put("mobileNo", mobileNo);
                            String errorMessage = jsonMetaObj.get("description") == null ? ""
                                    : (String) jsonMetaObj.get("description");
                            response.setMessage(errorMessage);
                            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                            response.setResponse(json);
                        }
                    } else {
                        response.setMessage(prop.getProperty(Constants.ADMIN_SEND_OTP_FAIL_MSG));
                        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                        response.setResponse(json);
                    }

                } else {
                    logger.error("sendOTP() apiResponse is blank:  {} for mobileNo: {} :", "", mobileNo);
                    response.setMessage(prop.getProperty(Constants.ADMIN_SEND_OTP_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setResponse(json);
                }

            } else {
                logger.error("sendOTP() mobile No. is blank:  {} for mobileNo: {} :", "", mobileNo);
                response.setMessage(prop.getProperty(Constants.ADMIN_SEND_OTP_FAIL_MSG));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("sendOTP() Response generated:  {} for mobileNo: {} :", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("sendOTP() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public SnapWorkResponse fetchCircleDetails(String mobileNo, SnapWorkRequest request) {
        JSONArray jsonArray = new JSONArray();
        JSONObject json = new JSONObject();

        try {
            logger.info("Inside fetchCircleDetails() method in AdminPortalLoginServiceImpl class..{}:", "");

            if (request == null) {
                throw new Exception(nullException);
            }

            if (StringUtils.isNotBlank(mobileNo)) {
                List<Map<String, Object>> rows = adminLoginDao.getCircleMasterDetails();
                logger.info("ADMIN_FETCH_CIRCLE_MST_DTLS rows.size():  {} for mobileNo: {} :", rows.size(), mobileNo);

                if (rows != null && !rows.isEmpty()) {
                    for (Map row : rows) {
                        logger.info("fetchCircleDetails() setting jsonObj :{}", row);
                        JSONObject jsonObj = new JSONObject();
                        jsonObj.put("circleName",
                                row.get("CIRCLE_NAME") == null ? "" : row.get("CIRCLE_NAME").toString());
                        jsonObj.put("circleCode",
                                row.get("CIRCLE_CODE") == null ? "" : row.get("CIRCLE_CODE").toString());
                        jsonObj.put("circleId", row.get("CIRCLE_ID") == null ? "" : row.get("CIRCLE_ID").toString());
                        jsonArray.add(jsonObj);
                    }
                    json.put("circleDetails", jsonArray);
                    response.setMessage(prop.getProperty(Constants.ADMIN_FETCH_CIRCLE_MST_DTLS_SUCC_MSG));
                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setResponse(json);
                    logger.info("Success Response generated:  {} for mobileNo: {} :", "", mobileNo);
                } else {
                    logger.error("fetchCircleDetails() Circle details not fetched :  {} for mobileNo: {} :", "", mobileNo);
                    response.setMessage(prop.getProperty(Constants.ADMIN_FETCH_CIRCLE_MST_DTLS_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setResponse(json);
                }

            }
            logger.info("fetchCircleDetails() Response generated:  {} for mobileNo: {} :", "", mobileNo);
            return response;

        } catch (Exception exe) {
            logger.error("fetchCircleDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public SnapWorkResponse dashboardAttendanceDetails(SnapWorkRequest request) {

        JSONArray jsonArray = new JSONArray();
        JSONObject json = new JSONObject();

        try {
            logger.info("Inside dashboardAttendanceDetails() method in AdminPortalLoginServiceImpl class..{}:", "");

            if (request == null) {
                throw new Exception(nullException);
            }

            String startDate = request.getStartDate().trim();
            String endDate = request.getEndDate().trim();

            if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {

                List<Map<String, Object>> rows = adminLoginDao.fetchAttendanceDataDetails(request);
                logger.info("ADMIN_FETCH_CIRCLE_WITH_DATE_ATTEND_DTLS rows.size() {}:", rows.size());

                if (rows != null && !rows.isEmpty()) {
                    for (Map row : rows) {
                        logger.info("dashboardAttendanceDetails() setting jsonObj :{}", row);
                        JSONObject jsonObj = new JSONObject();
                        String mobileNo = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
                        jsonObj.put("mobileNo", row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString());
                        jsonObj.put("name", row.get("USER_NAME") == null ? "" : row.get("USER_NAME").toString());
                        jsonObj.put("date", row.get("ATT_DATETIME") == null ? "" : row.get("ATT_DATETIME").toString());
                        String attendanceDate = row.get("ATT_DATETIME") == null ? ""
                                : row.get("ATT_DATETIME").toString();
                        jsonObj.put("outletVisited",
                                String.valueOf(adminLoginDao.getOutletVisistedCount(attendanceDate, mobileNo)));
                        jsonObj.put("distance", String.valueOf(calculateDistance(attendanceDate, mobileNo)));
                        jsonObj.put("duration", "");
                        jsonArray.add(jsonObj);
                    }

                    json.put("attendance", jsonArray);
                    response.setMessage(prop.getProperty(Constants.ADMIN_FETCH_ATTEND_DTLS_SUCC_MSG));
                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setResponse(json);
                    logger.info("Success Response generated {}:", "");
                } else {
                    logger.error("dashboardAttendanceDetails() startDate/EndDate is blank {}:", "");
                    response.setMessage(prop.getProperty(Constants.ADMIN_FETCH_ATTEND_DTLS_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setResponse(json);
                }
            }
            logger.info("dashboardAttendanceDetails() Response generated {}:", "");
            return response;

        } catch (Exception exe) {
            logger.error("dashboardAttendanceDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings({"unchecked"})
    public SnapWorkResponse resetPassword(String userName, String password, SnapWorkRequest request) {

        JSONObject json = new JSONObject();

        try {
            logger.info("Inside resetPassword() method in AdminPortalLoginServiceImpl class..{}:", "");
            if (request == null) {
                throw new Exception(nullException);
            }

            logger.info("Inside resetPassword() method in AdminPortalLoginServiceImpl class..{}:", "");

            if (StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(password)) {
                String encPassword = EncryptionUtil.generateEncryptPassword(password, userName);
                logger.info("encPassword : {}  for mobileNo: {} :", encPassword, userName);
                int updateCount = adminLoginDao.updateAdminPasswordDetails(userName, encPassword);
                logger.info("updateCount :  {} for mobileNo: {} :", updateCount, userName);

                if (updateCount > 0) {
                    json.put("userName", userName);
                    response.setMessage(prop.getProperty(Constants.ADMIN_RESET_PASSWD_SUCC_MSG));
                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setResponse(json);
                    logger.info("Success Response generated :  {} for mobileNo: {} :", "", userName);
                } else {
                    logger.error("resetPassword() Password not resetted :  {} for mobileNo: {} :", "", userName);
                    response.setMessage(prop.getProperty(Constants.ADMIN_RESET_PASSWD_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setResponse(json);
                }

            }
            logger.info("resetPassword() Response generated :  {} for mobileNo: {} :", "", userName);
            return response;

        } catch (Exception exe) {
            logger.error("resetPassword() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public SnapWorkResponse verifyOTP(String mobileNo, String otpVerificationCode, String otp, SnapWorkRequest request) {

        JSONObject json = new JSONObject();

        try {
            logger.info("Inside verifyOTP() method in AdminPortalLoginServiceImpl class..{}:", "");

            if (mobileNo == null) {
                throw new Exception("mobileNo can not ne null");
            }

            if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNotBlank(otpVerificationCode)
                    && StringUtils.isNotBlank(otp)) {

                JSONObject verifyOtpJsonReq = new JSONObject();
                verifyOtpJsonReq.put("ver", "1.0");
                verifyOtpJsonReq.put("feSessionId", RestClientUtil.generateFeSessionID());
                verifyOtpJsonReq.put("languageId", "001");
                verifyOtpJsonReq.put("customerId", mobileNo);
                verifyOtpJsonReq.put("custType", "SBA");
                verifyOtpJsonReq.put("requestType", "ONBOARDING");
                verifyOtpJsonReq.put("partnerId", "84657");
                verifyOtpJsonReq.put("reference1", "");
                verifyOtpJsonReq.put("reference2", "");
                verifyOtpJsonReq.put("reference3", "");
                verifyOtpJsonReq.put("reference4", "");
                verifyOtpJsonReq.put("reference5", "");
                verifyOtpJsonReq.put("verificationToken", otpVerificationCode);
                verifyOtpJsonReq.put("otpCode", otp);

                String reqParams = new EncryptionRSA().simpleEncrypt(verifyOtpJsonReq.toString(),
                        Base64.decodeBase64(PUB_KEY));
                String url = prop.getProperty("API_VERIFY_OTP_URL");
                String apiResponse = restClient.sendPostRequest(url, reqParams);

                if (StringUtils.isNotBlank(apiResponse)) {
                    logger.info("line no 344 {}:", "");
                    JSONParser parser = new JSONParser();
                    JSONObject jsonApiResObj = (JSONObject) parser.parse(apiResponse);
                    logger.info("Verify OTP Response {}:", jsonApiResObj);
                    JSONObject jsonMetaObj = (JSONObject) jsonApiResObj.get("meta");

                    if (jsonMetaObj.containsKey("status") && jsonMetaObj.containsKey("code")) {
                        logger.info("line no 351 {}:", "");
                        if (jsonMetaObj.get("code").equals("000") && jsonMetaObj.containsKey("description")
                                && jsonMetaObj.get("description").equals("OTP verified")) {
                            logger.info("line no 353 {}:", "");
                            json.put("mobileNo", mobileNo);
                            response.setMessage(prop.getProperty(Constants.ADMIN_VERIFY_OTP_SUCC_MSG));
                            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                            response.setResponse(json);
                            logger.info("Success Response generated :  {} for mobileNo: {} :", "", mobileNo);
                        } else {
                            logger.info("line no 361 {}:", "");
                            json.put("mobileNo", mobileNo);
                            String errorMessage = jsonMetaObj.get("description") == null ? ""
                                    : (String) jsonMetaObj.get("description");
                            response.setMessage(errorMessage);
                            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                            response.setResponse(json);
                        }
                    } else {
                        response.setMessage(prop.getProperty(Constants.ADMIN_VERIFY_OTP_FAIL_MSG));
                        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                        response.setResponse(json);
                    }

                } else {
                    logger.error("verifyOTP() apiResponse is blank:  {} for mobileNo: {} :", "", mobileNo);
                    response.setMessage(prop.getProperty(Constants.ADMIN_VERIFY_OTP_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setResponse(json);
                }
            } else {
                logger.error("verifyOTP() mobile No./otp/otpVerficationCode is blank:  {} for mobileNo: {} :", "", mobileNo);
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_RESPONSE_CODE));
                response.setResponse(json);
            }

            logger.info("verifyOTP() Response generated:  {} for mobileNo: {} :", "", mobileNo);
            return response;
        } catch (Exception exe) {
            logger.error("verifyOTP() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    public SnapWorkResponse downloadAttendance(String circleId, String startDate, String endDate) {

        JSONObject json = new JSONObject();
        StringBuilder data = new StringBuilder();

        try {
            logger.info("Inside download attendance () method in AdminPortalLoginServiceImpl class.. {}:", "");

            String[] CSV_HEADER = new String[]{"Name", "MobileNo", "Date", "OutletVisited", "Distance",
                    "Duration"};

            for (int i = 0; i < CSV_HEADER.length; i++) {
                data = data.append(CSV_HEADER[i]);

                if (CSV_HEADER.length - 1 == i) {
                    data = data.append("\n");
                } else {
                    data = data.append(",");
                }
            }

            List<AttendanceBean> getAttendanceBeanList = getAttendanceList(circleId, startDate, endDate);
            logger.info("downloadAttendance() method getAttendanceBeanList:  {} for circleId: {} :", getAttendanceBeanList, circleId);

            if (getAttendanceBeanList.isEmpty()) {
                data = data.append("");
            } else {
                for (AttendanceBean ob : getAttendanceBeanList) {
                    String userName = ob.getName();
                    String mobileNo = ob.getMobileNo();
                    String date = ob.getDate();
                    String outletVisited = ob.getOutletVisited();
                    String distance = ob.getDistance();
                    String duration = ob.getDuration();

                    data = data.append(userName).append(",");
                    data = data.append(mobileNo).append(",");
                    data = data.append(date).append(",");
                    data = data.append(outletVisited).append(",");
                    data = data.append(distance).append(",");
                    data = data.append(duration).append("\n");

                }
            }

            json.put("data", data);
            response.setMessage("Attendance details fetched successfully");
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
            response.setResponse(json);
            logger.info("Success Response generated:  {} for circleId: {} :", "", circleId);
        } catch (Exception exe) {
            logger.error("downloadAttendance() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }

        logger.info("downloadAttendance() Response generated:  {} for circleId: {}: ", "", circleId);
        return response;
    }

    @SuppressWarnings("rawtypes")
    public List<AttendanceBean> getAttendanceList(String circleId, String startDate, String endDate) {
        List<AttendanceBean> users = new ArrayList<>();

        try {
            logger.info("Inside getAttendanceList () method in AdminPortalLoginServiceImpl class.. {}:", "");

            List<Map<String, Object>> rows = adminLoginDao.fetchAttendanceDataDetails(circleId, startDate, endDate);
            logger.info("ADMIN_FETCH_CIRCLE_WITH_DATE_ATTEND_DTLS rows.size() :  {} for circleId: {}: ", rows.size(), circleId);

            if (rows != null && !rows.isEmpty()) {
                for (Map row : rows) {
                    logger.info("getAttendanceList() setting appVerJsonObj :{}:", row);
                    String userName = row.get("USER_NAME") == null ? "" : row.get("USER_NAME").toString();
                    String mobileNo = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
                    String date = row.get("ATT_DATETIME") == null ? "" : row.get("ATT_DATETIME").toString();
                    String attendanceDate = row.get("ATT_DATETIME") == null ? "" : row.get("ATT_DATETIME").toString();
                    String outletVisited = String.valueOf(adminLoginDao.getOutletVisistedCount(attendanceDate, mobileNo));
                    logger.info("DASHBOARD_FETCH_RETAILER_CHKIN_COUNT_DTLS outletVisited :  {} for mobileNo: {}:", outletVisited, mobileNo);
                    String distance = calculateDistance(attendanceDate, mobileNo);

                    if (distance.equals("")) {
                        distance = "0";
                    }

                    String duration = "NA";
                    users.add(new AttendanceBean(userName, mobileNo, date, outletVisited, distance, duration));
                }
            }
        } catch (Exception exe) {
            logger.error("getAttendanceList() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }
        logger.info("getAttendanceList() Response generated :  {} for circleId: {}: ", "", circleId);
        return users;
    }

    public String calculateDistance(String attendanceDate, String mobileNo) {
        CommonUtils commonUtils = new CommonUtils();
        double temp = 0;
        double totalDistance = 0;
        String distance = "";
        DecimalFormat decimalFormat = new DecimalFormat("0.0000");

        try {

            logger.info("Inside of calculateDistance() method in AdminPortalLoginController Class {}:", "");
            List<Map<String, Object>> rows = adminLoginDao.getLatLongDtls(attendanceDate, mobileNo);
            logger.info("DASHBOARD_FETCH_LAT_LONG_CHKIN_COUNT_DTLS rows.size() :  {} for mobileNo: {}:", rows.size(), mobileNo);

            if (rows != null && !rows.isEmpty()) {

                int count = adminLoginDao.getOutletVisistedCount(attendanceDate, mobileNo);
                logger.info("DASHBOARD_FETCH_RETAILER_CHKIN_COUNT_DTLS count :  {} for mobileNo: {}:", count, mobileNo);

                for (int i = 0; i < rows.size() - 1; i++) {


                    Map<String, Object> firstRow = rows.get(i);
                    String firstLatitude = firstRow.get("LATITUDE") == null ? "" : firstRow.get("LATITUDE").toString();
                    String firstLongitude = firstRow.get("LONGITUDE") == null ? ""
                            : firstRow.get("LONGITUDE").toString();

                    Map<String, Object> secondRow = rows.get(i + 1);

                    String secondLatitude = secondRow.get("LATITUDE") == null ? ""
                            : secondRow.get("LATITUDE").toString();
                    String secondLongitude = secondRow.get("LONGITUDE") == null ? ""
                            : secondRow.get("LONGITUDE").toString();

                    double outletDistance = commonUtils.calculateOutletDistance(firstLatitude, secondLatitude,
                            firstLongitude, secondLongitude);

                    temp = outletDistance;
                    outletDistance = totalDistance;
                    totalDistance = temp + outletDistance;
                    logger.info("totalDistance at line no 585 {}:", totalDistance);
                    distance = decimalFormat.format(totalDistance);
                }

                logger.info("totalDistance:  {} for mobileNo: {} :", totalDistance, mobileNo);
            }

        } catch (Exception exe) {
            logger.error("calculateDistance() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }
        logger.info("calculateDistance() Response generated:  {} for mobileNo: {}:", "", mobileNo);
        return distance;

    }

    @SuppressWarnings("unchecked")
    public SnapWorkResponse processLogOutRequest(String userName)
    {
        JSONObject json = new JSONObject();

        try
        {
            logger.info("Inside logOut() method in AdminPortalLoginServiceImpl class.. {}:", "");

            if (userName == null)
            {
                throw new Exception("request can not ne null");
            }

            logger.info("Inside logOutAttendanceUpload() method in LoginServiceImpl class.. {}:", "");

            if (StringUtils.isNotBlank(userName) && StringUtils.isNumeric(userName))
            {
                PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity =
                        ProObjectHelper.getObjForLogInOutTracker(userName, "", "", "0", "", "PADMIN");

                PromoterLoginTrackerAuditEntity saveResp =
                        adminLoginDao.saveLoginAndLogOutDetails_V2(promoterLoginTrackerAuditEntity);

                logger.info("LOGIN_SAVE_LOGIN_INFO_TRACKER_DTLS insertCount: {} for mobileNo: {}:", userName);

                if (saveResp != null)
                {
                    json.put("userName", userName);
                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.ADMIN_LOGOUT_SUCC_MSG));
                    response.setDescription(prop.getProperty(Constants.ADMIN_LOGOUT_SUCC_MSG));
                    response.setResponse(json);
                    logger.info("Success Response generated :  {} for userName: {}:", "", userName);
                }
                else
                {
                    logger.error("processLogOutRequest() insertCount not greater than zero:  {} for userName: {}:", "", userName);
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setMessage(prop.getProperty(Constants.ADMIN_LOGOUT_FAIL_MSG));
                    response.setDescription(prop.getProperty(Constants.ADMIN_LOGOUT_FAIL_MSG));
                    response.setResponse(json);
                }
            }
            else
            {
                logger.error("processLogOutRequest() User name is blank:  {} for userName: {}:", "", userName);
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setDescription(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("processLogOutRequest() Response generated:  {} for userName: {}:", "", userName);
            return response;
        }
        catch (Exception exe)
        {
            logger.error("processLogOutRequest() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setDescription(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setResponse(json);
            return response;
        }
    }

    @Override
    public SnapWorkResponse isRefreshToKen(SnapWorkRequest request) throws Exception {
        JSONObject json = new JSONObject();
        String jwtToken = commonJwtUtil.generateJwtToken(request.getMobileNo(), 0, "mobile");
        json.put("jwtToken", jwtToken);

        adminLoginDao.updateJWT(jwtToken, request.getMobileNo());

        response.setMessage(prop.getProperty(Constants.JWT_GENERATED_SUCCESSFULLY));
        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
        response.setResponse(json);

        return response;
    }
}
