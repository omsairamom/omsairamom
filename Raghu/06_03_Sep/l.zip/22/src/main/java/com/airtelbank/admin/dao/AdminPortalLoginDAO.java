package com.airtelbank.admin.dao;

import com.airtelbank.admin.bean.AdminLoginInfoTrackerBean;
import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.entity.PromoterLoginTrackerAuditEntity;
import com.airtelbank.admin.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.admin.repository.PromoterLoginTrackerAuditRepository;
import com.airtelbank.admin.repository.PromoterUserProfileMSTRepository;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Service
public class AdminPortalLoginDAO {

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	@Autowired
	PromoterUserProfileMSTRepository promoterUserProfileMSTRepository;

	public List<Map<String, Object>> validateAdminLoginDetails(String adminName, String password) throws Exception
	{
		List<Map<String, Object>> rows = null;

		try {
			String query = prop.getProperty(Constants.ADMIN_LOGIN_USER_DTLS);
			rows = jdbctemplate.queryForList(query, adminName);
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}


	public Optional<PromoterUserProfileMSTEntity> validateAdminLoginDetails_V2(String adminName, String password) throws Exception
	{
		return promoterUserProfileMSTRepository.findOneByUserNoWithStatus(adminName, "A");
	}

	public void setBlockCounterToXAndBlockExpiryY(PromoterUserProfileMSTEntity profileMSTEntity, Integer X, LocalDateTime Y){

		profileMSTEntity.setAttempts(X);
		profileMSTEntity.setBlockExpiryDate(Y);

	}

	public List<Map<String, Object>> getCircleMasterDetails() throws Exception {
		List<Map<String, Object>> rows = null;

		try {
			String query = prop.getProperty(Constants.ADMIN_FETCH_CIRCLE_MST_DTLS);
			rows = jdbctemplate.queryForList(query);
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}

	public List<Map<String, Object>> fetchAttendanceDataDetails(SnapWorkRequest request) throws Exception
	{
		List<Map<String, Object>> rows = null;
		String query = "";

		try {

			String circle = request.getCircleId() == null ? "" : request.getCircleId().trim();
			String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
			String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

			endDate = endDate +" 11:59:59 PM";

			if(StringUtils.isNotBlank(circle) && !circle.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_CIRCLE_WITH_DATE_ATTEND_DTLS);
				rows = jdbctemplate.
						queryForList(query, Integer.parseInt(circle), startDate, endDate);
			}else {
				query = prop.getProperty(Constants.ADMIN_FETCH_ALL_CIRCLE_ATTEND_DTLS);
				rows = jdbctemplate.queryForList(query, startDate, endDate);
			}

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}

	public List<Map<String, Object>> fetchAttendanceDataDetails(String circleId,String startDate,String endDate) throws Exception {

		List<Map<String, Object>> rows = null;
		String query = "";
		try {

			endDate = endDate +" 11:59:59 PM";
			if(StringUtils.isNotBlank(circleId) && !circleId.equals("All")) {
				query = prop.getProperty(Constants.ADMIN_FETCH_CIRCLE_WITH_DATE_ATTEND_DTLS);
				rows = jdbctemplate.queryForList(query, Integer.parseInt(circleId), startDate, endDate);
			}else {
				query = prop.getProperty(Constants.ADMIN_FETCH_ALL_CIRCLE_ATTEND_DTLS);
				rows = jdbctemplate.queryForList(query, startDate, endDate);
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return rows;
	}

	public int updateAdminPasswordDetails(final String userName,final String encPassword) throws Exception
	{
		int count = 0;
		String query = "";

		try
		{
			query = prop.getProperty(Constants.ADMIN_UPDATE_PASSWORD_DTLS);
			count = jdbctemplate.update(query, encPassword, userName);
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return count;
	}

	public List<Map<String, Object>>  getLatLongDtls(String displayDate,String mobileNo) throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows = null;
		try
		{
			query = prop.getProperty(Constants.DASHBOARD_FETCH_LAT_LONG_CHKIN_COUNT_DTLS);
			rows = jdbctemplate.queryForList(query, displayDate, mobileNo);
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return rows;
	}

	@SuppressWarnings("rawtypes")
	public int getOutletVisistedCount(String attendanceDate,String mobileNo) throws Exception
	{
		String query = "";
		List<Map<String, Object>> rows = null;
		int count = 0;

		try
		{
			query = prop.getProperty(Constants.DASHBOARD_FETCH_RETAILER_CHKIN_COUNT_DTLS);
			rows = jdbctemplate.queryForList(query, attendanceDate, mobileNo);

			if(!rows.isEmpty())
			{
				for (Map row : rows)
				{
					count = (Integer) (row.get("count") == null ? "" : Integer.parseInt(row.get("count").toString()));
				}
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public int saveAdminLoginInfoTrackerDetails(final AdminLoginInfoTrackerBean obj) throws Exception
	{
		int row = 0;
		try
		{
			final String INSERT_SQL = prop.getProperty(Constants.ADMIN_LOGIN_SAVE_LOGIN_INFO_TRACKER_DTLS);
			row = jdbctemplate.update(INSERT_SQL, obj.getUserName(),
					obj.getLoginType(),
					obj.getField1(),
					obj.getField2(),
					obj.getField3(),
					obj.getField4(),
					obj.getField5());
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return row;
	}

	public int updateJWT(String jwtToken, String lapuNo) throws Exception
	{
		int count = 0;
		String query = "";

		try
		{
			query = prop.getProperty(Constants.LOGIN_UPDATE_JWT_TOKEN);
			count = jdbctemplate.update(query, jwtToken, lapuNo);
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public String getJWT(String mobileNo) throws Exception
	{
		String jwt = "";
		try
		{
			String query = prop.getProperty(Constants.LOGIN_FETCH_JWT_TOKEN);

			List<Map<String, Object>> rows = jdbctemplate.queryForList(query, mobileNo);

			if (rows != null && !rows.isEmpty())
			{
				Map<String, Object> promoType  = rows.get(0);
				jwt = (String) promoType.get("JWT_TOKEN") == null ? "" : promoType.get("JWT_TOKEN").toString();
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return jwt;
	}

	//Revamp Code

	@Autowired
	PromoterLoginTrackerAuditRepository promoterLoginTrackerAuditRepository;

	public PromoterLoginTrackerAuditEntity saveLoginAndLogOutDetails_V2(PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity) throws Exception
	{
		return promoterLoginTrackerAuditRepository.saveAndFlush(promoterLoginTrackerAuditEntity);
	}
}
