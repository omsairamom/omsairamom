package com.airtelbank;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableAsync;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableAutoConfiguration
@EnableSwagger2
@EnableAsync
@PropertySource(value = "file:properties/application.properties", ignoreResourceNotFound = true)
public class AirtelAdminportalLoginApplication
{
	private static Logger logger = LoggerFactory.getLogger(AirtelAdminportalLoginApplication.class);

	public static void main(String[] args)
	{
		try
		{
			new SpringApplicationBuilder(AirtelAdminportalLoginApplication.class)
					.logStartupInfo(true)
					.run(args);
			System.out.println("Admin Portal Services Started......");
			logger.info("Admin Portal Services Started......");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@Bean
	public Docket productApi()
	{
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.apis(RequestHandlerSelectors.basePackage("com.airtelbank"))
				.build();
	}

	public ApiInfo apiInfo()
	{
		return new ApiInfo("Admin Portal REST API", "HCL TECH API.", "API TOS", "Terms of service", "apb@hcl.com", "License of API", "API license URL");
	}
}