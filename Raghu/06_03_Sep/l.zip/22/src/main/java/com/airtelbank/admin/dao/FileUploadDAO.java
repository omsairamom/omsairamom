package com.airtelbank.admin.dao;

import com.airtelbank.admin.bean.CircleMasterBean;
import com.airtelbank.admin.bean.KpiMasterBean;
import com.airtelbank.admin.bean.OthersHierarchyBean;
import com.airtelbank.admin.bean.RetailerDetailsBean;
import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class FileUploadDAO {

	private static Logger logger = LoggerFactory.getLogger(FileUploadDAO.class);

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	HashMap<String, String> CIRCLE_MAP = null;

	@SuppressWarnings("unused")
	public int storeUserDtls(int row, RetailerDetailsBean retailerBean, CircleMasterBean circleBean,
			OthersHierarchyBean othersBean, ArrayList<String> otherMobilelist) throws Exception {

		int retailerCount = 0;
		int circleCount = 0;
		int othersCount = 0;
		String roleName = "";
		String query = "";
		String ErrorMobileNo = "";
		int count = 0;
		List<Object[]> list = new ArrayList<>();

		logger.info("============row: {}:", row);
		ErrorMobileNo = retailerBean.getRetailerNo().trim();

		try {
			if (row != 0 && retailerBean != null) {
				query = prop.getProperty("ADMIN_CSV_RETAILER_DTLS");
				if (retailerBean.getLongitude().equals("NA") || retailerBean.getLatitude().equals("NA"))
				{
					try
					{
						Object[] arr = { retailerBean.getRetailerNo(), retailerBean.getRetailerName(), "0", "0",
								retailerBean.getVillageName(), retailerBean.getVillagesType(),
								retailerBean.getVillagePop(), retailerBean.getCity(), retailerBean.getBlockTehsil(),
								retailerBean.getDistrict(), retailerBean.getSiteId(), retailerBean.getCategory(),
								retailerBean.getOutletType() };
						list.add(arr);
						jdbctemplate.batchUpdate(query, list);
						retailerCount++;
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}
				else
				{
					try
					{
						Object[] arr = { retailerBean.getRetailerNo(), retailerBean.getRetailerName(),
								retailerBean.getLatitude(), retailerBean.getLongitude(), retailerBean.getVillageName(),
								retailerBean.getVillagesType(), retailerBean.getVillagePop(), retailerBean.getCity(),
								retailerBean.getBlockTehsil(), retailerBean.getDistrict(), retailerBean.getSiteId(),
								retailerBean.getCategory(), retailerBean.getOutletType() };
						list.add(arr);
						jdbctemplate.batchUpdate(query, list);
						retailerCount++;
					}
					catch (Exception e)
					{
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				logger.info("============retailerCount: {}:" , retailerCount);

				if (retailerCount > 0)
				{
					count = storeOtherDtls(othersBean, retailerBean, otherMobilelist);
				}
				logger.info("============storeOtherDtlscount: {}:" , count);
			}
		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}
		return count;
	}

	public int storeOtherDtls(OthersHierarchyBean othersBean, RetailerDetailsBean retailerBean,
			ArrayList<String> otherMobilelist) throws Exception {

		String query = "";
		int othersCount = 0;
		String ErrorMobileNo = "";

		try {
			query = prop.getProperty("ADMIN_CSV_OTHERS_DTLS");
			if (!otherMobilelist.contains(othersBean.getPromoterLapuNo().trim())
					&& !othersBean.getPromoterLapuNo().equals("0"))
			{
				try
				{
					ErrorMobileNo = othersBean.getPromoterLapuNo().trim();
					List<Object[]> promoterList = new ArrayList<>();
					Object[] promoterArr = { othersBean.getPromoterLapuNo(), othersBean.getPromoterName(),
							othersBean.getPromoterAgency(), othersBean.getPromoterEmployeeID(),
							othersBean.getPromoterDob(), othersBean.getPromoterDoj(), "PR" };
					promoterList.add(promoterArr);
					jdbctemplate.batchUpdate(query, promoterList);
					othersCount++;
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			if (!otherMobilelist.contains(othersBean.getTlNo().trim()) && !othersBean.getTlNo().equals("0"))
			{
				try
				{
					ErrorMobileNo = othersBean.getTlNo().trim();
					List<Object[]> tlList = new ArrayList<>();
					Object[] tlArr = { othersBean.getTlNo(), othersBean.getTlName(), othersBean.getTlAgency(),
							othersBean.getTlEmployeeID(), othersBean.getTlDob(), othersBean.getTlDoj(), "TL" };
					tlList.add(tlArr);
					jdbctemplate.batchUpdate(query, tlList);
					othersCount++;
				}
				catch (Exception e)
				{
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			if (!otherMobilelist.contains(othersBean.getZmNo().trim()) && !othersBean.getZmNo().equals("0"))
			{
				try
				{
					ErrorMobileNo = othersBean.getZmNo().trim();
					List<Object[]> zmList = new ArrayList<>();
					Object[] zmArr = { othersBean.getZmNo(), othersBean.getZmName(), othersBean.getZoneName(), "NA", "",
							"", "ZM" };
					zmList.add(zmArr);
					jdbctemplate.batchUpdate(query, zmList);
					othersCount++;
				}
				catch (Exception e)
				{
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}

			if (!otherMobilelist.contains(othersBean.getRmMsisdn().trim()) && !othersBean.getRmMsisdn().equals("0"))
			{
				try
				{
					ErrorMobileNo = othersBean.getRmMsisdn().trim();
					List<Object[]> rmList = new ArrayList<>();
					Object[] rmArr = { othersBean.getRmMsisdn(), othersBean.getRmName(), "NA", "NA", "", "", "RM" };
					rmList.add(rmArr);
					jdbctemplate.batchUpdate(query, rmList);
					othersCount++;
				}
				catch (Exception e)
				{
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}

			if (!otherMobilelist.contains(othersBean.getCphNo().trim()) && !othersBean.getCphNo().equals("0"))
			{
				try
				{
					ErrorMobileNo = othersBean.getCphNo().trim();
					List<Object[]> cphList = new ArrayList<>();
					Object[] cphArr = { othersBean.getCphNo(), othersBean.getCphName(), "NA", "NA", "", "", "CPH" };
					cphList.add(cphArr);
					jdbctemplate.batchUpdate(query, cphList);
					othersCount++;
				}
				catch (Exception e)
				{
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			/**
			 * insert record for MM(Merchant Manager) user
			 */

			if (!otherMobilelist.contains(othersBean.getMmno().trim()) && !othersBean.getMmno().equals("0"))
			{
				try
				{
					ErrorMobileNo = othersBean.getMmno().trim();
					List<Object[]> mmList = new ArrayList<>();
					Object[] mmArr = { othersBean.getMmno(), othersBean.getMmname(), "NA", "NA", "", "", "MM" };
					mmList.add(mmArr);
					jdbctemplate.batchUpdate(query, mmList);
					othersCount++;
				}
				catch (Exception e)
				{
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}

			try
			{

				if (!otherMobilelist.contains(othersBean.getPromoterLapuNo().trim())
						&& !othersBean.getPromoterLapuNo().equals("0"))
				{
					ErrorMobileNo = othersBean.getPromoterLapuNo();
					otherMobilelist.add(othersBean.getPromoterLapuNo());
				}

				if (!otherMobilelist.contains(othersBean.getTlNo().trim()) && !othersBean.getTlNo().equals("0"))
				{
					ErrorMobileNo = othersBean.getTlNo();
					otherMobilelist.add(othersBean.getTlNo());
				}

				if (!otherMobilelist.contains(othersBean.getZmNo().trim()) && !othersBean.getZmNo().equals("0"))
				{
					ErrorMobileNo = othersBean.getZmNo();
					otherMobilelist.add(othersBean.getZmNo());
				}

				if (!otherMobilelist.contains(othersBean.getRmMsisdn().trim())
						&& !othersBean.getRmMsisdn().equals("0"))
				{
					ErrorMobileNo = othersBean.getRmMsisdn();
					otherMobilelist.add(othersBean.getRmMsisdn());
				}

				if (!otherMobilelist.contains(othersBean.getCphNo().trim()) && !othersBean.getCphNo().equals("0")) {
					ErrorMobileNo = othersBean.getCphNo();
					otherMobilelist.add(othersBean.getCphNo());
				}

				if (!otherMobilelist.contains(othersBean.getMmno().trim()) && !othersBean.getMmno().equals("0")) {
					ErrorMobileNo = othersBean.getMmno();
					otherMobilelist.add(othersBean.getMmno());
				}
			}
			catch (Exception e)
			{
				CommonException.printStackTraceForDAO(e);
				saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
			}

		}
		catch (Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return othersCount;
	}

	public HashMap<String, String> getCategoryIdDtlsMap() throws Exception {

		List<Map<String, Object>> rows = null;
		String categoryId = "";
		String categoryName = "";
		String query = "";
		HashMap<String, String> CATEGORY_MAP = new HashMap<>();

		try {
			logger.info("inside populateZoneMaster() method FileUploadDao class {}:" , "");

			query = prop.getProperty("ADMIN_FETCH_CATEGORY_ID");
			rows = jdbctemplate.queryForList(query, new Object[] {});
			for (Map<String, Object> row : rows) {
				if (rows != null && !rows.isEmpty()) {
					categoryId = row.get("CAT_ID") == null ? "" : row.get("CAT_ID").toString();
					categoryName = row.get("CAT_NAME") == null ? "" : row.get("CAT_NAME").toString();
					CATEGORY_MAP.put(categoryName, categoryId);
				}
			}

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return CATEGORY_MAP;
	}

	public String getCircleIdDtls(CircleMasterBean circleBean) throws Exception {
		logger.info("circleBean: {} & name: {}:" , circleBean.getCircleCode() , circleBean.getCircleName());
		String circleId = "";

		try {
			logger.info("inside getCircleIdDtls() method FileUploadDao class {}:" , "");
			final String INSERT_SQL = prop.getProperty("ADMIN_CSV_CIRCLE_DTLS");

			KeyHolder keyHolder = new GeneratedKeyHolder();
			jdbctemplate.update(new PreparedStatementCreator() {
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(INSERT_SQL, new String[] { "CIRCLE_ID" });
					ps.setString(1, circleBean.getCircleName());
					ps.setString(2, circleBean.getCircleCode());
					return ps;
				}
			}, keyHolder);
			int cirId;
			if (keyHolder.getKeyList().isEmpty()) {
				cirId = 0;
			} else {
				cirId = keyHolder.getKey().intValue();
			}

			logger.info("cirId: {}:" , cirId);
			circleId = String.valueOf(cirId);
		} catch (Exception e) {

			CommonException.printStackTraceForDAO(e);
		}
		return circleId;
	}

	public HashMap<String, String> populateCircleMaster() throws Exception {

		String circleId = "";
		String circleName = "";
		String query = "";
		List<Map<String, Object>> rows = null;
		CIRCLE_MAP = new HashMap<>();
		try {
			logger.info("inside populateCircleMaster() method FileUploadDao class {}:" , "");
			query = prop.getProperty("ADMIN_FETCH_CIRCLE_ID");
			rows = jdbctemplate.queryForList(query, new Object[] {});
			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					circleId = row.get("CIRCLE_ID") == null ? "" : row.get("CIRCLE_ID").toString();
					circleName = row.get("CIRCLE_NAME") == null ? "" : row.get("CIRCLE_NAME").toString();
					CIRCLE_MAP.put(circleName, circleId);
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return CIRCLE_MAP;
	}

	public int saveKpiDetails_V2(KpiMasterBean masterBean, ArrayList<String> mobileNolist) throws Exception {
		List<Map<String, Object>> rows = null;
		int count = 0;
		int id = 0;
		int kpiUpdateCount = 0;
		int kpiDetailsCount = 0;

		try {
			String lapuNo = masterBean.getLapuNo();

			String promoterName = masterBean.getPromoterName();
			String CAT_Name = masterBean.getCatName();
			String KPI_Name = masterBean.getKpiName();
			String LMTD = masterBean.getLmtd();
			String MTD = masterBean.getMtd();
			String AchievedPercent = masterBean.getAchievedPercent();

			logger.info("Deepak Dao 0 From CSV ** lapuNo{}: CAT_Name{}: KPI_Name {}:" , lapuNo , CAT_Name ,KPI_Name);

			// Fetch from DB where LapuNo = Promoter No && Cat Nmae = Cat Name && KpiName =
			// If Row exist then update
			// else insert a new row
			String query = prop.getProperty("PROMOTER_KPI_MST_V2_FIND_LAPU_&&_CAT_NAME_&&_KPI_NAME");
			rows = jdbctemplate.queryForList(query, new Object[] { lapuNo, CAT_Name, KPI_Name });

			if (rows != null && !rows.isEmpty()) {

				for (Map<String, Object> row : rows) {
					String PROMOTER_KPI_ID = rows.get(0).get("PROMOTER_KPI_ID") == null ? ""
							: rows.get(0).get("PROMOTER_KPI_ID").toString();

					String myupdate_query = prop.getProperty("PROMOTER_KPI_MST_V2_UPDATE");

					kpiUpdateCount = jdbctemplate.update(myupdate_query, new Object[] { promoterName, LMTD, MTD,
							AchievedPercent, Integer.parseInt(PROMOTER_KPI_ID) });

					kpiDetailsCount++;
				}
			}

			else {

				final String INSERT_SQL = prop.getProperty("PROMOTER_KPI_MST_V2");

				KeyHolder keyHolder = new GeneratedKeyHolder();
				kpiDetailsCount = jdbctemplate.update(new PreparedStatementCreator() {
					public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
						PreparedStatement ps = connection.prepareStatement(INSERT_SQL,
								new String[] { "PROMOTER_KPI_ID" });
						ps.setString(1, lapuNo);
						ps.setString(2, promoterName);
						ps.setString(3, CAT_Name);
						ps.setString(4, KPI_Name);
						ps.setString(5, LMTD);
						ps.setString(6, MTD);
						ps.setString(7, AchievedPercent);

						return ps;
					}
				}, keyHolder);

				id = keyHolder.getKey().intValue();
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public int updateDelUserDtls(String lapu, String name, RetailerDetailsBean retailerBean,
			OthersHierarchyBean othersBean) throws Exception {

		String query = "";
		int count = 0;

		try {
			logger.info("inside updateDelUserDtls() method FileUploadDao class {}:" , "");
			if (isExistDeactiveDtls(lapu, name)) {
				query = prop.getProperty("ADMIN_UPDATE_DEL_BLOCK_FLAG");
				count = jdbctemplate.update(query, new Object[] { lapu });
			} else {
				logger.info(lapu + " Not Found for Deletion.");
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return count;
	}

	public boolean isExistDeactiveDtls(String lapu, String name) throws Exception {

		boolean falg = false;
		String query = "";
		List<Map<String, Object>> rows = null;

		try {
			query = prop.getProperty("ADMIN_EXIST_DEL_USERS");
			rows = jdbctemplate.queryForList(query, new Object[] { lapu });
			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					String lapuNo = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
					String delFalg = row.get("DEL_BLOCK_FLAG") == null ? "" : row.get("DEL_BLOCK_FLAG").toString();
					if (StringUtils.isNoneBlank(lapuNo) && StringUtils.isNoneBlank(delFalg)
							&& delFalg.equalsIgnoreCase("0")) {
						falg = true;
					}
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return falg;
	}

	public String getZoneIdDtls(OthersHierarchyBean othersBean) throws Exception {

		String zoneId = "";
		int zoneID = 0;

		try {
			logger.info("inside getZoneIdDtls() method FileUploadDao class {}:" , "");

			final String INSERT_SQL = prop.getProperty("UPLOAD_RET_CSV_SAVE_ZONE_MST_DETAILS");

			KeyHolder keyHolder = new GeneratedKeyHolder();
			jdbctemplate.update(new PreparedStatementCreator() {
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(INSERT_SQL, new String[] { "ZONE_ID" });
					ps.setString(1, othersBean.getZoneName());
					ps.setString(2, othersBean.getZoneName());
					return ps;
				}
			}, keyHolder);

			if (keyHolder.getKeyList().size() != 0) {
				zoneID = keyHolder.getKey().intValue();
			}

			zoneId = String.valueOf(zoneID);

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return zoneId;
	}

	@SuppressWarnings("rawtypes")
	public HashMap<String, String> populateZoneMaster() throws Exception {

		String query = "";
		List<Map<String, Object>> rows = null;
		String zoneId = "", zoneName = "";
		HashMap<String, String> ZONE_MAP = new HashMap<String, String>();

		try {
			logger.info("inside populateZoneMaster() method FileUploadDao class {}:" , "");
			query = prop.getProperty("UPLOAD_RET_CSV_FETCH_ZONE_ID");
			rows = jdbctemplate.queryForList(query, new Object[] {});
			if (rows != null && !rows.isEmpty()) {
				for (Map row : rows) {
					zoneId = row.get("ZONE_ID") == null ? "" : row.get("ZONE_ID").toString();
					zoneName = row.get("ZONE_NAME") == null ? "" : row.get("ZONE_NAME").toString();
					ZONE_MAP.put(zoneName, zoneId);
				}
			}

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return ZONE_MAP;
	}

	public int storeDtlsInAppUserForBatch(RetailerDetailsBean retailerBean, CircleMasterBean circleBean,
			OthersHierarchyBean othersBean, String circleId, String zoneId, String catId,
			ArrayList<String> mobileNolist, int rowNumber) throws Exception {

		String query = "";
		String ErrorMobileNo = "";
		int count = 0;

		try {

			if (retailerBean != null) {
				query = prop.getProperty("ADMIN_CSV_APP_USER");
				logger.info("Csv row number: " + rowNumber + ", LAPU_NO :" + retailerBean.getRetailerNo().trim());

				if (!mobileNolist.contains(retailerBean.getRetailerNo()) && !retailerBean.getRetailerNo().equals("0")) {

					logger.info("retailerBean.getRetailerNo() :" + retailerBean.getRetailerNo());
					try {

						ErrorMobileNo = retailerBean.getRetailerNo();
						if (StringUtils.isNumeric(ErrorMobileNo)) {

//							LAPU_NO,CAT_ID,CIRCLE_ID,USER_NAME,PROFILE_PIC_PATH,RTID,PRID,TLID,ZMID,RMID,CPHID,ISADMIN,LAST_LOGIN,LOG_OUT_TIME,DEL_BLOCK_FLAG,DEL_BLOCK_REASON,FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,UPDATED_DT,CREATED_DT,ZONE_ID)VALUES(?,?,?,?,?,?,?,?,?,?,?,'0',sysdate,sysdate,'0','NA','NA','NA','NA','NA','NA',sysdate,sysdate,?
							Object[] retailerArr = { retailerBean.getRetailerNo(), catId, circleId,
									retailerBean.getRetailerName(), "NA", "0", othersBean.getPromoterLapuNo(),
									othersBean.getTlNo(), othersBean.getZmNo(), othersBean.getRmMsisdn(),
									othersBean.getCphNo(), zoneId, othersBean.getPromoterType(), othersBean.getMmno() };
							List<Object[]> retailerList = new ArrayList<>();
							retailerList.add(retailerArr);
							jdbctemplate.batchUpdate(query, retailerList);
							count++;
						} else {
							saveErrorReocrdDtls("Invalid Retailer Lapu_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				if (!mobileNolist.contains(othersBean.getPromoterLapuNo().trim())
						&& !othersBean.getPromoterLapuNo().equals("0")) {

					logger.info("othersBean.getPromoterLapuNo() :" + othersBean.getPromoterLapuNo());
					try {

						ErrorMobileNo = othersBean.getPromoterLapuNo().trim();
						if (StringUtils.isNumeric(ErrorMobileNo)) {
							List<Object[]> promoterList = new ArrayList<>();
							Object[] ptomoterArr = { othersBean.getPromoterLapuNo(), catId, circleId,
									othersBean.getPromoterName(), "NA", retailerBean.getRetailerNo(), "0",
									othersBean.getTlNo(), othersBean.getZmNo(), othersBean.getRmMsisdn(),
									othersBean.getCphNo(), zoneId, othersBean.getPromoterType(), othersBean.getMmno() };
							promoterList.add(ptomoterArr);
							jdbctemplate.batchUpdate(query, promoterList);
							count++;
						} else {
							saveErrorReocrdDtls("Invalid PR_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}

					// add merchant promoter detail in merchant promoter db
					if (othersBean.getPromoterType().equals("Merchant")
							|| othersBean.getPromoterType().equals("Combined")) {
						logger.info("save data into merchant DB :" + othersBean.getPromoterLapuNo());
						// promterprofiletable

						RestTemplate restTemplate = new RestTemplate();

						final String baseUrl = prop.getProperty("API_MERCHANT_WHITELISTING");

						URI uri = new URI(baseUrl);

						SnapWorkRequest request = new SnapWorkRequest();
						request.setMobileNo(othersBean.getPromoterLapuNo());
						request.setPromoterName(othersBean.getPromoterName());
						request.setReference1("Y");

						ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
					}
				}

				if (!mobileNolist.contains(othersBean.getTlNo().trim()) && !othersBean.getTlNo().equals("0")) {

					logger.info("othersBean.getTlNo() :" + othersBean.getTlNo());
					try {

						ErrorMobileNo = othersBean.getTlNo().trim();
						if (StringUtils.isNumeric(ErrorMobileNo)) {
							List<Object[]> tlList = new ArrayList<>();
							Object[] tlArr = { othersBean.getTlNo(), catId, circleId, othersBean.getTlName(), "NA",
									retailerBean.getRetailerNo(), othersBean.getPromoterLapuNo(), "0",
									othersBean.getZmNo(), othersBean.getRmMsisdn(), othersBean.getCphNo(), zoneId,
									othersBean.getPromoterType(), othersBean.getMmno() };
							tlList.add(tlArr);
							jdbctemplate.batchUpdate(query, tlList);
							count++;
						} else {
							saveErrorReocrdDtls("Invalid TL_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}
				if (!mobileNolist.contains(othersBean.getZmNo().trim()) && !othersBean.getZmNo().equals("0")) {

					logger.info("othersBean.getZmNo() :" + othersBean.getZmNo());
					try {

						ErrorMobileNo = othersBean.getZmNo().trim();
						if (StringUtils.isNumeric(ErrorMobileNo)) {
							List<Object[]> zmList = new ArrayList<>();
							Object[] zmArr = { othersBean.getZmNo(), catId, circleId, othersBean.getZmName(), "NA",
									retailerBean.getRetailerNo(), othersBean.getPromoterLapuNo(), othersBean.getTlNo(),
									"0", othersBean.getRmMsisdn(), othersBean.getCphNo(), zoneId,
									othersBean.getPromoterType(), othersBean.getMmno() };
							zmList.add(zmArr);
							jdbctemplate.batchUpdate(query, zmList);
							count++;
						} else {
							saveErrorReocrdDtls("Invalid ZM_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}
				if (!mobileNolist.contains(othersBean.getRmMsisdn().trim()) && !othersBean.getRmMsisdn().equals("0")) {

					logger.info("othersBean.getRmMsisdn() :" + othersBean.getRmMsisdn());

					try {

						ErrorMobileNo = othersBean.getRmMsisdn().trim();
						if (StringUtils.isNumeric(ErrorMobileNo)) {
							List<Object[]> rmList = new ArrayList<>();
							Object[] rmArr = { othersBean.getRmMsisdn(), catId, circleId, othersBean.getRmName(), "NA",
									retailerBean.getRetailerNo(), othersBean.getPromoterLapuNo(), othersBean.getTlNo(),
									othersBean.getZmNo(), "0", othersBean.getCphNo(), zoneId,
									othersBean.getPromoterType(), othersBean.getMmno() };
							rmList.add(rmArr);
							jdbctemplate.batchUpdate(query, rmList);
							count++;
						} else {
							saveErrorReocrdDtls("Invalid RM_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}
				if (!mobileNolist.contains(othersBean.getCphNo().trim()) && !othersBean.getCphNo().equals("0")) {

					logger.info("othersBean.getCphNo() :" + othersBean.getCphNo());
					try {

						ErrorMobileNo = othersBean.getCphNo().trim();
						if (StringUtils.isNumeric(ErrorMobileNo)) {
							List<Object[]> cphList = new ArrayList<>();
							Object[] cphArr = { othersBean.getCphNo(), catId, circleId, othersBean.getCphName(), "NA",
									retailerBean.getRetailerNo(), othersBean.getPromoterLapuNo(), othersBean.getTlNo(),
									othersBean.getZmNo(), othersBean.getRmMsisdn(), "0", zoneId,
									othersBean.getPromoterType(), othersBean.getMmno() };
							cphList.add(cphArr);
							jdbctemplate.batchUpdate(query, cphList);
							count++;
						} else {
							saveErrorReocrdDtls("Invalid CPH_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}

				}

				/**
				 * Add Data for MMNO
				 */

				if (!othersBean.getMmno().equals("NA") && !mobileNolist.contains(othersBean.getMmno().trim())
						&& !othersBean.getMmno().equals("0")) {

					logger.info("othersBean.getMMNo() :" + othersBean.getMmno());
					try {

						ErrorMobileNo = othersBean.getMmno().trim();
						if (StringUtils.isNumeric(ErrorMobileNo)) {
							List<Object[]> mmList = new ArrayList<>();
							Object[] mmArr = { othersBean.getMmno(), catId, circleId, othersBean.getMmname(), "NA",
									retailerBean.getRetailerNo(), othersBean.getPromoterLapuNo(), othersBean.getTlNo(),
									othersBean.getZmNo(), othersBean.getRmMsisdn(), othersBean.getCphNo(), zoneId,
									othersBean.getPromoterType(), 0 };
							mmList.add(mmArr);
							jdbctemplate.batchUpdate(query, mmList);
							count++;
						} else {
							saveErrorReocrdDtls("Invalid MMNo", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}

				}

				try {
					if (!retailerBean.getRetailerNo().equals("NA")
							&& StringUtils.isNumeric(retailerBean.getRetailerNo())) {

						if (!mobileNolist.contains(retailerBean.getRetailerNo().trim())) {
							ErrorMobileNo = retailerBean.getRetailerNo();
							mobileNolist.add(retailerBean.getRetailerNo());
						}
						if (!mobileNolist.contains(othersBean.getPromoterLapuNo().trim())
								&& !othersBean.getPromoterLapuNo().equals("0")) {
							ErrorMobileNo = othersBean.getPromoterLapuNo();
							mobileNolist.add(othersBean.getPromoterLapuNo());
						}
						if (!mobileNolist.contains(othersBean.getTlNo().trim()) && !othersBean.getTlNo().equals("0")) {
							ErrorMobileNo = othersBean.getTlNo();
							mobileNolist.add(othersBean.getTlNo());
						}
						if (!mobileNolist.contains(othersBean.getZmNo().trim()) && !othersBean.getZmNo().equals("0")) {
							ErrorMobileNo = othersBean.getZmNo();
							mobileNolist.add(othersBean.getZmNo());
						}
						if (!mobileNolist.contains(othersBean.getRmMsisdn().trim())
								&& !othersBean.getRmMsisdn().equals("0")) {
							ErrorMobileNo = othersBean.getRmMsisdn();
							mobileNolist.add(othersBean.getRmMsisdn());
						}
						if (!mobileNolist.contains(othersBean.getCphNo().trim())
								&& !othersBean.getCphNo().equals("0")) {
							ErrorMobileNo = othersBean.getCphNo();
							mobileNolist.add(othersBean.getCphNo());
						}
						if (!mobileNolist.contains(othersBean.getMmno().trim()) && !othersBean.getMmno().equals("0")) {
							ErrorMobileNo = othersBean.getMmno();
							mobileNolist.add(othersBean.getMmno());
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return count;
	}

	public ArrayList<String> populateAppUserDtls() throws Exception {

		String query = "";
		List<Map<String, Object>> rows = null;
		ArrayList<String> list = new ArrayList<String>();
		try {
			logger.info("inside populateAppUserDtls() method FileUploadDao class {}:" , "");
			query = prop.getProperty("ADMIN_APP_USER_LAPU_NO_DTLS");
			rows = jdbctemplate.queryForList(query, new Object[] {});
			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					String lapu_no = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
					list.add(lapu_no);
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return list;
	}

	public ArrayList<String> populateOthersDtls() throws Exception {

		String query = "";
		List<Map<String, Object>> rows = null;
		ArrayList<String> list = new ArrayList<>();

		try {
			logger.info("inside populateOthersDtls() method FileUploadDao class {}:" , "");
			query = prop.getProperty("ADMIN_OTHERS_LAPU_NO_DTLS");
			rows = jdbctemplate.queryForList(query, new Object[] {});
			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					String lapu_no = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
					list.add(lapu_no);
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return list;
	}

	public void saveErrorReocrdDtls(String errorMsg, String ErrorMobileNo) throws Exception {

		try
		{
			logger.error("ErrorMobileNumber {} ErrorMobileNo {}:" , errorMsg, ErrorMobileNo);
			String query = prop.getProperty("ADMIN_RETAILER_CSV_ERROR_DTLS");
			jdbctemplate.update(query, new Object[] { ErrorMobileNo, errorMsg });

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

	}

	public int updateDtlsInAppUserForBatch(RetailerDetailsBean retailerBean, CircleMasterBean circleBean,
			OthersHierarchyBean othersBean, String circleId, String zoneId, String catId,
			ArrayList<String> mobileNolist, int rowNumber) throws Exception {

		String query = "";
		String ErrorMobileNo = "";
		int count = 0;

		try {
			logger.info("inside updateDtlsInAppUserForBatch() method FileUploadDao class {}:" , "");
			if (retailerBean != null) {
				query = prop.getProperty("ADMIN_CSV_APP_USER_UPDATE");
				logger.info("Csv row number: " + rowNumber + ", LAPU_NO :" + retailerBean.getRetailerNo().trim());

				ErrorMobileNo = retailerBean.getRetailerNo().trim();
				if (mobileNolist.contains(ErrorMobileNo)) { // update
//	UPDATE PAPP_APP_USERS SET CAT_ID=?,CIRCLE_ID=?, USER_NAME = ?,UPDATED_DT = sysdate, ZONE_ID =? PROMOTER_TYPE = ?   WHERE LAPU_NO=?

					logger.info("retailerBean.getRetailerNo() Update:" + retailerBean.getRetailerNo());
					try {
						if (StringUtils.isNumeric(ErrorMobileNo)) {

							List<Object[]> queryParams = new ArrayList<>();
							Object[] paramArr = { catId, circleId, retailerBean.getRetailerName(), zoneId,
									othersBean.getPromoterType(), ErrorMobileNo };
							queryParams.add(paramArr);
							jdbctemplate.batchUpdate(query, queryParams);

							count++;

						} else {
							saveErrorReocrdDtls("Invalid Retailer Lapu_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				// Update promoter data in users table
				ErrorMobileNo = othersBean.getPromoterLapuNo().trim();
				if (mobileNolist.contains(ErrorMobileNo) && !othersBean.getPromoterLapuNo().equals("0")) {
					logger.info("othersBean.getPromoterLapuNo(): {}:" , othersBean.getPromoterLapuNo());

					logger.info("othersBean.getPromoterLapuNo() update :" + othersBean.getPromoterLapuNo());
					try {

						if (StringUtils.isNumeric(ErrorMobileNo)) {

							List<Object[]> queryParams = new ArrayList<>();
							Object[] paramArr = { catId, circleId, othersBean.getPromoterName(), zoneId,
									othersBean.getPromoterType(), ErrorMobileNo };
							queryParams.add(paramArr);
							jdbctemplate.batchUpdate(query, queryParams);

							count++;
							logger.info("========updatecount: {}:" , count);

						} else {
							saveErrorReocrdDtls("Invalid PR_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}

					// update merchant promoter detail in merchant promoter db
					if (othersBean.getPromoterType().equals("Merchant")
							|| othersBean.getPromoterType().equals("Combined")) {
						logger.info("save data into merchant DB :" + othersBean.getPromoterLapuNo());
						// promterprofiletable

						RestTemplate restTemplate = new RestTemplate();

						final String baseUrl = prop.getProperty("API_MERCHANT_WHITELISTINGUPDATE");
						URI uri = new URI(baseUrl);

						SnapWorkRequest request = new SnapWorkRequest();
						request.setMobileNo(othersBean.getPromoterLapuNo());
						request.setPromoterName(othersBean.getPromoterName());

						ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);

						logger.info("=======insertintomerchantDB: {}:" , result.getStatusCodeValue());

					}
				}

				// Update TL in Users table
				ErrorMobileNo = othersBean.getTlNo().trim();
				if (mobileNolist.contains(ErrorMobileNo) && !ErrorMobileNo.equals("0")) {

					logger.info("othersBean.getTlNo() Update:" + othersBean.getTlNo());
					try {

						if (StringUtils.isNumeric(ErrorMobileNo)) {

							List<Object[]> queryParams = new ArrayList<>();
							Object[] paramArr = { catId, circleId, othersBean.getTlName(), zoneId,
									othersBean.getPromoterType(), ErrorMobileNo };
							queryParams.add(paramArr);
							jdbctemplate.batchUpdate(query, queryParams);

							count++;

						} else {
							saveErrorReocrdDtls("Invalid TL_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				// Update ZM data is user's table
				ErrorMobileNo = othersBean.getZmNo().trim();
				if (mobileNolist.contains(ErrorMobileNo) && !ErrorMobileNo.equals("0")) {
					logger.info("othersBean.getZmNo() Update: {}:" , othersBean.getZmNo());

					logger.info("othersBean.getZmNo() Update::" + othersBean.getZmNo());
					try {

						if (StringUtils.isNumeric(ErrorMobileNo)) {

							List<Object[]> queryParams = new ArrayList<>();
							Object[] paramArr = { catId, circleId, othersBean.getZmName(), zoneId,
									othersBean.getPromoterType(), ErrorMobileNo };
							queryParams.add(paramArr);
							jdbctemplate.batchUpdate(query, queryParams);

							count++;
							logger.info("========othersBean.getZmNo() updatecount : {}:" , count);

						} else {
							saveErrorReocrdDtls("Invalid ZM_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				// Update RMMsisdn data in user's table
				ErrorMobileNo = othersBean.getRmMsisdn().trim();
				if (mobileNolist.contains(ErrorMobileNo) && !ErrorMobileNo.equals("0")) {

					logger.info("othersBean.getRmMsisdn() Update::" + othersBean.getRmMsisdn());

					try {

						if (StringUtils.isNumeric(ErrorMobileNo)) {

							List<Object[]> queryParams = new ArrayList<>();
							Object[] paramArr = { catId, circleId, othersBean.getRmName(), zoneId,
									othersBean.getPromoterType(), ErrorMobileNo };
							queryParams.add(paramArr);
							jdbctemplate.batchUpdate(query, queryParams);

							count++;
							logger.info("========othersBean.getRmMsisdn() updatecount: {}:" , count);

						} else {
							saveErrorReocrdDtls("Invalid RM_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				// Update CPH data in user's table
				ErrorMobileNo = othersBean.getCphNo().trim();
				if (mobileNolist.contains(ErrorMobileNo) && !ErrorMobileNo.equals("0")) {

					logger.info("othersBean.getCphNo() Update::" + othersBean.getCphNo());
					try {

						if (StringUtils.isNumeric(ErrorMobileNo)) {

							List<Object[]> queryParams = new ArrayList<>();
							Object[] paramArr = { catId, circleId, othersBean.getCphName(), zoneId,
									othersBean.getPromoterType(), ErrorMobileNo };
							queryParams.add(paramArr);
							jdbctemplate.batchUpdate(query, queryParams);

							count++;
							logger.info("========othersBean.getCphNo()  updatecount: {}:" , count);

						} else {
							saveErrorReocrdDtls("Invalid CPH_No", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				// Update Merchant manager data in user's table
				ErrorMobileNo = othersBean.getMmno().trim();
				if (mobileNolist.contains(ErrorMobileNo) && !ErrorMobileNo.equals("0")) {

					logger.info("othersBean.getMMNo() Update::" + othersBean.getMmno());
					try {

						if (StringUtils.isNumeric(ErrorMobileNo)) {

							List<Object[]> queryParams = new ArrayList<>();
							Object[] paramArr = { catId, circleId, othersBean.getMmname(), zoneId,
									othersBean.getPromoterType(), ErrorMobileNo };
							queryParams.add(paramArr);
							jdbctemplate.batchUpdate(query, queryParams);

							count++;
							logger.info("========updatecount: {}:" , count);

						} else {
							saveErrorReocrdDtls("Invalid MMNo", ErrorMobileNo);
						}
					} catch (Exception e) {
						e.printStackTrace();
						saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
					}
				}

				try {
					if (!retailerBean.getRetailerNo().equals("NA")
							&& StringUtils.isNumeric(retailerBean.getRetailerNo())) {

						if (!mobileNolist.contains(retailerBean.getRetailerNo().trim())) {
							ErrorMobileNo = retailerBean.getRetailerNo();
							mobileNolist.add(retailerBean.getRetailerNo());
						}
						if (!mobileNolist.contains(othersBean.getPromoterLapuNo().trim())
								&& !othersBean.getPromoterLapuNo().equals("0")) {
							ErrorMobileNo = othersBean.getPromoterLapuNo();
							mobileNolist.add(othersBean.getPromoterLapuNo());
						}
						if (!mobileNolist.contains(othersBean.getTlNo().trim()) && !othersBean.getTlNo().equals("0")) {
							ErrorMobileNo = othersBean.getTlNo();
							mobileNolist.add(othersBean.getTlNo());
						}
						if (!mobileNolist.contains(othersBean.getZmNo().trim()) && !othersBean.getZmNo().equals("0")) {
							ErrorMobileNo = othersBean.getZmNo();
							mobileNolist.add(othersBean.getZmNo());
						}
						if (!mobileNolist.contains(othersBean.getRmMsisdn().trim())
								&& !othersBean.getRmMsisdn().equals("0")) {
							ErrorMobileNo = othersBean.getRmMsisdn();
							mobileNolist.add(othersBean.getRmMsisdn());
						}
						if (!mobileNolist.contains(othersBean.getCphNo().trim())
								&& !othersBean.getCphNo().equals("0")) {
							ErrorMobileNo = othersBean.getCphNo();
							mobileNolist.add(othersBean.getCphNo());
						}
						if (!mobileNolist.contains(othersBean.getMmno().trim()) && !othersBean.getMmno().equals("0")) {
							ErrorMobileNo = othersBean.getMmno();
							mobileNolist.add(othersBean.getMmno());
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			CommonException.printStackTraceForDAO(e);
		}
		return count;

	}

	public int updateUserDtls(int row, RetailerDetailsBean retailerBean, CircleMasterBean circleBean,
			OthersHierarchyBean othersBean, ArrayList<String> otherMobilelist) throws Exception {

		int retailerUpdateCount = 0;

		String Longitude = "";
		String Latitude = "";
		String query = "";
		String ErrorMobileNo = "";
		int count = 0;

		try {
			logger.info("inside updateUserDtls() method FileUploadDao class {}:" , "");
			if (row != 0 && retailerBean != null) {
				query = prop.getProperty("ADMIN_CSV_RETRAILER_DTLS_UPDATE");
				if (retailerBean.getLongitude().equals("NA") || retailerBean.getLatitude().equals("NA")) {

					Longitude = "0";
					Latitude = "0";

				} else {
					Longitude = retailerBean.getLongitude();
					Latitude = retailerBean.getLatitude();

				}

				ErrorMobileNo = retailerBean.getRetailerNo();

				List<Object[]> queryParams = new ArrayList<>();
				Object[] paramArr = { retailerBean.getRetailerName(), Latitude, Longitude,
						retailerBean.getVillageName(), retailerBean.getVillagesType(), retailerBean.getVillagePop(),
						retailerBean.getCity(), retailerBean.getBlockTehsil(), retailerBean.getDistrict(),
						retailerBean.getSiteId(), retailerBean.getCategory(), retailerBean.getOutletType(),
						ErrorMobileNo };
				queryParams.add(paramArr);
				jdbctemplate.batchUpdate(query, queryParams);

				retailerUpdateCount++;

				logger.info("============retailerUpdateCount: {}:" , retailerUpdateCount);

				if (retailerUpdateCount > 0) {
					count = updateOtherDtls(othersBean, retailerBean, otherMobilelist);
				}

				logger.info("============count: {} :" , count);

			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return count;
	}

	private int updateOtherDtls(OthersHierarchyBean othersBean, RetailerDetailsBean retailerBean,
			ArrayList<String> otherMobilelist) throws Exception {
		String query = "";
		int othersCount = 0;
		String ErrorMobileNo = "";

//		NAME=?,AGENCY=?,EMPLOYEE_ID=?,DOB=?,DOJ=?,USER_TYPE=?,UPDATED_DT=sysdate WHERE LAPU_NO=?

		try {
			query = prop.getProperty("UPDATE_ADMIN_CSV_OTHERS_DTLS");
			if (otherMobilelist.contains(othersBean.getPromoterLapuNo().trim())
					&& !othersBean.getPromoterLapuNo().equals("0") && !othersBean.getPromoterLapuNo().equals("NA")) {
				try {
					ErrorMobileNo = othersBean.getPromoterLapuNo().trim();

					logger.info("====promotername: {}:" , othersBean.getPromoterName());
					jdbctemplate.update(query,
							new Object[] { othersBean.getPromoterName().trim(), othersBean.getPromoterAgency().trim(),
									othersBean.getPromoterEmployeeID().trim(), othersBean.getPromoterDob().trim(),
									othersBean.getPromoterDoj().trim(), "PR", ErrorMobileNo.trim() });
					othersCount++;
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			if (otherMobilelist.contains(othersBean.getTlNo().trim()) && !othersBean.getTlNo().equals("0")
					&& !othersBean.getTlNo().equals("NA")) {
				try {

					ErrorMobileNo = othersBean.getTlNo().trim();

					jdbctemplate.update(query,
							new Object[] { othersBean.getTlName().trim(), othersBean.getTlAgency().trim(),
									othersBean.getTlEmployeeID().trim(), othersBean.getTlDob().trim(),
									othersBean.getTlDoj().trim(), "TL", ErrorMobileNo });

					othersCount++;
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			if (otherMobilelist.contains(othersBean.getZmNo().trim()) && !othersBean.getZmNo().equals("0")
					&& !othersBean.getZmNo().equals("NA")) {
				try {
					ErrorMobileNo = othersBean.getZmNo().trim();

					jdbctemplate.update(query, new Object[] { othersBean.getZmName().trim(),
							othersBean.getZoneName().trim(), "NA", "", "", "ZM", ErrorMobileNo.trim() });

					othersCount++;
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			if (otherMobilelist.contains(othersBean.getRmMsisdn().trim()) && !othersBean.getRmMsisdn().equals("0")
					&& !othersBean.getRmMsisdn().equals("NA")) {
				try {
					ErrorMobileNo = othersBean.getRmMsisdn().trim();

					jdbctemplate.update(query, new Object[] { othersBean.getRmName().trim(), "NA", "NA", "", "", "RM",
							ErrorMobileNo.trim() });

					othersCount++;
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			if (otherMobilelist.contains(othersBean.getCphNo().trim()) && !othersBean.getCphNo().equals("0")
					&& !othersBean.getCphNo().equals("NA")) {
				try {
					ErrorMobileNo = othersBean.getCphNo().trim();

					jdbctemplate.update(query, new Object[] { othersBean.getCphName().trim(), "NA", "NA", "", "", "CPH",
							ErrorMobileNo.trim() });

					othersCount++;
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}
			/**
			 * update record for MM(Merchant Manager) user
			 */

			if (!othersBean.getMmno().trim().equals("NA") && otherMobilelist.contains(othersBean.getMmno().trim())
					&& !othersBean.getMmno().equals("0")) {
				try {
					ErrorMobileNo = othersBean.getMmno().trim();
					logger.info("======mmNo: {}:" , ErrorMobileNo);

					jdbctemplate.update(query, new Object[] { othersBean.getMmname().trim(), "NA", "NA", "", "", "MM",
							ErrorMobileNo.trim() });
					othersCount++;
				} catch (Exception e) {
					e.printStackTrace();
					saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
				}
			}

			try {

				if (!otherMobilelist.contains(othersBean.getPromoterLapuNo().trim())
						&& !othersBean.getPromoterLapuNo().equals("0")) {
					ErrorMobileNo = othersBean.getPromoterLapuNo();
					otherMobilelist.add(othersBean.getPromoterLapuNo());
				}
				if (!otherMobilelist.contains(othersBean.getTlNo().trim()) && !othersBean.getTlNo().equals("0")) {
					ErrorMobileNo = othersBean.getTlNo();
					otherMobilelist.add(othersBean.getTlNo());
				}
				if (!otherMobilelist.contains(othersBean.getZmNo().trim()) && !othersBean.getZmNo().equals("0")) {
					ErrorMobileNo = othersBean.getZmNo();
					otherMobilelist.add(othersBean.getZmNo());
				}
				if (!otherMobilelist.contains(othersBean.getRmMsisdn().trim())
						&& !othersBean.getRmMsisdn().equals("0")) {
					ErrorMobileNo = othersBean.getRmMsisdn();
					otherMobilelist.add(othersBean.getRmMsisdn());
				}
				if (!otherMobilelist.contains(othersBean.getCphNo().trim()) && !othersBean.getCphNo().equals("0")) {
					ErrorMobileNo = othersBean.getCphNo();
					otherMobilelist.add(othersBean.getCphNo());
				}
				if (!otherMobilelist.contains(othersBean.getMmno().trim()) && !othersBean.getMmno().equals("0")) {
					ErrorMobileNo = othersBean.getMmno();
					otherMobilelist.add(othersBean.getMmno());
				}
			} catch (Exception e) {
				CommonException.printStackTraceForDAO(e);
				saveErrorReocrdDtls(e.getMessage(), ErrorMobileNo);
			}

		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}
		return othersCount;

	}

	public ArrayList<String> get_pramoter_kpi_mst_mobile_number() throws Exception {

		String query = "";
		List<Map<String, Object>> rows = null;
		ArrayList<String> list = new ArrayList<>();

		try {
			query = prop.getProperty("PROMOTER_KPI_MST_USER_LAPU_NO_DTLS");
			rows = jdbctemplate.queryForList(query, new Object[] {});
			if (rows != null && !rows.isEmpty()) {
				for (Map<String, Object> row : rows) {
					String lapu_no = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
					list.add(lapu_no);
				}
			}
		} catch (Exception e) {
			CommonException.printStackTraceForDAO(e);
		}

		return list;
	}
}