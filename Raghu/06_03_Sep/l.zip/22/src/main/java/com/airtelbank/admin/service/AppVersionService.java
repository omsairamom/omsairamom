package com.airtelbank.admin.service;

import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.util.CustomException;

/**
 * @author Anand Devadasu
 * @Company Snapwork Technologies Pvt Ltd.
 * @Date Jul 08, 2019 10:14:55 AM
 */
public interface AppVersionService
{
	SnapWorkResponse onLoadAppVersionDetails(SnapWorkRequest request) throws CustomException;
}
