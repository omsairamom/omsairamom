package com.airtelbank.admin.util;

public class Constants
{
    public static final String PROMOTER_TYPE = "PROMOTER_TYPE";

    public static final String JSON_PROMOTER_TYPE = "promoterType";

    public static final String JSON_KPI_PROMOTER_TYPE = "kpiPromoterType";

    public static final String KPI_CONFIG_FETCH_PROMOTER_TYPE = "KPI_CONFIG_FETCH_PROMOTER_TYPE";

    public static final String SUCCESS_STATUS_CODE = "SUCCESS_STATUS_CODE";

    public static final String FAILURE_NOT_FOUND = "FAILURE_NOT_FOUND";

    public static final String FAILURE_RESPONSE_CODE = "FAILURE_RESPONSE_CODE";

    public static final String FAILURE_INVALID_REQUEST = "FAILURE_INVALID_REQUEST";

    public static final String FAILURE_ERROR_MESSAGE = "FAILURE_ERROR_MESSAGE";

    public static final String FAILURE_STATUS_CODE = "FAILURE_STATUS_CODE";

	public static final CharSequence EMPTY_STRING = "";
	

    public static final String ADMIN_LOGIN_USER_SUCC_MSG = "ADMIN_LOGIN_USER_SUCC_MSG";

    public static final String LOGIN_JWT_TOKEN_GEN_FAILED = "LOGIN_JWT_TOKEN_GEN_FAILED";

    public static final String ADMIN_LOGIN_INVALID_PASSWD_MSG = "ADMIN_LOGIN_INVALID_PASSWD_MSG";

    public static final String ADMIN_LOGIN_USER_FAIL_MSG = "ADMIN_LOGIN_USER_FAIL_MSG";

    public static final String ADMIN_API_LOGIN_NAME = "ADMIN_API_LOGIN_NAME";

    public static final String ADMIN_SEND_OTP_SUCC_MSG = "ADMIN_SEND_OTP_SUCC_MSG";

    public static final String ADMIN_SEND_OTP_FAIL_MSG = "ADMIN_SEND_OTP_FAIL_MSG";

    public static final String ADMIN_API_SEND_OTP_NAME = "ADMIN_API_SEND_OTP_NAME";

    public static final String ADMIN_FETCH_CIRCLE_MST_DTLS_SUCC_MSG = "ADMIN_FETCH_CIRCLE_MST_DTLS_SUCC_MSG";

    public static final String ADMIN_FETCH_CIRCLE_MST_DTLS_FAIL_MSG = "ADMIN_FETCH_CIRCLE_MST_DTLS_FAIL_MSG";

    public static final String ADMIN_API_FETCH_CIRCLE_DTLS_NAME = "ADMIN_API_FETCH_CIRCLE_DTLS_NAME";

    public static final String ADMIN_FETCH_ATTEND_DTLS_SUCC_MSG = "ADMIN_FETCH_ATTEND_DTLS_SUCC_MSG";

    public static final String ADMIN_FETCH_ATTEND_DTLS_FAIL_MSG = "ADMIN_FETCH_ATTEND_DTLS_FAIL_MSG";

    public static final String ADMIN_API_ATTEND_DASHBOARD_VIEW_NAME = "ADMIN_API_ATTEND_DASHBOARD_VIEW_NAME";

    public static final String ADMIN_RESET_PASSWD_SUCC_MSG = "ADMIN_RESET_PASSWD_SUCC_MSG";

    public static final String ADMIN_RESET_PASSWD_FAIL_MSG = "ADMIN_RESET_PASSWD_FAIL_MSG";

    public static final String ADMIN_API_PASSWD_RESET_NAME = "ADMIN_API_PASSWD_RESET_NAME";

    public static final String ADMIN_VERIFY_OTP_SUCC_MSG = "ADMIN_VERIFY_OTP_SUCC_MSG";

    public static final String ADMIN_VERIFY_OTP_FAIL_MSG = "ADMIN_VERIFY_OTP_FAIL_MSG";

    public static final String ADMIN_API_VERIFY_OTP_NAME = "ADMIN_API_VERIFY_OTP_NAME";

    public static final String ADMIN_API_DOWNLOAD_ATTEND_NAME = "ADMIN_API_DOWNLOAD_ATTEND_NAME";

    public static final String ADMIN_LOGOUT_SUCC_MSG = "ADMIN_LOGOUT_SUCC_MSG";

    public static final String ADMIN_LOGOUT_FAIL_MSG = "ADMIN_LOGOUT_FAIL_MSG";

    public static final String ADMIN_API_LOGOUT_NAME = "ADMIN_API_LOGOUT_NAME";

    public static final String JWT_GENERATED_SUCCESSFULLY = "JWT_GENERATED_SUCCESSFULLY";

    public static final String ADMIN_FETCH_MARKET_DTLS_SUCC_MSG = "ADMIN_FETCH_MARKET_DTLS_SUCC_MSG";

    public static final String MARKET_FETCH_DTLS_FAIL_MSG = "MARKET_FETCH_DTLS_FAIL_MSG";

    public static final String APPVER_FETCH_DTLS_SUCC_MSG = "APPVER_FETCH_DTLS_SUCC_MSG";

    public static final String COMPLIANCE_FETCH_DTLS_SUCC_MSG = "COMPLIANCE_FETCH_DTLS_SUCC_MSG";

    public static final String COMPLIANCE_FETCH_DTLS_FAIL_MSG = "COMPLIANCE_FETCH_DTLS_FAIL_MSG";

    public static final String  DASHBOARD_ONLOAD_DATA_FETCH_SUCC_MSG = "DASHBOARD_ONLOAD_DATA_FETCH_SUCC_MSG";

    public static final String UPLOAD_RETAIL_FILE_SUCC_MSG = "UPLOAD_RETAIL_FILE_SUCC_MSG";

    public static final String UPLOAD_RETAIL_INVALID_FILE_EXTN_MSG = "UPLOAD_RETAIL_INVALID_FILE_EXTN_MSG";

    public static final String  UPLOAD_API_RETAILER_CSV_NAME = "UPLOAD_API_RETAILER_CSV_NAME";

    public static final String UPLOAD_KPI_FILE_SUCC_MSG = "UPLOAD_KPI_FILE_SUCC_MSG";

    public static final String  UPLOAD_HEADER_FILE_SUCC_MSG = "UPLOAD_HEADER_FILE_SUCC_MSG";

    public static final String KPI_CONFIG_SAVE_DTLS_SUCC_MSG = "KPI_CONFIG_SAVE_DTLS_SUCC_MSG";

    public static final String  KPI_CONFIG_SAVE_DTLS_FAIL_MSG = "KPI_CONFIG_SAVE_DTLS_FAIL_MSG";

    public static final String KPI_CONFIG_LESS_WEIGHT_AGE_SUCC_MSG = "KPI_CONFIG_LESS_WEIGHT_AGE_SUCC_MSG";

    public static final String  KPI_CONFIG_UPDATE_DTLS_SUCC_MSG = "KPI_CONFIG_UPDATE_DTLS_SUCC_MSG";

    public static final String  KPI_CONFIG_WEIGHT_AGE_FAIL_MSG = "KPI_CONFIG_WEIGHT_AGE_FAIL_MSG";

    public static final String  KPI_CONFIG_FETCH_DTLS_SUCC_MSG = "KPI_CONFIG_FETCH_DTLS_SUCC_MSG";

    public static final String ADMIN_LOGIN_USER_DTLS = "ADMIN_LOGIN_USER_DTLS";

    public static final String ADMIN_FETCH_CIRCLE_MST_DTLS = "ADMIN_FETCH_CIRCLE_MST_DTLS";

    public static final String ADMIN_FETCH_CIRCLE_WITH_DATE_ATTEND_DTLS = "ADMIN_FETCH_CIRCLE_WITH_DATE_ATTEND_DTLS";

    public static final String ADMIN_FETCH_ALL_CIRCLE_ATTEND_DTLS = "ADMIN_FETCH_ALL_CIRCLE_ATTEND_DTLS";

    public static final String ADMIN_UPDATE_PASSWORD_DTLS = "ADMIN_UPDATE_PASSWORD_DTLS";

    public static final String DASHBOARD_FETCH_LAT_LONG_CHKIN_COUNT_DTLS = "DASHBOARD_FETCH_LAT_LONG_CHKIN_COUNT_DTLS";

    public static final String DASHBOARD_FETCH_RETAILER_CHKIN_COUNT_DTLS = "DASHBOARD_FETCH_RETAILER_CHKIN_COUNT_DTLS";

    public static final String ADMIN_LOGIN_SAVE_LOGIN_INFO_TRACKER_DTLS = "ADMIN_LOGIN_SAVE_LOGIN_INFO_TRACKER_DTLS";

    public static final String LOGIN_UPDATE_JWT_TOKEN = "LOGIN_UPDATE_JWT_TOKEN";

    public static final String LOGIN_FETCH_JWT_TOKEN = "LOGIN_FETCH_JWT_TOKEN";

    public static final String ADMIN_FETCH_MARKET_VISITED_DTLS_ALL = "ADMIN_FETCH_MARKET_VISITED_DTLS_ALL";

    public static final String ADMIN_FETCH_MARKET_VISITED_RETAILER_DTLS = "ADMIN_FETCH_MARKET_VISITED_RETAILER_DTLS";

    public static final String DASHBOARD_FETCH_ASSIGNED_OUTLET_DTLS = "DASHBOARD_FETCH_ASSIGNED_OUTLET_DTLS";

    public static final String LOGIN_FETCH_ROLE_DTLS_OTHER_HIERARCHY = "LOGIN_FETCH_ROLE_DTLS_OTHER_HIERARCHY";

    public static final String ADMIN_FETCH_MARKET_VISITED_CHECK_IN_DTLS = "ADMIN_FETCH_MARKET_VISITED_CHECK_IN_DTLS";

    public static final String ADMIN_FETCH_MARKET_VISITED_CHECK_IN = "ADMIN_FETCH_MARKET_VISITED_CHECK_IN";

    public static final String ADMIN_FETCH_MARKET_VISITED_CHECK_OUT = "ADMIN_FETCH_MARKET_VISITED_CHECK_OUT";

    public static final String ADMIN_FETCH_MARKET_VISITED_LAT_LONG = "ADMIN_FETCH_MARKET_VISITED_LAT_LONG";

    public static final String COMPLIANCE_FETCH_SPEC_CIRZONE_DTLS = "COMPLIANCE_FETCH_SPEC_CIRZONE_DTLS";

    public static final String COMPLIANCE_FETCH_SPEC_CIR_ALL_ZONE_DTLS = "COMPLIANCE_FETCH_SPEC_CIR_ALL_ZONE_DTLS";

    public static final String COMPLIANCE_FETCH_SPEC_ZONE_ALL_CIR_DTLS = "COMPLIANCE_FETCH_SPEC_ZONE_ALL_CIR_DTLS";

    public static final String COMPLIANCE_FETCH_ALL_CIRZONE_DTLS = "COMPLIANCE_FETCH_ALL_CIRZONE_DTLS";

    public static final String GEO_FETCH_CATEGORY_MST_DTLS = "GEO_FETCH_CATEGORY_MST_DTLS";

    public static final String GEO_FETCH_ZONE_MST_DTLS = "GEO_FETCH_ZONE_MST_DTLS";

    public static final String DASHBOARD_FETCH_ROLE_MST_DTLS = "DASHBOARD_FETCH_ROLE_MST_DTLS";

    public static final String KPI_CONFIG_SAVE_DETAILS_MST = "KPI_CONFIG_SAVE_DETAILS_MST";

    public static final String KPI_CONFIG_SAVE_MEASURE_MST = "KPI_CONFIG_SAVE_MEASURE_MST";

    public static final String KPI_CONFIG_TARGET_DETAILS = "KPI_CONFIG_TARGET_DETAILS";

    public static final String KPI_CONFIG_UPDATE_DETAILS = "KPI_CONFIG_UPDATE_DETAILS";

    public static final String KPI_CONFIG_UPDATE_MEASURE_MST = "KPI_CONFIG_UPDATE_MEASURE_MST";

    public static final String KPI_CONFIG_IS_EXIST_KPI_ID_DETAILS = "KPI_CONFIG_IS_EXIST_KPI_ID_DETAILS";

    public static final String KPI_CONFIG_CATEGORY_ID = "KPI_CONFIG_CATEGORY_ID";

    public static final String KPI_CONFIG_IS_EXIST_KPI_DETAILS = "KPI_CONFIG_IS_EXIST_KPI_DETAILS";

    public static final String KPI_CONFIG_DETAILS_ID = "KPI_CONFIG_DETAILS_ID";

    public static final String KPI_CONFIG_IS_EXIST_MEASURES_DETAILS = "KPI_CONFIG_IS_EXIST_MEASURES_DETAILS";

    public static final String KPI_CONFIG_GET_PROMOTER_TYPE = "KPI_CONFIG_GET_PROMOTER_TYPE";

    public static final String KPI_CONFIG_CHECK_DTLS_EXIST = "KPI_CONFIG_CHECK_DTLS_EXIST";

    public static final String KPI_CONFIG_START_DATE_DTLS = "KPI_CONFIG_START_DATE_DTLS";

    public static final String KPI_CONFIG_END_DATE_DTLS = "KPI_CONFIG_END_DATE_DTLS";

    public static final String KPI_CONFIG_UPDATE_STATUS_DTLS = "KPI_CONFIG_UPDATE_STATUS_DTLS";

    public static final String KPI_CONFIG_EXISTING_QUARTER_DETAILS = "KPI_CONFIG_EXISTING_QUARTER_DETAILS";

    public static final String KPI_CONFIG_CURRENT_QUARTER_DETAILS = "KPI_CONFIG_CURRENT_QUARTER_DETAILS";

    public static final String KPI_CONFIG_WEIGHT_AGE_SUM = "KPI_CONFIG_WEIGHT_AGE_SUM";

    public static final String KPI_CONFIG_WEIGHT_AGE_SUM2 = "KPI_CONFIG_WEIGHT_AGE_SUM2";

    public static final String APPVER_SAVE_USERAGNT_DTLS = "APPVER_SAVE_USERAGNT_DTLS";

    public static final String APPVER_UPDATE_USERAGNT_DTLS = "APPVER_UPDATE_USERAGNT_DTLS";

    public static final String APPVER_CHECK_USERAGNT_DTLS_EXIST = "APPVER_CHECK_USERAGNT_DTLS_EXIST";

    public static final String APPVER_FETCH_USERAGNT_DTLS = "APPVER_FETCH_USERAGNT_DTLS";

    public static final String ADMIN_CSV_RETAILER_DTLS = "ADMIN_CSV_RETAILER_DTLS";

    public static final String ADMIN_CSV_OTHERS_DTLS = "ADMIN_CSV_OTHERS_DTLS";

    public static final String ADMIN_FETCH_CATEGORY_ID = "ADMIN_FETCH_CATEGORY_ID";

    public static final String ADMIN_CSV_CIRCLE_DTLS = "ADMIN_CSV_CIRCLE_DTLS";

    public static final String KPI_CONFIG_FETCH_DTLS_API_NAME = "KPI_CONFIG_FETCH_DTLS_API_NAME";

    public static final String password = "password";

    public static final String LATITUDE = "LATITUDE";

    public static final String LONGITUDE = "LONGITUDE";

    public static final String LAPU_NO = "LAPU_NO";

    public static final String DATE_OF_VISIT = "DATE_OF_VISIT";

    public static final String DISP_DATE = "DISP_DATE";
    public static final String Check_In = "Check_In";
    public static final String Check_In_Lat = "Check_In_Lat";
    public static final String Check_In_Long = "Check_In_Long";

    public static final String Check_Out = "Check_Out";
    public static final String Check_Out_Lat = "Check_Out_Lat";
    public static final String Check_Out_Long = "Check_Out_Long";

    public static final String Date = "Date";

    public static final String Name = "Name";
    public static final String LapuId = "LapuId";
    public static final String Retailer_Name = "Retailer_Name";
    public static final String Retailer_LapuId = "Retailer_LapuId";
    public static final String Assigned_Outlets = "Assigned_Outlets";

    public static final String Distance = "Distance";
    public static final String mobileNo = "mobileNo";

    public static final String PRODUCTION = "PRODUCTION";

    
    public static final String Validate_Success = "Validation Sucess";
    
    public static final String FILE_ALREADY_EXISTS = "File with same name already exists. Please try again with different file name.";
    public static final String FIVE_HUNDRED = "500";
    public static final String COLUMNS_MISSING = " columns missing";
    public static final String INVALID_TYPE = "Invalid Type";
    public static final String EXTRA_ROWS = " extra rows";
    public static final String PENDING = "Pending";
    public static final String PROCESSING = "Processing";
    public static final String DATA_WAS_UPLOADED_SUCCESSFULLY = "Data was uploaded successfully";
    public static final String SUCCESS = "Success";
    public static final String PROCESSED = "PROCESSED";
    public static final String TWO_HUNDRED = "200";
    public static final String FILE_PROCESSED_SUCCESSFULLY = "File processed successfully";
    public static final String PLEASE_TRY_AGAIN_WITH_A_DIFFERENT_FILE_NAME = "File could not be processed successfully. Please try again with different file name.";
    public static final String THE_FILE_IS_UNDER_PROCESSING = "The file is under processing";
    public static final String FOUR_HUNDRED_FOUR = "404";
    public static final String FILE_NOT_FOUND = "File with this name does not exist in the system";
    public static final String INCORRECT_HEADERS = "Incorrect headers";
    public static final String INCORRECT_FILE_EXTENSION = "Incorrect file extension";
    public static final String FILEUPLOAD = "fileUpload";
    public static final String FILENAME = "fileName";
    public static final String DATA = "data";
    public static final String CSV = ".csv";
    public static final String FAILED = "FAILED";
    public static final String InvalidFile = "Invalid file";
    public static final String InvalidFileName = "Invalid file name";
    public static final String ValidFileNameConstitutesOf = "A valid filename should contain alphanumeric characters and should not contain any special characters.";
    public static final String MAX_COUNT = "MAX_COUNT";
    public static final String EXPIRY_SESSION_IN_SECONDS = "EXPIRY_SESSION_IN_SECONDS";
    public static final String USER_BLOCKED_FOR_WRONG_ATTEMPT = "USER_BLOCKED_FOR_WRONG_ATTEMPT";
    public static final String WRONG_ATTEMPT_STATUS_CODE = "WRONG_ATTEMPT_STATUS_CODE";
    public static final String GET_PROMOTER_DETAILS = "PROMOTER_DETAILS";
    public static final String GET_OUTLET_DETAILS = "OUTLET_DETAILS";
    public static final String OUTLET_DETAILS_SUCC_MGS = "OUTLET_DETAILS_SUCC_MGS";
    public static final String PROMOTERS_DETAILS_SUCC_MGS = "PROMOTER_DETAILS_SUCC_MGS";

    public static final String GET_OUTLET_DETAIL = "GET_OUTLET_DETAIL";
    public static final String GET_MAPPEDPROMOTERS_LIST = "GET_MAPPEDPROMOTERS_LIST";
    
    public static final String INTERNAL_ERROR = "INTERNAL ERROR";
    public static final String THREE_HUNDRED = "300";
    public static final String DUPLICATE_RECORD = "Duplicate record";
    public static final String COLON = " : ";

	public static final String COMMA = " ,";

    

}