package com.airtelbank.admin.controller;


import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;

import com.airtelbank.admin.jwt.AeroCache;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dto.FileEnquiryRequest;
import com.airtelbank.admin.service.FileUploadService;
import com.airtelbank.admin.service.impl.PromoterUserFileProcessImpl;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@RestController
public class FileUploadController
{
    private static Logger logger = LoggerFactory.getLogger(FileUploadController.class);

    @Autowired
    SnapWorkResponse response;

    @Autowired
    FileUploadService fileUploadService;

    @Autowired
    PropertyManager prop;

    @Autowired
    CommonUtils commonUtil;

    @Autowired
    HttpServletRequest httpServletRequest;
    
    @Autowired
    PromoterUserFileProcessImpl promoterUserFileProcessImpl;
   
    

    JSONObject json = new JSONObject();
    long startTime = 0;
    long endTime = 0;
    long elapsedTimeMillis = 0;
    GsonBuilder gsonBuilder = new GsonBuilder();
    Gson gson = gsonBuilder.create();

    @PostMapping(path = "/v2/dashboard/upload-retailer")
    @Validated
    public ResponseEntity<Object> uploadRetailerCSVDetails1(@RequestParam("file") MultipartFile file)
    {
        try
        {
            String payload = httpServletRequest.getHeader("jwt_payload");
            org.json.JSONObject json1 = new org.json.JSONObject(payload);
            String mobileNo = json1.getString("mobileno");

            startTime = System.currentTimeMillis();
            logger.info("Inside uploadRetailerCSVDetails1() method in FileUploadController class.. {}:", "");

            if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo) && !file.isEmpty())
            {
                response = fileUploadService.retailerUploadDetails(file);
            }
            else
            {
                logger.error("uploadRetailerCSVDetails1() method : {}", "MobileNo blank/File Empty");
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            logger.info("uploadRetailerCSVDetails1() Request end timeInMillis {}:", endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("************************************************************************************************************************************* {}:" , "");
        }
        catch (Exception exe)
        {
            logger.error("uploadRetailerCSVDetails1() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        logger.info("uploadRetailerCSVDetails1() Response generated successful {}: ", "");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(path = "/v2/dashboard/upload-kpi")
    @Validated
    public ResponseEntity<Object> uploadKPICSVDetails_v2(@RequestParam("file") MultipartFile file)
    {
        try
        {
            startTime = System.currentTimeMillis();
            logger.info("Inside uploadKPICSVDetails_v2() method in FileUploadController class.. {}:", "");

            if (!file.isEmpty())
            {
                response = fileUploadService.kpiUploadDetailsv2(file);
            }
            else
            {
                logger.error("uploadKPICSVDetails_v2() method : {}", "File is empty");
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            logger.info("uploadKPICSVDetails_v2() Request end timeInMillis {}:", endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("************************************************************************************************************************************* {}:", "");

        }
        catch (Exception exe)
        {
            logger.error("uploadKPICSVDetails_v2() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        logger.info("uploadKPICSVDetails_v2() Response generated successful {}: ", "");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }



    @PostMapping(path = "/v2/file/upload")
    @Validated
    public ResponseEntity<Object> uploadPromoterCSVDetails(@RequestParam("file") MultipartFile file, @RequestParam("type") String type){
        try
        {
            String payload = httpServletRequest.getHeader("jwt_payload");
            org.json.JSONObject jsonPayload = new org.json.JSONObject(payload);
            String mobileNo = jsonPayload.getString("mobileno");

            startTime = System.currentTimeMillis();
            logger.info("Inside uploadPromoterCSVDetails() method in FileUploadController class.. {}:", "");

            if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNumeric(mobileNo) && !file.isEmpty())
            {
                response = fileUploadService.uploadPromoterCSVDetails(file, type,mobileNo);
            }
            else
            {
                logger.error("uploadPromoterCSVDetails() method : {}", "MobileNo blank/File Empty");
                response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            endTime = System.currentTimeMillis();
            logger.info("uploadPromoterCSVDetails() Request end timeInMillis {}:", endTime);
            elapsedTimeMillis = (endTime - startTime);
            commonUtil.convertMillis(elapsedTimeMillis);
            logger.info("************************************************************************************************************************************* {}:" , "");
        }
        catch (Exception exe)
        {
            logger.error("uploadPromoterCSVDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        logger.info("uploadPromoterCSVDetails() Response generated successful {}: ", "");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(path = "/v1/file/enquiry")
    @Validated
    public ResponseEntity<Object> enquirePromoterCSVDetails(@RequestBody FileEnquiryRequest request){
        try
        {
        		if(request!=null)
        			response = fileUploadService.enquirePromoterCSVDetails(request.getFileName());
            logger.info("************************************************************************************************************************************* {}:" , "");
        }
        catch (Exception exe)
        {
            logger.error("enquirePromoterCSVDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        logger.info("enquirePromoterCSVDetails() Response generated successful {}: ", "");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(path = "/v1/file/download")
    @Validated
    public ResponseEntity<Resource> download(@RequestBody FileEnquiryRequest request) throws IOException {

        Resource resource = null;
        try {
            if (request != null)
                resource = fileUploadService.downloadPromoterCSVDetails(request.getFileName());

        }
        catch (Exception exe)
        {
            logger.error("downloadPromoterCSVDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            commonUtil.exceptionHandler(prop, exe, response, json);
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+request.getFileName())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

}