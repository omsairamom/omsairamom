package com.airtelbank.admin.bean;

public class MarketVisitBean
{
    private String name;
    private String lapuId;
    private String assignedOutlets;
    private String date;
    private String retailerName;
    private String retailerLapuId;
    private String checkIn;
    private String checkInLat;
    private String checkInLong;
    private String checkOut;
    private String checkOutLat;
    private String checkOutLong;
    private String distanceVariation;

    public MarketVisitBean(String name, String lapuId, String assignedOutlets, String date, String retailerName, String retailerLapuId, String checkIn,
                           String checkInLat, String checkInLong, String checkOut, String checkOutLat, String checkOutLong, String DistanceVariation) {

        this.name = name;
        this.lapuId = lapuId;
        this.assignedOutlets = assignedOutlets;
        this.date = date;
        this.retailerName = retailerName;
        this.retailerLapuId = retailerLapuId;
        this.checkIn = checkIn;
        this.checkInLat = checkInLat;
        this.checkInLong = checkInLong;
        this.checkOut = checkOut;
        this.checkOutLat = checkOutLat;
        this.checkOutLong = checkOutLong;
        this.distanceVariation = DistanceVariation;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLapuId() {
        return lapuId;
    }

    public void setLapuId(String lapuId) {
        this.lapuId = lapuId;
    }

    public String getAssignedOutlets() {
        return assignedOutlets;
    }

    public void setAssignedOutlets(String assignedOutlets) {
        this.assignedOutlets = assignedOutlets;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRetailerName() {
        return retailerName;
    }

    public void setRetailerName(String retailerName) {
        this.retailerName = retailerName;
    }

    public String getRetailerLapuId() {
        return retailerLapuId;
    }

    public void setRetailerLapuId(String retailerLapuId) {
        this.retailerLapuId = retailerLapuId;
    }

    public String getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(String checkIn) {
        this.checkIn = checkIn;
    }

    public String getCheckInLat() {
        return checkInLat;
    }

    public void setCheckInLat(String checkInLat) {
        this.checkInLat = checkInLat;
    }

    public String getCheckInLong() {
        return checkInLong;
    }

    public void setCheckInLong(String checkInLong) {
        this.checkInLong = checkInLong;
    }

    public String getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(String checkOut) {
        this.checkOut = checkOut;
    }

    public String getCheckOutLat() {
        return checkOutLat;
    }

    public void setCheckOutLat(String checkOutLat) {
        this.checkOutLat = checkOutLat;
    }

    public String getCheckOutLong() {
        return checkOutLong;
    }

    public void setCheckOutLong(String checkOutLong) {
        this.checkOutLong = checkOutLong;
    }

    public String getDistanceVariation() {
        return distanceVariation;
    }

    public void setDistanceVariation(String distanceVariation) {
        this.distanceVariation = distanceVariation;
    }
}
