package com.airtelbank.admin.controller;

import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.entity.PromoterUserMSTEntity;
import com.airtelbank.admin.entity.PromoterUserProfileMSTEntity;
import com.airtelbank.admin.repository.PromoterUserMSTRepository;
import com.airtelbank.admin.repository.PromoterUserProfileMSTRepository;
import com.airtelbank.admin.service.AdminPortalLoginService;
import com.airtelbank.admin.util.CommonUtils;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.EncryptionUtil;
import com.airtelbank.admin.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*")
@RestController
public class AdminPortalLoginController
{
	private static Logger logger = LoggerFactory.getLogger(AdminPortalLoginController.class);

	@Autowired
	SnapWorkResponse response;

	@Autowired
	AdminPortalLoginService loginService;

	@Autowired
	PropertyManager prop;

	@Autowired
	CommonUtils commonUtil;

	@Autowired
	HttpServletRequest httpServletRequest;

	@Autowired
	private PromoterUserProfileMSTRepository promoterUserProfileMSTRepository;

	JSONObject json = new JSONObject();
	long startTime = 0;
	long endTime = 0;
	long elapsedTimeMillis = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();
	String rawPassword = "";
	String lineSpreator = "******************************************************** {}:";
	String encryptedPd = "******";

	@SuppressWarnings("unchecked")
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(path = "/v1/users/Login")
	public ResponseEntity<Object> adminLoginDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Admin Portal Login, Request start timeInMillis {}:", startTime);

			JSONParser parser = new JSONParser();
			JSONObject jsonResObj = (JSONObject) parser.parse(gson.toJson(request));
			String localPassword = (String) jsonResObj.get(Constants.password);
			rawPassword = localPassword.replace(localPassword, encryptedPd);
			jsonResObj.put(Constants.password, rawPassword);
			logger.info("Admin Portal Login, Request params  {}: ", jsonResObj);

			String userName = request.getUserName() == null ? "" : request.getUserName().trim();
			String password = request.getPassword() == null ? "" : request.getPassword().trim();

			if (StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(password))
			{
				response = loginService.adminLoginDetails(userName, password, request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator, "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/circle-master")
	public ResponseEntity<Object> fetchCircleMasterDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();

			String mobileNo = request.getUserName() == null ? "" : request.getUserName().trim();

			if (StringUtils.isNotBlank(mobileNo))
			{
				response = loginService.fetchCircleDetails(mobileNo, request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator, "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/dashboard/fetch-attendance")
	public ResponseEntity<Object> fetchDashboardAttendanceDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Fetch Attendance Details, Request start timeInMillis :{}", startTime);
			logger.info("Fetch Attendance Details, Request params :{}", gson.toJson(request));
			String circle = request.getCircleId().trim();
			String startDate = request.getStartDate().trim();
			String endDate = request.getEndDate().trim();

			if (StringUtils.isNotBlank(circle) && StringUtils.isNotBlank(startDate)
					&& StringUtils.isNotBlank(endDate))
			{
				response = loginService.dashboardAttendanceDetails(request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator ,"");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/reset-password")
	public ResponseEntity<Object> resetPasswordDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();

			JSONParser parser = new JSONParser();
			JSONObject jsonResObj = (JSONObject) parser.parse(gson.toJson(request));
			 rawPassword = (String) jsonResObj.get("password");
			rawPassword = rawPassword.replace(rawPassword, encryptedPd);
			jsonResObj.put("password", rawPassword);

			String userName = request.getUserName() == null ? "" : request.getUserName().trim();
			String password = request.getPassword() == null ? "" : request.getPassword().trim();

			if (StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(password))
			{
				response = loginService.resetPassword(userName, password, request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator, "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/send-otp")
	public ResponseEntity<Object> sendOTPDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();
			String mobileNo = request.getUserName() == null ? "" : request.getUserName().trim();

			if (StringUtils.isNotBlank(mobileNo))
			{
				response = loginService.sendOTP(mobileNo, request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator, "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/verify-otp")
	public ResponseEntity<Object> verifyOTPDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			if (request == null)
			{
				throw new Exception("request can't be null");
			}

			startTime = System.currentTimeMillis();
			logger.info("Admin Portal Verify OTP, Request start timeInMillis :{}", startTime);


			logger.info("Admin Portal Verify OTP, Request params {}:", gson.toJson(request));
			String mobileNo = request.getUserName().trim();
			String otp = request.getOtp().trim();
			String otpVerifCode = request.getOtpVerificationCode().trim();

			if (StringUtils.isNotBlank(mobileNo) && StringUtils.isNotBlank(otp)
					&& StringUtils.isNotBlank(otpVerifCode))
			{
				response = loginService.verifyOTP(mobileNo, otpVerifCode, otp, request);
			}
			else
			{
				response.setMessage(prop.getProperty("FAILURE_INVALID_REQUEST"));
				response.setStatusCode(prop.getProperty("FAILURE_STATUS_CODE"));
				response.setResponse(json);
			}

			logger.info("Admin Portal Verify OTP Details, Response {}:", gson.toJson(response));
			endTime = System.currentTimeMillis();
			logger.info("Admin Portal Verify OTP, Request end timeInMillis :{}", endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator, "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(value = "/v1/dashboard/download-attendance")
	public ResponseEntity<Object> downloadAttendanceDetails(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();
			logger.info("Download-Attendance Details, Request start timeInMillis {} :", startTime);
			logger.info("Download-Attendance Details, Request params {} :", gson.toJson(request));

			String circleId = request.getCircleId() == null ? "" : request.getCircleId().trim();
			String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
			String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();

			if(StringUtils.isNotBlank(circleId) && StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate))
			{
				loginService.downloadAttendance(circleId, startDate, endDate);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			logger.info("Download-Market Report Details, response {} :", gson.toJson(response));
			endTime = System.currentTimeMillis();
			logger.info("Download-Attendance Details, Request end timeInMillis {}:" , endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
		}
		catch (Exception exe)
		{
			CommonException.getPrintStackTrace(exe);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/logout")
	public ResponseEntity<Object> logOut(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			logger.info("userName {}:" ,request.getUserName());

			String payload = httpServletRequest.getHeader("jwt_payload");
			logger.info("jwt_payload logOut {}:" , payload);

			startTime = System.currentTimeMillis();
			String userName = request.getUserName() == null ? "" : request.getUserName().trim();

			if (StringUtils.isNotBlank(userName) && StringUtils.isNumeric(userName))
			{
				response = loginService.processLogOutRequest(userName);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			logger.info("Admin Portal Logout Request end timeInMillis {}:", endTime);
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator, "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(path = "/v1/users/refreshtoken")
	public ResponseEntity<Object> getToken(@Valid @RequestBody SnapWorkRequest request)
	{
		try
		{
			startTime = System.currentTimeMillis();

			if (StringUtils.isNotBlank(request.getMobileNo()))
			{
				response = loginService.isRefreshToKen(request);
			}
			else
			{
				response.setMessage(prop.getProperty(Constants.FAILURE_INVALID_REQUEST));
				response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
				response.setResponse(json);
			}

			endTime = System.currentTimeMillis();
			elapsedTimeMillis = (endTime - startTime);
			commonUtil.convertMillis(elapsedTimeMillis);
			logger.info(lineSpreator, "");
		}
		catch (Exception exe)
		{
			commonUtil.exceptionHandler(prop, exe, response, json);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}