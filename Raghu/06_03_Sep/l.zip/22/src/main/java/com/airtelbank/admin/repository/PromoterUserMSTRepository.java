package com.airtelbank.admin.repository;

import com.airtelbank.admin.entity.PromoterUserMSTEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PromoterUserMSTRepository extends JpaRepository<PromoterUserMSTEntity, Long> {

	public  PromoterUserMSTEntity findOneByUserNo(String userno);

}
