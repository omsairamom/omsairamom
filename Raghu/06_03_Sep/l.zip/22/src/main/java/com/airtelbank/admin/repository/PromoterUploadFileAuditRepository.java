package com.airtelbank.admin.repository;

import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PromoterUploadFileAuditRepository extends JpaRepository<PromoterUploadFileAuditEntity, Long> {



	public  PromoterUploadFileAuditEntity findOneByFileName(String name);

	
	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE PROMOTER_UPLOAD_FILE_AUDIT p SET p.status = :status WHERE p.id = :id", nativeQuery=true)
	public void updateFileStatus(@Param("status") String status, @Param("id") Long id);



    Optional<PromoterUploadFileAuditEntity> findByFileName(String fileName);

}
