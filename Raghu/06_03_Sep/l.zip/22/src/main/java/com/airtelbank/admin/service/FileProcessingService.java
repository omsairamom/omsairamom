package com.airtelbank.admin.service;


import com.airtelbank.admin.entity.PromoterUploadFileAuditEntity;

public interface FileProcessingService {
	
	void processFile(String filename, int type, PromoterUploadFileAuditEntity file) throws Exception;


}
