package com.airtelbank.admin.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.filters.SimplePatternFileListFilter;
import java.io.File;

@Configuration
@EnableIntegration
public class WhitelistFileListener {

    private static Logger logger = LoggerFactory.getLogger(WhitelistFileListener.class);

    @Value("${promoter.whitelist.file.input.directory.path}")
    private String promoterWhitelistFileDirectoryPath;
    private String FILE_PATTERN = "*.csv";

    @Autowired
    private WhitelistFileTransformer transformer;

    @Bean
    public IntegrationFlow whitelistIntegrationFlow(){
        logger.info("Inside whitelistIntegrationFlow() method in WhitelistFileListener class {}:" ,"");
        return IntegrationFlows.from(whitelistFileReadingMessageSource(),
                sourcePollingChannelAdapterSpec -> sourcePollingChannelAdapterSpec.poller(Pollers.fixedDelay(500)))
                .transform(transformer, "transform")
                .get();

    }

    @Bean
    public MessageSource<File> whitelistFileReadingMessageSource() {
        logger.info("Inside whitelistFileReadingMessageSource() method in WhitelistFileListener class {}:" ,"");
        FileReadingMessageSource sourceReader= new FileReadingMessageSource();
        sourceReader.setDirectory(new File(promoterWhitelistFileDirectoryPath));
        sourceReader.setFilter(new SimplePatternFileListFilter(FILE_PATTERN));
        sourceReader.setUseWatchService(true);
        sourceReader.setWatchEvents(FileReadingMessageSource.WatchEventType.CREATE);
        return sourceReader;
    }

//    @Bean
//    public MessageChannel fileChannel() {
//        return new DirectChannel();
//    }
//    @Bean
//    @InboundChannelAdapter(value = "fileChannel", poller = @Poller(fixedDelay = "1000"))
//    public MessageSource<File> fileReadingMessageSource() {
//        FileReadingMessageSource sourceReader= new FileReadingMessageSource();
//        sourceReader.setDirectory(new File(promoterWhitelistFileDirectoryPath));
//        sourceReader.setFilter(new SimplePatternFileListFilter(FILE_PATTERN));
//        sourceReader.setUseWatchService(true);
//        sourceReader.setWatchEvents(FileReadingMessageSource.WatchEventType.CREATE);
////        System.out.println(sourceReader.getScanner().listFiles());
//        return sourceReader;
//    }
//
//    @Bean
//    @ServiceActivator(inputChannel= "fileChannel")
//    public MessageHandler fileWritingMessageHandler() {
//        System.out.println("listner");
//        FileWritingMessageHandler handler = new FileWritingMessageHandler(new File(promoterOutletFileDirectoryPath));
//        handler.setFileExistsMode(FileExistsMode.REPLACE);
//        handler.setExpectReply(false);
//        return handler;
//    }

}