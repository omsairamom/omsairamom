package com.airtelbank.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;


@Getter
@Setter
@ToString
@Entity
@Table(name = "PROMOTER_UPLOAD_FILE_AUDIT",indexes =
{ 
		@Index(name = "IndexFileName",  columnList="fileName", unique = true),
		@Index(name = "IndexStatus",  columnList="status")
				
		})
@EntityListeners(AuditingEntityListener.class)
public class PromoterUploadFileAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(unique = true)
    @NotNull
    private String fileName;

    @Column
    @NotNull
    private String status;

    @Column
    private String author;

    @Column
    @NotNull
    private String type;

    @Column
    private String remark;

    @Column
    private String location;
 
    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdDate;

    @LastModifiedDate
    @Column
    private LocalDateTime updatedDate;
    
    @Column
    private String custom_field1;
    
    @Column
    private String custom_field2;
    
    @Column
    private String custom_field3;
    
    @Column
    private String custom_field4;
    
    @Column
    private String custom_field5;
    
    @Column
    private Integer totalRecords;
    
    @Column 
    private Integer processedRecords;
    
    @Column
    private Long processTime;
}
