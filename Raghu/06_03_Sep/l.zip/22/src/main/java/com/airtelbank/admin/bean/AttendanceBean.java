package com.airtelbank.admin.bean;

public class AttendanceBean
{
	private String name;
	private String mobileNo;
	private String date;
	private String outletVisited;
	private String distance;
	private String duration;

	public AttendanceBean(String name, String mobileNo, String date, String outletVisited, String distance,String duration)
	{
		this.name = name;
		this.mobileNo = mobileNo;
		this.date = date;
		this.outletVisited = outletVisited;
		this.distance = distance;
		this.duration = duration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getOutletVisited() {
		return outletVisited;
	}

	public void setOutletVisited(String outletVisited) {
		this.outletVisited = outletVisited;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

}
