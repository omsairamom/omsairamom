package com.airtelbank.admin.dao;

import com.airtelbank.admin.bean.AppVersionBean;
import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AppVersionDAO
{
	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	private final Logger logger = LoggerFactory.getLogger(AppVersionDAO.class.getClass());

	public int saveAppVersionDtls(SnapWorkRequest request, AppVersionBean obj) throws Exception
	{

		int row = 0;

		String action = request.getAction() == null ? "" : request.getAction().trim();

		if (action.equalsIgnoreCase("add"))
		{
			boolean isExist = isAppVersionDetailsExist(obj);
			if(!isExist) {

				final String INSERT_SQL = prop.getProperty(Constants.APPVER_SAVE_USERAGNT_DTLS);
				row = jdbctemplate.update(INSERT_SQL, obj.getUserAgent(),obj.getAppVersion(),obj.getMandatoryFlag(),obj.getLoadFlag(),
						obj.getUrl(),obj.getMessage());
			}
		}
		else if (action.equalsIgnoreCase("update"))
		{
			final String query = prop.getProperty(Constants.APPVER_UPDATE_USERAGNT_DTLS);
			row = jdbctemplate.update(query,
					obj.getAppVersion(),
					obj.getMandatoryFlag(),
					obj.getLoadFlag(),
					obj.getUrl(),
					obj.getMessage(),
					obj.getUserAgent());
		}
		logger.info("row {}:" ,row);

		return row;
	}

	public boolean isAppVersionDetailsExist(AppVersionBean obj) throws Exception
	{
		List<Map<String, Object>> rows = null;
		boolean falg = false ;
		String query = "";

		try
		{
			query = prop.getProperty(Constants.APPVER_CHECK_USERAGNT_DTLS_EXIST);
			rows = jdbctemplate.queryForList(query, obj.getUserAgent());

			if(rows != null && !rows.isEmpty() )
			{
				falg = true ;
			}
		}
		catch(Exception e)
		{
			CommonException.printStackTraceForDAO(e);
		}

		return falg;
	}

	public List<Map<String, Object>> fetchAppVersionDetails() throws Exception
	{
		List<Map<String, Object>> rows = null;

		String query = prop.getProperty(Constants.APPVER_FETCH_USERAGNT_DTLS);
		rows = jdbctemplate.queryForList(query);

		return rows;
	}
}