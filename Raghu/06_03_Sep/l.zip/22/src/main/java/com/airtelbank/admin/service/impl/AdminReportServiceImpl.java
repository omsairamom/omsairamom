package com.airtelbank.admin.service.impl;

import com.airtelbank.admin.bean.MarketVisitBean;
import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.airtelbank.admin.dao.AdminReportDAO;
import com.airtelbank.admin.service.AdminReportService;
import com.airtelbank.admin.util.*;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@SuppressWarnings("rawtypes")
public class AdminReportServiceImpl implements AdminReportService {
    private static final Logger logger = LoggerFactory.getLogger(AdminReportServiceImpl.class);

    @Autowired
    PropertyManager prop;

    @Autowired
    AdminReportDAO adminReportDAO;

    @Autowired
    SnapWorkResponse response;

    @Autowired
    SnapWorkRequest request;

    @Autowired
    CommonUtils commonUtil;

    private String[] CSV_HEADER;
    private  static final String MARKETVISITDTLSLOGGER = "dashboardMarketVisitDetails() method : {}";

    @Autowired
    SecureBuilderVer secureBuilderVer;

    @SuppressWarnings({"unchecked"})
    public SnapWorkResponse dashboardMarketVisitDetails(SnapWorkRequest request) {
        JSONObject json = new JSONObject();
        JSONArray jsonArray = new JSONArray();

        try {
            logger.info("Inside dashboardMarketVisitDetails() method in AdminReportServiceImpl class.. {}:", "");

            String roleName = request.getRoleName() == null ? "" : request.getRoleName().trim();
            String categoryId = request.getCategoryId() == null ? "" : request.getCategoryId().trim();
            String circleId = request.getCircleId() == null ? "" : request.getCircleId().trim();
            String zoneId = request.getZoneId() == null ? "" : request.getZoneId().trim();
            String startDate = request.getStartDate() == null ? "" : request.getStartDate().trim();
            String endDate = request.getEndDate() == null ? "" : request.getEndDate().trim();
            String userName = request.getUserName() == null ? "" : request.getUserName().trim();

            if (StringUtils.isNotBlank(startDate)) {
                List<Map<String, Object>> rows =
                        adminReportDAO.fetchMarketRoleDetails(categoryId, circleId, zoneId, roleName);
                logger.info("ADMIN_FETCH_MARKET_VISITED_DTLS_ALL rows.size() {}:", rows.size());

                if (!rows.isEmpty()) {
                    jsonArray = getMarketVisiterDetails(rows, roleName, startDate, endDate);

                    if (!jsonArray.isEmpty()) {
                        json.put("userName", userName);
                        json.put("marketVisitDetails", jsonArray);
                        response.setMessage(prop.getProperty(Constants.ADMIN_FETCH_MARKET_DTLS_SUCC_MSG));
                        response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                        response.setResponse(json);
                        logger.info("Success Response generated {}:", "");
                    } else {
                        logger.error(MARKETVISITDTLSLOGGER, "Market details Not fetched");
                        response.setMessage(prop.getProperty(Constants.MARKET_FETCH_DTLS_FAIL_MSG));
                        response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                        response.setResponse(json);
                    }
                } else {
                    logger.error(MARKETVISITDTLSLOGGER, "Rows empty");
                    response.setMessage(prop.getProperty(Constants.MARKET_FETCH_DTLS_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                    response.setResponse(json);
                }
            } else {
                logger.error(MARKETVISITDTLSLOGGER, "start date is blank");
                response.setMessage(prop.getProperty(Constants.MARKET_FETCH_DTLS_FAIL_MSG));
                response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
                response.setResponse(json);
            }

            logger.info("dashboardMarketVisitDetails() Response generated {}:", "");
            return response;
        } catch (Exception exe) {
            logger.error("dashboardMarketVisitDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
            response.setMessage(prop.getProperty(Constants.FAILURE_ERROR_MESSAGE));
            response.setStatusCode(prop.getProperty(Constants.FAILURE_STATUS_CODE));
            response.setResponse(json);
            return response;
        }
    }

    @SuppressWarnings("unchecked")
    private JSONArray getMarketVisiterDetails(List<Map<String, Object>> appRows, String roleName, String startDate, String endDate) {
        JSONArray jsonArray = new JSONArray();
        String checkInLatitude = "";
        String checkInLongitude = "";
        String dateOfVisit = "";
        String checkInTime = "";
        String displayDate = "";

        try {
            logger.info("Inside getMarketVisiterDetails() method in AdminReportServiceImpl class {}:", "");

            if (appRows != null && !appRows.isEmpty() && StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
                for (Map row : appRows) {
                    logger.info("getMarketVisiterDetails() appRows: {} for roleName: {}:", row, roleName);

                    String lapuNo = row.get("PROMTR_MOBNO") == null ? "" : row.get("PROMTR_MOBNO").toString();
                    String name = row.get("USER_NAME") == null ? "" : row.get("USER_NAME").toString();
                    String retailerNo = row.get("LAPU_NO") == null ? "" : row.get("LAPU_NO").toString();
                    String retailerName = adminReportDAO.fetchMarketVisitedRetailerDetails(retailerNo);
                    logger.info("ADMIN_FETCH_MARKET_VISITED_RETAILER_DTLS retailerName {}:", retailerName);

                    String assignedOutlets = String.valueOf(adminReportDAO.getOutletVisistedCount(roleName, lapuNo));
                    logger.info("DASHBOARD_FETCH_ASSIGNED_OUTLET_DTLS assignedOutlets {}:", assignedOutlets);

                    List<Map<String, Object>> rows = adminReportDAO.fetchMarketVisitedCheckInDetails(retailerNo, lapuNo, startDate, endDate);
                    logger.info("ADMIN_FETCH_MARKET_VISITED_CHECK_IN_DTLS rows.size() {}:", rows.size());

                    if (!rows.isEmpty()) {
                        JSONObject jsonObj = new JSONObject();

                        for (Map row2 : rows) {
                            logger.info("getMarketVisiterDetails() inOrOut :{}", row2);
                            String inOrOut = row2.get("IN_OR_OUT") == null ? "" : row2.get("IN_OR_OUT").toString();

                            if (inOrOut.equals("0")) {
                                List<Map<String, Object>> checkInrows = adminReportDAO.fetchCheckInDetails(retailerNo, lapuNo, startDate, endDate);
                                logger.info("ADMIN_FETCH_MARKET_VISITED_CHECK_IN checkInrows.size() {}:", checkInrows.size());

                                if (checkInrows != null && !checkInrows.isEmpty()) {
                                    for (Map<String, Object> row3 : checkInrows) {
                                        logger.info("getMarketVisiterDetails() checkInrows :{}", row3);
                                        checkInLatitude = row3.get(Constants.LATITUDE) == null ? "" : row3.get(Constants.LATITUDE).toString();
                                        checkInLongitude = row3.get(Constants.LONGITUDE) == null ? "" : row3.get(Constants.LONGITUDE).toString();
                                        dateOfVisit = row3.get(Constants.DATE_OF_VISIT) == null ? "" : row3.get(Constants.DATE_OF_VISIT).toString();
                                        displayDate = row3.get("DISP_DATE") == null ? "" : row3.get("DISP_DATE").toString();
                                        checkInTime = dateOfVisit;
                                        jsonObj.put(Constants.Check_In, checkInTime);
                                        jsonObj.put(Constants.Check_In_Lat, checkInLatitude);
                                        jsonObj.put(Constants.Check_In_Long, checkInLongitude);
                                        jsonObj.put(Constants.Date, displayDate);
                                    }
                                }
                            } else if (inOrOut.equals("1")) {

                                List<Map<String, Object>> checkOutrows = adminReportDAO.fetchCheckOutDetails(retailerNo, lapuNo, startDate, endDate);
                                logger.info("ADMIN_FETCH_MARKET_VISITED_CHECK_OUT checkOutrows.size() {}:", checkOutrows.size());

                                if (checkOutrows != null && !checkOutrows.isEmpty()) {
                                    for (Map row4 : checkOutrows) {
                                        logger.info("getMarketVisiterDetails() checkOutrows :{}", row4);
                                        checkInLatitude = row4.get(Constants.LATITUDE) == null ? "" : row4.get(Constants.LATITUDE).toString();
                                        checkInLongitude = row4.get(Constants.LONGITUDE) == null ? "" : row4.get(Constants.LONGITUDE).toString();
                                        dateOfVisit = row4.get(Constants.DATE_OF_VISIT) == null ? "" : row4.get(Constants.DATE_OF_VISIT).toString();
                                        checkInTime = dateOfVisit;
                                        jsonObj.put(Constants.Check_Out, checkInTime);
                                        jsonObj.put(Constants.Check_Out_Lat, checkInLatitude);
                                        jsonObj.put(Constants.Check_Out_Long, checkInLongitude);
                                    }
                                }
                            }

                            jsonObj.put(Constants.Name, name);
                            jsonObj.put(Constants.LapuId, lapuNo);
                            jsonObj.put(Constants.Retailer_Name, retailerName);
                            jsonObj.put(Constants.Retailer_LapuId, retailerNo);
                            jsonObj.put(Constants.Assigned_Outlets, assignedOutlets);
                        }

                        String distance = String.valueOf(calculateDistance(displayDate, lapuNo, retailerNo));

                        if (StringUtils.isBlank(distance)) {
                            distance = "0";
                        }

                        jsonObj.put(Constants.Distance, distance);
                        jsonArray.add(jsonObj);
                    }
                }
            }

        } catch (Exception exe) {
            logger.error("getMarketVisiterDetails() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }
        logger.info("getMarketVisiterDetails() Response generated : {} for roleName: {}:", "", roleName);
        return jsonArray;
    }

    private String calculateDistance(String displayDate, String mobileNo, String retailerNo) throws Exception {
        CommonUtils commonUtils = new CommonUtils();
        double totalDistance = 0;
        String distance = "";
        DecimalFormat decimalFormat = new DecimalFormat("0.00");

        List<Map<String, Object>> rows = adminReportDAO.getLatLongDtls(displayDate, mobileNo, retailerNo);
        logger.info("ADMIN_FETCH_MARKET_VISITED_LAT_LONG rows.size() : {} for mobileNo: {}:", rows.size(), mobileNo);

        if (!rows.isEmpty()) {
            for (Map<String, Object> row : rows) {
                logger.info("calculateDistance() setting lat/longitude : {} for mobileNo: {}:", row, mobileNo);

                String retailerLatitude = row.get("LATITUDE").toString();
                String retailerLongitude = row.get("LONGITUDE").toString();

                String promoterLatitude = row.get("PROMOTER_LATITUDE").toString();
                String promoterLongitude = row.get("PROMOTER_LONGITUDE").toString();

                totalDistance = commonUtils.calculateMarketDistance(retailerLatitude, promoterLatitude,
                        retailerLongitude, promoterLongitude);

                distance = decimalFormat.format(totalDistance);

                logger.info("distance : {} for mobileNo: {}:", distance, mobileNo);
            }
        }
        logger.info("calculateDistance() Response generated : {} for mobileNo: {}:", "", mobileNo);
        return distance;
    }

    @Override
    public SnapWorkResponse downloadMarketVisit(String roleName, String categoryId, String circleId, String zoneId, String startDate, String endDate) throws CustomException {

        JSONObject json = new JSONObject();
        StringBuilder data = new StringBuilder();

        try {
            logger.info("Inside downloadMarketVisit() method in AdminReportServiceImpl class.. {}:", "");

            CSV_HEADER = new String[]{"Name", "LAPUID", "AssignedOutlets", "Date", "RetailerName", "RetailerLAPUID", "CheckIn", "CheckInLAT", "CheckInLong", "CheckOut", "CheckOutLAT", "CheckOutLong", "DistanceVariation"};

            for (int i = 0; i < CSV_HEADER.length; i++) {
                data = data.append(CSV_HEADER[i]);

                if (CSV_HEADER.length - 1 == i) {
                    data = data.append("\n");
                } else {
                    data = data.append(",");
                }
            }


            List<MarketVisitBean> getMarketVisitList = getMarketVisitList(categoryId, roleName, circleId, zoneId, startDate, endDate);
            logger.info("getMarketVisitList.size() {}:", getMarketVisitList.size());

            if (getMarketVisitList.isEmpty()) {
                data = data.append(" ");
            } else {
                for (MarketVisitBean ob : getMarketVisitList) {
                    String name = ob.getName();
                    String lapuId = ob.getLapuId();
                    String assignedOutlets = ob.getAssignedOutlets();
                    String date = ob.getDate();
                    String retailerName = ob.getRetailerName();

                    String retailerLapuId = ob.getRetailerLapuId();
                    String checkIn = ob.getCheckIn();
                    String checkInLat = ob.getCheckInLat();
                    String checkInLong = ob.getCheckInLong();

                    String checkOut = ob.getCheckOut();
                    String checkOutLat = ob.getCheckOutLat();
                    String checkOutLong = ob.getCheckOutLong();
                    String distance = ob.getDistanceVariation();

                    data = data.append(name).append(",");
                    data = data.append(lapuId).append(",");
                    data = data.append(assignedOutlets).append(",");
                    data = data.append(date).append(",");
                    data = data.append(retailerName).append(",");
                    data = data.append(retailerLapuId).append(",");
                    data = data.append(checkIn).append(",");
                    data = data.append(checkInLat).append(",");
                    data = data.append(checkInLong).append(",");
                    data = data.append(checkOut).append(",");
                    data = data.append(checkOutLat).append(",");
                    data = data.append(checkOutLong).append(",");
                    data = data.append(distance).append("\n");

                }
            }

            json.put("data", data);
            response.setMessage("Download market details fetched successfully");
            response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
            response.setResponse(json);
            logger.info("Success Response generated {}:", "");
        } catch (Exception exe) {
            logger.error("downloadMarketVisit() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }
        logger.info("downloadMarketVisit() Response generated {}:", "");
        return response;
    }

    public List<MarketVisitBean> getMarketVisitList(String categoryId, String roleName, String circleId, String zoneId, String startDate, String endDate) {
        JSONObject json = new JSONObject();
        List<MarketVisitBean> users = new ArrayList<>();

        try {
            logger.info("Inside of getMarketVisitList() method in AdminReportServiceImpl class {}:", "");
            logger.info("startDate {}:", startDate);
            logger.info("endDate {}:", endDate);

            if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {

                List<Map<String, Object>> rows = adminReportDAO.fetchMarketRoleDetails(categoryId, circleId, zoneId, roleName);
                logger.info("ADMIN_FETCH_MARKET_VISITED_DTLS_ALL rows.size(): {} for categoryId: {}:", rows.size(), categoryId);

                if (rows != null && !rows.isEmpty()) {
                    JSONArray jsonArray = getMarketVisiterDetails(rows, roleName, startDate, endDate);

                    for (int i = 0; i < jsonArray.size(); i++) {

                        JSONObject ob = (JSONObject) jsonArray.get(i);

                        String name = ob.get("Name") == null ? "" : ob.get("Name").toString();
                        String lapuId = ob.get("LapuId") == null ? "" : ob.get("LapuId").toString();
                        String assignedOutlets = ob.get("Assigned_Outlets") == null ? "" : ob.get("Assigned_Outlets").toString();
                        String date = ob.get("Date") == null ? "" : ob.get("Date").toString();
                        String retailerName = ob.get("Retailer_Name") == null ? "" : ob.get("Retailer_Name").toString();

                        String retailerLapuId = ob.get("Retailer_LapuId") == null ? "" : ob.get("Retailer_LapuId").toString();
                        String checkIn = ob.get("Check_In") == null ? "" : ob.get("Check_In").toString();
                        String checkInLat = ob.get("Check_In_Lat") == null ? "" : ob.get("Check_In_Lat").toString();
                        String checkInLong = ob.get("Check_In_Long") == null ? "" : ob.get("Check_In_Long").toString();

                        String checkOut = ob.get("Check_Out") == null ? "" : ob.get("Check_Out").toString();
                        String checkOutLat = ob.get("Check_Out_Lat") == null ? "" : ob.get("Check_Out_Lat").toString();
                        String checkOutLong = ob.get("Check_Out_Long") == null ? "" : ob.get("Check_Out_Long").toString();
                        String distance = ob.get("Distance") == null ? "" : ob.get("Distance").toString();

                        users.add(new MarketVisitBean(name, lapuId, assignedOutlets, date, retailerName, retailerLapuId, checkIn, checkInLat, checkInLong, checkOut, checkOutLat, checkOutLong, distance));
                    }
                } else {
                    logger.info("getMarketVisitList() Market fecth details failed: {} for categoryId: {}:", "", categoryId);
                    response.setMessage(prop.getProperty(Constants.MARKET_FETCH_DTLS_FAIL_MSG));
                    response.setStatusCode(prop.getProperty(Constants.SUCCESS_STATUS_CODE));
                    response.setResponse(json);
                    logger.info("Success Response generated: {} for categoryId: {}:", "", categoryId);
                }
            }
        } catch (Exception exe) {
            logger.error("getMarketVisitList() Internal Exception {}, {}:", exe.getMessage(), exe.getCause());
            CommonException.getPrintStackTrace(exe);
        }

        logger.info("getMarketVisitList() Response generated: {} for categoryId: {}:", "", categoryId);
        return users;
    }


}