package com.airtelbank.admin.bean;

public class KpiDetailsMaterBean
{
    private String kpiType;
    private String kpiDesc;
    private String sqlQuery;
    private String kpiUpdatedBy;

    public String getKpiType() {
        return kpiType;
    }

    public void setKpiType(String kpiType) {
        this.kpiType = kpiType;
    }

    public String getKpiDesc() {
        return kpiDesc;
    }

    public void setKpiDesc(String kpiDesc) {
        this.kpiDesc = kpiDesc;
    }

    public String getSqlQuery() {
        return sqlQuery;
    }

    public void setSqlQuery(String sqlQuery) {
        this.sqlQuery = sqlQuery;
    }

    public String getKpiUpdatedBy() {
        return kpiUpdatedBy;
    }

    public void setKpiUpdatedBy(String kpiUpdatedBy) {
        this.kpiUpdatedBy = kpiUpdatedBy;
    }
}
