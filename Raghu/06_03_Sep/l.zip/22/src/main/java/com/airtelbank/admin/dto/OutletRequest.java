package com.airtelbank.admin.dto;

public class OutletRequest {
	
	
	 private String outletPhoneNumber;
	 private String outletName;
	 private String outletType;
	
	 private String promoterPhoneNumber;
	 private String action;
	 
	public String getOutletPhoneNumber() {
		return outletPhoneNumber;
	}
	public void setOutletPhoneNumber(String outletPhoneNumber) {
		this.outletPhoneNumber = outletPhoneNumber;
	}
	public String getOutletName() {
		return outletName;
	}
	public void setOutletName(String outletName) {
		this.outletName = outletName;
	}
	public String getOutletType() {
		return outletType;
	}
	public void setOutletType(String outletType) {
		this.outletType = outletType;
	}
	
	
	public String getPromoterPhoneNumber() {
		return promoterPhoneNumber;
	}
	public void setPromoterPhoneNumber(String promoterPhoneNumber) {
		this.promoterPhoneNumber = promoterPhoneNumber;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	
	@Override
	public String toString() {
			return "OutletRequest [outletPhoneNumber=" + outletPhoneNumber + ", outletName=" + outletName + ", outletType="
					+ outletType + ", siteId="  + ", circleId=" + ", promoterPhoneNumber="
					+ promoterPhoneNumber + ", action=" + action + "]";
		}
	 

}
