package com.airtelbank.admin.dao;

import com.airtelbank.admin.util.Constants;
import com.airtelbank.admin.util.PropertyManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GeoFencingDAO {

	@Autowired
	JdbcTemplate jdbctemplate;

	@Autowired
	PropertyManager prop;

	public List<Map<String, Object>> getCircleMasterDetails() throws Exception
	{
		List<Map<String, Object>> rows = null;

		String query = prop.getProperty(Constants.ADMIN_FETCH_CIRCLE_MST_DTLS);
		rows = jdbctemplate.queryForList(query);

		return rows;
	}

	public List<Map<String, Object>> getCategoryMasterDetails() throws Exception
	{
		List<Map<String, Object>> rows = null;

		String query = prop.getProperty(Constants.GEO_FETCH_CATEGORY_MST_DTLS);
		rows = jdbctemplate.queryForList(query);

		return rows;
	}

	public List<Map<String, Object>> getZoneMasterDetails() throws Exception
	{
		List<Map<String, Object>> rows = null;

		String query = prop.getProperty(Constants.GEO_FETCH_ZONE_MST_DTLS);
		rows = jdbctemplate.queryForList(query);

		return rows;
	}

	public List<Map<String, Object>> getRoleMasterDetails() throws Exception
	{
		List<Map<String, Object>> rows = null;

		String query = prop.getProperty(Constants.DASHBOARD_FETCH_ROLE_MST_DTLS);
		rows = jdbctemplate.queryForList(query);

		return rows;
	}
}