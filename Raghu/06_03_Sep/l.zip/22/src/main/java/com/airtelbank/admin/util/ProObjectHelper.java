package com.airtelbank.admin.util;


import com.airtelbank.admin.entity.PromoterLoginTrackerAuditEntity;

public class ProObjectHelper
{

    public static PromoterLoginTrackerAuditEntity getObjForLogInOutTracker(String mobileNo, String latitude,
                                                             String longitude, String loginType, String udid, String channel)
    {
        PromoterLoginTrackerAuditEntity promoterLoginTrackerAuditEntity =
                new PromoterLoginTrackerAuditEntity();
        promoterLoginTrackerAuditEntity.setUserNo(mobileNo);
        promoterLoginTrackerAuditEntity.setLatitude(latitude);
        promoterLoginTrackerAuditEntity.setLongitude(longitude);
        promoterLoginTrackerAuditEntity.setLogInType(loginType);
        promoterLoginTrackerAuditEntity.setDeviceId(udid);
        promoterLoginTrackerAuditEntity.setChannel(channel);
        promoterLoginTrackerAuditEntity.setCustom_field1("NA");
        promoterLoginTrackerAuditEntity.setCustom_field2("NA");
        promoterLoginTrackerAuditEntity.setCustom_field3("NA");
        promoterLoginTrackerAuditEntity.setCustom_field4("NA");
        promoterLoginTrackerAuditEntity.setCustom_field5("NA");

        return promoterLoginTrackerAuditEntity;
    }
}
