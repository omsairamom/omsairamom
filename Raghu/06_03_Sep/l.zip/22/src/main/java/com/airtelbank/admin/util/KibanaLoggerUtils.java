package com.airtelbank.admin.util;

import com.airtelbank.admin.bean.KibanaLoggerBean;
import com.airtelbank.admin.common.CommonException;
import com.airtelbank.admin.common.SnapWorkRequest;
import com.airtelbank.admin.common.SnapWorkResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Ayush Saxena
 * @Company HCL Technologies Pvt Ltd.
 * @Date Apr 11, 2021 11:04:45 AM
 */
@Service
public class KibanaLoggerUtils
{
	@Autowired
	HttpServletRequest httpServletRequest;
	
	@Value("${kibana.log.message.separator}")
	private String separator;
	
	public static Logger kibanaLogger = LoggerFactory.getLogger("kibanaLogger");
	private static Logger logger = LoggerFactory.getLogger(KibanaLoggerUtils.class);
	
	GsonBuilder gsonBuilder = new GsonBuilder();
	Gson gson = gsonBuilder.create();
	
	@SuppressWarnings("unchecked")
	public void saveAdminWebKibanaLoggers(SnapWorkRequest request,SnapWorkResponse response,long totalTime,String apiName)
	{
		try
		{
			logger.info("Inside saveAdminWebKibanaLoggers() method in AdminPortalLoginServiceImpl class.....");

			JSONObject jsonReqObj = null;
			KibanaLoggerBean obj = new KibanaLoggerBean();


			if (request != null)
			{
				String requestString = new Gson().toJson(request);
				jsonReqObj = new JSONObject(requestString);

				if (jsonReqObj.has("password"))
				{
					String password = (String) jsonReqObj.optString("password");
					password = password.replace(password, "******");
					jsonReqObj.put("password", password);
				}
				if (jsonReqObj.has("otp"))
				{
					String otp = (String) jsonReqObj.optString("otp");
					otp = otp.replace(otp, "******");
					jsonReqObj.put("otp", otp);
				}
				
				String mobileNo="";
				String payload = httpServletRequest.getHeader("jwt_payload");
				if(payload != null) {
				 org.json.JSONObject jsonPayload = new org.json.JSONObject(payload);
	             mobileNo = jsonPayload.getString("mobileno");
				}
				//obj.setCustMobileNo(request.getMobileNo());
				obj.setCustMobileNo(mobileNo);
				
				
				//obj.setId1(request.getUserName());
				//obj.setId2(request.getMobileNo());
				//obj.setId3(request.getCategoryId());
				//obj.setId4(request.getAction());
				//obj.setId5(request.getRoleId());
				//obj.setId6(request.getChannel());
				obj.setRequest(jsonReqObj);
				obj.setServiceid(apiName == null ? "" : apiName);
				obj.setResponse(gson.toJson(response));
			}

			SimpleDateFormat dtf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			Date date = cal.getTime();
			String currentDate = dtf.format(date);

			obj.setServiceid(apiName == null ? "" : apiName);
//			obj.setApiId("");
//
//			obj.setContentId("");
//			obj.setTranId("");
//			obj.setAmount("");
//
//			obj.setId7("");
//			obj.setId8("");
//			obj.setId9("");
//			obj.setId10("");
//			obj.setNumber1("");
//			obj.setNumber2("");
//			obj.setNumber3("");
			obj.setDate1(currentDate);
		//	obj.setDate2("");
			obj.setResponse(gson.toJson(response));
			obj.setHttpStatus("0");
			obj.setRespCode(response.getStatusCode());
			obj.setRespMsg(response.getMessage());
			obj.setTotalTime(totalTime);
			obj.setHttpStatus(response.getStatus());
			obj.setExpMsg(response.getExpMsg());
			obj.setExpCause(response.getExpCause());
			obj.setExpLocalMsg(response.getExpLocalMsg());

			printKibanaLogs(obj);
			logger.info("Admin Kibana logs generated Successful..{}:" , apiName);
		}
		catch (Exception exe)
		{
			logger.error("Exception occured in KibanaLoggerUtils {}:", apiName);
			CommonException.getPrintStackTrace(exe);
		}
	}
	
	public void printKibanaLogs(KibanaLoggerBean obj)
	{
		String message = "";
		
		try
		{
			message = 
					            obj.getServiceid() +
					separator + obj.getApiId() +
					separator + obj.getCustMobileNo() +
					separator + obj.getLatitude()+
					separator+  obj.getLongitude()+
					separator+  obj.getContentId()+
					separator + obj.getTranId() +
					separator + obj.getAmount() + 
					separator + obj.getId1()+
					separator + obj.getId2() +
					separator + obj.getId3()+
					separator + obj.getId4() + 
					separator + obj.getId5() + 
					separator + obj.getId6() +
					separator + obj.getId7() +
					separator + obj.getId8() +
					separator + obj.getId9() + 
					separator + obj.getId10() +
					separator + obj.getNumber1() + 
					separator + obj.getNumber2() + 
					separator + obj.getNumber3()+
					separator + obj.getDate1() + 
					separator + obj.getDate2() + 
					separator + obj.getRequest() + 
					separator + obj.getResponse() + 
					separator+  obj.getRespMsg()+
					separator+  obj.getRespDesc()+
					separator + obj.getHttpStatus() + 
					separator + obj.getRespCode() + 
					separator+  obj.getExpMsg() + 
					separator+  obj.getExpCause() +
					separator+  obj.getExpLocalMsg()+
					separator+  obj.getTotalTime();

			kibanaLogger.info(message);
		}
		catch (Exception exe)
		{
			logger.error("Exception in Print Kibana Logs {}:");
			CommonException.getPrintStackTrace(exe);
		}
	}
}
