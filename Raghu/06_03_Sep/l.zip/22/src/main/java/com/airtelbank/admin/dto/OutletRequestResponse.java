package com.airtelbank.admin.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class OutletRequestResponse {

	 @CsvBindByName(column = "OutletNo")
	 @CsvBindByPosition(position = 0)
	 private String outletPhoneNumber;
	 
	 @CsvBindByName(column = "OName")
	 @CsvBindByPosition(position = 1)
	 private String outletName;
	 
	 @CsvBindByName(column = "OType")
	 @CsvBindByPosition(position = 2)
	 private String outletType;
	 	 	 
	 @CsvBindByName(column = "PromoterNo")
	 @CsvBindByPosition(position = 3)
	 private String promoterPhoneNumber;
	 
	 @CsvBindByName(column = "Action")
	 @CsvBindByPosition(position = 4)
	 private String action;
	 
	 @CsvBindByName(column = "Remarks")
	 @CsvBindByPosition(position = 5)
	 private String remarks;
	 
	public String getOutletPhoneNumber() {
		return outletPhoneNumber;
	}
	public void setOutletPhoneNumber(String outletPhoneNumber) {
		this.outletPhoneNumber = outletPhoneNumber;
	}
	public String getOutletName() {
		return outletName;
	}
	public void setOutletName(String outletName) {
		this.outletName = outletName;
	}
	public String getOutletType() {
		return outletType;
	}
	public void setOutletType(String outletType) {
		this.outletType = outletType;
	}
	
	public String getPromoterPhoneNumber() {
		return promoterPhoneNumber;
	}
	public void setPromoterPhoneNumber(String promoterPhoneNumber) {
		this.promoterPhoneNumber = promoterPhoneNumber;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
