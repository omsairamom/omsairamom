package com.airtelbank.admin.bean;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class RetailerDetailsBean
{
    private String retailerNo;
    private String retailerName;
    private String outletType;
    private String longitude;
    private String latitude;
    private String villageName;
    private String villagesType;
    private String villagePop;
    private String city;
    private String blockTehsil;
    private String district;
    private String siteId;
    private String category;

    public String getOutletType() {
        return outletType;
    }

    public void setOutletType(String outletType) {
        this.outletType = outletType;
    }

    public String getRetailerNo() {
        return retailerNo;
    }

    public void setRetailerNo(String retailerNo) {
        this.retailerNo = retailerNo;
    }

    public String getRetailerName() {
        return retailerName;
    }

    public void setRetailerName(String retailerName) {
        this.retailerName = retailerName;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getVillagesType() {
        return villagesType;
    }

    public void setVillagesType(String villagesType) {
        this.villagesType = villagesType;
    }

    public String getVillagePop() {
        return villagePop;
    }

    public void setVillagePop(String villagePop) {
        this.villagePop = villagePop;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getBlockTehsil() {
        return blockTehsil;
    }

    public void setBlockTehsil(String blockTehsil) {
        this.blockTehsil = blockTehsil;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
